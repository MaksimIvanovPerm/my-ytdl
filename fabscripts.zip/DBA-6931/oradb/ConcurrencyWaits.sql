select *
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='Concurrency'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'logout restrictor' as logoutrestrictor,
'Shared IO Pool Memory' as SharedIOPoolMemory,
'latch: cache buffers chains' as latchcachebufferschains,
'buffer busy waits' as bufferbusywaits,
'db flash cache invalidate wait' as dbflashcacheinvalidatewait,
'log file sync: SCN ordering' as logfilesyncSCNordering,
'enq: TX - index contention' as enqTXindexcontention,
'latch: Undo Hint Latch' as latchUndoHintLatch,
'latch: In memory undo latch' as latchInmemoryundolatch,
'latch: MQL Tracking Latch' as latchMQLTrackingLatch,
'IM buffer busy' as IMbufferbusy,
'securefile chain update' as securefilechainupdate,
'enq: HV - contention' as enqHVcontention,
'SecureFile mutex' as SecureFilemutex,
'enq: WG - lock fso' as enqWGlockfso,
'Inmemory Populate: get loadscn' as InmemoryPopulategetloadscn,
'latch: row cache objects' as latchrowcacheobjects,
'row cache lock' as rowcachelock,
'row cache read' as rowcacheread,
'libcache interrupt action by LCK' as libcacheinterruptactionbyLCK,
'cursor: mutex X' as cursormutexX,
'cursor: mutex S' as cursormutexS,
'cursor: pin X' as cursorpinX,
'cursor: pin S' as cursorpinS,
'cursor: pin S wait on X' as cursorpinSwaitonX,
'enq: CB - role operation' as enqCBroleoperation,
'latch: shared pool' as latchsharedpool,
'LCK0 row cache object free' as LCK0rowcacheobjectfree,
'library cache pin' as librarycachepin,
'library cache lock' as librarycachelock,
'library cache load lock' as librarycacheloadlock,
'library cache: mutex X' as librarycachemutexX,
'library cache: mutex S' as librarycachemutexS,
'resmgr:internal state change' as resmgrinternalstatechange,
'resmgr:sessions to exit' as resmgrsessionstoexit,
'pipe put' as pipeput,
'REPL Apply: dependency' as REPLApplydependency,
'Cube Build Master Wait for Jobs' as CubeBuildMasterWaitforJobs
)
    )
order by snap_id
