SELECT v1.snap_time as snap_tim, 
       v1.snap_id*1 as snap_id,
       v2.proc_amount*1 as processes_amount,
       v2.proc_limit*1 as processes_limit,
       v1.sess_amount*1 as sessions_amount, 
       v1.sess_limit*1 as sessions_limit
FROM (
select  to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24.mi') as snap_time,
        s.snap_id,
        T.CURRENT_UTILIZATION AS sess_amount,
        T.LIMIT_VALUE AS sess_limit
from sys.WRH$_RESOURCE_LIMIT t, sys.WRM$_SNAPSHOT s
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and t.DBID=S.DBID and t.INSTANCE_NUMBER=S.INSTANCE_NUMBER and t.SNAP_ID=S.SNAP_ID
  and T.RESOURCE_NAME ='sessions' ) v1,
(select  to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24.mi') as snap_time,
        s.snap_id,
        T.CURRENT_UTILIZATION AS proc_amount,
        T.LIMIT_VALUE AS proc_limit
from sys.WRH$_RESOURCE_LIMIT t, sys.WRM$_SNAPSHOT s
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and t.DBID=S.DBID and t.INSTANCE_NUMBER=S.INSTANCE_NUMBER and t.SNAP_ID=S.SNAP_ID
  and T.RESOURCE_NAME ='processes' ) v2
WHERE v2.snap_id=v1.snap_id
ORDER BY v1.snap_id
