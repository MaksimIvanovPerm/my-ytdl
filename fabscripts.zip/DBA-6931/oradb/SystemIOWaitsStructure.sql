select *
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='System I/O'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'Clonedb bitmap file write' as Clonedbbitmapfilewrite,
'Log archive I/O' as LogarchiveIO,
'RMAN backup & recovery I/O' as RMANbackupRecoveryIO,
'Standby redo I/O' as StandbyredoIO,
'Network file transfer' as Networkfiletransfer,
'io done' as iodone,
'RMAN Disk slave I/O' as RMANDiskslaveIO,
'RMAN Tape slave I/O' as RMANTapeslaveIO,
'DBWR slave I/O' as DBWRslaveIO,
'LGWR slave I/O' as LGWRslaveIO,
'Archiver slave I/O' as ArchiverslaveIO,
'control file sequential read' as controlfilesequentialread,
'control file single write' as controlfilesinglewrite,
'control file parallel write' as controlfileparallelwrite,
'recovery read' as recoveryread,
'RFS sequential i/o' as RFSsequentialio,
'RFS random i/o' as RFSrandomio,
'RFS write' as RFSwrite,
'log file sequential read' as logfilesequentialread,
'log file single write' as logfilesinglewrite,
'log file parallel write' as logfileparallelwrite,
'db file parallel write' as dbfileparallelwrite,
'db file async I/O submit' as dbfileasyncIOsubmit,
'flashback log file write' as flashbacklogfilewrite,
'flashback log file read' as flashbacklogfileread,
'cell smart incremental backup' as cellsmartincrementalbackup,
'cell smart restore from backup' as cellsmartrestorefrombackup,
'kfk: async disk IO' as kfkasyncdiskIO,
'cell manager opening cell' as cellmanageropeningcell,
'cell manager closing cell' as cellmanagerclosingcell,
'cell manager discovering disks' as cellmanagerdiscoveringdisks
)
    )
order by snap_id
