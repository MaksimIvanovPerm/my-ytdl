select * from (with local_data as (select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
                                          S.SNAP_ID                                           as snap_id,
                                          SE.EVENT_NAME                                       as stat_name,
                                          sum(SE.TIME_WAITED_MICRO)                           as stat_value
                                     from WRM$_SNAPSHOT         s,
                                          DBA_HIST_SYSTEM_EVENT se
                                     where s.dbid            = :v_dbid
                                       and S.INSTANCE_NUMBER = 1
                                       and S.DBID            = se.dbid
                                       and S.INSTANCE_NUMBER = SE.INSTANCE_NUMBER
                                       and s.snap_id         = se.snap_id
                                       and S.SNAP_ID between :v_begin_snap
                                                         and :v_end_snap
                                       and SE.EVENT_NAME in ('remote db operation',
                                                             'remote db file read',
                                                             'remote db file write',
                                                             'ARCH wait for net re-connect',
                                                             'LGWR wait on ATTACH',
                                                             'ARCH wait on ATTACH',
                                                             'ARCH wait for netserver start',
                                                             'LNS wait on ATTACH',
                                                             'LNS wait on SENDREQ',
                                                             'LNS wait on DETACH',
                                                             'LGWR wait on SENDREQ',
                                                             'LGWR wait on DETACH',
                                                             'ARCH wait on SENDREQ',
                                                             'ARCH wait on DETACH',
                                                             'ARCH wait for netserver init 2',
                                                             'LNS wait on LGWR',
                                                             'LGWR wait on LNS',
                                                             'ARCH wait for flow-control',
                                                             'ARCH wait for netserver detach',
                                                             'TCP Socket (KGAS)',
                                                             'virtual circuit wait',
                                                             'dispatcher listen timer',
                                                             'dedicated server timer',
                                                             'SQL*Net message to client',
                                                             'SQL*Net message to dblink',
                                                             'SQL*Net more data to client',
                                                             'SQL*Net more data to dblink',
                                                             'SQL*Net more data from client',
                                                             'SQL*Net message from dblink',
                                                             'SQL*Net more data from dblink',
                                                             'SQL*Net vector data to client',
                                                             'SQL*Net vector data from client',
                                                             'SQL*Net vector data to dblink',
                                                             'SQL*Net vector data from dblink',
                                                             'TEXT: URL_DATASTORE network wait')
                                     group by S.BEGIN_INTERVAL_TIME,
                                              S.SNAP_ID,
                                              SE.EVENT_NAME),
                    b          as ( select * from local_data ),
                    e          as ( select * from local_data )
  select e.snap_time as snap_time,
         e.snap_id   as snap_id,
         e.stat_name as stat_name,
         case when (e.stat_value - b.stat_value) < 0
           then null
           else (e.stat_value - b.stat_value)
           end       as value_diff
    from b,
         e
    where e.snap_id   = (b.snap_id + 1)
      and e.stat_name = b.stat_name
              ) v
pivot (max(value_diff) for stat_name in (
'remote db operation'              as remote_db_operation,
'remote db file read'              as remote_db_file_read,
'remote db file write'             as remote_db_file_write,
'ARCH wait for net re-connect'     as ARCH_wait_for_net_re_connect,
'LGWR wait on ATTACH'              as LGWR_wait_on_ATTACH,
'ARCH wait on ATTACH'              as ARCH_wait_on_ATTACH,
'ARCH wait for netserver start'    as ARCH_wait_for_netserver_start,
'LNS wait on ATTACH'               as LNS_wait_on_ATTACH,
'LNS wait on SENDREQ'              as LNS_wait_on_SENDREQ,
'LNS wait on DETACH'               as LNS_wait_on_DETACH,
'LGWR wait on SENDREQ'             as LGWR_wait_on_SENDREQ,
'LGWR wait on DETACH'              as LGWR_wait_on_DETACH,
'ARCH wait on SENDREQ'             as ARCH_wait_on_SENDREQ,
'ARCH wait on DETACH'              as ARCH_wait_on_DETACH,
'ARCH wait for netserver init 2'   as ARCH_wait_for_netserver_init_2,
'LNS wait on LGWR'                 as LNS_wait_on_LGWR,
'LGWR wait on LNS'                 as LGWR_wait_on_LNS,
'ARCH wait for flow-control'       as ARCH_wait_for_flow_control,
'ARCH wait for netserver detach'   as ARCH_wait_for_netserver_detach,
'TCP Socket (KGAS)'                as TCP_Socket__KGAS_,
'virtual circuit wait'             as virtual_circuit_wait,
'dispatcher listen timer'          as dispatcher_listen_timer,
'dedicated server timer'           as dedicated_server_timer,
'SQL*Net message to client'        as SQL_Net_message_to_client,
'SQL*Net message to dblink'        as SQL_Net_message_to_dblink,
'SQL*Net more data to client'      as SQL_Net_more_data_to_client,
'SQL*Net more data to dblink'      as SQL_Net_more_data_to_dblink,
'SQL*Net more data from client'    as SQL_Net_more_data_from_client,
'SQL*Net message from dblink'      as SQL_Net_message_from_dblink,
'SQL*Net more data from dblink'    as SQL_Net_more_data_from_dblink,
'SQL*Net vector data to client'    as SQL_Net_vector_data_to_client,
'SQL*Net vector data from client'  as SQLNet_vector_data_4fm_client,
'SQL*Net vector data to dblink'    as SQL_Net_vector_data_to_dblink,
'SQL*Net vector data from dblink'  as SQLNet_vector_data4rmdblink,
'TEXT: URL_DATASTORE network wait' as TEXT_URL_DATASTORE_ntwrk_wt)
)
order by snap_id
