select  snap_time as snap_time,
        snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  and S.SNAP_ID between :v_begin_snap and :v_end_snap
--  order by s.snap_id desc
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
pivot (
max(value_diff)
for stat_name in (
 'execute count' as executions,
 'logons cumulative' as logons,
 'sorts (memory)' as memory_sorts,
 'sorts (disk)' as disk_sorts,
 'parse count (hard)' as hard_parses,
 'parse count (total)' as parses,
 'user calls' as user_calls,
 'physical reads' as physical_reads,
 'physical writes' as physical_writes,
 'db block changes' as block_changes,
 'session logical reads' as logical_reads,
 'redo size' as redo_size,
 'user commits' as user_commit,
 'user rollbacks' as user_rollback)
 )
order by snap_id
