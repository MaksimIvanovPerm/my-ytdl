select *
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and SE.EVENT_NAME in (
  'remote log force - commit','log file sync','nologging standby txn commit','enq: BB - 2PC across RAC instances'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'remote log force - commit' AS rem_log_force_cmt,
'log file sync' AS log_file_sync,
'nologging standby txn commit' AS nologg_stb_txn_cmt,
'enq: BB - 2PC across RAC instances' AS enq_BB_2PC_acr
    )
     )
order by snap_id
