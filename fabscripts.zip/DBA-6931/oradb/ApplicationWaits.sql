select *
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='Application'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'enq: PW - flush prewarm buffers' as enqPWflushprewarmbuffers,
'enq: RO - contention' as enqROcontention,
'enq: RO - fast object reuse' as enqROfastobjectreuse,
'enq: KO - fast object checkpoint' as enqKOfastobjectcheckpoint,
'enq: TM - contention' as enqTMcontention,
'enq: TX - row lock contention' as enqTXrowlockcontention,
'Wait for Table Lock' as WaitforTableLock,
'enq: RC - Result Cache: Contention' as enqRCResultCacheContention,
'Streams capture: filter callback waiting for ruleset' as StrmCaptrFiltrCallBckWtn4Rlst,
'Streams: apply reader waiting for DDL to apply' as e1,
'SQL*Net break/reset to client' as SQLNetbreakresettoclient,
'SQL*Net break/reset to dblink' as SQLNetbreakresettodblink,
'External Procedure initial connection' as e2,
'External Procedure call' as ExternalProcedurecall,
'enq: UL - contention' as enqULcontention,
'OLAP DML Sleep' as OLAPDMLSleep,
'WCR: replay lock order' as WCRreplaylockorder
)
    )
order by snap_id
