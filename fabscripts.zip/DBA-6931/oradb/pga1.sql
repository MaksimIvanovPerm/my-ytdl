select *
from (
with local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as stat_name,
        ST.value as bytes
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=:v_dbid
  and S.INSTANCE_NUMBER=1 and S.SNAP_ID
  between :v_begin_snap
      and :v_end_snap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.NAME in ('extra bytes read/written','total PGA inuse','total PGA allocated','maximum PGA allocated')
),
b as ( select * from local_data ),
e as ( select * from local_data )
select to_char(e.snap_time,'dd.mm.yyyy hh24:mi') as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 ) v
 pivot (
max(value_diff)
for stat_name in (
'extra bytes read/written' as extra_bytes,
'total PGA inuse' as pga_inuse,
'total PGA allocated' as pga_alloc,
'maximum PGA allocated' as max_pga_alloc
 )
 )
order by snap_time
