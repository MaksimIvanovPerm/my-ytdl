select *
from
(with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=:v_dbid
  and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID
  between :v_begin_snap
      and :v_end_snap
    ),
e as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=:v_dbid
  and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between :v_begin_snap
                    and :v_end_snap
   )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
)
pivot (
max(value_diff)
for stat_name in (
'PGA memory freed back to OS' as PGA_memory_freed_back_to_OS,
'aggregate PGA auto target' as aggregate_PGA_auto_target,
'aggregate PGA target parameter' as aggregate_PGA_target_parameter,
'bytes processed' as bytes_processed,
'cache hit percentage' as cache_hit_percentage,
'extra bytes read/written' as extra_bytes_read_written,
'global memory bound' as global_memory_bound,
'max processes count' as max_processes_count,
'maximum PGA allocated' as maximum_PGA_allocated,
'maximum PGA used for auto workareas' as maxPGA_used4auto_wa,
'maximum PGA used for manual workareas' as maxPGA_used4manual_wa,
'over allocation count' as over_allocation_count,
'process count' as process_count,
'recompute count (total)' as recompute_count__total_,
'total PGA allocated' as total_PGA_allocated,
'total PGA inuse' as total_PGA_inuse,
'total PGA used for auto workareas' as totalPGA_used4auto_wa,
'total freeable PGA memory' as total_freeable_PGA_memory
)
 )
order by snap_time
