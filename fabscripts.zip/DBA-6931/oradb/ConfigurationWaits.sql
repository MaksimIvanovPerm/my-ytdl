select *
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy~hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','nologging range consumption list','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','SecureFile log buffer','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','REPL Apply: commit','wait for EMON to process ntfns' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'free buffer waits' as freebufferwaits,
'checkpoint completed' as checkpointcompleted,
'write complete waits' as writecompletewaits,
'write complete waits: flash cache' as writecompletewaitsflashcache,
'latch: redo writing' as latchredowriting,
'latch: redo copy' as latchredocopy,
'log buffer space' as logbufferspace,
'log file switch (checkpoint incomplete)' as lgflSwtchChckpIntinComplete,
'log file switch (private strand flush incomplete)' as lgflSwtchPrvtStrndflshIncmplt,
'log file switch (archiving needed)' as logfileswitchArchivingneeded,
'log file switch completion' as logfileswitchcompletion,
'flashback buf free by RVWR' as flashbackbuffreebyRVWR,
'nologging range consumption list' as nologgingrangeconsumptionlist,
'enq: ST - contention' as enqSTcontention,
'undo segment extension' as undosegmentextension,
'undo segment tx slot' as undosegmenttxslot,
'enq: TX - allocate ITL entry' as enqTXallocateITLentry,
'statement suspended, wait error to be cleared' as StmtSuspendedWaitErrToBeClrd,
'SecureFile log buffer' as SecureFilelogbuffer,
'enq: HW - contention' as enqHWcontention,
'enq: SS - contention' as enqSScontention,
'sort segment request' as sortsegmentrequest,
'enq: SQ - contention' as enqSQcontention,
'Global transaction acquire instance locks' as GlblTxAcquireinstancelocks,
'REPL Apply: commit' as REPLApplycommit,
'wait for EMON to process ntfns' as waitforEMONtoprocessntfns
)
    )
order by snap_id
