SELECT * FROM (SELECT snap_time,
                      snap_id,
                      name,
                      --snap_delta,
                      --ns_delta,
                      CASE
                        WHEN ns_delta>0 THEN Round(snap_delta/ns_delta,0)
                        ELSE 0
                      END AS connections
                 FROM (
                   WITH local_data AS (SELECT to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
                                              s.snap_id,
                                              sss.num_samples,
                                              t.sampled_total_conn,
                                              t.name
                                         FROM sys.wrh$_SHARED_SERVER_SUMMARY sss,
                                              sys.wrh$_dispatcher t,
                                              sys.WRM$_SNAPSHOT s
                                         where s.dbid = :v_dbid
                                           and S.INSTANCE_NUMBER=1
                                           and S.SNAP_ID between :v_begin_snap and :v_end_snap
                                           and t.DBID=S.DBID
                                           and t.INSTANCE_NUMBER=S.INSTANCE_NUMBER
                                           and t.SNAP_ID=S.SNAP_ID
                                           AND sss.dbid=s.dbid
                                           AND sss.INSTANCE_NUMBER=S.INSTANCE_NUMBER
                                           and sss.SNAP_ID=S.SNAP_ID
                                         --ORDER BY s.snap_id ASC, t.name asc
                                      ),
                       b as ( select * from local_data ),
                       e as ( select * from local_data )
                  SELECT e.snap_time,
                         e.snap_id,
                         e.num_samples AS ens,
                         b.num_samples AS bns,
                         e.sampled_total_conn,
                         e.name,
                         case
                           when (e.sampled_total_conn - b.sampled_total_conn) < 0 then null
                           else (e.sampled_total_conn - b.sampled_total_conn)
                         end as snap_delta,
                         case
                           when (e.num_samples - b.num_samples) < 0 then null
                           else (e.num_samples - b.num_samples)
                         end as ns_delta
                    FROM b, e
                    WHERE e.snap_id=(b.snap_id+1) AND e.name=b.name
--ORDER BY e.snap_id ASC, e.name asc
 )
  )
pivot( max(connections) for name in (
  'D000' AS D000,
  'D001' AS D001,
  'D002' AS D002,
  'D003' AS D003,
  'D004' AS D004,
  'D005' AS D005)
)
ORDER BY snap_id asc
