select *
  from (SELECT to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
               S.SNAP_ID as snap_id,
               sg.component AS component,
               sg.current_size AS current_size
          FROM SYS.wrh$_mem_dynamic_comp sg,
               WRM$_SNAPSHOT s
          where s.dbid=:v_dbid
            and S.INSTANCE_NUMBER=:v_instnum
            and S.snap_id between :v_begin_snap and :v_end_snap
            and SG.DBID=s.dbid
            and SG.INSTANCE_NUMBER=S.INSTANCE_NUMBER
            and SG.SNAP_ID=S.SNAP_ID
            AND sg.component IN ('DEFAULT buffer cache','Shared IO Pool','java pool','large pool','shared pool','streams pool')
       )
pivot (
max(current_size)
for component in (
 'DEFAULT buffer cache' AS Def_bc,
 'Shared IO Pool' AS ShrdIO_Pool,
 'java pool' AS java_pool,
 'large pool' AS large_pool,
 'shared pool' AS shared_pool,
 'streams pool' AS streams_pool)
 )
order by snap_id
