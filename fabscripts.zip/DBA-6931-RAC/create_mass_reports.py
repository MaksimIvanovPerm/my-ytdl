import subprocess
import logging
import threading

thread_num = 0

def create_report(ip, sid):
    """
    A function that can be used by a thread
    """
    logging.info("creating report on server " + ip +
                 " for database " + sid
                )
    subprocess.call(["python3", "oracle-awr-report.py", "--host", ip,  "--sid",  sid,  "--db_name",  ip, "--logging", "ERROR"])
    

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(threadName)s %(levelname)s %(message)s')

try:
    db_list = open("db.conf")
except OSError as err:
    logging.critical("OS error: {0}".format(err))
    raise
except Exception:
    logging.critical("Unexpected error:", sys.exc_info()[0])
    raise
for db_string in db_list.readlines():
    if not db_string.startswith("\n") and not db_string.startswith("#"):
        ip, sid = db_string.split(':')
        sid = sid.replace("\r", "").replace("\n", "")
        """ for multi thread using """
        thread_name = "Thread_" + str(thread_num)
        thread_num += 1
        new_thread = threading.Thread(target=create_report, name=thread_name, args=(ip, sid))
        new_thread.start()
        """ for single thread using """
        # create_report(ip, sid)

