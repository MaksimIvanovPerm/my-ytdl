select *
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=:v_dbid and S.INSTANCE_NUMBER=:v_inst_num
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between :v_begin_snap and :v_end_snap
  and SE.EVENT_NAME in ( 'Parameter File I/O','Disk file operations I/O','Disk file I/O Calibration','Disk file Mirror Read','Disk file Mirror/Media Repair Write','direct path sync','Datapump dump file I/O','dbms_file_transfer I/O','DG Broker configuration file I/O','Data file init write','Log file init write','Pluggable Database file copy','File Copy','Shared IO Pool IO Completion','local write wait','buffer read retry','read by other session','db flash cache single block physical read','db flash cache multiblock physical read','db flash cache write','db file sequential read','db file scattered read','db file single write','db file parallel read','direct path read','direct path read temp','direct path write','direct path write temp','flashback log file sync','cell smart table scan','cell smart index scan','cell external table smart scan','cell statistics gather','cell smart file creation','Archive Manager file transfer I/O','securefile direct-read completion','securefile direct-write completion','BFILE read','utl_file I/O','external table read','external table write','external table open','external table seek','external table misc IO','dbverify reads','TEXT: File System I/O','ASM sync cache disk read','ASM Fixed Package I/O','ASM Staleness File I/O','cell single block physical read','cell multiblock physical read','cell list of blocks physical read','cell physical read no I/O','cell single block read request','cell multiblock read request','cell list of blocks read request' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'Parameter File I/O' as ParameterFileIO,
'Disk file operations I/O' as DiskfileoperationsIO,
'Disk file I/O Calibration' as DiskfileIOCalibration,
'Disk file Mirror Read' as DiskfileMirrorRead,
'Disk file Mirror/Media Repair Write' as DiskfileMirrorMediaRepairWrite,
'direct path sync' as directpathsync,
'Datapump dump file I/O' as DatapumpdumpfileIO,
'dbms_file_transfer I/O' as dbms_file_transferIO,
'DG Broker configuration file I/O' as DGBrokerconfigurationfileIO,
'Data file init write' as Datafileinitwrite,
'Log file init write' as Logfileinitwrite,
'Pluggable Database file copy' as PluggableDatabasefilecopy,
'File Copy' as FileCopy,
'Shared IO Pool IO Completion' as SharedIOPoolIOCompletion,
'local write wait' as localwritewait,
'buffer read retry' as bufferreadretry,
'read by other session' as readbyothersession,
'db flash cache single block physical read' as dbflashcacheSblckphysread,
'db flash cache multiblock physical read' as dbflashcacheMblckphysread,
'db flash cache write' as dbflashcachewrite,
'db file sequential read' as dbfilesequentialread,
'db file scattered read' as dbfilescatteredread,
'db file single write' as dbfilesinglewrite,
'db file parallel read' as dbfileparallelread,
'direct path read' as directpathread,
'direct path read temp' as directpathreadtemp,
'direct path write' as directpathwrite,
'direct path write temp' as directpathwritetemp,
'flashback log file sync' as flashbacklogfilesync,
'cell smart table scan' as cellsmarttablescan,
'cell smart index scan' as cellsmartindexscan,
'cell external table smart scan' as cellexternaltablesmartscan,
'cell statistics gather' as cellstatisticsgather,
'cell smart file creation' as cellsmartfilecreation,
'Archive Manager file transfer I/O' as ArchiveManagerfiletransferIO,
'securefile direct-read completion' as ScrfileDrct_rdcompletion,
'securefile direct-write completion' as ScrfileDrct_wrcompletion,
'BFILE read' as BFILEread,
'utl_file I/O' as utl_fileIO,
'external table read' as externaltableread,
'external table write' as externaltablewrite,
'external table open' as externaltableopen,
'external table seek' as externaltableseek,
'external table misc IO' as externaltablemiscIO,
'dbverify reads' as dbverifyreads,
'TEXT: File System I/O' as TEXT_FileSystemIO,
'ASM sync cache disk read' as ASMsynccachediskread,
'ASM Fixed Package I/O' as ASMFixedPackageIO,
'ASM Staleness File I/O' as ASMStalenessFileIO,
'cell single block physical read' as cellsingleblockphysicalread,
'cell multiblock physical read' as cellmultiblockphysicalread,
'cell list of blocks physical read' as celllistofblocksphysicalread,
'cell physical read no I/O' as cellphysicalreadnoIO,
'cell single block read request' as cellsingleblockreadrequest,
'cell multiblock read request' as cellmultiblockreadrequest,
'cell list of blocks read request' as celllistofblocksreadrequest
)
    )
order by snap_id
