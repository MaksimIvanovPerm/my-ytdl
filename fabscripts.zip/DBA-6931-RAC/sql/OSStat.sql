select
v.snap_time as snap_time,
v.snap_id as snap_id,
v.NUM_CPUS as NUM_CPUS,
v.IDLE_TIME as IDLE_TIME,
v.BUSY_TIME as BUSY_TIME,
v.USER_TIME as USER_TIME,
v.SYS_TIME as SYS_TIME,
v.IOWAIT_TIME as IOWAIT_TIME,
v.NICE_TIME as NICE_TIME,
v.RSRC_MGR_CPU_WAIT_TIME as RSRC_MGR_CPU_WAIT_TIME,
v.LOAD as LOAD,
v.NUM_CPU_SOCKETS as NUM_CPU_SOCKETS,
v.PHYSICAL_MEMORY_BYTES as PHYSICAL_MEMORY_BYTES,
v.VM_IN_BYTES as VM_IN_BYTES,
v.VM_OUT_BYTES as VM_OUT_BYTES,
v.NUM_CPU_CORES AS NUM_CPU_CORES,
v.FREE_MEMORY_BYTES AS FREE_MEMORY_BYTES,
v.INACTIVE_MEMORY_BYTES AS INACTIVE_MEMORY_BYTES,
v.SWAP_FREE_BYTES AS SWAP_FREE_BYTES
from (
select *
from (
with
local_data as (
select to_char(S.BEGIN_INTERVAL_TIME,'dd.mm.yyyy hh24:mi') as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from sys.WRM$_SNAPSHOT s, sys.WRH$_OSSTAT os, sys.WRH$_OSSTAT_NAME osn
where   S.dbid=:v_dbid and s.INSTANCE_NUMBER=:v_inst_num
    and S.SNAP_ID between :v_begin_snap and :v_end_snap
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,
'IDLE_TIME' as IDLE_TIME,
'BUSY_TIME' as BUSY_TIME,
'USER_TIME' as USER_TIME,
'SYS_TIME' as SYS_TIME,
'IOWAIT_TIME' as IOWAIT_TIME,
'NICE_TIME' as NICE_TIME,
'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,
'LOAD' as LOAD,
'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,
'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,
'VM_IN_BYTES' as VM_IN_BYTES,
'VM_OUT_BYTES' as VM_OUT_BYTES,
'NUM_CPU_CORES' AS NUM_CPU_CORES,
'FREE_MEMORY_BYTES' AS FREE_MEMORY_BYTES,
'INACTIVE_MEMORY_BYTES' AS INACTIVE_MEMORY_BYTES,
'SWAP_FREE_BYTES' AS SWAP_FREE_BYTES
)
)
 )  v
order by v.snap_id
