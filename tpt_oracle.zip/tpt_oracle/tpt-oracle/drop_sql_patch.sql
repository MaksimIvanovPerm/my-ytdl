EXEC dbms_sqldiag.drop_sql_patch('&1');
