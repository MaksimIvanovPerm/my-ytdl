UPDATE t4 SET object_id = object_id + 1 WHERE object_id = 500;
