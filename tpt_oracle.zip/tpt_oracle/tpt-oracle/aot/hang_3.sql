UPDATE t4 SET owner = 'X' WHERE rownum <= 100;
UPDATE t3 SET owner = 'X' WHERE rownum <= 100;
