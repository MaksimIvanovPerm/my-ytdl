/*
$ORACLE_HOME/bin/sqlplus -S / as sysdba << __EOF__
alter session set current_schema=excellent;
drop table sessstat_log;
create table sessstat_log (time number, sess_sid NUMBER, sess_serial NUMBER, sess_stat number) tablespace excellent;
exit;
__EOF__

sudo chown oracle:oracle ./stat.dat; sudo mv -v ./stat.dat /home/oracle/DBA-8464/
cat /dev/null > ./stat.out
while read line
do
 x=`echo $line | awk '{print $4}'`
 x=`echo -n $x | tr [:upper:] [:lower:]`
  echo $x | grep -i -q "e"
 v_rc=$?
 if [ "$v_rc" -eq "0" ]
 then
  base=$(echo $x | cut -d 'e' -f1)
  exp=$(($(echo $x | cut -d 'e' -f2)*1))
  x=$(bc <<< "$base*(10^$exp)")
 fi
 y=`echo $line | awk '{print $1" "$2" "$3}'`
 echo "$y $x" >> ./stat.out
done < stat.dat

TRUNCATE TABLE excellent.sessstat_log REUSE STORAGE;

echo "load data
 infile 'stat.out'
 into table excellent.sessstat_log
 fields terminated by \" \" optionally enclosed by '\"'
 ( time, sess_sid, sess_serial, sess_stat )" > loader.ctl; cat  loader.ctl

sqlldr \'/ as sysdba\' control=loader.ctl direct=Y
*/

CREATE INDEX sessstat_log_sid_serial_idx ON excellent.sessstat_log(sess_sid, sess_serial) TABLESPACE excellent;

SELECT count(*)
FROM excellent.sessstat_log t
;

SELECT sess_id, regexp_substr(sess_id,'\d+',1,1) AS sess_sid,
       regexp_substr(sess_id,'\d+',1,2) AS sess_serial
FROM (SELECT DISTINCT t.sess_sid||' '||t.sess_serial AS sess_id
FROM excellent.sessstat_log t)
;

SELECT *
FROM excellent.sessstat_log t
WHERE t.sess_sid=955 AND t.sess_serial=22464
ORDER BY t.TIME asc
;

begin
 EXECUTE IMMEDIATE 'drop table sess_stat_DBA_8464';
EXCEPTION
 WHEN OTHERS THEN NULL;
END;
/

create table sess_stat_DBA_8464 (time number, sess_sid NUMBER, sess_serial NUMBER, sess_stat number) TABLESPACE excellent;
TRUNCATE TABLE sess_stat_DBA_8464 REUSE STORAGE;

DECLARE
 CURSOR c1 IS
SELECT sess_id, regexp_substr(sess_id,'\d+',1,1) AS sess_sid,
       regexp_substr(sess_id,'\d+',1,2) AS sess_serial, sample_count
FROM (
  SELECT t.sess_sid||' '||t.sess_serial AS sess_id, Count(*) AS sample_count
  FROM excellent.sessstat_log t
  GROUP BY t.sess_sid||' '||t.sess_serial
  )
WHERE sample_count>1;

 v_x NUMBER;
BEGIN
 FOR i IN c1
 LOOP
   --Dbms_Output.put_line(i.sess_sid||' '||i.sess_serial||' '||v_x);
   INSERT INTO sess_stat_DBA_8464(time, sess_sid, sess_serial, sess_stat)
   SELECT time, sess_sid, sess_serial, --sess_stat, prev_sess_stat,
       sess_stat - prev_sess_stat AS stat_value
FROM (
SELECT t.TIME AS TIME,
t.sess_sid AS sess_sid,
t.sess_serial AS sess_serial,
t.sess_stat AS sess_stat,
Lag(t.sess_stat,1,0) OVER (ORDER BY t.TIME asc) AS prev_sess_stat,
Row_Number() OVER (ORDER BY t.TIME asc) AS rid
FROM excellent.sessstat_log t
WHERE t.sess_sid=i.sess_sid AND t.sess_serial=i.sess_serial
ORDER BY t.TIME ASC )
WHERE rid>1
;
  COMMIT;
 END LOOP;
END;
/

SELECT time, sess_sid, sess_serial, --sess_stat, prev_sess_stat,
       sess_stat - prev_sess_stat AS stat_value
FROM (
SELECT t.TIME AS TIME,
t.sess_sid AS sess_sid,
t.sess_serial AS sess_serial,
t.sess_stat AS sess_stat,
Lag(t.sess_stat,1,0) OVER (ORDER BY t.TIME asc) AS prev_sess_stat,
Row_Number() OVER (ORDER BY t.TIME asc) AS rid
FROM excellent.sessstat_log t
WHERE t.sess_sid=11 AND t.sess_serial=10671
ORDER BY t.TIME ASC )
WHERE rid>1
;

SELECT Sum(t.sess_stat) AS total
FROM sess_stat_DBA_8464 t
--WHERE t.sess_sid=103 AND t.sess_serial=55055
--ORDER BY t.TIME asc
;

SELECT t.TIME, Sum(t.sess_stat) AS all_sess_stat
FROM sess_stat_DBA_8464 t
GROUP BY t.time
ORDER BY t.TIME asc
;

SELECT t.sess_sid||'.'||t.sess_serial AS sess_info,
       Sum(t.sess_stat) AS sess_stat,
       Count(t.time) AS sample_count
FROM sess_stat_DBA_8464 t
WHERE 1=1 --t.TIME=1568259184
  --AND t.sess_sid||'.'||t.sess_serial NOT IN ( '777.21357')
group BY t.sess_sid||'.'||t.sess_serial
ORDER BY sess_stat desc
;


SELECT t.sess_sid||'.'||t.sess_serial AS sess_info,
       Round(Sum(t.sess_stat)/1024/1024,2) AS sess_stat
FROM sess_stat_DBA_8464 t
WHERE 1=1 --t.TIME BETWEEN 1568253777 AND 1568265491
  AND t.sess_sid=795  AND t.sess_serial = 31179
group BY t.sess_sid||'.'||t.sess_serial
ORDER BY sess_stat desc
;


SELECT t.*
FROM sess_stat_DBA_8464 t
WHERE 1=1 --t.TIME BETWEEN 1568253777 AND 1568265491
  AND t.sess_sid=554  AND t.sess_serial = 586
ORDER BY sess_stat desc
;
