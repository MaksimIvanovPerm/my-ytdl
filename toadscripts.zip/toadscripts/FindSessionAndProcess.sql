set echo off verify off arraysize 5000

select s.sid||','||s.serial# AS sess_id, s.machine, s.osuser, s.action, s.MODULE, t.sql_id, t.sql_text
from sys.v_$open_cursor t, sys.v_$session s
WHERE t.saddr=s.saddr
ORDER BY s.osuser;

select s.osuser, Count(*) 
from sys.v_$open_cursor t, sys.v_$session s
WHERE t.saddr=s.saddr
GROUP BY rollup(s.osuser)
ORDER BY 2 desc
;

SELECT event_name, wait_time_milli, wait_count, Round(cumsum_waits/total_waits*100,2) AS pct
FROM (
SELECT t.event as event_name, t.wait_time_milli, t.wait_count,
       Sum(wait_count) OVER (partition by t.event ORDER BY null) AS total_waits,
       Sum(wait_count) OVER (partition by t.event ORDER BY t.wait_time_milli ROWS BETWEEN unbounded preceding AND CURRENT row) AS cumsum_waits
FROM V$EVENT_HISTOGRAM t
WHERE 1=1
  --AND t.event in ('log file sync', 'log file parallel write', 'log file single write')
 AND t.event in ('asynch descriptor resize','direct path write temp','direct path read temp', 'db file sequential read','db file scattered read','Disk file operations I/O')
ORDER BY t.event, t.wait_time_milli
 )
;


SELECT SYSDATE, v.*
FROM (
select count(*), event from v$session_wait
where event not like 'SQL*%'
GROUP by event
order by 1 asc ) v;

select * from sys.v_$sql_shared_cursor t
WHERE t.child_number>=25
ORDER BY t.child_number desc;

--alter system kill session '450,51593' immediate;
alter system kill session '2242,1327' immediate;
exec dbms_system.set_ev(2242,1327, 10237, 1, '');
exec dbms_system.set_ev(6, 4975, 10237, 0, '');
--define sql_sess_sid=1045

SELECT *
FROM v$session s
WHERE s.username='GASHKOV'
;
select s.action, s.MODULE, p.spid, round(P.PGA_USED_MEM/1024/1024, 2) as pga_used_mem,
       s.sid||','||s.serial# as sess_id, S.BLOCKING_SESSION as who_blocks,
       s.final_blocking_session,
       sw.event, SW.P1, SW.P2, sw.p3, SW.SECONDS_IN_WAIT,
       s.username, s.status, s.server, s.machine, s.program,s.sql_id, s.prev_sql_id, s.terminal, s.logon_time,
       (select OBJ.OWNER||'.'||OBJ.OBJECT_NAME||' '||OBJ.OBJECT_TYPE from dba_objects obj where obj.object_id in (S.ROW_WAIT_OBJ#)) as rw_obj_name,
       S.LAST_CALL_ET, S.SERVICE_NAME, s.sql_child_number,
       p.pga_used_mem, Round(p.pga_alloc_mem/1024/1024,2) AS pga_alloc_mem, p.pga_max_mem
from sys.v_$process p, sys.v_$session s, v$session_wait sw
where s.paddr = p.addr and s.sid=sw.sid
--AND s.type='USER'
--AND s.sql_id IN ('d24tdxbxdxn9jn9','493td50n44ssn')
--AND s.username NOT IN ('RADIUS_USER','SHADOW99','WIFI_USER','GS_USER')
--AND s.server='SHARED'
--AND Lower(s.username) = 'myshev_vv'
--AND s.sid IN (922, 2242)
--AND s.machine='uk-billing-ivanovm'
--AND s.event='log file sync'
--AND s.serial#=1043
--AND s.module like 'client\_un%' escape '\'
--AND s.MODULE = 'testcase'
--AND s.action ='testcase'
--AND s.MODULE NOT IN ( 'TOAD 12.1.0.22', 'Toad.exe', 'TOAD 13.1.0.78', 'TOAD 11.5.0.56', 'TOAD background query session', 'pr_debtor_jur_pack.get_structure', 'Arm_XML20161201.exe', 'Arm_XML20170507.exe', 'PL/SQL Developer')
--AND s.sid IN (SELECnnT jr.sid FROM sys.dba_jobs_running jr)
--and s.event = 'library cache lock'
--AND ( s.MODULE LIKE 'wcc\_main%' ESCAPE '\' OR s.MODULE LIKE 'bills\_view%' ESCAPE '\' OR s.MODULE LIKE 'wcc2\_main%' ESCAPE '\')
--AND s.action LIKE '%556check%'
--and s.status NOT IN ('INACTIVE')
--AND Lower(s.program) LIKE 'toad%'
--AND S.BLOCKING_SESSION IS null
--AND Upper(s.machine) ='CORP\PERM-TERMINAL-8'
--AND Lower(s.service_name)='odi.hq.ertelecom.ru'
--AND s.program='AUTOpd.exe'
--AND s.SERVICE_NAME='private_web.spb.ertelecom.ru'
--ORDER BY s.sql_id DESC
--ORDER BY s.module aSC
--ORDER BY s.sql_id DESC
--ORDER BY s.username
ORDER BY s.module asc
--ORDER BY s.program asc
;

select 'kill -9 '||p.spid, S.PROCESS as client_process, s.action, s.MODULE,
s.sid||','||s.serial# as sess_id, s.blocking_session as who_blocks,S.BLOCKING_SESSION_STATUS,
       s.final_blocking_session AS final_blocker_sid,
s.sql_id, s.sql_hash_value, s.plsql_entry_object_id, s.plsql_entry_subprogram_id, s.plsql_object_id, s.plsql_subprogram_id,
        round(P.PGA_USED_MEM/1024/1024, 2) as pga_used_mem, s.plsql_entry_object_id, s.plsql_object_id,
       sw.event, SW.P1, SW.P2, sw.p3, SW.SECONDS_IN_WAIT, S.ROW_WAIT_OBJ# as row_wait_obj,
       (select OBJ.OWNER||'.'||OBJ.OBJECT_NAME||' '||OBJ.OBJECT_TYPE from dba_objects obj where obj.object_id in (S.ROW_WAIT_OBJ#)) as rw_obj_name,
       s.sql_id, s.prev_sql_id,
       s.username, s.status, s.server, s.machine, s.program, s.terminal, s.logon_time, S.SERVICE_NAME
from v$process p, sys.v_$session s, v$session_wait sw
where s.paddr = p.addr and s.sid=sw.sid
AND s.TYPE='USER'
--AND p.spid IN (86002)
--AND s.status='ACTIVE'
--AND S.BLOCKING_SESSION_STATUS  = 'VALID'
--AND s.username='POPOV_AV11'
and s.sid IN (892)
--and s.event = 'enq: TM - contention'
--AND s.osuser='admin'
--AND s.module='eql_params_pub.params_data_xml';
--AND s.serial#=0
--AND s.action='repair_replication'
--AND s.sid IN (SELECT jr.sid FROM sys.dba_jobs_running jr)
--AND s.MODULE LIKE 'dwh_charges_support2%'
 --AND Lower(s.machine) LIKE '%uk-gashkov%'
--AND s.username ='KHRENOV_VV'
-- AND s.blocking_session=202
--AND Lower(s.machine) LIKE '%ubuntu%'
--AND s.program='rman@genesys-db1 (TNS V1-V3)'
ORDER BY s.module
;

SELECT s.sid, t.xidusn, t.status, t.start_time, t.USED_UBLK, t.xid
FROM sys.v_$transaction t, sys.v_$session s
WHERE t.ses_addr=s.saddr
  AND s.MODULE='audclean'
;


SELECT *
FROM sys.V_$SESSION_EVENT se
WHERE 1=1
  AND se.sid=&&v_sid
ORDER BY se.time_waited desc
  ;

define sql_sess_sid=496
SELECT *
FROM (
select sess.sid,
       sess.action, sess.MODULE, sess.sql_id, sess.program, sess.username, sess.machine,
       sn.name as name, s.value as value
from sys.v$sesstat s, sys.v$statname sn, sys.v$session sess
where S.STATISTIC#=SN.STATISTIC#
  AND s.sid=sess.sid
  --and s.sid=&&sql_sess_sid
  and S.VALUE > 0
  AND sn.name='db block changes'
order by s.value DESC
 )
 WHERE ROWNUM<=20;

SELECT *
FROM v$statname t
WHERE t.name LIKE '%block%'
;

SELECT *
FROM V$TEMPSEG_USAGE t
--WHERE t.session_num=&&sql_sess_sid  sql_id    segtype       segblk#
ORDER BY t.blocks desc
;
SELECT rownum as id, s.sid, s.serial#, substr(s.username,1,16) as username, s.status, s.server, s.program, s.sql_id, t.segtype,
       Round((t.blocks*32768)/1024/1024,2) AS tempsize_mb, s.event
FROM sys.v_$session s, V$TEMPSEG_USAGE t
WHERE s.saddr=t.session_addr
order by tempsize_mb desc;

SELECT * FROM sys.dba_resumable t;

SELECT *
FROM sys.V_$SQL_WORKAREA  t
--WHERE t.sql_id='gnz5jv60grv9t'
--ORDER BY t.last_memory_used desc
ORDER BY t.max_tempseg_size DESC nulls last
;

SELECT t.sql_id, t.sql_exec_start, t.operation_type, t.sid, t.actual_mem_used, t.number_passes,
       t.tempseg_size
FROM sys.V_$SQL_WORKAREA_ACTIVE t
--WHERE t.sid=&&sql_sess_sid
ORDER BY t.actual_mem_used desc
;

select * 
from sys.V_$SQL_WORKAREA_HISTOGRAM t
;

SELECT *
FROM sys.v_$statname sn
WHERE sn.name LIKE '%pga%'
ORDER BY sn.name
;

SELECT sid, serial#, event, sql_id, action, module, name, stat_value, sess_time,
       CASE
       WHEN sess_time IS NOT NULL AND sess_time > 0 THEN Round(stat_value/sess_time,2)
       ELSE null
       END AS stat_per_second
FROM (
SELECT s.sid, s.serial#, s.event, s.sql_id, s.action, s.MODULE, sn.name, t1.Value AS stat_value, Round((SYSDATE-s.logon_time)*24*3600,2) AS sess_time
FROM v$sesstat t1, sys.v_$statname sn, sys.v_$session s
WHERE t1.statistic#=sn.statistic#
  AND sn.name = 'session pga memory'
  AND t1.sid=s.sid
  AND s.TYPE='USER'
  --AND s.status='ACTIVE'
--ORDER BY t1.Value DESC
 )
 ORDER BY stat_value DESC
;

select t.sql_id, t.address, t.hash_value, t.sql_text from v$sql t where t.sql_text like '%label1%';
define v_sqlid="97rkn8cac96um"
column v_address new_value v_address noprint;
column v_hash new_value v_hash noprint;
select t.address as v_address, t.hash_value as v_hash from v$sqlarea t where t.sql_id='&&v_sqlid';
define
EXEC sys.dbms_shared_pool.purge('&&v_address,&&v_hash', 'C');
select t.* from sys.v_$sqlarea t where t.sql_id='&&v_sqlid';

exec dbms_sqldiag.dump_trace(p_sql_id=>'&&v_sqlid', p_child_number=>0, p_component=>'Optimizer', p_file_id=>'20210606_1');
exec dbms_sqldiag.dump_trace('&&v_sqlid', 0, 'Compiler', '20210606_1');

select t.* 
from sys.dba_sql_management_config t;

select --t.signature||'' as signature
       t.*
from DBA_SQL_PLAN_BASELINES t;

define v_sqlhandle="SQL_ca9264ac5c0594e2"
select t.* from table(dbms_xplan.display_sql_plan_baseline('&&v_sqlhandle', null, 'TYPICAL')) t;

SELECT t.sql_id, t.CHILD_NUMBER, t.plan_hash_value, t.executions, --t.IS_REOPTIMIZABLE, t.buffer_gets,
       --t.exact_matching_signature||'' as exact_matching_signature, t.force_matching_signature||'' as force_matching_signature,
       t.is_bind_sensitive, t.is_bind_aware, t.is_shareable
FROM   sys.V_$SQL t
WHERE  t.sql_id='&&v_sqlid';

select t.plan_hash_value, t.child_number, t.id, t.parent_id, t.operation, t.options, t.object_owner||'.'||t.object_name
from sys.v_$sql_plan t
where t.sql_id='&&v_sqlid'
order by t.plan_hash_value asc, t.child_number asc, t.id asc
;

exec dbms_spd.flush_sql_plan_directive;
select * 
from sys.DBA_SQL_PLAN_DIRECTIVES t;

select * 
from sys.DBA_SQL_PLAN_DIR_OBJECTS t
where t.owner='EXCELLENT' and t.object_type='TABLE';


SELECT t.sql_id,t.OLD_HASH_VALUE, plan_hash_value, t.executions, t.sql_profile, T.SQL_FULLTEXT
       --*
from sys.v_$sql t
WHERE 1=1
--AND t.sql_id IN ( '03zc0wf0dt7n8')
--t.sql_id IN ('2gc5zu9jwgzq0')
--t.hash_value=2020259514
AND Upper(t.sql_fulltext) LIKE '%MYUPDATE%' ESCAPE '\'
--AND Upper(t.sql_fulltext) LIKE '%EX.EXECUTER\_NAME%' ESCAPE '\'
;

SELECT *
FROM sys.v_$sql_plan t
WHERE t.sql_id in ('5nmf91bapg5bf','cy8pkwdp339ag')
  --AND t.hash_value=1611887384
  --AND t.full_plan_hash_value=1611887384
  --AND t.plan_hash_value=3896610687
  --AND t.child_number=1
ORDER BY t.child_number, t.id asc
;

SELECT *
FROM sys.V_$SQL_PLAN_STATISTICS_ALL t
WHERE t.sql_id='66su9xf1jft8n'
  --AND t.child_number=0
ORDER BY t.id
;

SELECT Round(t.USED_UBLK*(SELECT Value FROM v$parameter WHERE name='db_block_size')/1024/1024, 2) AS undo_size_mb
FROM v_$transaction t, v$session s
WHERE s.saddr=t.SES_ADDR AND s.sid=1347;

select *
from v$process p
where p.spid=9160;

select  OBJ.OWNER||'.'||OBJ.OBJECT_NAME||' '||OBJ.OBJECT_TYPE as locked_obj,
        t.SESSION_ID,
        S.ACTION||' '||S.MODULE as sess_info,
        S.EVENT as sess_event,
        S.PROGRAM as sess_program,
        t.ORACLE_USERNAME,
        t.OS_USER_NAME,
        t.PROCESS,
        Decode(t.locked_mode, 0, 'None',
                             1, 'Null (NULL)',
                             2, 'Row-S (SS)',
                             3, 'Row-X (SX)',
                             4, 'Share (S)',
                             5, 'S/Row-X (SSX)',
                             6, 'Exclusive (X)',
                             t.locked_mode) locked_mode,
        S.BLOCKING_SESSION as who_bloks
from V$LOCKED_OBJECT t, dba_objects obj, v$session s
where OBJ.OBJECT_ID=t.OBJECT_ID
  and T.SESSION_ID=S.SID and T.ORACLE_USERNAME=S.USERNAME
order by T.SESSION_ID, T.OBJECT_ID;


select count(*), T.PLSQL_ENTRY_OBJECT_ID
from SYS.V_$ACTIVE_SESSION_HISTORY t
where T.SESSION_ID=68 and T.SESSION_SERIAL#=28923
  and T.SAMPLE_TIME >= (sysdate - 2/24)
group by T.PLSQL_ENTRY_OBJECT_ID;


select *
from SYS.DBA_PROCEDURES t
where T.OBJECT_ID=61075;

SELECT *
FROM sys.dba_objects t
WHERE t.object_id=5373365;

define sess_num="151"
-- session stat
CREATE GLOBAL TEMPORARY TABLE bstat
ON COMMIT PRESERVE ROWS
as
select SN.NAME, S.VALUE
from v$sesstat s, v$statname sn
where S.STATISTIC#=SN.STATISTIC#
  and S.VALUE > 0 and S.SID=&&sess_num
order by S.VALUE desc;

CREATE GLOBAL TEMPORARY TABLE estat
ON COMMIT PRESERVE ROWS
as
select SN.NAME, S.VALUE
from v$sesstat s, v$statname sn
where S.STATISTIC#=SN.STATISTIC#
  and S.VALUE > 0 and S.SID=&&sess_num
order by S.VALUE desc;

TRUNCATE TABLE bstat;
TRUNCATE TABLE estat;

INSERT INTO bstat select SN.NAME, S.VALUE
from v$sesstat s, v$statname sn
where S.STATISTIC#=SN.STATISTIC#
  and S.VALUE > 0 and S.SID=&&sess_num
order by S.VALUE desc;

COMMIT;

INSERT INTO estat select SN.NAME, S.VALUE
from v$sesstat s, v$statname sn
where S.STATISTIC#=SN.STATISTIC#
  and S.VALUE > 0 and S.SID=&&sess_num
order by S.VALUE desc;

COMMIT;

SELECT * FROM bstat t
ORDER BY t.Value desc;

SELECT * FROM estat t
ORDER BY t.Value desc;

SELECT *
FROM (
SELECT e.name AS stat_name,
       Nvl(e.Value,0)-Nvl(b.value,0) AS delta
FROM bstat b, estat e
WHERE b.name(+)=e.name
 )
 ORDER BY DELTA desc
;

------------------------------------------------


select s.event, S.TOTAL_WAITS, S.TIME_WAITED_MICRO from v$session_event s where S.SID=1957 order by 2 desc;


select * from v$pgastat;


select s.state, S.BLOCKING_SESSION_STATUS, S.BLOCKING_SESSION, S.ACTION, S.MODULE, s.event from v$session s where s.sid in (539)
union all
select s.state, S.BLOCKING_SESSION_STATUS, S.BLOCKING_SESSION, S.ACTION, S.MODULE, s.event from v$session s where s.sid in (1417);


select * from DBA_HIST_ACTIVE_SESS_HISTORY t
where T.SESSION_ID in (342) and T.SESSION_SERIAL#=15762
  and trunc(T.SAMPLE_TIME,'DD') = to_date('03.02.2012','dd.mm.yyyy')
order by T.SAMPLE_TIME desc;

select * from sys.V_$ACTIVE_SESSION_HISTORY T
where T.SESSION_ID=107 and T.SESSION_SERIAL#=15858
--  and T.EVENT='db file sequential read'
--  and t.p1=46
ORDER BY t.sample_id asc
;

select --distinct t.event
       t.*
from V$ACTIVE_SESSION_HISTORY T
where 1=1
  AND T.SESSION_ID=295
  and T.SESSION_SERIAL#=4809
ORDER BY t.sample_id asc
;

select sum(T.time_waited ),
       t.p2
from V$ACTIVE_SESSION_HISTORY T
where T.SESSION_ID=342 and T.SESSION_SERIAL#=15762
  and T.EVENT='db file sequential read'
  and t.p1=46
group by t.p2
order by 1 desc;

select * from V$TRANSACTION t where t.xid='0E002A0041AD3300';
select sn.name, t.value
from v$sesstat t, v$statname sn
where t.sid=2582
  and T.STATISTIC#=sn.STATISTIC#
  and t.value > 0
order by t.value desc;

--alter system kill session '499, 11515' immediate;
select 'alter system kill session '''||s.sid||', '||s.serial#||''' immediate;'
from v$process p, v$session s, v$session_wait sw
where s.paddr = p.addr and s.sid=sw.sid and s.event in ('cursor: pin S wait on X');


select 'kill -9 '||p.spid
from v$process p, v$session s, v$session_wait sw
where s.paddr = p.addr and s.sid=sw.sid and s.event in ('cursor: pin S wait on X')
  and p.spid not in (12389, 12395);

select s.sid, s.serial#, s.username, s.status,
       s.server, s.machine, s.program, s.action, s.module, p.spid,
       s.sql_address,
       s.sql_hash_value
from v$process p, v$session s
where s.paddr = p.addr and s.status='ACTIVE' and s.type='USER' and s.machine <> 'PERM\UK-MSKP-5'
order by s.sid;

select 'alter system kill session '''||s.sid||', '||s.serial#||''' immediate;'
from v$process p, v$session s, v$session_wait sw
where s.paddr = p.addr and s.sid=sw.sid and s.sid in ();

select s.sid||' '||s.serial#||' '||s.username||' '||s.status||' '||s.server||' '||s.program||' '||p.spid
from v$process p, v$session s
where s.paddr = p.addr and s.sid in ();

select * from v$database;

select * from v$session
where paddr in (select addr
                from v$process
                where spid in (16882, 16928, 17569));
select * from v$sql
where address='00000000CCE38DF8' and hash_value='2659136679';

select s.sid, s.serial#, s.server, s.status, s.program, S.MACHINE, sn.name, st.value
from v$sesstat st, v$statname sn, v$session s
where  st.STATISTIC#=sn.STATISTIC# and st.sid=s.sid
       and st.value > 0
       and s.sid=81
order by st.value desc;

select s.sid, s.serial#, s.server, s.status, s.program, S.MACHINE, sn.name, st.value
from v$sesstat st, v$statname sn, v$session s
where  st.STATISTIC#=sn.STATISTIC# and st.sid=s.sid
       and st.value > 0
       and s.sid=58
order by st.value desc;

select s.sid, s.serial#, s.server, s.status, s.program, S.MACHINE, sn.name, st.value
from v$sesstat st, v$statname sn, v$session s
where  st.STATISTIC#=sn.STATISTIC# and st.sid=s.sid
       and st.value > 0
       and s.sid=79
order by st.value desc;


select s.sid, s.serial#, s.status, s.server, s.program, s.machine, S.USERNAME, stn.name, st.value
from v$sesstat st, v$session s, v$statname stn
where st.sid=s.sid
      and STN.STATISTIC#=ST.STATISTIC#
      and stn.name like '%CPU%'
      and s.type='USER'
      and s.status='ACTIVE'
order by s.sid, stn.name desc;

desc v$statname;

select s.sid, s.serial#, s.status, s.server, s.program, s.machine, p.pga_used_mem, P.PGA_ALLOC_MEM
from v$session s, v$process p
where s.paddr=p.addr and s.type='USER'
order by p.pga_used_mem desc;


SELECT s.sid, s.serial#, s.username, s.osuser, s.machine, s.status, kglpnmod "Mode", kglpnreq "Req"
FROM x$kglpn p, v$session s
WHERE p.kglpnuse=s.saddr AND  kglpnhdl='00000000CA2AC130' order by kglpnmod;


select p.spid, S.serial#, s.status, S.USERNAME, S.SERver, S.MACHINE, S.PROGRAM, S.ACTION
from v$session s, v$process p
where s.sid=388 and s.paddr=p.addr;

select * from v$instance;

select * from dba_users where username='RIAS_MONIT';
select * from dba_profiles where profile='RIAS_MONITORING';
alter profile RIAS_MONITORING limit connect_time 60;

SELECT V.OWNER, V.OBJECT_NAME, V.OBJECT_TYPE, V.BLCK_IN_BCACHE, V.FREE_BLCK, V.XCUR_BLCK, V.CR_BLCK, V.DIRTY_BLCK, V.DATA_BLCK, V.SORT_BLCK, V.SEGM_HEADER_BLCK AS SEGHEADER_BLCK, SUM(V.BLCK_IN_BCACHE) OVER() AS TOTAL_BLOCK, SYSDATE AS TIME_ID
FROM
(SELECT DO.OWNER OWNER, DO.OBJECT_NAME OBJECT_NAME, DO.OBJECT_TYPE OBJECT_TYPE, BH.CLASS#, BH.STATUS, BH.DIRTY, COUNT(*) OVER (PARTITION BY DO.OWNER, DO.OBJECT_NAME) BLCK_IN_BCACHE, COUNT(DECODE(LOWER(BH.STATUS),'free',1,NULL)) OVER (PARTITION BY DO.OWNER, DO.OBJECT_NAME) FREE_BLCK, COUNT(DECODE(LOWER(BH.STATUS),'xcur',1,NULL)) OVER (PARTITION BY DO.OWNER, DO.OBJECT_NAME) XCUR_BLCK, COUNT(DECODE(LOWER(BH.STATUS),'cr',1,NULL)) OVER (PARTITION BY DO.OWNER, DO.OBJECT_NAME) CR_BLCK, COUNT(DECODE(LOWER(BH.STATUS),'read',1,NULL)) OVER (PARTITION BY DO.OWNER, DO.OBJECT_NAME) READ_BLCK, COUNT(DECODE(LOWER(BH.STATUS),'mrec',1,NULL)) OVER (PARTITION BY DO.OWNER, DO.OBJECT_NAME) MRECOVER_BLCK, COUNT(DECODE(LOWER(BH.STATUS),'irec',1,NULL)) OVER (PARTITI

select * from DBA_DATAPUMP_JOBS;
select * from DBA_DATAPUMP_SESSIONS;
select * from v$session where saddr in (select saddr from  DBA_DATAPUMP_SESSIONS);



SELECT owner||'.'||segment_name||', type: '||segment_type||', tablespace: '||tablespace_name
FROM sys.dba_extents
WHERE file_id = 88
 AND 2468130 BETWEEN block_id and block_id + blocks -1;

select * from DBA_DATAPUMP_JOBS;
select * from DBA_DATAPUMP_SESSIONS;

--user
--users

define usr_name="rias_admin"
define usr_pwd10g="349CE3F935DD8870;S:3E79B3146AEF470B1B951A7484F675290AF6F6EE27D779AB3E8EAC5A9312"
define usr_pwd11g=""
define usr_pwd12c=""

column usr_profile new_value usr_profile noprint;
SELECT t.profile as usr_profile FROM dba_users t WHERE t.username=upper('&&usr_name');
select '&&usr_profile' as col from dual;
--define usr_profile="rias_devel"


alter user &&usr_name profile default;
--alter user &&usr_name account unlock identified by "&&usr_pwd10g";
--alter user &&usr_name account unlock identified by values '&&usr_pwd';
begin
 execute immediate 'alter user &&usr_name account unlock identified by values ''&&usr_pwd10g&&usr_pwd11g&&usr_pwd12c''';
end;
/
alter user &&usr_name profile &&usr_profile;

column def_tempts new_value def_tempts noprint;
SELECT dp.property_value def_tempts FROM database_properties dp WHERE dp.property_name='DEFAULT_TEMP_TABLESPACE';
column def_ts new_value def_ts noprint;
SELECT dp.property_value def_ts FROM database_properties dp WHERE dp.property_name='DEFAULT_PERMANENT_TABLESPACE';
create user &&usr_name identified by "&&usr_pwd" default tablespace users temporary tablespace temp profile &&usr_profile;
--alter user &&usr_name account lock;
grant create session, select any table to &&usr_name;
GRANT BSS_DEVEL TO &&usr_name;
grant CONNECT, RESOURCE, select any table to &&usr_name;
--GRANT support_role TO &&usr_name;
--GRANT ALTER SYSTEM TO &&usr_name;
--GRANT create database link TO &&usr_name;
--GRANT DBA TO DUDYREV_KV
REVOKE rias_dba from &&usr_name;
REVOKE ALTER system from &&usr_name;
alter user &&usr_name default role all;

grant select any table to &&usr_name;
grant select on sys.dba_objects to &&usr_name;
grant select on sys.dba_source to &&usr_name;

grant alter session to &&usr_name;
GRANT SELECT ON v_$session TO &&usr_name;
GRANT SELECT ON v_$sql_plan_statistics_all TO &&usr_name;
GRANT SELECT ON v_$sql_plan TO &&usr_name;
GRANT SELECT ON v_$sql TO &&usr_name;

SELECT *
FROM sys.dba_objects t
WHERE t.owner=upper('&&usr_name')
;
set linesize 256
spool /tmp/output.log replace
SELECT t.user#, t.name, --t.password, t.SPARE4,
       case 
       when t.password is not null and t.spare4 is not null then t.password||';'||t.SPARE4
       when t.password is null and t.spare4 is not null then t.SPARE4
       when t.password is not null and t.spare4 is null then t.password
       end as hashes
FROM sys.user$ t
WHERE 1=1
  and t.name=upper('&&usr_name')
  --t.name LIKE 'RIAS\_MONIT%' ESCAPE '\'
  --and t.name in ('RADYGIN_SV','LOBANOV_MD','TUKACHEVA_NA','IMAMOV_AA','BARABOSHKIN_DE')
;
spool off

SELECT -- username||' '||account_status||' '||profile
      --t.username, t.account_status, t.password_versions
      *
from dba_users t
WHERE 1=1
--  AND T.USERNAME=upper('&&usr_name')
--AND t.user_id IN (81, 70, 112)
--AND t.expiry_date IS not NULL
--AND t.PROFILE IN ('ORA_STIG_PROFILE')
--AND t.default_tablespace IN ('USERS')
--Lower(T.USERNAME) LIKE 'web%'
--AND t.account_status='OPEN'
--AND regexp_like(T.USERNAME,'PRIVATE_EXCELLENT[0-9]?')
--AND T.USERNAME LIKE 'EXCELLENT%' ESCAPE '\'
--AND t.user_id IN (60)
--and t.username IN ('RADYGIN_SV','LOBANOV_MD','TUKACHEVA_NA','IMAMOV_AA','BARABOSHKIN_DE')
--AND t.default_tablespace IN ('USERS') AND t. expiry_date IS NOT null
--ORDER BY t.user_id
ORDER BY t.username
;

--rights

SELECT t.*
       --t.grantee||' '||t.privilege||' '||t.admin_option AS ststem_provs
FROM sys.dba_sys_privs t
WHERE 1=1
  and t.GRANTEE=upper('&&usr_name')
  --and t.privilege LIKE '%DEBUG CONNECT SESSION%'
  --AND t.admin_option!='NO'
ORDER BY t.privilege;

SELECT sysdate, t.*
--t.granted_role||' '||t.admin_option||' '||t.default_role AS col
from dba_role_privs t
WHERE 1=1
  and T.GRANTEE=upper('&&usr_name')
  --and t.grantee IN ('LOBANOV_MD','BEZRUKIKH_AN','KASHIRINA_LV','TCUTCKAREVA_TG','VERKHOLANTCEVA_VA','KASIMOVA_IR','PRUDNIKOV_AV')
  --AND t.granted_role IN ('RIAS_BSS_QA')
order by t.granted_role;


select t.*
       --'grant '||t.privilege||' on '||t.owner||'.'||t.table_name||' to &&usr_name;' AS cmd
from dba_tab_privs t
where 1=1
 and T.GRANTEE=upper('&&usr_name')
 --AND t.table_name IN ('DBA_OBJECTS')
 --AND t.owner=upper('FSM_ADM_SO')
 --AND Lower(t.table_name) IN ('content_providers')
order by t.owner, t.table_name, t.privilege;

SELECT *
FROM sys.dba_roles t
WHERE 1=1
  and t.ROLE=upper('&&usr_name')
  --and t.ROLE LIKE '%CATALOG%'
ORDER BY t.role
;


SELECT t.profile, t.limit
       --distinct t.profile
       --distinct t.resource_name
FROM sys.dba_profiles t
WHERE 1=1
 --t.PROFILE=Upper('&&usr_name')
 AND t.resource_name='IDLE_TIME'
ORDER BY t.profile
;

--ALTER PROFILE RIAS_ADMIN limit SESSIONS_PER_USER UNLIMITED;

select * from SYS.V_$SORT_SEGMENT t;
select * from SYS.V_$SORT_USAGE t order by t.blocks desc;
select * from SYS.V_$ROLLSTAT t order by t.rssize desc;
select sum(t.rssize)/1024/1024/1024 from SYS.V_$ROLLSTAT t where t.xacts=1;
select *
from SYS.V_$TRANSACTION t
where T.SES_ADDR=( select s.SADDR from v$session s where s.sid=268 and S.SERIAL#=21451 );
select * from SYS.V_$UNDOSTAT t order by T.END_TIME desc;

SELECT *
FROM sys.dba_ts_quotas t
;

DECLARE
 v_pwdhash sys.user$.password%TYPE;
CURSOR c1 IS
SELECT t.*
from dba_users t
WHERE 1=1
  AND t.expiry_date IS not NULL
  AND t.default_tablespace IN ('USERS')
  AND t.PROFILE LIKE 'RIAS%'
  AND t.account_status IN ('OPEN','EXPIRED(GRACE)')
ORDER BY t.username;
BEGIN
 FOR i IN c1
 LOOP
  v_pwdhash := NULL;
  SELECT t.password INTO v_pwdhash FROM  sys.user$ t WHERE t.name=i.username;
  IF v_pwdhash IS NOT NULL
  THEN
   EXECUTE IMMEDIATE 'alter user '||i.username||' profile default';
   EXECUTE IMMEDIATE 'alter user '||i.username||' account unlock identified by values '''||v_pwdhash||'''';
   Dbms_Output.put_line('alter user '||i.username||' profile default');
   Dbms_Output.put_line('alter user '||i.username||' account unlock identified by values '''||v_pwdhash||'''');
  END IF;
 END LOOP;
END;
/


select --+ ordered
 l.kgllkhdl as HANDLER,
 w.kglobtyd,
 w.kglnaown,
 w.kglnaobj,
 l.kgllktype,
 decode(l.kgllkmod, 0,
        'None',1,
        'Null',2,
        'Share',3,'Exclusive',
        'Unknown') mode_held,
 decode(l.kgllkreq,0,
        'None',1,
        'Null',2,
        'Share',3,
        'Exclusive','Unknown') mode_req,
 to_char(s.seconds_in_wait) as secs_in_wait,
 s.event,
 to_char(s.sid) as sid,
 to_char(s.serial#) as serial, s.blocking_session AS blocker,
 s.program,
 substr(a.sql_text, 1, 100) as sql_text
  from (select distinct p1raw
          from v$session
         where state = 'WAITING'
           and event in ('library cache lock', 'library cache pin')) b,
       sys.dba_kgllock l,
       x$kglob w,
       sys.v_$session s,
       v$sqlarea a
 where l.kgllkhdl = b.p1raw
   and l.kgllkhdl = w.kglhdadr
   and l.kgllkuse = s.saddr
   and s.sql_address = a.address(+)
   and s.sql_hash_value = a.hash_value(+)
 order by kgllkhdl, s.seconds_in_wait desc, l.kgllktype
 ;

select o.owner,
       o.object_name,
       o.object_type,
       o.last_ddl_time,
       o.status,
       l.session_id,
       l.oracle_username,
       decode (l.locked_mode,
               0, 'None',
               1, 'Null (NULL)',
               2, 'Row-S (SS)',
               3, 'Row-X (SX)',
               4, 'Share (S)',
               5, 'S/Row-X (SSX)',
               6, 'Exclusive (X)',
               l.locked_mode)
         locked_mode
  from sys.dba_objects o, sys.v_$locked_object l
where o.object_id = l.object_id and o.object_name = 'CITIES';


@/home/maksim/toadscripts/spoolit.sql
