ALTER SESSION SET nls_date_format='yyyy-mm-dd hh24:mi:ss';

SELECT * FROM dba_tablespaces t;

SELECT * FROM dba_data_files t WHERE t.TABLESPACE_NAME='FDA_DATA';

CREATE TABLESPACE fda_tb DATAFILE '/db/u11/oradata/dwh/fda_tb_01.dbf' SIZE 128M AUTOEXTEND ON NEXT 128M MAXSIZE 30G;
/*
ALTER DATABASE DATAFILE 14 RESIZE 16M;
ALTER DATABASE DATAFILE 14 AUTOEXTEND OFF;
ALTER DATABASE DATAFILE 14 AUTOEXTEND ON NEXT 2M MAXSIZE 64M;
*/

CREATE flashback ARCHIVE DEFAULT default_fda TABLESPACE fda_tb retention 1 DAY;

/*
with help of ALTER FLASHBACK ARCHIVE statement, you're able to:
    Change the retention time of a Flashback Data Archive
    Purge some or all of its data
    Add, modify, and remove tablespaces
*/

GRANT FLASHBACK ARCHIVE ADMINISTER TO KOZMINIH;

-- purge dba_recyclebing;

SELECT * FROM dba_users t;

DROP TABLE AWR_PUBLISHER.test_table purge;

CREATE TABLE AWR_PUBLISHER.test_table AS SELECT * FROM dba_objects;

CREATE UNIQUE INDEX AWR_PUBLISHER.test_table_idx ON AWR_PUBLISHER.test_table (object_id);

SELECT Count(*) FROM AWR_PUBLISHER.test_table;

ALTER TABLE AWR_PUBLISHER.test_table flashback ARCHIVE;

UPDATE AWR_PUBLISHER.test_table t SET t.object_name='qqq' WHERE t.owner='AWR_PUBLISHER';
COMMIT;

DECLARE
 v_n    NUMBER := 5;
BEGIN
FOR i IN 1..v_n
LOOP
 Dbms_Application_Info.set_action('iteration '||i);
 UPDATE  AWR_PUBLISHER.test_table t
 SET t.object_name=t.object_name, t.owner=t.owner;
 COMMIT;
END LOOP;
END;
/

SELECT OBJECT_ID||' '||object_name FROM AWR_PUBLISHER.test_table AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE)
  WHERE owner='AWR_PUBLISHER';

TRUNCATE TABLE AWR_PUBLISHER.test_table DROP STORAGE;

ALTER TABLE  AWR_PUBLISHER.test_table NO FLASHBACK ARCHIVE;

SELECT * FROM DBA_FLASHBACK_ARCHIVE t;

SELECT * FROM DBA_FLASHBACK_ARCHIVE_TS t;

SELECT * FROM SYS.DBA_FLASHBACK_ARCHIVE_TABLES t;


SELECT *
FROM sys.dba_tables t
WHERE t.owner='EXCELLENT'
  AND t.tablespace_name!='FDA_DATA'
  AND t.table_name NOT IN (SELECT arc.table_name
                           FROM SYS.DBA_FLASHBACK_ARCHIVE_TABLES arc
                           WHERE arc.owner_name='EXCELLENT'
                          )
;

ALTER TABLE  EXCELLENT.GEO_HOUSES_ENFORTA FLASHBACK ARCHIVE;

ALTER FLASHBACK ARCHIVE default_fda purge ALL;
ALTER FLASHBACK ARCHIVE default_fda modify TABLESPACE fda_tb QUOTA 64M;
ALTER FLASHBACK ARCHIVE default_fda modify TABLESPACE fda_tb;
ALTER FLASHBACK ARCHIVE default_fda modify retention 1 day;

SELECT *
FROM dba_segments t
WHERE t.TABLESPACE_NAME='FDA_TB';

SELECT *
FROM dba_objects t
WHERE t.CREATED >= (SYSDATE - 60/(24*60));


SELECT *
FROM dba_objects t
WHERE t.object_name LIKE '%\_FBA\_%' ESCAPE '\';

DROP FLASHBACK ARCHIVE default_fda;

DROP TABLESPACE fda_tb INCLUDING CONTENTS AND DATAFILES;

SELECT *
FROM dba_objects t
where t.object_name='RIAS_ACCOUNT_LOGON';

