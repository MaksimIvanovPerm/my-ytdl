SELECT  To_Char(t.RUNSTARTTIME,'dd.mm.yyyy hh24:mi') AS RUNSTARTTIME,
        (extract(hour FROM t.RUNENDTIME-t.RUNSTARTTIME))*3600 + (extract(minute FROM t.RUNENDTIME-t.RUNSTARTTIME))*60 + extract(SECOND FROM t.RUNENDTIME-t.RUNSTARTTIME) AS ela_time_sec
        --,t.RUNSTATUS
FROM CAMPAIGN.UA_CCRUNLOG t
WHERE t.FLOWCHARTID=2775
  --AND Lower(t.RUNSTATUS) IN ('run failed','run succeeded')
  AND Lower(t.RUNSTATUS)='run succeeded'
  AND t.RUNSTARTTIME > To_Date('23.06.2015 15:07:21','dd.mm.yyyy hh24:mi:ss')
ORDER BY t.RUNSTARTTIME;

DECLARE
 v_start_time     DATE := To_Date('23.06.2015 19:30','dd.mm.yyyy hh24:mi:ss');
BEGIN
 WHILE (v_start_time <= sysdate)
 LOOP
    Dbms_Output.put_line( To_Char(v_start_time,'dd.mm.yyyy hh24:mi') );
    v_start_time := v_start_time+1/24;
 END LOOP;
END;
/

-- SplineInterpolation.r

SELECT *
FROM PERFSTAT.STATS$SQLTEXT t
WHERE t.sql_id='8u9c5ybgucu6q';

SELECT *
FROM perfstat.stats$sql_plan_usage t
WHERE t.sql_id='8u9c5ybgucu6q';

SELECT *
FROM stats$sql_plan t
WHERE t.plan_hash_value=1998684210;

