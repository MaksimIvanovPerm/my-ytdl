alter session set nls_date_format='yyyy.mm.dd hh24:mi';

select * from v$database;

SELECT * FROM v$instance;

select SEGMENT_NAME,SEGMENT_TYPE,
       Round(bytes/1024/1024/1024, 2) AS size_Gb
from sys.dba_segments t
WHERE t.owner='PERFSTAT'
ORDER BY t.bytes desc;

select * from user_jobs;

select sysdate from dual;

SELECT * FROM v$database;

SELECT * FROM v$instance;

define v_dbid=3440237077
define v_bsnap=825
define v_esnap=1224
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ', ';

select *
from PERFSTAT.STATS$SNAPSHOT s
where S.dbid=&&v_dbid
order by S.SNAP_ID desc;

SELECT *
FROM perfstat.audlog t
WHERE t.logrecord LIKE 'D:%'
ORDER BY t.datetime desc;

SELECT *
FROM sys.dba_data_files t
WHERE t.tablespace_name='MONITOR';

--ALTER TABLESPACE MONITOR ADD DATAFILE '/db/u11/oradata/dwh/monitor_02.dbf' SIZE 128M AUTOEXTEND ON NEXT 128M MAXSIZE 5G;
--ALTER DATABASE DATAFILE 283 AUTOEXTEND ON next 128M maxsize 20G;
--ALTER DATABASE DATAFILE 283 RESIZE 8M;

EXEC statspack.purge(i_begin_snap => 1, i_end_snap => 3);
COMMIT;

SELECT Min(s.SNAP_ID) AS bsnap,
       Max(s.SNAP_ID) AS esnap,
       Trunc(s.SNAP_TIME,'DD') AS snap_day
from PERFSTAT.STATS$SNAPSHOT s
where S.dbid=&&v_dbid
GROUP BY Trunc(s.SNAP_TIME,'DD')
ORDER BY Trunc(s.SNAP_TIME,'DD');


select min(S.SNAP_ID) as min_snap_id, max(S.SNAP_ID) as max_snap_id
from PERFSTAT.STATS$SNAPSHOT s
where S.dbid=&&v_dbid
order by S.SNAP_ID desc;

SELECT *
FROM PERFSTAT.stats$statspack_parameter t
;

SELECT *
FROM PERFSTAT.audlog t
ORDER BY t.datetime desc
;

-- Service Time
select *
from (
with
local_data as (
select  --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_TIME,
        --s.snap_time AS snap_time,
        S.SNAP_ID as snap_id,
        TMN.STAT_NAME as stat_name,
        TM.VALUE as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYS_TIME_MODEL tm, PERFSTAT.STATS$TIME_MODEL_STATNAME tmn
where TM.DBID=S.DBID and TM.INSTANCE_NUMBER=S.INSTANCE_NUMBER and TM.SNAP_ID=S.SNAP_ID
  and TM.STAT_ID=TMN.STAT_ID
  and S.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
pivot (
max(value_diff)
for stat_name in (
'DB time' as db_time,
'DB CPU' as db_cpu,
'background elapsed time' as bgrnd_el_tm,
'background cpu time' as bgrnd_cpu_tm,
'sequence load elapsed time' as seq_load_el_tm,
'parse time elapsed' as parse_el_tm,
'hard parse elapsed time' as hard_parse_el_tm,
'sql execute elapsed time' as sql_exec_el_tm,
'connection management call elapsed time' as conn_mgmnt_call_el_tm,
'failed parse elapsed time' as failed_parse_el_tm,
'failed parse (out of shared memory) elapsed time' as fail_parse_outofshmem_el_tm,
'hard parse (sharing criteria) elapsed time' as hrd_parse_sharing_crit_el_tm,
'hard parse (bind mismatch) elapsed time' as hrd_prs_bing_mismtch_el_tm,
'PL/SQL execution elapsed time' as plsql_exec_el_tm,
'inbound PL/SQL rpc elapsed time' as inbnd_plsql_rpc_el_tm,
'PL/SQL compilation elapsed time' as plsql_compile_el_tm,
'Java execution elapsed time' as java_exec_el_tm,
'repeated bind elapsed time' as repeat_bind_el_tm,
'RMAN cpu time (backup/restore)' as rman_bcp_rstr_cpu_tm)
)
order by snap_id;

-- Wait time structure
-- select distinct wait_class from SYS.V_$EVENT_NAME
select snap_time, snap_id, Concurrency, UserIO, SystemIO, Administrative, Other, Configuration, Application, Network, Commit
from (
with    local_data as (
select  --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_TIME,
        S.SNAP_ID as snap_id,
        en.WAIT_CLASS as stat_name,
        sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID
group by S.SNAP_TIME, S.SNAP_ID, EN.WAIT_CLASS
             ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in ('Cluster' as Clster,
'Concurrency' as Concurrency,
'User I/O' as UserIO,
'System I/O' as SystemIO,
'Administrative' as Administrative,
'Other' as Other,
'Scheduler' AS Scheduler,
'Configuration' as Configuration,
'Cluster' AS ClusterWaits,
'Application' as Application,
'Queueing' AS Queueing,
'Idle' as Idle,
'Network' as Network,
'Commit' as Commit)
    )
order by snap_id;


-- Concurrency Class Wait Structure
-- select * from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='Concurrency';

select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_TIME as snap_time,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='Concurrency'
   --and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'logout restrictor' as logoutrestrictor,
'Shared IO Pool Memory' as SharedIOPoolMemory,
'latch: cache buffers chains' as latchcachebufferschains,
'buffer busy waits' as bufferbusywaits,
'db flash cache invalidate wait' as dbflashcacheinvalidatewait,
'log file sync: SCN ordering' as logfilesyncSCNordering,
'enq: TX - index contention' as enqTX_indexcontention,
'latch: Undo Hint Latch' as latchUndoHintLatch,
'latch: In memory undo latch' as latchInmemoryundolatch,
'latch: MQL Tracking Latch' as latchMQLTrackingLatch,
'IM buffer busy' as IMbufferbusy,
'securefile chain update' as securefilechainupdate,
'enq: HV - contention' as enqHV_contention,
'SecureFile mutex' as SecureFilemutex,
'enq: WG - lock fso' as enqWG_lockfso,
'Inmemory Populate: get loadscn' as InmemoryPopulategetloadscn,
'latch: row cache objects' as latchrowcacheobjects,
'row cache lock' as rowcachelock,
'row cache read' as rowcacheread,
'libcache interrupt action by LCK' as libcacheinterruptactionbyLCK,
'cursor: mutex X' as cursormutexX,
'cursor: mutex S' as cursormutexS,
'cursor: pin X' as cursorpinX,
'cursor: pin S' as cursorpinS,
'cursor: pin S wait on X' as cursorpinSwaitonX,
'enq: CB - role operation' as enqCB_roleoperation,
'latch: shared pool' as latchsharedpool,
'LCK0 row cache object free' as LCK0rowcacheobjectfree,
'library cache pin' as librarycachepin,
'library cache lock' as librarycachelock,
'library cache load lock' as librarycacheloadlock,
'library cache: mutex X' as librarycachemutexX,
'library cache: mutex S' as librarycachemutexS,
'resmgr:internal state change' as resmgrinternalstatechange,
'resmgr:sessions to exit' as resmgrsessionstoexit,
'pipe put' as pipeput,
'REPL Apply: dependency' as REPLApplydependency,
'Cube Build Master Wait for Jobs' as CubeBuildMasterWaitforJobs
)
    )
order by snap_id;
--------------------------------------------------------------------------------


-- Commit class
-- select name from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='Commit'
select *
from (
with
local_data as (
select to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='Commit'
   --and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'log file sync' as log_file_sync,
'remote log force - commit' AS remote_log_force_commit,
'nologging standby txn commit' AS nologging_standby_txn_commit,
'enq: BB - 2PC across RAC INSTANCES' AS enq_BB_2PC_across_RAC
)
    )
order by snap_id;

-- Network class
-- select * from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='Network'

SELECT *
FROM (
with
local_data as (
select to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='Network'
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
pivot (
max(value_diff)
for stat_name in
(
'remote db operation' as remote_db_operation,
'remote db file read' as remote_db_file_read,
'remote db file write' as remote_db_file_write,
'ARCH wait for net re-connect' as ARCH_wait4net_reconnect,
'LGWR wait on ATTACH' as LGWR_wait_on_ATTACH,
'ARCH wait on ATTACH' as ARCH_wait_on_ATTACH,
'ARCH wait for netserver start' as ARCH_wait4netserver_start,
'LNS wait on ATTACH' as LNS_wait_on_ATTACH,
'LNS wait on SENDREQ' as LNS_wait_on_SENDREQ,
'LNS wait on DETACH' as LNS_wait_on_DETACH,
'LGWR wait on SENDREQ' as LGWR_wait_on_SENDREQ,
'LGWR wait on DETACH' as LGWR_wait_on_DETACH,
'ARCH wait on SENDREQ' as ARCH_wait_on_SENDREQ,
'ARCH wait on DETACH' as ARCH_wait_on_DETACH,
'ARCH wait for netserver init 2' as ARCH_wait4netserver_init_2,
'LNS wait on LGWR' as LNS_wait_on_LGWR,
'LGWR wait on LNS' as LGWR_wait_on_LNS,
'ARCH wait for flow-control' as ARCH_wait4flow_control,
'ARCH wait for netserver detach' as ARCH_wait4netserver_detach,
'TCP Socket (KGAS)' as TCP_Socket_KGAS,
'virtual circuit wait' as virtual_circuit_wait,
'dispatcher listen timer' as dispatcher_listen_timer,
'dedicated server timer' as dedicated_server_timer,
'SQL*Net message to client' as SQLNet_message_to_client,
'SQL*Net message to dblink' as SQLNet_message_to_dblink,
'SQL*Net more data to client' as SQLNet_more_data_to_client,
'SQL*Net more data to dblink' as SQLNet_more_data_to_dblink,
'SQL*Net more data from client' as SQLNet_more_data_from_client,
'SQL*Net message from dblink' as SQLNet_message_from_dblink,
'SQL*Net more data from dblink' as SQLNet_more_data_from_dblink,
'SQL*Net vector data to client' as SQLNet_vector_data_to_client,
'SQL*Net vector data from client' as SQLNet_vector_data_from_client,
'SQL*Net vector data to dblink' as SQLNet_vector_data_to_dblink,
'SQL*Net vector data from dblink' as SQLNet_vector_data_from_dblink,
'TEXT: URL_DATASTORE network wait' as TEXT_URL_DS_network_wait
)
    )
order by snap_id;


-- SystemIO class
-- select * from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='System I/O'
SET define off

SELECT *
FROM (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_TIME as snap_time,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='System I/O'
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
pivot (
max(value_diff)
for stat_name in
(
'Clonedb bitmap file write' as Clonedb_bitmap_file_write,
'Log archive I/O' as_Log_archive_IO,
'RMAN backup & recovery I/O' as RMAN_backup_recovery_IO,
'Standby redo I/O' as Standby_redo_IO,
'Network file transfer' as Network_file_transfer,
'io done' as_io_done,
'RMAN Disk slave I/O' as RMAN_Disk_slave_IO,
'RMAN Tape slave I/O' as RMAN_Tape_slave_IO,
'DBWR slave I/O' as DBWR_slave_IO,
'LGWR slave I/O' as LGWR_slave_IO,
'Archiver slave I/O' as Archiver_slave_IO,
'control file sequential read' as control_file_sequential_read,
'control file single write' as control_file_single_write,
'control file parallel write' as control_file_parallel_write,
'recovery read' as recovery_read,
'RFS sequential i/o' as RFS_sequential_io,
'RFS random i/o' as RFS_random_io,
'RFS write' as RFS_write,
'log file sequential read' as log_file_sequential_read,
'log file single write' as log_file_single_write,
'log file parallel write' as log_file_parallel_write,
'db file parallel write' as db_file_parallel_write,
'db file async I/O submit' as db_file_async_IO_submit,
'flashback log file write' as flashback_log_file_write,
'flashback log file read' as flashback_log_file_read,
'cell smart incremental backup' as cell_smart_incremental_backup,
'cell smart restore from backup' as cell_smart_restore_from_backup,
'kfk: async disk IO' as kfk_async_disk_IO,
'cell manager opening cell' as cell_manager_opening_cell,
'cell manager closing cell' as cell_manager_closing_cell,
'cell manager discovering disks' as cell_manager_discovering_disks
)
    )
order by snap_id;

-- UserIO class
-- select * from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='User I/O'
select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_TIME,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='User I/O'
   --and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'Archive Manager file transfer I/O' as ArchManagerFileTransferIO,
'ASM Fixed Package I/O' as ASM_Fixed_Package_I_O,
'ASM Staleness File I/O' as ASM_Staleness_File_I_O,
'BFILE read' as BFILE_read,
'buffer read retry' as buffer_read_retry,
'cell list of blocks physical read' as cell_list_of_blcksPhRead,
'cell multiblock physical read' as cell_multiblock_physical_read,
'cell single block physical read' as cell_single_blockPhRead,
'cell smart file creation' as cell_smart_file_creation,
'cell smart index scan' as cell_smart_index_scan,
'cell smart table scan' as cell_smart_table_scan,
'cell statistics gather' as cell_statistics_gather,
'Data file init write' as Data_file_init_write,
'Datapump dump file I/O' as Datapump_dump_file_I_O,
'db file parallel read' as db_file_parallel_read,
'db file scattered read' as db_file_scattered_read,
'db file sequential read' as db_file_sequential_read,
'db file single write' as db_file_single_write,
'db flash cache multiblock physical read' as db_flash_cache_mblckPhRead,
'db flash cache single block physical read' as db_flash_cache_sblckPhRead,
'db flash cache write' as db_flash_cache_write,
'dbms_file_transfer I/O' as dbms_file_transfer_I_O,
'dbverify reads' as dbverify_reads,
'DG Broker configuration file I/O' as DGBConfFileIO,
'direct path read' as direct_path_read,
'direct path read temp' as direct_path_read_temp,
'direct path sync' as direct_path_sync,
'direct path write' as direct_path_write,
'direct path write temp' as direct_path_write_temp,
'Disk file I/O Calibration' as Disk_file_I_O_Calibration,
'Disk file Mirror Read' as Disk_file_Mirror_Read,
'Disk file Mirror/Media Repair Write' as DiskFileMirrorMediaRepairWrite,
'Disk file operations I/O' as Disk_file_operations_I_O,
'external table misc IO' as external_table_misc_IO,
'external table open' as external_table_open,
'external table read' as external_table_read,
'external table seek' as external_table_seek,
'external table write' as external_table_write,
'flashback log file sync' as flashback_log_file_sync,
'local write wait' as local_write_wait,
'Log file init write' as Log_file_init_write,
'Parameter File I/O' as Parameter_File_I_O,
'read by other session' as read_by_other_session,
'securefile direct-read completion' as securefileDirectRdCompletion,
'securefile direct-write completion' as securefileDirectWrCompletion,
'Shared IO Pool IO Completion' as Shared_IO_Pool_IO_Completion,
'TEXT: File System I/O' as TEXT__File_System_I_O,
'utl_file I/O' as utl_file_I_O
)
    )
order by snap_id;


-- Configuration class
-- select * from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='Configuration'
select *
from (
with
local_data as (
select S.SNAP_TIME as snap_time,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='Configuration'
   --and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'free buffer waits' as free_buffer_waits,
'checkpoint completed' as checkpoint_completed,
'write complete waits' as write_complete_waits,
'write complete waits: flash cache' as writeCompleteWaitsFlashCache,
'latch: redo writing' as latch__redo_writing,
'latch: redo copy' as latch__redo_copy,
'log buffer space' as log_buffer_space,
'log file switch (checkpoint incomplete)' as logFileSwitchChckptIncomplete_,
'log file switch (private strand flush incomplete)' as LFSwitchPrivStrandFlushIncmplt,
'log file switch (archiving needed)' as LFSwitchArchiving_needed,
'log file switch completion' as lfs_completion,
'flashback buf free by RVWR' as flashback_buf_free_by_RVWR,
'enq: ST - contention' as enqSTcontention,
'undo segment extension' as undo_segment_extension,
'undo segment tx slot' as undo_segment_tx_slot,
'enq: TX - allocate ITL entry' as enqTXallocate_ITL_entry,
'statement suspended, wait error to be cleared' as StmtSspnddWaitErrToBeCleared,
'enq: HW - contention' as enqHWcontention,
'enq: SS - contention' as enqSScontention,
'sort segment request' as sort_segment_request,
'enq: SQ - contention' as enqSQcontention,
'Global transaction acquire instance locks' as GlblTrnsAcquireInstanceLocks,
'Streams apply: waiting to commit' as StreamsApplyWaiting_to_commit,
'wait for EMON to process ntfns' as wait_for_EMON_to_process_ntfns
)
    )
order by snap_id;

-- Others class
-- See R-script AnalyzeOthersWaitClass.r and do
-- cat ./class_events.txt | grep -f ./filter.txt at dwh
-- select ''''||en.name||''' as e'||rownum||',' as col from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='Other'

select SNAP_TIME,
       SNAP_ID,
       E4,E11,E14,E16,E17,E19,E20,E32,E34,E35,E39,E46,E51,E69,E77,E174,E176,E179,E183,E185,E186,E189,E199,E201,E203,E235,E238,E240,E241,E243,E290,E291,E296,E303,E304,E305,E336,E345,E346,E365,E366,E370,E373,E379,E409,E424,E443,E458,E459,E460,E461,E464,E466,E479,E519,E521,E547,E548,E562,E656,E705,E706,E719,E731
       --*
from (
with
local_data as (
select to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='Other'
   --and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'null event' as e1,
'events in waitclass Other' as e2,
'enq: WM - WLM Plan activation' as e3,
'latch free' as e4,
'kslwait unit test event 1' as e5,
'kslwait unit test event 2' as e6,
'kslwait unit test event 3' as e7,
'unspecified wait event' as e8,
'latch activity' as e9,
'wait list latch activity' as e10,
'wait list latch free' as e11,
'global enqueue expand wait' as e12,
'free process state object' as e13,
'inactive session' as e14,
'process terminate' as e15,
'latch: call allocation' as e16,
'latch: session allocation' as e17,
'check CPU wait times' as e18,
'enq: CI - contention' as e19,
'enq: PR - contention' as e20,
'ksim generic wait event' as e21,
'debugger command' as e22,
'ksdxexeother' as e23,
'ksdxexeotherwait' as e24,
'enq: PE - contention' as e25,
'enq: PG - contention' as e26,
'ksbsrv' as e27,
'ksbcic' as e28,
'process startup' as e29,
'process shutdown' as e30,
'prior spawner clean up' as e31,
'latch: messages' as e32,
'rdbms ipc message block' as e33,
'rdbms ipc reply' as e34,
'latch: enqueue hash chains' as e35,
'enq: FP - global fob contention' as e36,
'enq: RE - block repair contention' as e37,
'enq: BM - clonedb bitmap file write' as e38,
'asynch descriptor resize' as e39,
'imm op' as e40,
'slave exit' as e41,
'enq: KM - contention' as e42,
'enq: KT - contention' as e43,
'enq: CA - contention' as e44,
'enq: KD - determine DBRM master' as e45,
'reliable message' as e46,
'broadcast mesg queue transition' as e47,
'broadcast mesg recovery queue transition' as e48,
'master exit' as e49,
'ksv slave avail wait' as e50,
'enq: PV - syncstart' as e51,
'enq: PV - syncshut' as e52,
'enq: SP - contention 1' as e53,
'enq: SP - contention 2' as e54,
'enq: SP - contention 3' as e55,
'enq: SP - contention 4' as e56,
'IPC send completion sync' as e57,
'OSD IPC library' as e58,
'IPC wait for name service busy' as e59,
'IPC busy async request' as e60,
'IPC waiting for OSD resources' as e61,
'ksxr poll remote instances' as e62,
'ksxr wait for mount shared' as e63,
'DBMS_LDAP: LDAP operation ' as e64,
'wait for FMON to come up' as e65,
'enq: FM - contention' as e66,
'enq: XY - contention' as e67,
'set director factor wait' as e68,
'latch: active service list' as e69,
'enq: AS - service activation' as e70,
'enq: PD - contention' as e71,
'cleanup of aborted process' as e72,
'enq: RU - contention' as e73,
'enq: RU - waiting' as e74,
'rolling migration: cluster quiesce' as e75,
'LMON global data update' as e76,
'process diagnostic dump' as e77,
'enq: MX - sync storage server info' as e78,
'master diskmon startup' as e79,
'master diskmon read' as e80,
'DSKM to complete cell health check' as e81,
'pmon dblkr tst event' as e82,
'latch: ges resource hash list' as e83,
'DFS lock handle' as e84,
'ges LMD to shutdown' as e85,
'ges client process to exit' as e86,
'ges global resource directory to be frozen' as e87,
'ges resource directory to be unfrozen' as e88,
'gcs resource directory to be unfrozen' as e89,
'ges LMD to inherit communication channels' as e90,
'ges lmd sync during reconfig' as e91,
'ges wait for lmon to be ready' as e92,
'ges cgs registration' as e93,
'wait for master scn' as e94,
'ges yield cpu in reconfig' as e95,
'ges2 proc latch in rm latch get 1' as e96,
'ges2 proc latch in rm latch get 2' as e97,
'ges lmd/lmses to freeze in rcfg' as e98,
'ges lmd/lmses to unfreeze in rcfg' as e99,
'ges lms sync during dynamic remastering and reconfig' as e100,
'ges LMON to join CGS group' as e101,
'ges pmon to exit' as e102,
'ges lmd and pmon to attach' as e103,
'gcs drm freeze begin' as e104,
'gcs retry nowait latch get' as e105,
'gcs remastering wait for read latch' as e106,
'ges cached resource cleanup' as e107,
'ges generic event' as e108,
'ges retry query node' as e109,
'ges process with outstanding i/o' as e110,
'ges user error' as e111,
'ges enter server mode' as e112,
'gcs enter server mode' as e113,
'gcs drm freeze in enter server mode' as e114,
'gcs ddet enter server mode' as e115,
'ges cancel' as e116,
'ges resource cleanout during enqueue open' as e117,
'ges resource cleanout during enqueue open-cvt' as e118,
'ges master to get established for SCN op' as e119,
'ges LMON to get to FTDONE ' as e120,
'ges1 LMON to wake up LMD - mrcvr' as e121,
'ges2 LMON to wake up LMD - mrcvr' as e122,
'ges2 LMON to wake up lms - mrcvr 2' as e123,
'ges2 LMON to wake up lms - mrcvr 3' as e124,
'ges inquiry response' as e125,
'ges reusing os pid' as e126,
'ges LMON for send queues' as e127,
'ges LMD suspend for testing event' as e128,
'ges performance test completion' as e129,
'kjbopen wait for recovery domain attach' as e130,
'kjudomatt wait for recovery domain attach' as e131,
'kjudomdet wait for recovery domain detach' as e132,
'kjbdomalc allocate recovery domain - retry' as e133,
'kjbdrmcvtq lmon drm quiesce: ping completion' as e134,
'ges RMS0 retry add redo log' as e135,
'readable standby redo apply remastering' as e136,
'ges DFS hang analysis phase 2 acks' as e137,
'ges/gcs diag dump' as e138,
'global plug and play automatic resource creation' as e139,
'gcs lmon dirtydetach step completion' as e140,
'recovery instance recovery completion ' as e141,
'ack for a broadcasted res from a remote instance' as e142,
'KJC: Wait for msg sends to complete' as e143,
'ges message buffer allocation' as e144,
'kjctssqmg: quick message send wait' as e145,
'kjctcisnd: Queue/Send client message' as e146,
'gcs domain validation' as e147,
'latch: gcs resource hash' as e148,
'affinity expansion in replay' as e149,
'wait for sync ack' as e150,
'wait for verification ack' as e151,
'wait for assert messages to be sent' as e152,
'wait for scn ack' as e153,
'lms flush message acks' as e154,
'name-service call wait' as e155,
'CGS wait for IPC msg' as e156,
'kjxgrtest' as e157,
'IMR mount phase II completion' as e158,
'IMR disk votes' as e159,
'IMR rr lock release' as e160,
'IMR net-check message ack' as e161,
'IMR rr update' as e162,
'IMR membership resolution' as e163,
'IMR CSS join retry' as e164,
'CGS skgxn join retry' as e165,
'gcs to be enabled' as e166,
'gcs log flush sync' as e167,
'GCR ctx lock acquisition' as e168,
'GCR lock acquisition' as e169,
'GCR CSS join retry' as e170,
'GCR member Data from CSS ' as e171,
'SGA: allocation forcing component growth' as e172,
'SGA: sga_target resize' as e173,
'control file heartbeat' as e174,
'control file diagnostic dump' as e175,
'enq: CF - contention' as e176,
'enq: SW - contention' as e177,
'enq: DS - contention' as e178,
'enq: TC - contention' as e179,
'enq: TC - contention2' as e180,
'buffer exterminate' as e181,
'buffer resize' as e182,
'latch: cache buffers lru chain' as e183,
'enq: PW - perwarm status in dbw0' as e184,
'latch: checkpoint queue latch' as e185,
'latch: cache buffer handles' as e186,
'kcbzps' as e187,
'DBWR range invalidation sync' as e188,
'buffer deadlock' as e189,
'buffer latch' as e190,
'cr request retry' as e191,
'writes stopped by instance recovery or database suspension' as e192,
'lock escalate retry' as e193,
'lock deadlock retry' as e194,
'prewarm transfer retry' as e195,
'recovery buffer pinned' as e196,
'TSE master key rekey' as e197,
'TSE SSO wallet reopen' as e198,
'enq: CR - block range reuse ckpt' as e199,
'wait for MTTR advisory state object' as e200,
'latch: object queue header operation' as e201,
'Wait on stby instance close' as e202,
'ARCH wait for archivelog lock' as e203,
'enq: WL - Test access/locking' as e204,
'FAL archive wait 1 sec for REOPEN minimum' as e205,
'TEST: action sync' as e206,
'TEST: action hang' as e207,
'RSGA: RAC reconfiguration' as e208,
'enq: WL - RAC-wide SGA contention' as e209,
'LGWR ORL/NoExp FAL archival' as e210,
'MRP wait on process start' as e211,
'MRP wait on process restart' as e212,
'MRP wait on startup clear' as e213,
'MRP inactivation' as e214,
'MRP termination' as e215,
'MRP state inspection' as e216,
'MRP wait on archivelog arrival' as e217,
'MRP wait on archivelog archival' as e218,
'log switch/archive' as e219,
'ARCH wait on c/f tx acquire 1' as e220,
'RFS attach' as e221,
'RFS create' as e222,
'RFS close' as e223,
'RFS announce' as e224,
'RFS register' as e225,
'RFS detach' as e226,
'RFS ping' as e227,
'RFS dispatch' as e228,
'enq: WL - RFS global state contention' as e229,
'LGWR simulation latency wait' as e230,
'LNS simulation latency wait' as e231,
'Data Guard: RFS disk I/O' as e232,
'ARCH wait for process start 1' as e233,
'ARCH wait for process death 1' as e234,
'ARCH wait for process start 3' as e235,
'Data Guard: process exit' as e236,
'Data Guard: process clean up' as e237,
'LGWR-LNS wait on channel' as e238,
'enq: WR - contention' as e239,
'LGWR wait for redo copy' as e240,
'latch: redo allocation' as e241,
'log file switch (clearing log file)' as e242,
'enq: WL - contention' as e243,
'enq: RN - contention' as e244,
'DFS db file lock' as e245,
'enq: DF - contention' as e246,
'enq: IS - contention' as e247,
'enq: FS - contention' as e248,
'enq: DM - contention' as e249,
'enq: RP - contention' as e250,
'latch: gc element' as e251,
'enq: RT - contention' as e252,
'enq: RT - thread internal enable/disable' as e253,
'enq: IR - contention' as e254,
'enq: IR - contention2' as e255,
'enq: MR - contention' as e256,
'enq: MR - standby role transition' as e257,
'shutdown after switchover to standby' as e258,
'parallel recovery coord wait for reply' as e259,
'parallel recovery coord send blocked' as e260,
'parallel recovery slave wait for change' as e261,
'enq: BR - file shrink' as e262,
'enq: BR - proxy-copy' as e263,
'enq: BR - multi-section restore header' as e264,
'enq: BR - multi-section restore section' as e265,
'enq: BR - space info datafile hdr update' as e266,
'enq: BR - request autobackup' as e267,
'enq: BR - perform autobackup' as e268,
'enq: ID - contention' as e269,
'Backup Restore Throttle sleep' as e270,
'Backup Restore Switch Bitmap sleep' as e271,
'Backup Restore Event 19778 sleep' as e272,
'enq: AB - ABMR process start/stop' as e273,
'enq: AB - ABMR process initialized' as e274,
'Auto BMR completion' as e275,
'Auto BMR RPC standby catchup' as e276,
'enq: MN - contention' as e277,
'enq: PL - contention' as e278,
'enq: SB - logical standby metadata' as e279,
'enq: SB - table instantiation' as e280,
'Logical Standby Apply shutdown' as e281,
'Logical Standby pin transaction' as e282,
'Logical Standby dictionary build' as e283,
'Logical Standby Terminal Apply' as e284,
'Logical Standby Debug' as e285,
'Resolution of in-doubt txns' as e286,
'enq: XR - quiesce database' as e287,
'enq: XR - database force logging' as e288,
'standby query scn advance' as e289,
'change tracking file synchronous read' as e290,
'change tracking file synchronous write' as e291,
'change tracking file parallel write' as e292,
'block change tracking buffer space' as e293,
'CTWR media recovery checkpoint request' as e294,
'enq: CT - global space management' as e295,
'enq: CT - local space management' as e296,
'enq: CT - change stream ownership' as e297,
'enq: CT - state' as e298,
'enq: CT - state change gate 1' as e299,
'enq: CT - state change gate 2' as e300,
'enq: CT - CTWR process start/stop' as e301,
'enq: CT - reading' as e302,
'recovery area: computing dropped files' as e303,
'recovery area: computing obsolete files' as e304,
'recovery area: computing backed up files' as e305,
'recovery area: computing applied logs' as e306,
'enq: RS - file delete' as e307,
'enq: RS - record reuse' as e308,
'enq: RS - prevent file delete' as e309,
'enq: RS - prevent aging list update' as e310,
'enq: RS - persist alert level' as e311,
'enq: RS - read alert level' as e312,
'enq: RS - write alert level' as e313,
'enq: FL - Flashback database log' as e314,
'enq: FL - Flashback db command' as e315,
'enq: FD - Marker generation' as e316,
'enq: FD - Tablespace flashback on/off' as e317,
'enq: FD - Flashback coordinator' as e318,
'enq: FD - Flashback on/off' as e319,
'enq: FD - Restore point create/drop' as e320,
'enq: FD - Flashback logical operations' as e321,
'flashback free VI log' as e322,
'flashback log switch' as e323,
'RVWR wait for flashback copy' as e324,
'parallel recovery read buffer free' as e325,
'parallel recovery change buffer free' as e326,
'cell smart flash unkeep' as e327,
'datafile move cleanup during resize' as e328,
'blocking txn id for DDL' as e329,
'transaction' as e330,
'inactive transaction branch' as e331,
'txn to complete' as e332,
'PMON to cleanup pseudo-branches at svc stop time' as e333,
'PMON to cleanup detached branches at shutdown' as e334,
'test long ops' as e335,
'latch: undo global data' as e336,
'undo segment recovery' as e337,
'unbound tx' as e338,
'wait for change' as e339,
'wait for another txn - undo rcv abort' as e340,
'wait for another txn - txn abort' as e341,
'wait for another txn - rollback to savepoint' as e342,
'undo_retention publish retry' as e343,
'enq: TA - contention' as e344,
'enq: TX - contention' as e345,
'enq: US - contention' as e346,
'wait for stopper event to be increased' as e347,
'wait for a undo record' as e348,
'wait for a paralle reco to abort' as e349,
'enq: IM - contention for blr' as e350,
'enq: TD - KTF dump entries' as e351,
'enq: TE - KTF broadcast' as e352,
'enq: CN - race with txn' as e353,
'enq: CN - race with reg' as e354,
'enq: CN - race with init' as e355,
'latch: Change Notification Hash table latch' as e356,
'enq: CO - master slave det' as e357,
'enq: FE - contention' as e358,
'latch: change notification client cache latch' as e359,
'enq: TF - contention' as e360,
'latch: lob segment hash table latch' as e361,
'latch: lob segment query latch' as e362,
'latch: lob segment dispenser latch' as e363,
'Wait for shrink lock2' as e364,
'Wait for shrink lock' as e365,
'L1 validation' as e366,
'Wait for TT enqueue' as e367,
'kttm2d' as e368,
'ktsambl' as e369,
'ktfbtgex' as e370,
'enq: DT - contention' as e371,
'enq: TS - contention' as e372,
'enq: FB - contention' as e373,
'enq: SK - contention' as e374,
'enq: DW - contention' as e375,
'enq: SU - contention' as e376,
'enq: TT - contention' as e377,
'ktm: instance recovery' as e378,
'instance state change' as e379,
'enq: SJ - Slave Task Cancel' as e380,
'Space Manager: slave messages' as e381,
'index block split' as e382,
'kdblil wait before retrying ORA-54' as e383,
'dupl. cluster key' as e384,
'kdic_do_merge' as e385,
'enq: DL - contention' as e386,
'enq: HQ - contention' as e387,
'enq: HP - contention' as e388,
'enq: WG - delete fso' as e389,
'enq: SL - get lock' as e390,
'enq: SL - escalate lock' as e391,
'enq: SL - get lock for undo' as e392,
'enq: ZH - compression analysis' as e393,
'Compression analysis' as e394,
'row cache cleanup' as e395,
'row cache process' as e396,
'enq: DV - contention' as e397,
'enq: SO - contention' as e398,
'enq: TP - contention' as e399,
'enq: RW - MV metadata contention' as e400,
'enq: OC - contention' as e401,
'enq: OL - contention' as e402,
'kkdlgon' as e403,
'kkdlsipon' as e404,
'kkdlhpon' as e405,
'kgltwait' as e406,
'kksfbc research' as e407,
'kksscl hash split' as e408,
'kksfbc child completion' as e409,
'enq: CU - contention' as e410,
'enq: AE - lock' as e411,
'enq: PF - contention' as e412,
'enq: IL - contention' as e413,
'enq: CL - drop label' as e414,
'enq: CL - compare labels' as e415,
'enq: MK - contention' as e416,
'enq: OW - initialization' as e417,
'enq: OW - termination' as e418,
'enq: RK - set key' as e419,
'enq: RL - RAC wallet lock' as e420,
'enq: ZZ - update hash tables' as e421,
'enq: ZA - add std audit table partition' as e422,
'enq: ZF - add fga audit table partition' as e423,
'enq: DX - contention' as e424,
'enq: DR - contention' as e425,
'pending global transaction(s)' as e426,
'free global transaction table entry' as e427,
'library cache revalidation' as e428,
'library cache shutdown' as e429,
'BFILE closure' as e430,
'BFILE check if exists' as e431,
'BFILE check if open' as e432,
'BFILE get length' as e433,
'BFILE get name object' as e434,
'BFILE get path object' as e435,
'BFILE open' as e436,
'BFILE internal seek' as e437,
'waiting to get CAS latch' as e438,
'waiting to get RM CAS latch' as e439,
'resmgr:internal state cleanup' as e440,
'xdb schema cache initialization' as e441,
'ASM cluster file access' as e442,
'CSS initialization' as e443,
'CSS group registration' as e444,
'CSS group membership query' as e445,
'CSS operation: data query' as e446,
'CSS operation: data update' as e447,
'CSS Xgrp shared operation' as e448,
'CSS operation: query' as e449,
'CSS operation: action' as e450,
'CSS operation: diagnostic' as e451,
'GIPC operation: dump' as e452,
'GPnP Initialization' as e453,
'GPnP Termination' as e454,
'GPnP Get Item' as e455,
'GPnP Set Item' as e456,
'GPnP Get Error' as e457,
'ADR file lock' as e458,
'ADR block file read' as e459,
'ADR block file write' as e460,
'CRS call completion' as e461,
'dispatcher shutdown' as e462,
'listener registration dump' as e463,
'latch: virtual circuit queues' as e464,
'listen endpoint status' as e465,
'OJVM: Generic' as e466,
'select wait' as e467,
'jobq slave shutdown wait' as e468,
'jobq slave TJ process wait' as e469,
'job scheduler coordinator slave wait' as e470,
'enq: JD - contention' as e471,
'enq: JQ - contention' as e472,
'enq: OD - Serializing DDLs' as e473,
'kkshgnc reloop' as e474,
'optimizer stats update retry' as e475,
'wait active processes' as e476,
'SUPLOG PL wait for inflight pragma-d PL/SQL' as e477,
'enq: MD - contention' as e478,
'enq: MS - contention' as e479,
'wait for kkpo ref-partitioning *TEST EVENT*' as e480,
'enq: AP - contention' as e481,
'PX slave connection' as e482,
'PX slave release' as e483,
'PX Send Wait' as e484,
'PX qref latch' as e485,
'PX server shutdown' as e486,
'PX create server' as e487,
'PX signal server' as e488,
'PX Deq Credit: free buffer' as e489,
'PX Deq: Test for msg' as e490,
'PX Deq: Test for credit' as e491,
'PX Deq: Signal ACK RSG' as e492,
'PX Deq: Signal ACK EXT' as e493,
'PX Deq: reap credit' as e494,
'PX Nsq: PQ descriptor query' as e495,
'PX Nsq: PQ load info query' as e496,
'PX Deq Credit: Session Stats' as e497,
'PX Deq: Slave Session Stats' as e498,
'PX Deq: Slave Join Frag' as e499,
'enq: PI - contention' as e500,
'enq: PS - contention' as e501,
'latch: parallel query alloc buffer' as e502,
'kxfxse' as e503,
'kxfxsp' as e504,
'PX Deq: Table Q qref' as e505,
'PX Deq: Table Q Get Keys' as e506,
'PX Deq: Table Q Close' as e507,
'GV$: slave acquisition retry wait time' as e508,
'PX hash elem being inserted' as e509,
'latch: PX hash array latch' as e510,
'enq: AY - contention' as e511,
'enq: TO - contention' as e512,
'enq: IT - contention' as e513,
'enq: BF - allocation contention' as e514,
'enq: BF - PMON Join Filter cleanup' as e515,
'enq: RD - RAC load' as e516,
'timer in sksawat' as e517,
'scginq AST call' as e518,
'kupp process wait' as e519,
'Kupp process shutdown' as e520,
'Data Pump slave startup' as e521,
'Data Pump slave init' as e522,
'enq: KP - contention' as e523,
'Replication Dequeue ' as e524,
'knpc_acwm_AwaitChangedWaterMark' as e525,
'knpc_anq_AwaitNonemptyQueue' as e526,
'knpsmai' as e527,
'enq: SR - contention' as e528,
'Streams capture: waiting for database startup' as e529,
'Streams miscellaneous event' as e530,
'enq: SI - contention' as e531,
'Streams: RAC waiting for inter instance ack' as e532,
'enq: IA - contention' as e533,
'enq: JI - contention' as e534,
'qerex_gdml' as e535,
'enq: AT - contention' as e536,
'opishd' as e537,
'kpodplck wait before retrying ORA-54' as e538,
'enq: CQ - contention' as e539,
'Streams AQ: emn coordinator waiting for slave to start' as e540,
'wait for EMON to spawn' as e541,
'EMON termination' as e542,
'EMON slave messages' as e543,
'enq: SE - contention' as e544,
'tsm with timeout' as e545,
'Streams AQ: waiting for busy instance for instance_name' as e546,
'enq: TQ - TM contention' as e547,
'enq: TQ - DDL contention' as e548,
'enq: TQ - INI contention' as e549,
'enq: TQ - DDL-INI contention' as e550,
'AQ propagation connection' as e551,
'enq: DP - contention' as e552,
'enq: MH - contention' as e553,
'enq: ML - contention' as e554,
'enq: PH - contention' as e555,
'enq: SF - contention' as e556,
'enq: XH - contention' as e557,
'enq: WA - contention' as e558,
'Streams AQ: QueueTable kgl locks' as e559,
'AQ spill debug idle' as e560,
'queue slave messages' as e561,
'Streams AQ: qmn coordinator waiting for slave to start' as e562,
'enq: CX - TEXT: Index Specific Lock' as e563,
'enq: OT - TEXT: Generic Lock' as e564,
'XDB SGA initialization' as e565,
'enq: XC - XDB Configuration' as e566,
'NFS read delegation outstanding' as e567,
'Data Guard Broker Wait' as e568,
'enq: RF - synch: DG Broker metadata' as e569,
'enq: RF - atomicity' as e570,
'enq: RF - synchronization: aifo master' as e571,
'enq: RF - new AI' as e572,
'enq: RF - synchronization: critical ai' as e573,
'enq: RF - RF - Database Automatic Disable' as e574,
'enq: RF - FSFO Observer Heartbeat' as e575,
'enq: RF - DG Broker Current File ID' as e576,
'enq: RF - FSFO Primary Shutdown suspended' as e577,
'PX Deq: OLAP Update Reply' as e578,
'PX Deq: OLAP Update Execute' as e579,
'PX Deq: OLAP Update Close' as e580,
'OLAP Parallel Type Deq' as e581,
'OLAP Parallel Temp Grow Request' as e582,
'OLAP Parallel Temp Grow Wait' as e583,
'OLAP Parallel Temp Grew' as e584,
'OLAP Null PQ Reason' as e585,
'OLAP Aggregate Master Enq' as e586,
'OLAP Aggregate Client Enq' as e587,
'OLAP Aggregate Master Deq' as e588,
'OLAP Aggregate Client Deq' as e589,
'enq: AW - AW$ table lock' as e590,
'enq: AW - AW state lock' as e591,
'enq: AW - user access for AW' as e592,
'enq: AW - AW generation lock' as e593,
'enq: AG - contention' as e594,
'enq: AO - contention' as e595,
'enq: OQ - xsoqhiAlloc' as e596,
'enq: OQ - xsoqhiFlush' as e597,
'enq: OQ - xsoq*histrecb' as e598,
'enq: OQ - xsoqhiClose' as e599,
'enq: OQ - xsoqhistrecb' as e600,
'enq: AM - client registration' as e601,
'enq: AM - shutdown' as e602,
'enq: AM - rollback COD reservation' as e603,
'enq: AM - background COD reservation' as e604,
'enq: AM - ASM cache freeze' as e605,
'enq: AM - ASM ACD Relocation' as e606,
'enq: AM - group use' as e607,
'enq: AM - group block' as e608,
'enq: AM - ASM File Destroy' as e609,
'enq: AM - ASM User' as e610,
'enq: AM - ASM Password File Update' as e611,
'enq: AM - ASM Amdu Dump' as e612,
'enq: AM - disk offline' as e613,
'enq: AM - ASM reserved' as e614,
'enq: AM - block repair' as e615,
'enq: AM - ASM disk based alloc/dealloc' as e616,
'enq: AM - ASM file descriptor' as e617,
'enq: AM - ASM file relocation' as e618,
'enq: AM - ASM Grow ACD' as e619,
'ASM internal hang test' as e620,
'ASM Instance startup' as e621,
'buffer busy' as e622,
'buffer freelistbusy' as e623,
'buffer rememberlist busy' as e624,
'buffer writeList full' as e625,
'no free buffers' as e626,
'buffer write wait' as e627,
'buffer invalidation wait' as e628,
'buffer dirty disabled' as e629,
'ASM metadata cache frozen' as e630,
'enq: CM - gate' as e631,
'enq: CM - instance' as e632,
'enq: CM - diskgroup dismount' as e633,
'enq: XQ - recovery' as e634,
'enq: XQ - relocation' as e635,
'enq: XQ - purification' as e636,
'enq: AD - allocate AU' as e637,
'enq: AD - deallocate AU' as e638,
'enq: AD - relocate AU' as e639,
'enq: DO - disk online' as e640,
'enq: DO - disk online recovery' as e641,
'enq: DO - Staleness Registry create' as e642,
'enq: DO - startup of MARK process' as e643,
'enq: DO - disk online operation' as e644,
'extent map load/unlock' as e645,
'enq: XL - fault extent map' as e646,
'Sync ASM rebalance' as e647,
'enq: DG - contention' as e648,
'enq: DD - contention' as e649,
'enq: HD - contention' as e650,
'enq: DN - contention' as e651,
'Cluster stabilization wait' as e652,
'Cluster Suspension wait' as e653,
'ASM background starting' as e654,
'ASM db client exists' as e655,
'ASM file metadata operation' as e656,
'ASM network foreground exits' as e657,
'enq: FA - access file' as e658,
'enq: RX - relocate extent' as e659,
'enq: RX - unlock extent' as e660,
'log write(odd)' as e661,
'log write(even)' as e662,
'checkpoint advanced' as e663,
'enq: FR - contention' as e664,
'enq: FR - use the thread' as e665,
'enq: FR - recover the thread' as e666,
'enq: FG - serialize ACD relocate' as e667,
'enq: FG - FG redo generation enq race' as e668,
'enq: FG - LGWR redo generation enq race' as e669,
'enq: FT - allow LGWR writes' as e670,
'enq: FT - disable LGWR writes' as e671,
'enq: FC - open an ACD thread' as e672,
'enq: FC - recover an ACD thread' as e673,
'enq: FX - issue ACD Xtnt Relocation CIC' as e674,
'rollback operations block full' as e675,
'rollback operations active' as e676,
'enq: RB - contention' as e677,
'ASM: MARK subscribe to msg channel' as e678,
'enq: PT - contention' as e679,
'ASM PST operation' as e680,
'global cache busy' as e681,
'lock release pending' as e682,
'dma prepare busy' as e683,
'GCS lock cancel' as e684,
'GCS lock open S' as e685,
'GCS lock open X' as e686,
'GCS lock open' as e687,
'GCS lock cvt S' as e688,
'GCS lock cvt X' as e689,
'GCS lock esc X' as e690,
'GCS lock esc' as e691,
'GCS recovery lock open' as e692,
'GCS recovery lock convert' as e693,
'kfcl: instance recovery' as e694,
'no free locks' as e695,
'lock close' as e696,
'enq: KQ - access ASM attribute' as e697,
'ASM Volume Background' as e698,
'ASM DG Unblock' as e699,
'enq: AV - persistent DG number' as e700,
'enq: AV - volume relocate' as e701,
'enq: AV - AVD client registration' as e702,
'enq: AV - add/enable first volume in DG' as e703,
'ASM: OFS Cluster membership update' as e704,
'enq: WF - contention' as e705,
'enq: WP - contention' as e706,
'enq: FU - contention' as e707,
'enq: MW - contention' as e708,
'AWR Flush' as e709,
'AWR Metric Capture' as e710,
'enq: TB - SQL Tuning Base Cache Update' as e711,
'enq: TB - SQL Tuning Base Cache Load' as e712,
'enq: SH - contention' as e713,
'enq: AF - task serialization' as e714,
'MMON slave messages' as e715,
'MMON (Lite) shutdown' as e716,
'enq: MO - contention' as e717,
'enq: TL - contention' as e718,
'enq: TH - metric threshold evaluation' as e719,
'enq: TK - Auto Task Serialization' as e720,
'enq: TK - Auto Task Slave Lockout' as e721,
'enq: RR - contention' as e722,
'WCR: RAC message context busy' as e723,
'WCR: capture file IO write' as e724,
'WCR: Sync context busy' as e725,
'latch: WCR: sync' as e726,
'latch: WCR: processes HT' as e727,
'enq: JS - contention' as e728,
'enq: JS - job run lock - synchronize' as e729,
'enq: JS - job recov lock' as e730,
'enq: JS - queue lock' as e731,
'enq: JS - sch locl enqs' as e732,
'enq: JS - q mem clnup lck' as e733,
'enq: JS - evtsub add' as e734,
'enq: JS - evtsub drop' as e735,
'enq: JS - wdw op' as e736,
'enq: JS - evt notify' as e737,
'enq: JS - aq sync' as e738,
'enq: XD - ASM disk drop/add' as e739,
'enq: XD - ASM disk ONLINE' as e740,
'enq: XD - ASM disk OFFLINE' as e741,
'cell worker online completion' as e742,
'cell worker retry ' as e743,
'cell manager cancel work request' as e744,
'secondary event' as e745
)
    )
order by snap_id;


-- For DM: events which time_waited changes, it is not static
select *
from (
with
local_data as (
select S.SNAP_ID as snap_id,
       se.EVENT_ID as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID in ( select inr_SE.EVENT_ID
                        from PERFSTAT.STATS$SNAPSHOT inr_s, PERFSTAT.STATS$SYSTEM_EVENT inr_se
                        where inr_s.dbid=&&v_dbid and inr_S.INSTANCE_NUMBER=1 and inr_S.SNAP_ID between &&v_bsnap and &&v_esnap
                          and inr_S.DBID=inr_se.dbid and inr_S.INSTANCE_NUMBER=inr_SE.INSTANCE_NUMBER and inr_s.snap_id=inr_se.snap_id
                        group by inr_SE.EVENT_ID
                        having variance(inr_SE.TIME_WAITED_MICRO) > 0
                        )
group by S.SNAP_TIME, S.SNAP_ID, SE.EVENT_ID
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
 pivot
 (
  max(value_diff)
  for stat_name in
  (
3176176482 as "3176176482",
4078387448 as "4078387448",
4205197519 as "4205197519",
215477332 as "215477332",
3999721902 as "3999721902",
2867289651 as "2867289651",
1328744198 as "1328744198",
133155944 as "133155944",
2942611488 as "2942611488",
352301881 as "352301881",
1646780882 as "1646780882",
4043670897 as "4043670897",
3401628503 as "3401628503",
4266849434 as "4266849434",
1645217925 as "1645217925",
2900750527 as "2900750527",
58311103 as "58311103",
1989349184 as "1989349184",
1394127552 as "1394127552",
4090013609 as "4090013609",
554161347 as "554161347",
1830121438 as "1830121438",
2587381521 as "2587381521",
906644781 as "906644781",
2326919048 as "2326919048",
86156091 as "86156091",
143262751 as "143262751",
2539661515 as "2539661515",
114164561 as "114164561",
1729366244 as "1729366244",
782339817 as "782339817",
1973577887 as "1973577887",
2505166323 as "2505166323",
295718413 as "295718413",
3539483025 as "3539483025",
1179235204 as "1179235204",
866018717 as "866018717",
2093619153 as "2093619153",
3357856061 as "3357856061",
1403232821 as "1403232821",
1117386924 as "1117386924",
818280116 as "818280116",
2332720660 as "2332720660",
3807851191 as "3807851191",
3412713426 as "3412713426",
2576559565 as "2576559565",
660190475 as "660190475",
3213517201 as "3213517201",
4229542060 as "4229542060",
3834950329 as "3834950329",
506183215 as "506183215",
3926164927 as "3926164927",
2696347763 as "2696347763",
1847483002 as "1847483002",
218992928 as "218992928",
1780066010 as "1780066010",
166678035 as "166678035",
3992632846 as "3992632846",
1055154682 as "1055154682",
3056446529 as "3056446529",
549236675 as "549236675",
310662678 as "310662678",
1714089451 as "1714089451",
916468430 as "916468430",
2952162927 as "2952162927",
266850936 as "266850936",
2701153470 as "2701153470",
2161531084 as "2161531084",
3845123846 as "3845123846",
2652584166 as "2652584166",
885859547 as "885859547",
38438084 as "38438084",
1781586680 as "1781586680",
1421975091 as "1421975091",
1963888671 as "1963888671",
989870553 as "989870553",
4092822979 as "4092822979",
306423829 as "306423829",
2779959231 as "2779959231",
1307477558 as "1307477558",
834992820 as "834992820",
1452455426 as "1452455426",
1786390478 as "1786390478",
2067390145 as "2067390145",
3530226808 as "3530226808",
3474287957 as "3474287957",
1494394835 as "1494394835"
  )
 )
order by snap_id;
--------------------------------------------------------------------------------
-- Given event, by event name

SELECT *
FROM (
with
local_data as (
select S.SNAP_ID as snap_id,
       se.EVENT as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT in (
'db file sequential read','read by other session'
                      )
group by S.SNAP_TIME, S.SNAP_ID, SE.EVENT ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name )
 pivot
 (
  max(value_diff)
  for stat_name in
  (
'db file sequential read' AS db_file_sequental_read,
'read by other session' AS read_by_other_session
  )
 )
order by snap_id;


-- Given events, by their ID-s
select ''''||EN.EVENT_ID||''' as '||regexp_replace(regexp_replace(replace(EN.NAME,' ','_'),'[-:/\(\)]',''),'_{2,}','_')||',' as event_name
from SYS.V_$EVENT_NAME en
where EN.EVENT_ID in ( 133155944,3213517201,310662678 );

select *
from (
with
local_data as (
select S.SNAP_ID as snap_id,
       se.EVENT_ID as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID in (
   4078387448,215477332,2867289651,133155944,114164561,866018717,3357856061,3213517201,549236675,310662678,2161531084,1307477558,1452455426,1494394835
                      )
group by S.SNAP_TIME, S.SNAP_ID, SE.EVENT_ID
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
 pivot
 (
  max(value_diff)
  for stat_name in
  (
'866018717' as rdbms_ipc_message,
'3213517201' as control_file_sequential_read,
'4078387448' as control_file_parallel_write,
'2161531084' as buffer_busy_waits,
'549236675' as log_file_sequential_read,
'215477332' as log_file_single_write,
'3357856061' as log_buffer_space,
'2867289651' as lf_swtch_chckpnt_incmplt,
'114164561' as lf_swtch_pstrnd_flsh_incmplt,
'1307477558' as db_file_single_write,
'133155944' as db_file_async_IO_submit,
'310662678' as enq_TX_row_lock_contention,
'1452455426' as resmgrcpu_quantum,
'1494394835' as enq_CF_contention
  )
 )

order by snap_id;


--------------------------------------------------------------------------------

-- Application class
-- select * from SYS.V_$EVENT_NAME en where EN.WAIT_CLASS='Application'
select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_TIME as snap_time,
       S.SNAP_ID as snap_id,
       en.name as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSTEM_EVENT se,SYS.V_$EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
   and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
   and SE.EVENT_ID=EN.EVENT_ID and EN.WAIT_CLASS='Application'
   --and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.SNAP_TIME, S.SNAP_ID, EN.NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'enq: PW - flush prewarm buffers' as enqPW_flush_prewarm_buffers,
'enq: RO - contention' as eqnRO_contention,
'enq: RO - fast object reuse' as eqnRO_fast_object_reuse,
'enq: KO - fast object checkpoint' as eqnKO_fast_object_checkpoint,
'enq: TM - contention' as eqnTM_contention,
'enq: TX - row lock contention' as eqnTX_row_lock_contention,
'Wait for Table Lock' as Wait_for_Table_Lock,
'enq: RC - Result Cache: Contention' as eqnRC_ResultCacheContention,
'Streams capture: filter callback waiting for ruleset' as StrmsCptrFltrCallbackWt4rlst,
'Streams: apply reader waiting for DDL to apply' as StreamsApplRdrW4DDL2apply,
'SQL*Net break/reset to client' as SQL_Net_break_reset_to_client,
'SQL*Net break/reset to dblink' as SQL_Net_break_reset_to_dblink,
'External Procedure initial connection' as ExtProcInitialConnection,
'External Procedure call' as External_Procedure_call,
'enq: UL - contention' as eqnUL___contention,
'OLAP DML Sleep' as OLAP_DML_Sleep,
'WCR: replay lock order' as WCR__replay_lock_order
)
)
order by snap_id;

-- SQLstat

select  S.SNAP_TIME as snap_time,
        S.SNAP_ID as snap_id,
        --Sum(SQL.CONCURRENCY_WAIT_TIME) as WPR_Value
        --Sum(SQL.cpu_time) as stat_value
        Sum(SQL.disk_reads) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SQL_SUMMARY sql
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SQL.DBID=S.DBID and SQL.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SQL.SNAP_ID=S.SNAP_ID
/*  AND SQL.sql_id NOT IN (
  'b6usrg82hwsa3','6zuxjy7z9xhts','awg9n1dr9a94a','31thrqdtanxs9','7cty4909kxdbp','a973yknzh02hd','2whm2vvjb98k7','5zctks426mb07','dbvkky621gqtr','710vza2n7gy3m','0hhmdwwgxbw0r','751bqx9nnqap5','7m7rpm1f232f2','0r8dpavrq3vk0','fjzu9f12wbj6u','39tn1f1n1xnt2','adnpcdx1xhsrk','49p17gnmj347g','0z0y63pbqh9rp','01qgdjsnfa36g','63p9mc85ba9cw','1cnwnjtwdnwa2','g1bjzwuqcmudu','11t14az9n5nsf','6tunc1gnb481k','8k4jz67wvdvxw'
  )*/
GROUP BY s.snap_time, s.snap_id
order by s.snap_id desc;

with
local_data as (
select  S.SNAP_TIME as snap_time,
        S.SNAP_ID as snap_id,
        --Sum(SQL.disk_reads) as disk_reads
        --Sum(SQL.user_io_wait_time) as user_io_wait_time
        --Sum(SQL.elapsed_time) as stat_value
        Sum(SQL.cpu_time) as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SQL_SUMMARY sql
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SQL.DBID=S.DBID and SQL.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SQL.SNAP_ID=S.SNAP_ID
GROUP BY S.SNAP_TIME, s.snap_id
--ORDER BY s.snap_id
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       --e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1)
ORDER BY e.snap_id;

SELECT *
FROM (
with
local_data as (
select  S.SNAP_TIME as snap_time,
        S.SNAP_ID as snap_id,
        SQL.sql_id AS sql_id,
        --Sum(SQL.disk_reads) as disk_reads
        --Sum(SQL.user_io_wait_time) as user_io_wait_time
        --Sum(SQL.elapsed_time) as stat_value
        SQL.cpu_time as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SQL_SUMMARY sql
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SQL.DBID=S.DBID and SQL.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SQL.SNAP_ID=S.SNAP_ID
  AND SQL.sql_id IN (
'b6usrg82hwsa3','6zuxjy7z9xhts','awg9n1dr9a94a','31thrqdtanxs9','7cty4909kxdbp','a973yknzh02hd','2whm2vvjb98k7','5zctks426mb07','dbvkky621gqtr','710vza2n7gy3m','0hhmdwwgxbw0r','751bqx9nnqap5','7m7rpm1f232f2','0r8dpavrq3vk0','fjzu9f12wbj6u','39tn1f1n1xnt2','adnpcdx1xhsrk','49p17gnmj347g','0z0y63pbqh9rp','01qgdjsnfa36g','63p9mc85ba9cw','1cnwnjtwdnwa2','g1bjzwuqcmudu','11t14az9n5nsf','6tunc1gnb481k','8k4jz67wvdvxw'
  )
--GROUP BY S.SNAP_TIME, s.snap_id, SQL.sql_id
--ORDER BY s.snap_id
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.sql_id AS sql_id,
       --e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1)
 )
pivot (
 Max(value_diff)
 FOR sql_id IN (
'b6usrg82hwsa3' as qb6usrg82hwsa3,
'6zuxjy7z9xhts' as q6zuxjy7z9xhts,
'awg9n1dr9a94a' as qawg9n1dr9a94a,
'31thrqdtanxs9' as q31thrqdtanxs9,
'7cty4909kxdbp' as q7cty4909kxdbp,
'a973yknzh02hd' as qa973yknzh02hd,
'2whm2vvjb98k7' as q2whm2vvjb98k7,
'5zctks426mb07' as q5zctks426mb07,
'dbvkky621gqtr' as qdbvkky621gqtr,
'710vza2n7gy3m' as q710vza2n7gy3m,
'0hhmdwwgxbw0r' as q0hhmdwwgxbw0r,
'751bqx9nnqap5' as q751bqx9nnqap5,
'7m7rpm1f232f2' as q7m7rpm1f232f2,
'0r8dpavrq3vk0' as q0r8dpavrq3vk0,
'fjzu9f12wbj6u' as qfjzu9f12wbj6u,
'39tn1f1n1xnt2' as q39tn1f1n1xnt2,
'adnpcdx1xhsrk' as qadnpcdx1xhsrk,
'49p17gnmj347g' as q49p17gnmj347g,
'0z0y63pbqh9rp' as q0z0y63pbqh9rp,
'01qgdjsnfa36g' as q01qgdjsnfa36g,
'63p9mc85ba9cw' as q63p9mc85ba9cw,
'1cnwnjtwdnwa2' as q1cnwnjtwdnwa2,
'g1bjzwuqcmudu' as qg1bjzwuqcmudu,
'11t14az9n5nsf' as q11t14az9n5nsf,
'6tunc1gnb481k' as q6tunc1gnb481k,
'8k4jz67wvdvxw' as q8k4jz67wvdvxw
  )
)
ORDER BY snap_id;


select  snap_time, snap_id, sql_id,
        round(ctime_by_snap_id/ttime_by_snap_id,4) as part_from_ttime
from (
select  snap_time, snap_id,
        sql_id,
        sum(APPLICATION_WAIT_TIME) over (order by snap_id) as ttime_by_snap_id,
        sum(APPLICATION_WAIT_TIME) over (order by snap_id rows between unbounded preceding and current row) as ctime_by_snap_id
from (
select  to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_ID as snap_id,
        SQL.SQL_ID as sql_id,
        SQL.APPLICATION_WAIT_TIME as APPLICATION_WAIT_TIME
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SQL_SUMMARY sql
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SQL.DBID=S.DBID and SQL.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SQL.SNAP_ID=S.SNAP_ID
  and SQL.APPLICATION_WAIT_TIME > 0
order by s.snap_id, SQL.APPLICATION_WAIT_TIME desc
)
 )
 where ctime_by_snap_id/ttime_by_snap_id <= 0.9;


select  T.sql_id, T.PIECE, T.SQL_TEXT
from PERFSTAT.STATS$SQLTEXT t
where T.SQL_ID in ( 'b6usrg82hwsa3','6zuxjy7z9xhts','awg9n1dr9a94a','31thrqdtanxs9','7cty4909kxdbp','a973yknzh02hd','2whm2vvjb98k7','5zctks426mb07','dbvkky621gqtr','710vza2n7gy3m','0hhmdwwgxbw0r','751bqx9nnqap5','7m7rpm1f232f2','0r8dpavrq3vk0','fjzu9f12wbj6u','39tn1f1n1xnt2','adnpcdx1xhsrk','49p17gnmj347g','0z0y63pbqh9rp','01qgdjsnfa36g','63p9mc85ba9cw','1cnwnjtwdnwa2','g1bjzwuqcmudu','11t14az9n5nsf','6tunc1gnb481k','8k4jz67wvdvxw' )
order by T.SQL_ID, T.PIECE;

SELECT *
FROM stats$sqltext t
WHERE t.old_hash_value=177778982;

SELECT *
FROM stats$sql_plan_usage t
WHERE t.old_hash_value=301587701
ORDER BY t.snap_id;

SELECT *
FROM perfstat.stats$sql_plan t
WHERE t.plan_hash_value=758538904;

-- OSStat data --
-- SELECT * FROM PERFSTAT.STATS$OSSTAT t;
-- select * from PERFSTAT.STATS$OSSTATNAME sn order by sn.osstat_id;
select *
from (
with local_data as (
select  --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_TIME AS snap_time,
        s.snap_id as snap_id,
        ST.VALUE as stat_value,
        SN.STAT_NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$OSSTAT st, PERFSTAT.STATS$OSSTATNAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and ST.DBID=S.DBID and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and ST.SNAP_ID=S.SNAP_ID
    and ST.OSSTAT_ID=SN.OSSTAT_ID
    and SN.STAT_NAME in ('OS_CPU_WAIT_TIME','RSRC_MGR_CPU_WAIT_TIME','BUSY_TIME','IDLE_TIME','IOWAIT_TIME','USER_TIME','SYS_TIME','VM_IN_BYTES','VM_OUT_BYTES')
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 )
pivot (
max(value_diff)
for stat_name in (
'OS_CPU_WAIT_TIME' as OS_CPU_WAIT_TIME,
'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,
'BUSY_TIME' as BUSY_TIME,
'IDLE_TIME' as IDLE_TIME,
'IOWAIT_TIME' as IOWAIT_TIME,
'USER_TIME' as USER_TIME,
'SYS_TIME' as SYS_TIME,
'VM_IN_BYTES' as VM_IN_BYTES,
'VM_OUT_BYTES' as VM_OUT_BYTES
)
 )
order by snap_id;

SELECT *
FROM (
select  S.SNAP_TIME AS snap_time,
        s.snap_id as snap_id,
        ST.VALUE as stat_value,
        SN.STAT_NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$OSSTAT st, PERFSTAT.STATS$OSSTATNAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and ST.DBID=S.DBID and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and ST.SNAP_ID=S.SNAP_ID
    and ST.OSSTAT_ID=SN.OSSTAT_ID
    and SN.STAT_NAME in ('LOAD','FREE_MEMORY_BYTES','INACTIVE_MEMORY_BYTES','SWAP_FREE_BYTES','TCP_SEND_SIZE_MIN','TCP_SEND_SIZE_MAX','TCP_RECEIVE_SIZE_MIN','TCP_RECEIVE_SIZE_MAX')
 )
pivot (
 Max(stat_value)
 FOR stat_name IN (
'LOAD' AS load,
'FREE_MEMORY_BYTES' AS free_mem_bytes,
'INACTIVE_MEMORY_BYTES' AS inactive_mem_bytes,
'SWAP_FREE_BYTES' AS swap_free_bytes,
'TCP_SEND_SIZE_MIN' AS tcp_send_size_min,
'TCP_SEND_SIZE_MAX' AS tcp_send_size_max,
'TCP_RECEIVE_SIZE_MIN' AS tcp_receive_size_min,
'TCP_RECEIVE_SIZE_MAX' AS tcp_receive_size_max
  )
)
ORDER BY snap_id asc
;



-----------------

-- SGA stat --
select distinct SGAST.POOL
from PERFSTAT.STATS$SGASTAT sgast;

select *
from (
with local_data as (
select  to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        s.snap_id as snap_id,
        decode(SGAST.NAME,'free memory',SGAST.POOL,SGAST.NAME) as stat_name,
        SGAST.BYTES as stat_value
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SGASTAT sgast
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and SGAST.DBID=S.DBID and SGAST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SGAST.SNAP_ID=S.SNAP_ID
    and SGAST.NAME in ('free memory','buffer_cache')
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 )
 pivot (
max(value_diff)
for stat_name in (
'buffer_cache' as buffer_cache,
'java pool' as java_pool,
'streams pool' as streams_pool,
'shared pool' as shared_pool,
'large pool' as large_pool
)
 )
order by snap_id;
--------------

-- undo stat
SELECT s.snap_time as snap_time,
       s.snap_id AS snap_id,
       u.activeblks ,
       u.unexpiredblks,
       u.expiredblks,
       u.maxconcurrency,
       u.unxpstealcnt,
       u.expstealcnt
FROM PERFSTAT.stats$undostat u, PERFSTAT.STATS$SNAPSHOT s
WHERE s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  AND u.DBID=s.dbid and u.INSTANCE_NUMBER=S.INSTANCE_NUMBER and u.snap_id=s.snap_id
ORDER BY u.end_time
;
--------------

-- Load profile
select  snap_time as snap_time,
         snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_time as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.name as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st, SYS.V_$STATNAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.STATISTIC#=sn.STATISTIC# and SN.NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
--  order by s.snap_id desc
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'execute count' as executions,
'logons cumulative' as logons,
'sorts (memory)' as memory_sorts,
'sorts (disk)' as disk_sorts,
'parse count (hard)' as hard_parses,
'parse count (total)' as parses,
'user calls' as user_calls,
'physical reads' as physical_reads,
'physical writes' as physical_writes,
'db block changes' as block_changes,
'session logical reads' as logical_reads,
'redo size' as redo_size,
'user commits' as user_commit,
'user rollbacks' as user_rollback)
 )
order by snap_id;


-- Physical Reads stats
select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_time as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and St.NAME in (
'physical writes','physical read total IO requests','physical read total multi block requests','physical reads','physical reads cache','physical read flash cache hits','physical reads direct','physical reads direct temporary tablespace','physical reads cache prefetch','physical reads prefetch warmup','physical reads retry corrupt','physical reads direct (lob)'
  ) ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical writes' AS phw,
'physical read total IO requests' as totalIO,
'physical read total multi block requests' as total_mblckIO,
'physical reads' as phr,
'physical reads cache' as phr_cache,
'physical read flash cache hits' as phr_flash_cache_hits,
'physical reads direct' as phr_direct,
'physical reads direct temporary tablespace' as phr_direct_tmp_tblspc,
'physical reads cache prefetch' as phr_cache_prefetch,
'physical reads prefetch warmup' as phr_prefetch_warmup,
'physical reads retry corrupt' as phr_retry_corrupt,
'physical reads direct (lob)' as phr_direct_lob
)
 )
order by snap_id;


-- Physical IO stats
select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_time as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and St.NAME in (
'physical read IO requests','physical read requests optimized','physical read total IO requests','physical read total multi block requests','physical write IO requests','physical write total IO requests','physical write total multi block requests'
  ) ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read IO requests' as pr_IO_rqsts,
'physical read requests optimized' as pr_rqsts_optimized,
'physical read total IO requests' as pr_ttl_IO_rqsts,
'physical read total multi block requests' as pr_total_mlt_blck_rqsts,
'physical write IO requests' as pw_IO_rqsts,
'physical write total IO requests' as pw_ttl_IO_rqsts,
'physical write total multi block requests' as pw_ttl_mlt_blck_rqsts
)
 )
order by snap_id;
--------------------------------------------------------------------------------


-- AllStat
SELECT  --snap_id,
        stat_name,
        Round(StdDev(stat_value),2) AS sd_stat_value
FROM (
select s.snap_id as snap_id,
       Nvl(ST.Value,0) as stat_value,
       St.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  )
  HAVING StdDev(stat_value) > 0
  GROUP BY stat_name;

SELECT t.name AS stat_name,
       t.STATISTIC# AS stat_id
FROM sys.v_$statname t
WHERE 1=1
/*AND t.name IN (
'buffer is not pinned count','LOB table id lookup cache misses','parse count (describe)','bytes sent via SQL*Net to client','user calls','recursive cpu usage','session uga memory','enqueue conversions','enqueue releases','consistent gets - examination','consistent gets direct','db block changes','consistent changes','physical write IO requests','DBWR thread checkpoint buffers written','DBWR checkpoints','hot buffers moved to head of LRU','commit cleanout failures: block lost','commit cleanouts','physical reads direct (lob)','redo entries','redo size','redo KB read for transport','index crx upgrade (positioned)','lob reads','index fetch by key','HSC OLTP Compressed Blocks','HSC OLTP negative compression','java call heap object count','java call heap live object count max','java call heap collected count','table fetch by rowid','table fetch continued row','rows fetched via callback','Effective IO time','Batched IO single block count','cleanouts and rollbacks - consistent read gets','rollback changes - undo records applied','active txn count during cleanout','commit batch requested','IMU undo allocation size','cursor authentications','bytes received via SQL*Net from client','sorts (rows)','user rollbacks','DB time','process last non-idle time','session uga memory max','cell physical IO interconnect bytes','physical writes direct temporary tablespace','DBWR revisited being-written buffer','redo log space requests','redo log space wait time','redo synch writes','redo KB read (memory)','root node splits','heap block compress','java call heap total size max','java call heap used size max','java session heap used size max','total number of times SMON posted','Number of read IOs issued','background checkpoints started','Batched IO (full) vector count','Batched IO slow jump count','RowCR hits','commit batch/immediate requested','IMU Flushes','IMU CR rollbacks','java session heap live size max','java session heap live object count','workarea executions - multipass','parse time cpu','opened cursors cumulative','opened cursors current','user I/O wait time','in call idle wait time','enqueue waits','max cf enq hold time','total cf enq hold time','db block gets direct','consistent gets','consistent gets from cache','logical read bytes from cache','physical reads cache','physical reads cache prefetch','physical reads prefetch warmup','redo buffer allocation retries','redo blocks written','redo synch time (usec)','leaf node 90-10 splits','securefile bytes non-transformed','CCursor + sql area evicted','session cursor cache hits','java call heap object count max','TBS Extension: tasks created','SMON posted for dropping temp segment','table scan rows gotten','table scan blocks gotten','redo KB read (memory) for transport','Batched IO (bound) vector count','temp space allocated (bytes)','undo change vector size','RowCR attempts','RowCR - row contention','transaction rollbacks','Commit SCN cached','Block Cleanout Optim referenced','tune down retentions in space pressure','commit batch performed','global undo segment hints were stale','local undo segment hints helped','java session heap object count','Parallel operations downgraded to serial','no buffer to keep pinned count','parse count (total)','bytes via SQL*Net vector to client','Requests to/from client','logons current','CPU used when call started','scheduler wait time','non-idle wait time','session connect time','background timeouts','session pga memory','physical write total multi block requests','physical write total bytes','total number of cf enq holders','physical reads','physical reads direct','physical writes from cache','physical reads direct temporary tablespace','physical write bytes','physical writes non checkpoint','free buffer requested','write clones created in foreground','physical writes direct (lob)','redo wastage','redo synch poll writes','HSC IDL Compressed Blocks','HSC OLTP positive compression','Heap Segment Array Updates','java call heap live size','java call heap live size max','java call heap live object count','java call heap gc count','cluster key scan block gets','Batched IO vector block count','Batched IO block miss count','Batched IO (space) vector count','transaction tables consistent reads - undo records applied','no work - consistent read gets','rollbacks only - consistent read gets','deferred (CURRENT) block cleanout applications','auto extends on undo tablespace','drop segment calls in space pressure','steps of tune down ret. in space pressure','commit immediate requested','commit batch/immediate performed','commit immediate performed','commit wait/nowait performed','commit nowait performed','IMU contention','IMU pool not allocated','workarea executions - optimal','bytes sent via SQL*Net to dblink','pinned cursors current','concurrency wait time','DBWR checkpoint buffers written','commit cleanout failures: buffer being written','commit cleanout failures: callback failure ','redo size for direct writes','redo ordering marks','redo KB read','failed probes on index block reclamation','recursive aborts on index block reclamation','index scans kdiixs1','HSC OLTP Space Saving','HSC Compressed Segment Block Changes','HSC OLTP inline compression','securefile direct read ops','TBS Extension: files extended','TBS Extension: bytes extended','table scans (direct read)','Batched IO double miss count','shared io pool buffer get failure','commit txn count during cleanout','cleanout - number of ktugct calls','min active SCN optimization applied on CR','IMU commits','IMU recursive-transaction flush','Misses for writing mapping','java session heap object count max','workarea executions - onepass','parse time elapsed','parse count (hard)','bytes received via SQL*Net from dblink','sorts (memory)','recursive calls','enqueue requests','db block gets from cache (fastpath)','physical read IO requests','physical writes','summed dirty queue length','DBWR tablespace checkpoint buffers written','DBWR transaction table writes','exchange deadlocks','dirty buffers inspected','commit cleanout failures: cannot pin','commit cleanouts successfully completed','CR blocks created','shared hash latch upgrades - wait','calls to kcmgas','redo blocks checksummed by FG (exclusive)','redo synch time','redo synch polls','leaf node splits','lob writes unaligned','Heap Segment Array Inserts','securefile direct read bytes','securefile number of non-transformed flushes','sql area purged','java call heap used size','java session heap used size','SMON posted for undo segment shrink','table scans (short tables)','file io service time','Batched IO same unit count','global undo segment hints helped','local undo segment hints were stale','IMU Redo allocation size','java session heap live size','workarea memory allocated','execute count','session logical reads','CPU used by this session','application wait time','non-idle wait count','messages sent','enqueue timeouts','enqueue deadlocks','physical read total multi block requests','physical write total IO requests','db block gets','db block gets from cache','physical read bytes','DBWR object drop buffers written','DBWR undo block writes','pinned buffers inspected','free buffer inspected','switch current to new buffer','write clones created in background','calls to get snapshot scn: kcmgss','redo write time','redo blocks checksummed by LGWR','lob writes','index fast full scans (full)','HSC OLTP recursive compression','session cursor cache count','TBS Extension: tasks executed','SMON posted for undo segment recovery','table scans (rowid ranges)','cluster key scans','background checkpoints completed','Batched IO vector read count','Batched IO buffer defrag count','data blocks consistent reads - undo records applied','cleanouts only - consistent read gets','immediate (CR) block cleanout applications','space was not found by tune down','commit wait/nowait requested','commit nowait requested','IMU- failed to get a private strand','java session heap live object count max','buffer is pinned count','parse count (failures)','SQL*Net roundtrips to/from client','SQL*Net roundtrips to/from dblink','sorts (disk)','logons cumulative','user commits','messages received','session pga memory max','physical read total IO requests','physical read total bytes','consistent gets from cache (fastpath)','physical writes direct','prefetch clients - default','change write time','prefetched blocks aged out before use','shared hash latch upgrades - no wait','calls to kcmgcs','redo writes','redo subscn max counts','redo synch long waits','branch node splits','HSC Heap Segment Block Changes','HSC OLTP Non Compressible Blocks','sql area evicted','java call heap total size','java call heap collected bytes','table scans (long tables)','file io wait time','total number of slots','transaction tables consistent read rollbacks','immediate (CURRENT) block cleanout applications','Cached Commit SCN referenced','space was found by tune down','IMU ktichg flush'
) */
AND t.name LIKE '%temp%'
;

SELECT t.name AS stat_name,
       t.STATISTIC# AS stat_id
FROM sys.v_$statname t
WHERE t.STATISTIC# IN (22,24,17,544,48);

-- Given statistincs
select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_time AS snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and St.NAME in (
'physical reads direct temporary tablespace','physical writes direct temporary tablespace','temp space allocated (bytes)'
  ) ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical reads direct temporary tablespace' AS s1,'physical writes direct temporary tablespace' AS s2, 'temp space allocated (bytes)'  AS s3
)
 )
order by snap_id;


-- Memory resizing operation
select  MR.*
from PERFSTAT.STATS$MEMORY_RESIZE_OPS mr
where MR.COMPONENT='shared pool'
order by MR.SNAP_ID;


select *
from (
with local_data as (
select  to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_ID as snap_id,
        MR.COMPONENT as component,
        MR.FINAL_SIZE as final_size
from PERFSTAT.STATS$MEMORY_RESIZE_OPS mr, PERFSTAT.STATS$SNAPSHOT s
where S.dbid=&&v_dbid and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=MR.DBID and S.SNAP_ID=MR.SNAP_ID
  ),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.component as component,
       case when (e.final_size - b.final_size) < 0 then null else (e.final_size - b.final_size) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.component=b.component
 ) v
 pivot (
max(value_diff)
for component in (
'DEFAULT buffer cache' as def_buff_cache,
'streams pool' as streams_pool,
'shared pool' as shared_pool
)
 )
order by snap_id;

select *
from PERFSTAT.STATS$MEMORY_DYNAMIC_COMPS mr;


-- Event explanation
select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_TIME AS snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st, SYS.V_$STATNAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.STATISTIC#=sn.STATISTIC# and SN.NAME in (
  'pinned buffers inspected','physical writes from cache','physical writes','index fast full scans (full)','free buffer requested','free buffer inspected','user I/O wait time','physical reads','physical reads cache'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'user I/O wait time' as userIOwt,
'physical reads' as ph_reads,
'physical reads cache' as ph_reads_cache,
'free buffer inspected' as free_buff_insp,
'free buffer requested' as free_buff_req,
'pinned buffers inspected' as pin_buff_insp,
'physical writes from cache' as ph_wr_from_bcache,
'physical writes' as ph_writes,
'index fast full scans (full)' as indx_ffs
)
 )
order by snap_id;
--------------------------------------------------------------------------------
-- Physical Reads stats
select *
from (
with
local_data as (
select to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st, SYS.V_$STATNAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.STATISTIC#=sn.STATISTIC# and SN.NAME in (
'physical read total IO requests','physical read total multi block requests','physical reads','physical reads cache','physical read flash cache hits','physical reads direct','physical reads direct temporary tablespace','physical reads cache prefetch','physical reads prefetch warmup','physical reads retry corrupt','physical reads direct (lob)'
  )
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read total IO requests' as totalIO,
'physical read total multi block requests' as total_mblckIO,
'physical reads' as phr,
'physical reads cache' as phr_cache,
'physical read flash cache hits' as phr_flash_cache_hits,
'physical reads direct' as phr_direct,
'physical reads direct temporary tablespace' as phr_direct_tmp_tblspc,
'physical reads cache prefetch' as phr_cache_prefetch,
'physical reads prefetch warmup' as phr_prefetch_warmup,
'physical reads retry corrupt' as phr_retry_corrupt,
'physical reads direct (lob)' as phr_direct_lob
)
 )
order by snap_id;
---------------------------------------------------------------------------------------------------------------
-- PhysicalIO stats
select *
from (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st, SYS.V_$STATNAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.STATISTIC#=sn.STATISTIC# and SN.NAME in (
'physical read total IO requests','physical read total multi block requests','physical reads','physical reads cache','physical read flash cache hits','physical reads direct','physical reads direct temporary tablespace','physical reads cache prefetch','physical reads prefetch warmup','physical reads retry corrupt','physical reads direct (lob)','physical write bytes','physical write IO requests','physical write total bytes','physical write total IO requests','physical write total multi block requests','physical writes','physical writes direct','physical writes direct (lob)','physical writes direct temporary tablespace','physical writes from cache','physical writes non checkpoint'
  )
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read total IO requests' as phr_totalIO,
'physical read total multi block requests' as phr_total_mblckIO,
'physical reads' as phrs,
'physical reads cache' as phr_cache,
'physical read flash cache hits' as phr_flash_cache_hits,
'physical reads direct' as phr_direct,
'physical reads direct temporary tablespace' as phr_direct_tmp_tblspc,
'physical reads cache prefetch' as phr_cache_prefetch,
'physical reads prefetch warmup' as phr_prefetch_warmup,
'physical reads retry corrupt' as phr_retry_corrupt,
'physical reads direct (lob)' as phr_direct_lob,
'physical write bytes' as phw_bytes,
'physical write IO requests' as phw_IO_rqsts,
'physical write total bytes' as phw_total_bytes,
'physical write total IO requests' as phw_total_IO_rqsts,
'physical write total multi block requests' as phw_total_multi_block_rqsts,
'physical writes' as phws,
'physical writes direct' as phws_direct,
'physical writes direct (lob)' as phws_direct_lob,
'physical writes direct temporary tablespace' as phws_direct_temp_tblspc,
'physical writes from cache' as phws_from_cache,
'physical writes non checkpoint' as phws_non_chckpnt
)
 )
order by snap_id;

---------------------------------------------------------------------------------------------------------------

-- Redo stats
select *
from (
with
local_data as (
select to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.NAME as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SYSSTAT st, SYS.V_$STATNAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.STATISTIC#=sn.STATISTIC# and SN.NAME in (
'redo KB read','redo KB read (memory)','redo KB read (memory) for transport','redo KB read for transport','redo blocks checksummed by FG (exclusive)','redo blocks checksummed by LGWR','redo blocks read for recovery','redo blocks written','redo buffer allocation retries','redo entries','redo entries for lost write detection','redo k-bytes read for recovery','redo k-bytes read for terminal recovery','redo log space requests','redo log space wait time','redo ordering marks','redo size','redo size for direct writes','redo size for lost write detection','redo subscn max counts','redo synch long waits','redo synch poll writes','redo synch polls','redo synch time','redo synch time (usec)','redo synch writes','redo wastage','redo write broadcast ack count','redo write broadcast ack time','redo write broadcast lgwr post count','redo write time','redo writes'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'redo KB read' as r_KB_read,
'redo KB read (memory)' as r_KB_read_memory,
'redo KB read (memory) for transport' as r_KB_read_mem4transport,
'redo KB read for transport' as r_KB_read4transport,
'redo blocks checksummed by FG (exclusive)' as r_blcks_chcksmmd_byFGexclusive,
'redo blocks checksummed by LGWR' as r_blocks_checksummed_by_LGWR,
'redo blocks read for recovery' as r_blocks_read4recovery,
'redo blocks written' as r_blocks_written,
'redo buffer allocation retries' as r_buffer_allocation_retries,
'redo entries' as r_entries,
'redo entries for lost write detection' as r_entries4lost_write_detection,
'redo k-bytes read for recovery' as r_kb_read4recovery,
'redo k-bytes read for terminal recovery' as r_kb_read4terminal_recovery,
'redo log space requests' as r_log_space_requests,
'redo log space wait time' as r_log_space_wait_time,
'redo ordering marks' as r_ordering_marks,
'redo size' as r_size,
'redo size for direct writes' as r_size4direct_writes,
'redo size for lost write detection' as r_size4lost_wr_detection,
'redo subscn max counts' as r_subscn_max_counts,
'redo synch long waits' as r_synch_long_waits,
'redo synch poll writes' as r_synch_poll_writes,
'redo synch polls' as r_synch_polls,
'redo synch time' as r_synch_time,
'redo synch time (usec)' as r_synch_time_usec,
'redo synch writes' as r_synch_writes,
'redo wastage' as r_wastage,
'redo write broadcast ack count' as rw_broadcast_ack_count,
'redo write broadcast ack time' as rw_broadcast_ack_time,
'redo write broadcast lgwr post count' as rw_broadcast_lgwr_post_count,
'redo write time' as rw_time,
'redo writes' as redo_writes
)
 )
order by snap_id asc;

-- resource usage
-- select * from stats$resource_limit t;
-- select distinct resource_name from stats$resource_limit t;

SELECT  s.snap_time AS snap_time,
        t.snap_id,
        t.current_utilization AS cutilization,
        t.limit_value AS limit
from stats$resource_limit t, PERFSTAT.STATS$SNAPSHOT s
WHERE t.resource_name='sessions'
  AND t.snap_id=s.snap_id AND t.dbid=s.dbid
  AND s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 AND S.SNAP_ID between &&v_bsnap and &&v_esnap
ORDER BY t.snap_id
;

--------------------------------------------------------------------------------
-- TEMPORARY TBS STat

SELECT *
FROM PERFSTAT.STATS$TEMPSTATXS t
WHERE t.TSNAME='TEMP';

with
local_data as (
SELECT to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_id as snap_id,
       Sum(t.PHYBLKRD) AS PHYBLKRD,
       Sum(t.PHYBLKWRT) AS PHYBLKWRT,
       Sum(t.readtim) AS readtime,
       Sum(t.writetim) AS writetime
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$TEMPSTATXS t
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and T.DBID=s.dbid and T.INSTANCE_NUMBER=S.INSTANCE_NUMBER and t.snap_id=s.snap_id
  AND t.TSNAME='TEMP'
GROUP BY to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi'), s.snap_id ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       case when (e.PHYBLKRD - b.PHYBLKRD) < 0 then null else (e.PHYBLKRD - b.PHYBLKRD) end as PHYBLKRD,
       case when (e.PHYBLKWRT - b.PHYBLKWRT) < 0 then null else (e.PHYBLKWRT - b.PHYBLKWRT) end as PHYBLKWRT,
       case when (e.readtime - b.readtime) < 0 then null else (e.readtime - b.readtime) end as readtime,
       case when (e.writetime - b.writetime) < 0 then null else (e.writetime - b.writetime) end as writetime
from b, e
where e.snap_id=(b.snap_id+1)
ORDER BY snap_id;

-- SQL
/*
 select * from PERFSTAT.STATS$SQL_SUMMARY st;
 select * from perfstat.stats$sql_plan t;
 select * from perfstat.stats$sql_plan_usage t;
 select * from perfstat.stats$sql_statistics t;
 select * from perfstat.stats$sqltext t;
*/

select DISTINCT pu.sql_id
from perfstat.stats$sql_plan pl, perfstat.stats$sql_plan_usage pu, perfstat.stats$sqltext st
WHERE pl.plan_hash_value=pu.plan_hash_value
  AND pu.snap_id=pl.snap_id
  AND pu.sql_id=st.sql_id
  AND st.command_type IN (2,6,7)
  AND pl.object_owner='TPCC'
  --AND t.plan_hash_value=3003446045
;

SELECT  st.sql_id AS sql_id,
        st.sql_text
FROM perfstat.stats$sqltext st
WHERE st.sql_id IN ('bswc46zum45tj','8m96hr974yu7a','6f80tjwtrnnsq','82tfppq8s0dc2','5ps73nuy5f2vj','69gxtaqr1vk8j','c90b8j61ndux8','2xf7pasj5qz0a','g5u7xuchhfu62','95yr4xtfr50hx')
  AND st.piece=0
;

-- Command types
-- 6,7,2: dml
SELECT *
FROM V$SQLCOMMAND t
ORDER BY t.COMMAND_TYPE;

-- SQL_SUMMARY
SELECT *
FROM (
with
local_data as (
select --to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       S.SNAP_TIME AS snap_time,
       s.snap_id as snap_id,
       ST.rows_processed as stat_value,
       St.sql_id as stat_name
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SQL_SUMMARY st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.sql_id in (
'5ps73nuy5f2vj'
  )
   ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 )v
pivot (
max(value_diff)
for stat_name in (
'5ps73nuy5f2vj' AS q5ps73nuy5f2vj
)
 )
order by snap_id;

-- SQLText
SELECT t.*
FROM PERFSTAT.STATS$SQLTEXT t
WHERE t.sql_id IN ('cfwawa1jtks5s','61m27wx7gzpfv','8d3ba7n63tdrj')
ORDER BY t.sql_id, t.PIECE;

-- given sql_id work properties
with
local_data as (
select to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       s.snap_id as snap_id,
       ST.EXECUTIONS as stat_value,
       ST.APPLICATION_WAIT_TIME AS APPLICATION_WAIT_TIME,
       ST.CONCURRENCY_WAIT_TIME AS CONCURRENCY_WAIT_TIME,
       ST.CLUSTER_WAIT_TIME AS CLUSTER_WAIT_TIME,
       ST.USER_IO_WAIT_TIME AS USER_IO_WAIT_TIME,
       ST.ROWS_PROCESSED AS ROWS_PROCESSED,
       ST.ELAPSED_TIME AS ELAPSED_TIME,
       ST.AVG_HARD_PARSE_TIME AS AVG_HARD_PARSE_TIME
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SQL_SUMMARY st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.sql_id='82tfppq8s0dc2'),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as EXECUTIONS,
       case when (e.APPLICATION_WAIT_TIME - b.APPLICATION_WAIT_TIME) < 0 then null else (e.APPLICATION_WAIT_TIME - b.APPLICATION_WAIT_TIME) end as APPLICATION_WAIT_TIME,
       case when (e.CONCURRENCY_WAIT_TIME - b.CONCURRENCY_WAIT_TIME) < 0 then null else (e.CONCURRENCY_WAIT_TIME - b.CONCURRENCY_WAIT_TIME) end as CONCURRENCY_WAIT_TIME,
       case when (e.CLUSTER_WAIT_TIME - b.CLUSTER_WAIT_TIME) < 0 then null else (e.CLUSTER_WAIT_TIME - b.CLUSTER_WAIT_TIME) end as CLUSTER_WAIT_TIME,
       case when (e.USER_IO_WAIT_TIME - b.USER_IO_WAIT_TIME) < 0 then null else (e.USER_IO_WAIT_TIME - b.USER_IO_WAIT_TIME) end as USER_IO_WAIT_TIME,
       case when (e.ROWS_PROCESSED - b.ROWS_PROCESSED) < 0 then null else (e.ROWS_PROCESSED - b.ROWS_PROCESSED) end as ROWS_PROCESSED,
       case when (e.ELAPSED_TIME - b.ELAPSED_TIME) < 0 then null else (e.ELAPSED_TIME - b.ELAPSED_TIME) end as ELAPSED_TIME,
       case when (e.AVG_HARD_PARSE_TIME - b.AVG_HARD_PARSE_TIME) < 0 then null else (e.AVG_HARD_PARSE_TIME - b.AVG_HARD_PARSE_TIME) end as AVG_HARD_PARSE_TIME
from b, e
where e.snap_id=(b.snap_id+1)
ORDER BY snap_id;



--------------------------------------------------------------------------------
-- Find out who does most part of the changes
select count(*) as cnt, sql_id
from (
select  snap_time, snap_id, sql_id, rows_processed,
        round(cum_sum_by_snap/sum_by_snap,2) as pct
from (
select  to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_ID as snap_id,
        CMD.SQL_ID as sql_id,
        CMD.ROWS_PROCESSED as rows_processed,
        --row_number() over (partition by S.SNAP_ID order by CMD.ROWS_PROCESSED desc) as rnum
        sum(CMD.ROWS_PROCESSED) over (partition by S.SNAP_ID order by null) as sum_by_snap,
        sum(CMD.ROWS_PROCESSED) over (partition by S.SNAP_ID order by CMD.ROWS_PROCESSED desc rows between unbounded preceding and current row) as cum_sum_by_snap
from PERFSTAT.STATS$SQL_SUMMARY cmd, PERFSTAT.STATS$SNAPSHOT s
where   s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and CMD.DBID=S.DBID and CMD.INSTANCE_NUMBER=S.INSTANCE_NUMBER and CMD.SNAP_ID=S.SNAP_ID
  and CMD.COMMAND_TYPE in (2,6,7) -- Insert,Update,Delete
  and CMD.ROWS_PROCESSED > 0
order by S.SNAP_ID, CMD.ROWS_PROCESSED desc
 )
where round(cum_sum_by_snap/sum_by_snap,2) <= 0.9
  )
group by sql_id
order by cnt desc;



-- Batching
DECLARE
 CURSOR c1 IS
 SELECT Min(s.SNAP_ID) AS bsnap,
       Max(s.SNAP_ID) AS esnap,
       Trunc(s.SNAP_TIME,'DD') AS snap_day
from PERFSTAT.STATS$SNAPSHOT s
where S.dbid=&&v_dbid
GROUP BY Trunc(s.SNAP_TIME,'DD')
ORDER BY Trunc(s.SNAP_TIME,'DD');

BEGIN
 FOR i IN c1
 LOOP
    IF  i.bsnap < i.esnap
    then
     Dbms_Output.put_line('define begin_snap='||i.bsnap);
     Dbms_Output.put_line('define end_snap='||i.esnap);
     Dbms_Output.put_line('define report_name=sp_'||i.bsnap||'_'||i.esnap||'.txt');
     Dbms_Output.put_line('@${ORACLE_HOME}/rdbms/admin/spreport.sql');
    ELSE
     Dbms_Output.put_line('/* => ||'i.bsnap||' '||i.esnap||' <= skipped */');
    END IF;
 END LOOP;
END;
/

--------------------------------------------------------------------------------
--ash-like stat
define sampleid=10
define sampletime="20200622 22:00:00"
define base64="1" --UTL_ENCODE.BASE64
define db_chst="CL8MSWIN1251"
SELECT  --&&sampleid*1 AS sample_id, &&sampletime||'' AS sample_time,
          s.sid AS session_id, s.serial# AS session_serial#,
          p.spid AS os_pid,
          s.process AS os_client_pid, s.osuser AS os_client_user,
          Decode(s.TYPE,'USER','FOREGROUND','BACKGROUND') AS session_type,
          s.user# AS user_id, s.schema# AS schema_id,
          CASE WHEN s.MODULE IS NOT NULL THEN utl_encode.text_encode( s.MODULE, '&&db_chst', &&base64)
          ELSE NULL
          END AS MODULE,
          CASE WHEN s.action IS NOT NULL THEN utl_encode.text_encode( s.action, '&&db_chst', &&base64)
          ELSE null
          END AS action,
          CASE WHEN s.machine IS NOT NULL THEN utl_encode.text_encode( s.machine, '&&db_chst', &&base64)
          ELSE null
          end AS machine,
          CASE WHEN s.program IS NOT NULL THEN utl_encode.text_encode( s.program, '&&db_chst', &&base64)
          ELSE null
          END AS program,
          s.service_name AS service_name, s.sql_id AS sql_id, s.sql_child_number AS sql_child_number,
          --Nvl(st.command_type,'0'),
          s.command AS sql_opcode,
          s.sql_hash_value AS sql_hash_value,
          --sp.id AS sql_plan_line_id, sp.operation AS sql_plan_operation, sp.options AS sql_plan_options,
          s.sql_exec_id AS sql_exec_id, s.sql_exec_start  AS sql_exec_start,
          s.plsql_entry_object_id AS plsql_entry_object_id, s.plsql_entry_subprogram_id AS plsql_entry_subprogram_id,
          s.plsql_object_id AS plsql_object_id, s.plsql_subprogram_id AS plsql_subprogram_id,
          s.event# AS event_id, s.event AS event,
          s.p1text AS p1text, s.p1, s.p2text AS p2text, s.p2, s.p3text AS p3text, s.p3,
          s.wait_class_id AS wait_class_id, s.wait_class AS wait_class, s.wait_time AS wait_time,
          s.state AS session_state,
          s.blocking_session_status AS blocking_session_status, s.blocking_session AS blocking_session,
          s.final_blocking_session_status AS final_blocking_session_status, s.final_blocking_session AS final_blocking_session,
          s.row_wait_obj# AS current_obj#, s.row_wait_file# AS current_file#, s.row_wait_block# AS current_block#, s.row_wait_row# AS current_row#,
          t.xid AS xid, t.used_ublk AS used_undo_blks, t.status AS tx_status, t.start_time AS tx_start_time,
          sess_stat.session_pga_max, sess_stat.session_pga_current, sess_stat.sess_temp_current
FROM  sys.v_$session s
      --, sys.v_$sql st
      --,sys.v_$sql_plan sp
      ,sys.v_$process p
      ,sys.v_$transaction t
      ,(SELECT *
        FROM (
          SELECT st.sid AS sess_sid, sn.name AS stat_name, st.Value AS stat_value
          FROM sys.v_$sesstat st, sys.v_$statname sn
          WHERE st.statistic#=sn.statistic#
            AND sn.name IN ('session pga memory max', 'session pga memory','temp space allocated (bytes)') )
        pivot (
           max(stat_value)
           for stat_name in (
              'session pga memory max' AS session_pga_max,
              'session pga memory' AS session_pga_current,
              'temp space allocated (bytes)' AS sess_temp_current )
        )
        ) sess_stat
WHERE 1=1
  AND s.paddr=p.addr
  --AND s.sql_id=st.sql_id(+)
  --AND s.sql_address=sp.address AND s.sql_hash_value=sp.hash_value
  AND s.saddr=t.ses_addr(+)
  --AND s.sid=t.SESSION_NUM(+) AND s.saddr=tu.SESSION_ADDR(+)
  AND s.sid=sess_stat.sess_sid(+)
;

SELECT * FROM sys.v_$session s;
SELECT * FROM sys.v_$sesstat st;
SELECT * FROM sys.v_$statname sn
WHERE lower(sn.name) LIKE '%temp%'
;
SELECT *
FROM sys.v_$sesstat st, sys.v_$statname sn
WHERE st.statistic#=sn.statistic#
  AND sn.name IN ('session pga memory max', 'session pga memory','temp space allocated (bytes)')
;

SELECT *
FROM (
SELECT st.sid AS sess_sid, sn.name AS stat_name, st.Value AS stat_value
FROM sys.v_$sesstat st, sys.v_$statname sn
WHERE st.statistic#=sn.statistic#
  AND sn.name IN ('session pga memory max', 'session pga memory','temp space allocated (bytes)') )
pivot (
 max(stat_value)
for stat_name in (
'session pga memory max' AS session_pga_max,
'session pga memory' AS session_pga_current,
'temp space allocated (bytes)' AS sess_temp_current
 )
)
;

SELECT *
FROM (
SELECT *
FROM excellent.ashdata t
ORDER BY t.sample_id DESC )
WHERE ROWNUM <= 100
;

SELECT Count(DISTINCT t.sample_id)
FROM excellent.ashdata t
;

SELECT t.sample_id, Round(Sum(t.sess_temp_current)/1024/1024,2) AS temp_space_usage_mb
FROM excellent.ashdata t
GROUP BY t.sample_id
ORDER BY t.sample_id asc
;