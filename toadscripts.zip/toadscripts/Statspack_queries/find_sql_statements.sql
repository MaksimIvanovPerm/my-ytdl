SELECT *
FROM PERFSTAT.stats$sqltext t
WHERE t.old_hash_value=1636991789
;

SELECT *
FROM PERFSTAT.stats$sql_plan_usage t
WHERE t.old_hash_value=1636991789
;

SELECT *
FROM perfstat.stats$sql_plan t
WHERE t.plan_hash_value=872895089
;

SELECT *
FROM perfstat.stats$sql_plan_usage t
WHERE t.sql_id='0zqx67r0gk8hy'
;

SELECT *
from PERFSTAT.STATS$SNAPSHOT s
where s.dbid=2041257920 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 224 and 352
ORDER BY s.snap_id;


SELECT Count(*), st.MODULE
from PERFSTAT.STATS$SNAPSHOT s,  PERFSTAT.STATS$SQL_SUMMARY st
where s.dbid=2041257920 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 224 and 352
  AND ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
GROUP BY st.MODULE
ORDER BY 1 desc;

select Count(distinct s.snap_id) AS cnt_d_snap_id,
       Count(DISTINCT ST.EXECUTIONS) as cnt_d_stat_value,
       St.sql_id as sql_id
from PERFSTAT.STATS$SNAPSHOT s, PERFSTAT.STATS$SQL_SUMMARY st
where s.dbid=2041257920 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 224 and 352
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  AND ST.COMMAND_TYPE=3
  AND Lower(st.MODULE) LIKE 'nqsserver%'
HAVING Count(distinct s.snap_id)=114 -- AND Count(DISTINCT ST.EXECUTIONS)=114
GROUP BY st.sql_id
ORDER BY cnt_d_stat_value desc


SELECT *
FROM sys.wrh$_sqltext t
WHERE t.dbid=2041257920 AND t.sql_id iN ('cfwawa1jtks5s','61m27wx7gzpfv','8d3ba7n63tdrj');

SELECT *
FROM v$sql t
WHERE t.sql_id iN ('cfwawa1jtks5s','61m27wx7gzpfv','8d3ba7n63tdrj');

SELECT *
FROM PERFSTAT.STATS$SQL_PLAN t
WHERE t.PLAN_HASH_VALUE=1636991789;

SELECT *
FROM PERFSTAT.STATS$SQLTEXT t
WHERE t.sql_id='61m27wx7gzpfv';

SELECT *
FROM SYS.WRH$_SQL_PLAN t
WHERE t.dbid=2041257920 AND t.sql_id='61m27wx7gzpfv';