-- Load profile, if service name is given by name
select  snap_time as snap_time,
            snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
with
local_data as (
select to_timestamp(Sn.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       sn.snap_id as snap_id,
       Sv.VALUE as stat_value,
       St.name as stat_name
from PERFSTAT.STATS$SNAPSHOT sn, PERFSTAT.STAT$_SERVICE_STAT sv, SYS.V_$STATNAME st, PERFSTAT.STAT$_SERVICES_NAME svn
where sn.dbid=&&v_dbid and Sn.INSTANCE_NUMBER=1 and Sn.SNAP_ID between &&v_bsnap and &&v_esnap
  and Sv.DBID=sn.dbid and Sv.INSTANCE_NUMBER=Sn.INSTANCE_NUMBER and sv.snap_id=sn.snap_id
  and ST.STAT_ID=sv.STAT_ID and St.NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  AND sv.dbid=svn.dbid AND sv.snap_id=svn.snap_id AND sv.SERVICE_NAME_HASH=svn.SERVICE_NAME_HASH
  AND svn.SERVICE_NAME='bianalytic'),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 )
pivot (
max(value_diff)
for stat_name in (
'execute count' as executions,
'logons cumulative' as logons,
'sorts (memory)' as memory_sorts,
'sorts (disk)' as disk_sorts,
'parse count (hard)' as hard_parses,
'parse count (total)' as parses,
'user calls' as user_calls,
'physical reads' as physical_reads,
'physical writes' as physical_writes,
'db block changes' as block_changes,
'session logical reads' as logical_reads,
'redo size' as redo_size,
'user commits' as user_commit,
'user rollbacks' as user_rollback)
 )
ORDER BY snap_id;

-- Load profile, if service name is given by it's hash
select  snap_time as snap_time,
            snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
with
local_data as (
select to_timestamp(Sn.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
       sn.snap_id as snap_id,
       Sv.VALUE as stat_value,
       St.name as stat_name
from PERFSTAT.STATS$SNAPSHOT sn, PERFSTAT.STAT$_SERVICE_STAT sv, SYS.V_$STATNAME st
where sn.dbid=2041257920 and Sn.INSTANCE_NUMBER=1 and Sn.SNAP_ID between 364 and 1026
  and Sv.DBID=sn.dbid and Sv.INSTANCE_NUMBER=Sn.INSTANCE_NUMBER and sv.snap_id=sn.snap_id
  and ST.STAT_ID=sv.STAT_ID and St.NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  AND sv.SERVICE_NAME_HASH=3427055676
  -- 3427055676=SYS$USERS
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 )
pivot (
max(value_diff)
for stat_name in (
'execute count' as executions,
'logons cumulative' as logons,
'sorts (memory)' as memory_sorts,
'sorts (disk)' as disk_sorts,
'parse count (hard)' as hard_parses,
'parse count (total)' as parses,
'user calls' as user_calls,
'physical reads' as physical_reads,
'physical writes' as physical_writes,
'db block changes' as block_changes,
'session logical reads' as logical_reads,
'redo size' as redo_size,
'user commits' as user_commit,
'user rollbacks' as user_rollback)
 )
ORDER BY snap_id;


SELECT DISTINCT s.STAT_ID
FROM PERFSTAT.STAT$_SERVICE_STAT s, PERFSTAT.STAT$_SERVICES_NAME svn
WHERE s.SERVICE_NAME_HASH=Svn.SERVICE_NAME_HASH
  AND svn.SERVICE_NAME='cmt_analytic.ertelecom.ru';

-- Find statistics, for the given service, which are not static;

SELECT ''''||stat_id||''' as '||name||',' AS col
FROM SYS.V_$STATNAME st
WHERE st.STAT_ID IN (2748282437,1431595225,2821698184,3678609077,3868577743,1236385760,3804491469,582481098,3211650785,798730793,3671147913,2877738702,1759426133,326482564,3649082374,2263124246,916801489,1388758753,2432034337,1099569955,2666645286,63887964,3143187968,2882015696,2453370665,1190468109,85052502,3332107451);

SELECT *
FROM  SYS.V$SYS_TIME_MODEL stm
WHERE stm.STAT_ID IN (2748282437,1431595225,2821698184,3678609077,3868577743,1236385760,3804491469,582481098,3211650785,798730793,3671147913,2877738702,1759426133,326482564,3649082374,2263124246,916801489,1388758753,2432034337,1099569955,2666645286,63887964,3143187968,2882015696,2453370665,1190468109,85052502,3332107451);

SELECT  v.stat_id AS stat_id,
        stn.CLASS AS class,
        stn.NAME AS stat_name
FROM (
SELECT  st.stat_id AS stat_id
        --,Avg(st.Value) AS avg_stat_value
        --,StdDev(st.Value) AS sd_stat_value
FROM PERFSTAT.STAT$_SERVICE_STAT st, PERFSTAT.STAT$_SERVICES_NAME svn
WHERE st.dbid=2041257920 AND ST.INSTANCE_NUMBER=1 AND ST.SNAP_ID BETWEEN 364 and 1026
  AND st.dbid=svn.DBID AND st.snap_id=svn.SNAP_ID AND st.SERVICE_NAME_HASH=svn.SERVICE_NAME_HASH
  --AND svn.SERVICE_NAME='dwh.ertelecom.ru'
   AND svn.SERVICE_NAME='cmt_analytic.ertelecom.ru'
--HAVING StdDev(st.Value) > 0
GROUP BY st.stat_id ) v, SYS.V_$STATNAME stn
WHERE  stn.stat_id=v.stat_id

--------------------------------------------------------------------------------
-- Time model for the given service

select *
from (
with
local_data as (
SELECT  to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_ID as snap_id
        ,stm.STAT_NAME AS stat_name
        ,st.Value AS stat_value
FROM PERFSTAT.STAT$_SERVICE_STAT st, PERFSTAT.STAT$_SERVICES_NAME svn, PERFSTAT.STATS$SNAPSHOT s, SYS.V_$SYS_TIME_MODEL stm
WHERE s.dbid=2041257920 AND S.INSTANCE_NUMBER=1 AND S.SNAP_ID BETWEEN 364 and 1026
  AND ST.DBID=s.dbid AND ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER AND ST.SNAP_ID=s.snap_id
  AND st.dbid=svn.DBID AND st.snap_id=svn.SNAP_ID AND st.SERVICE_NAME_HASH=svn.SERVICE_NAME_HASH
  AND st.STAT_ID=stm.STAT_ID AND stm.STAT_NAME IN (
  'DB time','DB CPU','parse time elapsed','sql execute elapsed time'
  )
  --AND svn.SERVICE_NAME='dwh.ertelecom.ru'
  --AND svn.SERVICE_NAME='cmt_analytic.ertelecom.ru'
  --AND svn.SERVICE_NAME='bianalytic'
  AND svn.SERVICE_NAME='cmt.ertelecom.ru'
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
 pivot (
max(value_diff)
for stat_name in (
'DB time' as db_time,
'DB CPU' as db_cpu,
'sql execute elapsed time' as sql_exec_el_tm
 )
)
order by snap_id;
;

-- AllStatistics for the given service
select *
from (
with
local_data as (
SELECT to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_ID as snap_id
        ,st.STAT_ID AS stat_name
        ,st.Value AS stat_value
FROM PERFSTAT.STAT$_SERVICE_STAT st, PERFSTAT.STAT$_SERVICES_NAME svn, PERFSTAT.STATS$SNAPSHOT s
WHERE s.dbid=2041257920 AND S.INSTANCE_NUMBER=1 AND S.SNAP_ID BETWEEN 364 and 1026
  AND ST.DBID=s.dbid AND ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER AND ST.SNAP_ID=s.snap_id
  AND st.dbid=svn.DBID AND st.snap_id=svn.SNAP_ID AND st.SERVICE_NAME_HASH=svn.SERVICE_NAME_HASH
  AND svn.SERVICE_NAME='cmt_analytic.ertelecom.ru'
  AND st.stat_id IN (2748282437,1431595225,2821698184,3678609077,3868577743,1236385760,3804491469,582481098,3211650785,798730793,3671147913,2877738702,1759426133,326482564,3649082374,2263124246,916801489,1388758753,2432034337,1099569955,2666645286,63887964,3143187968,2882015696,2453370665,1190468109,85052502,3332107451)
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
 pivot (
max(value_diff)
for stat_name in (
'2666645286' as logons,
'85052502' as opened_cursors,
'582481098' as user_commits,
'3671147913' as user_rollbacks,
'2882015696' as user_calls,
'3143187968' as session_logical_reads,
'3649082374' as DB_time,
'2432034337' as cluster_wt,
'3868577743' as concurrency_wt,
'1099569955' as application_wt,
'3332107451' as user_IO_wt,
'2263124246' as physical_reads,
'916801489' as db_block_changes,
'1190468109' as physical_writes,
'1236385760' as redo_size,
'2877738702' as gc_cr_blck_received,
'1759426133' as gc_cr_blck_receive_time,
'326482564' as gc_cr_blck_rcvd,
'1388758753' as gc_cr_blck_rcv_time,
'3678609077' as sess_crsr_cch_hits,
'3211650785' as wa_execs_optimal,
'798730793' as wa_execs_onepass,
'3804491469' as wa_execs_multipass,
'1431595225' as parse_time_elapsed,
'63887964' as parse_count_total,
'2453370665' as execute_count
 )
)
order by snap_id;

-- Given statistics for the given service
-- AllStatistics for the given service

select *
from (
with
local_data as (
SELECT to_timestamp(S.SNAP_TIME,'yyyy.mm.dd hh24:mi') as snap_time,
        S.SNAP_ID as snap_id
        ,st.STAT_ID AS stat_name
        ,st.Value AS stat_value
FROM PERFSTAT.STAT$_SERVICE_STAT st, PERFSTAT.STAT$_SERVICES_NAME svn, PERFSTAT.STATS$SNAPSHOT s
WHERE s.dbid=2041257920 AND S.INSTANCE_NUMBER=1 AND S.SNAP_ID BETWEEN 364 and 1026
  AND ST.DBID=s.dbid AND ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER AND ST.SNAP_ID=s.snap_id
  AND st.dbid=svn.DBID AND st.snap_id=svn.SNAP_ID AND st.SERVICE_NAME_HASH=svn.SERVICE_NAME_HASH
  AND svn.SERVICE_NAME='cmt_analytic.ertelecom.ru'
  AND st.stat_id IN (2263124246,3332107451,1190468109)
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 )
 pivot (
max(value_diff)
for stat_name in (
2263124246 as physical_reads,
3332107451 as user_IO_wt,
1190468109 as physical_writes
 )
)
order by snap_id;



--------------------------------------------------------------------------------

SELECT t.NAME_HASH AS NAME_HASH
       ,t.NETWORK_NAME AS NETWORK_NAME
FROM V$SERVICES t;

SELECT  t.SERVICE_NAME_HASH AS SERVICE_NAME_HASH
        ,t.STAT_ID AS STAT_ID
        ,t.Value AS VALUE
FROM  V$SERVICE_STATS t;

SELECT  t.SERVICE_NAME_HASH AS SERVICE_NAME_HASH
        ,t.WAIT_CLASS_ID AS WAIT_CLASS_ID
        ,t.TOTAL_WAITS AS TOTAL_WAITS
        ,t.TIME_WAITED AS TIME_WAITED
FROM  V$SERVICE_WAIT_CLASS t;



SELECT  t.SERVICE_NAME_HASH AS SERVICE_NAME_HASH
        ,t.EVENT_ID AS EVENT_ID
        ,t.TOTAL_WAITS AS TOTAL_WAITS
        ,t.TOTAL_TIMEOUTS AS TOTAL_TIMEOUTS
        ,t.TIME_WAITED AS TIME_WAITED
        ,t.MAX_WAIT AS MAX_WAIT
        ,t.TIME_WAITED_MICRO  AS TIME_WAITED_MICRO
FROM V$SERVICE_EVENT t;

SELECT *
FROM V$SERV_MOD_ACT_STATS t;

SELECT *
FROM v$services ;

