INSERT INTO sys.WRM$_DATABASE_INSTANCE 
SELECT * FROM SYS.DATABASE_INSTANCE_EXT;
COMMIT;  

INSERT INTO SYS.WRM$_SNAPSHOT SELECT * FROM SYS.SNAPSHOT_EXT t WHERE t.dbid!=(SELECT dbid FROM v$database);
COMMIT;

/*INSERT INTO sys.WRM$_BASELINE 
SELECT * FROM SYS.BASELINE_EXT t WHERE t.dbid!=(SELECT dbid FROM v$database);
COMMIT;  

INSERT INTO SYS.WRM$_SNAP_ERROR 
SELECT * FROM SNAP_ERROR_EXT t WHERE t.dbid!=(SELECT dbid FROM v$database);
COMMIT; 

INSERT INTO SYS.WRM$_WR_USAGE SELECT * FROM SYS.WR_USAGE_EXT t;
COMMIT;
INSERT INTO SYS.WRM$_BASELINE_DETAILS SELECT * FROM SYS.BASELINE_DETAILS_EXT t WHERE t.dbid!=(SELECT dbid FROM v$database);
COMMIT;
INSERT INTO SYS.WRM$_COLORED_SQL SELECT * FROM SYS.COLORED_SQL_EXT t WHERE t.dbid!=(SELECT dbid FROM v$database);
COMMIT;

INSERT INTO SYS.WRM$_SNAPSHOT_DETAILS SELECT * FROM SYS.SNAPSHOT_DETAILS_EXT t WHERE t.dbid!=(SELECT dbid FROM v$database);
COMMIT;
INSERT INTO SYS.WRM$_BASELINE_TEMPLATE SELECT * FROM SYS.BASELINE_TEMPLATE_EXT t WHERE t.dbid!=(SELECT dbid FROM v$database);
COMMIT;
truncate table sys.WRM$_BASELINE ;
truncate table SYS.WRM$_SNAP_ERROR ;
truncate table SYS.WRM$_WR_USAGE;
truncate table SYS.WRM$_BASELINE_DETAILS;
truncate table SYS.WRM$_COLORED_SQL;
truncate table SYS.WRM$_SNAPSHOT_DETAILS;
truncate table SYS.WRM$_BASELINE_TEMPLATE;
*/

DECLARE
  v_ext_t_name    VARCHAR2(30) := Upper('IOSTAT_FUNCTION_EXT');
  v_awr_owner     VARCHAR2(30) := Upper('SYS');
  v_table_name    VARCHAR2(30) := Upper('WRH$_IOSTAT_FUNCTION');
  v_cv            SYS_REFCURSOR;
  c_pack_size     NUMBER := 1000;
  v_cntr          NUMBER;

  CURSOR c1 IS
  SELECT DISTINCT t.dbid
  FROM sys.WRM$_DATABASE_INSTANCE t
  WHERE t.dbid!=(SELECT dbid FROM v$database);

BEGIN
  EXECUTE IMMEDIATE 'SELECT Count(*) FROM '||v_awr_owner||'.'||v_ext_t_name INTO v_cntr;
  IF v_cntr = 0
  THEN
    Dbms_Output.put_line('Ext. table '||v_ext_t_name||' is empty');
  ELSE
    Dbms_Output.put_line('Ext. table '||v_ext_t_name||' '||v_cntr);
    FOR i IN c1
    LOOP
      BEGIN
        EXECUTE IMMEDIATE 'insert into '||v_awr_owner||'.'||v_table_name||' SELECT v.*, '||i.dbid||' AS con_dbid FROM ( SELECT * FROM '||v_awr_owner||'.'||v_ext_t_name||' t where t.dbid='||i.dbid||' ) v';
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          Dbms_Output.put_line('DBID: '||i.dbid||' '||SQLCODE||' '||SubStr(SQLERRM,1,128));
      END;
    END LOOP;
  END IF;  
END;
/
