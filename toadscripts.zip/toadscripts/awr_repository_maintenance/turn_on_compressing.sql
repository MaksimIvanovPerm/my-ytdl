-- exec dbms_workload_repository.MODIFY_SNAPSHOT_SETTINGS(interval=>0);

DECLARE
  CURSOR c1 IS
  SELECT *
  FROM sys.dba_indexes t
  WHERE t.table_owner='SYS'
    AND regexp_like(t.table_name,'WR[HM]\$_.*');
BEGIN
  FOR i IN c1
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'alter index '||i.owner||'.'||i.index_name||' rebuild COMPRESS advanced low';
      -- EXECUTE IMMEDIATE 'alter index '||i.owner||'.'||i.index_name||' rebuild COMPRESS';
      Dbms_Output.put_line(i.owner||'.'||i.index_name||': ok');
    EXCEPTION
    WHEN OTHERS THEN
      Dbms_Output.put_line(i.index_name||': '||SQLCODE||' '||SubStr(SQLERRM,1,128));
    END;
  END LOOP;
END;
/


DECLARE
  CURSOR c1 is
SELECT *
FROM sys.dba_ind_partitions i
WHERE i.index_owner='SYS'
  AND i.index_name IN (SELECT t1.index_name
                        FROM sys.dba_indexes t1
                        WHERE t1.table_owner='SYS'
                          AND regexp_like(t1.table_name,'WR[HM]\$_.*'));
BEGIN
  FOR i IN c1
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'alter index '||i.index_owner||'.'||i.index_name||' rebuild partition '||i.partition_name||' COMPRESS advanced low';
      Dbms_Output.put_line(i.index_owner||'.'||i.index_name||':'||i.partition_name||' ok');
    EXCEPTION
    WHEN OTHERS THEN
      Dbms_Output.put_line(i.index_owner||'.'||i.index_name||':'||i.partition_name||': '||SQLCODE||' '||SubStr(SQLERRM,1,128));
    END;
  END LOOP;
END;
/

DECLARE
  CURSOR c1 is
SELECT *
FROM sys.dba_tables t
WHERE t.owner='SYS'
  AND regexp_like(t.table_name,'WR[HM]\$_.*');

BEGIN
  FOR i IN c1
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'alter table '||i.owner||'.'||i.table_name||' row store compress advanced';
      Dbms_Output.put_line(i.owner||'.'||i.table_name||' ok');
    EXCEPTION
    WHEN OTHERS THEN
      Dbms_Output.put_line(i.owner||'.'||i.table_name||': '||SQLCODE||' '||SubStr(SQLERRM,1,128));
    END;
  END LOOP;
END;
/

SELECT *
FROM sys.dba_tab_partitions t
WHERE t.table_owner='SYS' AND t.table_name='WRH$_SYS_TIME_MODEL';