DECLARE
  CURSOR c1 IS
  SELECT *
  FROM sys.dba_tables t
  WHERE t.OWNER='SYS' AND t.TABLE_NAME LIKE 'WRH$%'
  ORDER BY t.TABLE_NAME;

  CURSOR c2 (p_tab_name IN VARCHAR2, p_pk_name IN VARCHAR2) IS
  SELECT t.COLUMN_NAME AS col_name
  FROM sys.dba_cons_columns t
  WHERE t.OWNER='SYS' AND t.TABLE_NAME=p_tab_name AND t.CONSTRAINT_NAME=p_pk_name
  ORDER BY t.POSITION;

  CURSOR c3(p_tab_name IN varchar2) IS
  SELECT t.COLUMN_NAME AS col_name
  FROM sys.dba_tab_columns t
  WHERE t.OWNER='SYS' AND t.TABLE_NAME=p_tab_name
  ORDER BY t.COLUMN_ID;



  v_pk_name           VARCHAR2(30) := '';
  v_str               VARCHAR2(256) := '';
  v_columns           VARCHAR2(4096) := '';
  v_n                 NUMBER;

  v_dblink_name       VARCHAR2(30) := 'DWH3';
  v_src_alias         CHAR(1) := 's';
  v_trg_alias         CHAR(1) := 't';

BEGIN
  FOR i IN c1
  LOOP
    v_pk_name := '';
    BEGIN
      SELECT t.CONSTRAINT_NAME
      INTO v_pk_name
      FROM sys.dba_constraints t
      WHERE t.CONSTRAINT_TYPE='P' AND t.OWNER='SYS' AND t.TABLE_NAME = i.TABLE_NAME;
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

    --Dbms_Output.put_line(i.TABLE_NAME||': '||v_pk_name);
    IF v_pk_name IS NOT NULL
    THEN
      v_n := 1;
      FOR j IN c2(i.TABLE_NAME, v_pk_name)
      LOOP
        IF v_n = 1
        THEN
          v_str := v_trg_alias||'.'||j.col_name||'='||v_src_alias||'.'||j.col_name;
        ELSE
          v_str := v_str||' and '||v_trg_alias||'.'||j.col_name||'='||v_src_alias||'.'||j.col_name;
        END IF;
        v_n := v_n + 1;
      END LOOP;

      --Dbms_Output.put_line(i.TABLE_NAME||':'||v_pk_name||':'||v_str);
      Dbms_Output.put_line('merge into '||i.TABLE_NAME||' '||v_trg_alias||' using (select * from  '||i.TABLE_NAME||'@'||v_dblink_name||') '||v_src_alias);
      Dbms_Output.put_line('on ('||v_str||')');

      v_n := 1;
      v_columns := '';
      FOR j IN c3(i.TABLE_NAME)
      LOOP
        IF v_n = 1
        THEN
          v_columns := v_trg_alias||'.'||j.col_name||'='||v_src_alias||'.'||j.col_name;
        ELSE
          v_columns := v_columns||','||v_trg_alias||'.'||j.col_name||'='||v_src_alias||'.'||j.col_name;
        END IF;
        v_n := v_n + 1;
      END LOOP;

      Dbms_Output.put_line('WHEN MATCHED THEN UPDATE SET ('||v_columns||')');

      v_n := 1;
      v_columns := '';
      for j in c3(i.TABLE_NAME)
      loop
       IF v_n = 1
       then
        v_columns := j.col_name;
       else
        v_columns := v_columns||','||j.col_name;
       end if;
       v_n := v_n + 1;
      end loop;

      Dbms_Output.put_line('WHEN NOT MATCHED THEN INSERT ('||regexp_replace(v_columns,'([^,]+)(,?)',v_trg_alias||'.\1\2')||')');
      Dbms_Output.put_line('VALUES ('||regexp_replace(v_columns,'([^,]+)(,?)',v_src_alias||'.\1\2')||');');
      Dbms_Output.put_line('commit;');
    END IF;



  END LOOP;
END;
/


/*
DECLARE
  v_str       VARCHAR2(128) := 'DBID,SNAP_ID,INSTANCE_NUMBER,SAMPLE_ID,SESSION_ID,CON_DBID';
BEGIN
  Dbms_Output.put_line( regexp_replace(v_str,'([^,]+),?','t.\1') );
END;
/
  */

/*
 Special cases are:
 WRH$_SGASTAT

*/

