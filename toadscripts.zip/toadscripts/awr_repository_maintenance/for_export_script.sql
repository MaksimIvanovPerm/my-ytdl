DECLARE
  v_owner   VARCHAR2(30) := Upper('SYS');
  v_tab     VARCHAR2(30) := Upper('WRM$_SNAPSHOT');
  v_rlim    NUMBER := 10;
  v_query   VARCHAR2(256) := 'select * from '||v_owner||'.'||v_tab||' where rownum <= '||v_rlim;
  v_c1      INTEGER;
  v_col_cnt INTEGER;
  v_desc_t  DBMS_SQL.DESC_TAB;
  v_idx     BINARY_INTEGER;
  v_cval    VARCHAR2(2048);
  v_lval    CLOB;
  v_tsval   TIMESTAMP;
  v_nmbr    NUMBER;
  v_date    DATE;
  v_status  INTEGER;

  v_fh      UTL_FILE.FILE_TYPE;
  v_dir     VARCHAR2(30) := Upper('CSV_DIR');
  v_opmd    varchar2(2) := 'w'; -- mode of a file opening
  v_lsize   NUMBER := 1024; -- line size
  v_fext    CHAR(4) := '.dat';
  v_fname   VARCHAR2(64) := v_tab||v_fext;

  v_lsep    CHAR(1) := '|'; -- line separator char, EOL
  v_fsep    CHAR(1) := ';'; -- field separator char
  v_sbrkt   CHAR(1) := '"'; -- string field braket char

  v_ts_fmt  VARCHAR2(30) := 'yyyy.dd.mm hh24:mi:ss';
  v_debug   NUMBER := 0;

  PROCEDURE define_column_proc
  IS
  BEGIN

/*
# from $ORACLE_HOME/rdbms/admin/dbmssql.sql
  -------------
  --  Named Datatype CONSTANTS
  --
  Varchar2_Type                         constant pls_integer :=   1;
  Number_Type                           constant pls_integer :=   2;
  Long_Type                             constant pls_integer :=   8;
  Rowid_Type                            constant pls_integer :=  11;
  Date_Type                             constant pls_integer :=  12;
  Raw_Type                              constant pls_integer :=  23;
  Long_Raw_Type                         constant pls_integer :=  24;
  Char_Type                             constant pls_integer :=  96;
  Binary_Float_Type                     constant pls_integer := 100;
  Binary_Double_Type                    constant pls_integer := 101;
  MLSLabel_Type                         constant pls_integer := 106;
  User_Defined_Type                     constant pls_integer := 109;
  Ref_Type                              constant pls_integer := 111;
  Clob_Type                             constant pls_integer := 112;
  Blob_Type                             constant pls_integer := 113;
  Bfile_Type                            constant pls_integer := 114;
  Timestamp_Type                        constant pls_integer := 180;
  Timestamp_With_TZ_Type                constant pls_integer := 181;
  Interval_Year_to_Month_Type           constant pls_integer := 182;
  Interval_Day_To_Second_Type           constant pls_integer := 183;
  Urowid_Type                           constant pls_integer := 208;
  Timestamp_With_Local_TZ_type          constant pls_integer := 231;
*/
    FOR i IN 1..v_col_cnt
    LOOP

     IF v_desc_t(i).col_type = 112
     THEN
        -- CLOB Type
        DBMS_SQL.DEFINE_COLUMN(v_c1,i,v_lval);
     ELSIF v_desc_t(i).col_type = 180
     THEN
        -- TS Type
        DBMS_SQL.DEFINE_COLUMN(v_c1,i,v_tsval);
     ELSIF v_desc_t(i).col_type = 2
     THEN
      -- NUMBER Type
      DBMS_SQL.DEFINE_COLUMN(v_c1,i,v_nmbr);
     ELSE
        -- All others types: define as a string
        DBMS_SQL.DEFINE_COLUMN(v_c1,i,v_cval,2048);
     END IF;
    END LOOP;

  END define_column_proc;

  PROCEDURE col_value_proc
  IS
  BEGIN
    FOR i IN 1..v_col_cnt
    LOOP
      IF v_desc_t(i).col_type = 112
      THEN
        -- It's a CLOB
        v_lval := '';
        DBMS_SQL.COLUMN_VALUE(v_c1,i,v_lval);
        --UTL_FILE.PUT(v_fh, v_sbrkt||v_lval||v_sbrkt);
      ELSIF v_desc_t(i).col_type = 180
      THEN
        -- It's a TS
        v_tsval := NULL;
        DBMS_SQL.COLUMN_VALUE(v_c1,i,v_tsval);
        --UTL_FILE.PUT(v_fh, v_sbrkt||To_Char(v_tsval,v_ts_fmt)||v_sbrkt);
        --UTL_FILE.PUT(v_fh, v_sbrkt||To_Char(v_tsval)||v_sbrkt);
        --Dbms_Output.put_line(v_sbrkt||To_Char(v_tsval,v_ts_fmt)||v_sbrkt);
        --Dbms_Output.put_line(v_sbrkt||v_tsval||v_sbrkt);
        --Dbms_Output.put_line(v_tsval);
        UTL_FILE.PUT(v_fh, sysdate);
      ELSIF v_desc_t(i).col_type = 2
      THEN
        -- It's a number
        v_nmbr := NULL;
        DBMS_SQL.COLUMN_VALUE(v_c1,i,v_nmbr);
        UTL_FILE.PUT(v_fh, v_nmbr);
      ELSE
        -- Some other type, treat as a string
        v_cval := '';
        DBMS_SQL.COLUMN_VALUE(v_c1,i,v_cval);
        UTL_FILE.PUT(v_fh, v_sbrkt||v_cval||v_sbrkt);
      END IF;
    END LOOP;
  END col_value_proc;

BEGIN
/*
http://www.toadworld.com/platforms/oracle/w/wiki/3328.dbms-sql-describe-columns.aspx
*/
  -- DBMS_OUTPUT.PUT_LINE('# '||v_query||';');
  v_c1 := DBMS_SQL.OPEN_CURSOR;
  v_debug := 1;
  DBMS_SQL.PARSE(v_c1,v_query,DBMS_SQL.NATIVE);
  v_debug := 2;
  DBMS_SQL.DESCRIBE_COLUMNS(v_c1,v_col_cnt,v_desc_t);
  v_debug := 3;
  --DBMS_OUTPUT.PUT_LINE('Column count is: '||v_col_cnt);

  /*
  v_idx := v_desc_t.first;
  WHILE v_idx IS NOT NULL
  LOOP
    DBMS_OUTPUT.PUT_LINE(v_desc_t(v_idx).col_name||' '||v_desc_t(v_idx).col_type);
    v_idx := v_desc_t.NEXT(v_idx);
  END LOOP;
  */

  define_column_proc;
  v_debug := 4;

  v_status := DBMS_SQL.EXECUTE(v_c1);
  v_debug := 5;

  v_fh := UTL_FILE.FOPEN(v_dir,v_fname,v_opmd);
  v_debug := 6;
  UTL_FILE.PUT_LINE(v_fh,'# '||v_query||';');

  LOOP
    EXIT WHEN ( DBMS_SQL.FETCH_ROWS(v_c1) <= 0 );
    col_value_proc;
    UTL_FILE.PUT(v_fh,v_lsep); -- EOL
  END LOOP;
  v_debug := 7;

  DBMS_SQL.CLOSE_CURSOR(v_c1);
  UTL_FILE.FCLOSE(v_fh);
  DBMS_OUTPUT.PUT_LINE(v_desc_t.count);
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('debug code: '||v_debug);
    UTL_FILE.FCLOSE_ALL;
    RAISE;
END;
/

-- select * from SYS.WRM$_SNAPSHOT where rownum <= 10;
-- alter session set nls_date_format='yyyy.mm.dd hh24:mi:ss';
-- create or replace directory csv_dir as '/db/additional/oradata/csv/';
-- SELECT * FROM dba_directories t;
/*
DECLARE
  v_fh      UTL_FILE.FILE_TYPE;
  v_dir     VARCHAR2(30) := Upper('CSV_DIR');
  v_opmd    varchar2(2) := 'w'; -- mode of a file opening
  v_num     NUMBER := 9;
BEGIN
  v_fh := UTL_FILE.FOPEN(v_dir,'WRM$_SNAPSHOT.dat',v_opmd);
  --UTL_FILE.PUT(v_fh,systimestamp);
  UTL_FILE.PUT(v_fh,v_num);
  UTL_FILE.FCLOSE_ALL;
END;
/

*/