-- STS routine
EXEC DBMS_SQLTUNE.CREATE_SQLSET(sqlset_name=>'TPCH_STS',description=>'Select-statements for TPCH test');

select p.* from table(dbms_sqltune.select_workload_repository(begin_snap => 44287, end_snap => 44288, basic_filter=>'parsing_schema_name in (''EXCELLENT'',''RIAS'',''ARM_XML'')' )) p;

SELECT *
FROM table(DBMS_SQLTUNE.SELECT_CURSOR_CACHE('parsing_schema_name=''TPCH'''))
WHERE Lower(sql_text) LIKE 'select %'
  --AND sql_text NOT LIKE '% DS_SVC %'
  --AND sql_text NOT LIKE '%/* OPT_DYN_SAMP */%'
  --AND sql_text NOT LIKE '%/* stub_code*/%'
ORDER BY first_load_time  desc
;

SELECT * FROM table ( DBMS_XPLAN.DISPLAY_CURSOR('8sxw8w85tu46d', NULL, 'ALL'));
SELECT * FROM table ( DBMS_XPLAN.DISPLAY_AWR('1pr9z7f8nh2az', 2437417311, 3252500659, 'ALL'));

define v_sts_name="2020_11_19"
define v_task_name="STA_20210606"
define v_task_descr="curious"

exec DBMS_SQLTUNE.DROP_TUNING_TASK('&&v_task_name');

EXEC DBMS_SQLTUNE.DROP_SQLSET(sqlset_name=>'&&v_sts_name');
COMMIT;

DECLARE
 cur          DBMS_SQLTUNE.SQLSET_CURSOR;
 v_sts_name   VARCHAR2(30) := '&&v_sts_name';
BEGIN
 OPEN cur FOR
   SELECT VALUE(P)
   FROM table( DBMS_SQLTUNE.SELECT_CURSOR_CACHE('parsing_schema_name=''TPCH''') ) P
   WHERE Lower(P.sql_text) LIKE 'select %'
     AND P.sql_text NOT LIKE '% DS_SVC %'
     AND P.sql_text NOT LIKE '%/* OPT_DYN_SAMP */%'
     AND P.sql_text NOT LIKE '%/* stub_code*/%'
;

DBMS_SQLTUNE.LOAD_SQLSET(sqlset_name => '&&v_sts_name', populate_cursor => cur);

END;
/

select p.*
from table(dbms_sqltune.select_workload_repository(begin_snap => &&v_bsnap, end_snap => &&v_esnap, basic_filter=>'parsing_schema_name in (''UNICA_USER'',''CAMPAIGN'',''CMDM'',''PLATFORM'',''STAGE'',''EXCHANGE'')' )) p
WHERE 1=1 --p.command_type=3
  AND p.sql_id IN (); 


EXEC DBMS_SQLTUNE.CREATE_SQLSET(sqlset_name=>'&&v_sts_name',description=>'&&v_task_descr');

DECLARE
  cur sys_refcursor;
BEGIN
  OPEN cur FOR
    SELECT --p.*
           VALUE (P)
    FROM table(dbms_sqltune.select_workload_repository(&&v_bsnap,&&v_esnap)) P
    WHERE 1=1 --P.command_type=3
      AND P.parsing_schema_name IN ('BITEST')
      AND p.sql_id IN ()
      ;

  DBMS_SQLTUNE.LOAD_SQLSET(sqlset_name => '&&v_sts_name', populate_cursor => cur);
  CLOSE cur;
END;
/

SELECT *
FROM sys.DBA_SQLSET t
ORDER BY t.created desc
;

SELECT *
FROM sys.DBA_SQLSET_STATEMENTS t
WHERE t.sqlset_name='&&v_sts_name'
      --t.sql_id='fbfsz48q1m3ht'
ORDER BY t.sql_id
;

SELECT *
FROM  DBA_SQLSET_REFERENCES t
WHERE t.sqlset_name='&&v_sts_name'
;
-- SAA routines ------------------------
SELECT * FROM DBA_ADVISOR_DEFINITIONS t;
EXEC DBMS_ADVISOR.CREATE_TASK(advisor_name=>'SQL Access Advisor',task_name=>'&&v_task_name',task_desc=>'&&v_task_descr');

select *
from SYS.DBA_ADVISOR_PARAMETERS t
where t.task_name='&&v_task_name'
ORDER BY t.parameter_name;

EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'ANALYSIS_SCOPE', Value=>'MVIEW,PARTITION');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'CREATION_COST', Value=>'TRUE');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DAYS_TO_EXPIRE', Value=>3);
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DEF_MVIEW_OWNER', Value=>'BITEST');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DEF_MVIEW_TABLESPACE', Value=>'TAB_STORAGE_SLOW');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DEF_MVLOG_TABLESPACE', Value=>'TAB_STORAGE_SLOW');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DEF_PARTITION_TABLESPACE', Value=>'TAB_STORAGE_SLOW');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DML_VOLATILITY', Value=>'TRUE');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'JOURNALING', Value=>'INFORMATION');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'MODE', Value=>'COMPREHENSIVE');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'MVIEW_NAME_TEMPLATE', Value=>'dba10499mv_<TASK_ID>_<SEQ>');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'STORAGE_CHANGE', Value=>5368709120);
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'MODE', Value=>'COMPREHENSIVE');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'TIME_LIMIT', Value=>60*6);
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'REFRESH_MODE', Value=>'ON_DEMAND');


EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'ANALYSIS_SCOPE', Value=>'INDEX');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'CREATION_COST', Value=>'TRUE');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DML_VOLATILITY', Value=>'TRUE');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'JOURNALING', Value=>'INFORMATION6');
--����� �������, SQL Access Advisor ��������� ������� �� �������� ��������� ������� ������������ ������� ������� � ������������� ���������� ������� ���������� ��������
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DAYS_TO_EXPIRE', Value=>5);
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DEF_INDEX_OWNER', Value=>'UNICA_USER');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'DEF_INDEX_TABLESPACE', Value=>'TS_CMDM');
EXECUTE DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=>'&&v_task_name', parameter=>'MODE', Value=>'COMPREHENSIVE');
--EXECUTE DBMS_SQLTUNE.SET_TUNING_TASK_PARAMETER (task_name=>'&&v_task_name', parameter=>'TIME_LIMIT', value => 72*3600);


EXECUTE DBMS_ADVISOR.ADD_STS_REF(task_name=>'&&v_task_name',sts_owner=>'SYS',workload_name=>'&&v_sts_name');
SELECT * FROM DBA_ADVISOR_SQLA_WK_MAP;

-- exec DBMS_ADVISOR.RESET_TASK(task_name=>'&&v_task_name');
DECLARE
 v_job_id NUMBER;
BEGIN
  Dbms_Job.submit(v_job_id,'begin DBMS_ADVISOR.EXECUTE_TASK(task_name=>''&&v_task_name''); end;',sysdate);
  COMMIT;
  Dbms_Output.put_line('job is is: '||v_job_id);
END;
/

SELECT * FROM sys.dba_jobs_running t;

SELECT * FROM DBA_ADVISOR_JOURNAL t
WHERE t.task_name='&&v_task_name'
ORDER BY t.journal_entry_seq
;

SELECT *
FROM sys.DBA_ADVISOR_TASKS t
WHERE t.task_name='&&v_task_name'
;

/*
SET long 1000000 pagesize 0 longchunksize 1000
COLUMN get_clob format a80
spool &&v_task_name..txt replace
SELECT DBMS_ADVISOR.get_task_report('&&v_task_name') FROM dual;
spool off
*/

SELECT *
FROM DBA_ADVISOR_ACTIONS
WHERE task_name='&&v_task_name'
ORDER BY action_id;

declare
CURSOR curs IS
  SELECT DISTINCT action_id, command, attr1, attr2, attr3, attr4
  FROM dba_advisor_actions
  WHERE task_name = '&&v_task_name'
  ORDER BY action_id;
  v_action        number;
  v_command     VARCHAR2(32);
  v_attr1       VARCHAR2(4000);
  v_attr2       VARCHAR2(4000);
  v_attr3       VARCHAR2(4000);
  v_attr4       VARCHAR2(4000);
  v_attr5       VARCHAR2(4000);
BEGIN
  OPEN curs;
  DBMS_OUTPUT.PUT_LINE('=========================================');
  DBMS_OUTPUT.PUT_LINE('Task_name = &&v_task_name');
  LOOP
     FETCH curs INTO
       v_action, v_command, v_attr1, v_attr2, v_attr3, v_attr4 ;
   EXIT when curs%NOTFOUND;
   DBMS_OUTPUT.PUT_LINE('Action ID: ' || v_action);
   DBMS_OUTPUT.PUT_LINE('Command : ' || v_command);
   DBMS_OUTPUT.PUT_LINE('Attr1 (name)      : ' || SUBSTR(v_attr1,1,30));
   DBMS_OUTPUT.PUT_LINE('Attr2 (tablespace): ' || SUBSTR(v_attr2,1,30));
   DBMS_OUTPUT.PUT_LINE('Attr3             : ' || SUBSTR(v_attr3,1,30));
   DBMS_OUTPUT.PUT_LINE('Attr4             : ' || v_attr4);
   DBMS_OUTPUT.PUT_LINE('Attr5             : ' || v_attr5);
   DBMS_OUTPUT.PUT_LINE('----------------------------------------');
   END LOOP;
   CLOSE curs;
   DBMS_OUTPUT.PUT_LINE('=========END RECOMMENDATIONS============');
END show_recm;
/

EXECUTE DBMS_ADVISOR.CREATE_FILE(DBMS_ADVISOR.GET_TASK_SCRIPT('&&v_task_name'),'AWR_DUMPS', '&&v_task_name..sql');
--select DIRECTORY_PATH from sys.dba_directories where DIRECTORY_NAME='AWR_DUMPS';
-- EOF SAA routines --------------------


-- STA routines
-- How to Move SQL Profiles from One Database to Another (Including to Higher Versions) (Doc ID 457531.1)
-- Adding task by sql-text

declare
my_sqltext   CLOB;
my_task_name VARCHAR2(30);
begin
my_sqltext := '';
my_task_name := DBMS_SQLTUNE.CREATE_TUNING_TASK (my_sqltext, NULL, scope=>'COMPREHENSIVE', time_limit=>(60*60), task_name=>'&&v_task_name');
dbms_output.put_line(my_task_name);
end;
/

-- Adding task by sql_id|plan_hash
DECLARE
 my_task_name VARCHAR2(30);
begin
 my_task_name := DBMS_SQLTUNE.CREATE_TUNING_TASK(
  sql_id=>'ggj89myf14t2q',
  plan_hash_value=>1107306053,
  scope=>'COMPREHENSIVE',
  time_limit=>3600,
  task_name=>'&&v_task_name');
END;
/

-- Adding task with data from awr-rep
DECLARE
 my_task_name VARCHAR2(30);
begin
 my_task_name := DBMS_SQLTUNE.CREATE_TUNING_TASK(begin_snap=>&&v_bsnap, end_snap=>&&v_esnap,
  sql_id=>'871q1pcffs21b',
  plan_hash_value=>4151722489,
  scope=>'COMPREHENSIVE',
  time_limit=>3600,
  task_name=>'&&v_task_name');
END;
/


-- Adding task by sql_set
DECLARE
 my_task_name    VARCHAR2(30);
begin
 my_task_name := DBMS_SQLTUNE.CREATE_TUNING_TASK(
  sqlset_name=>'&&v_sts_name',
  scope=>'COMPREHENSIVE',  --scope=>'LIMITED',
  time_limit=>3600,
  task_name=>'&&v_task_name');
END;
/


select *
from SYS.DBA_ADVISOR_TASKS t
where t.task_name='&&v_task_name'
ORDER BY t.created desc;

BEGIN
  DBMS_SQLTUNE.SET_TUNING_TASK_PARAMETER (task_name=>'&&v_task_name', parameter=>'TIME_LIMIT', value => 1*3600);
  DBMS_SQLTUNE.SET_TUNING_TASK_PARAMETER (task_name=>'&&v_task_name', parameter=>'TEST_EXECUTE', value=>'AUTO'); --FULL/AUTO/OFF
  DBMS_SQLTUNE.SET_TUNING_TASK_PARAMETER (task_name=>'&&v_task_name', parameter=>'DAYS_TO_EXPIRE', value => 1);
  DBMS_SQLTUNE.SET_TUNING_TASK_PARAMETER (task_name=>'&&v_task_name', parameter=>'EXECUTION_DAYS_TO_EXPIRE', value => 1);
END;
/

select *
from SYS.DBA_ADVISOR_PARAMETERS t
where t.task_name='&&v_task_name'
ORDER BY t.parameter_name;

DECLARE
 v_job_id NUMBER;
BEGIN
  Dbms_Job.submit(v_job_id,'begin DBMS_SQLTUNE.EXECUTE_TUNING_TASK(task_name=>''&&v_task_name''); end;',sysdate);
  COMMIT;
  Dbms_Output.put_line('job is is: '||v_job_id);
END;
/

SELECT * FROM sys.dba_jobs t
WHERE t.job IN (1248)
;

SELECT * FROM sys.dba_jobs_running t;

-- exec DBMS_JOB.Run(973);
-- exec DBMS_JOB.REMOVE(31986);
-- commit;

SELECT *
FROM v$session_longops t
WHERE t.sid=1017
  AND t.serial#=58017
 --t.sid IN (2809) AND t.serial#=59935
ORDER BY t.last_update_time desc
;

select *
from V$ADVISOR_PROGRESS t
where t.sid IN (109) AND t.serial#=37584
;

SELECT --t.task_name||' '||t.status
       *
FROM sys.DBA_ADVISOR_TASKS t
WHERE t.task_name='&&v_task_name'
      --t.task_name LIKE 'tune_query%'
ORDER BY t.task_id desc
;

EXEC DBMS_SQLTUNE.INTERRUPT_TUNING_TASK(task_name=>'&&v_task_name');
EXEC DBMS_SQLTUNE.RESUME_TUNING_TASK(task_name=>'&&v_task_name');

set pagesize 0 LONG 200000 LONGCHUNKSIZE 1000 LINESIZE 128
spool /tmp/&&v_task_name..txt replace
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK( '&&v_task_name', 'TEXT', 'ALL', 'ALL' ) AS report FROM   DUAL;
spool off

SELECT *
FROM sys.DBA_ADVISOR_FINDINGS t
WHERE t.task_name='&&v_task_name'
;

SELECT *
FROM sys.DBA_ADVISOR_RECOMMENDATIONS t
WHERE t.task_name='&&v_task_name'
  --AND t.TYPE='SQL PROFILE'
  --AND t.TYPE='INDEX'
;

SELECT r.task_name, f.object_id, ' execute dbms_sqltune.accept_sql_profile(task_name => '''||f.task_name||''', object_id => '||f.object_id||', category=>''TPCH_TEST'', task_owner => ''SYS'', replace => TRUE, force_match=>true);' AS cmd
FROM sys.DBA_ADVISOR_RECOMMENDATIONS r, sys.DBA_ADVISOR_FINDINGS f
WHERE r.task_name='&&v_task_name'
  AND r.TYPE='SQL PROFILE'
  AND r.task_name=f.task_name AND r.finding_id=f.finding_id
;

--execute dbms_sqltune.accept_sql_profile(task_name => '&&v_task_name', task_owner => 'SYS', category=>'TPCH_TEST',replace => TRUE);
execute dbms_sqltune.accept_sql_profile(task_name => '&&v_task_name', task_owner => 'SYS', category=>'DEFAULT',description=>'&&v_task_descr',force_match=>TRUE,replace => TRUE);
execute dbms_sqltune.accept_sql_profile(task_name => '&&v_task_name', object_id => 2, task_owner => 'SYS', category=>'DEFAULT',description=>'&&v_task_descr',force_match=>TRUE,replace => TRUE);
define sql_profile_name="SYS_SQLPROF_0163a6b9641d0004"
EXECUTE DBMS_SQLTUNE.ALTER_SQL_PROFILE(name=>'&&sql_profile_name',attribute_name=>'CATEGORY',Value=>'DEFAULT');
EXECUTE DBMS_SQLTUNE.ALTER_SQL_PROFILE(name=>'&&sql_profile_name',attribute_name=>'description',Value=>'&&v_task_descr');

set head on echo off
SELECT *
FROM sys.DBA_SQL_PROFILES t
WHERE 1=1 --t.description='&&v_task_descr'
  --AND Upper(t.sql_text) LIKE '%V\_CONTACTHISTORY%' ESCAPE '\'
ORDER BY t.created desc
;

define v_profilename="SYS_SQLPROF_0179e28d50c60000"
SELECT extractValue(value(h),'.') AS hint
FROM sys.sqlobj$data od, sys.sqlobj$ so,
     table(xmlsequence(extract(xmltype(od.comp_data),'/outline_data/hint'))) h
WHERE so.name = '&&v_profilename'
  AND so.signature = od.signature
  AND so.category = od.category
  AND so.obj_type = od.obj_type
  AND so.plan_id = od.plan_id
;

-- Moving sql_profile
exec DBMS_SQLTUNE.CREATE_STGTAB_SQLPROF(table_name=>'STAGE',schema_name=>'TPCH',tablespace_name=>'EXCELLENT');

SELECT * FROM TPCH.STAGE;

exec DBMS_SQLTUNE.PACK_STGTAB_SQLPROF (profile_category=>'TPCH_TEST',staging_table_name =>'STAGE',staging_schema_owner=>'TPCH');

EXEC DBMS_SQLTUNE.UNPACK_STGTAB_SQLPROF(profile_category=>'TPCH_TEST',replace => TRUE,staging_table_name => 'STAGE', staging_schema_owner=>'TPCH');

EXEC DBMS_SQLTUNE.DROP_SQL_PROFILE('SYS_SQLPROF_01717862f31d0000',true);

BEGIN
 FOR i IN (SELECT name FROM SYS.DBA_SQL_PROFILES WHERE category='TPCH_TEST' AND task_exec_name='EXEC_25863')
 loop
   DBMS_SQLTUNE.DROP_SQL_PROFILE(i.name,true);
 END LOOP;
END;
/

BEGIN
 FOR i IN (SELECT name FROM SYS.DBA_SQL_PROFILES WHERE category='DEFAULT' AND name IN ('SYS_SQLPROF_0168c7661f8e0000','SYS_SQLPROF_016948416bc30006'))
 loop
   DBMS_SQLTUNE.DROP_SQL_PROFILE(i.name,true);
 END LOOP;
END;
/


-- EOF STA routines

