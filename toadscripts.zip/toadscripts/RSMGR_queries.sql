-- Deleteing mapping rule
BEGIN
  DBMS_RESOURCE_MANAGER.CLEAR_PENDING_AREA();
  DBMS_RESOURCE_MANAGER.CREATE_PENDING_AREA();
  DBMS_RESOURCE_MANAGER.SET_CONSUMER_GROUP_MAPPING('CLIENT_MACHINE','WORKGROUP\WINXP',NULL);
  DBMS_RESOURCE_MANAGER.SUBMIT_PENDING_AREA();
END;
/

BEGIN
  DBMS_RESOURCE_MANAGER.CLEAR_PENDING_AREA();
  DBMS_RESOURCE_MANAGER.CREATE_PENDING_AREA();
  DBMS_RESOURCE_MANAGER.UPDATE_PLAN_DIRECTIVE(
         PLAN                  => 'RESTRICT_CRAZY_ACTIVITY',
         GROUP_OR_SUBPLAN      => 'DSS_GROUP',
         new_switch_time => 300,
         new_switch_estimate => FALSE,
         new_switch_io_megabytes => 2500,
         new_switch_for_call => TRUE
        );
  DBMS_RESOURCE_MANAGER.SUBMIT_PENDING_AREA();
END;
/

-- exec DBMS_RESOURCE_MANAGER_PRIVS.GRANT_SWITCH_CONSUMER_GROUP('BITEST','SYS_GROUP',FALSE);
-- exec  DBMS_RESOURCE_MANAGER.SWITCH_CONSUMER_GROUP_FOR_SESS ('1334','3271', 'DSS_GROUP');
-- exec DBMS_RESOURCE_MANAGER.SWITCH_CONSUMER_GROUP_FOR_USER ('BITEST','DSS_GROUP');

EXEC DBMS_RESOURCE_MANAGER.SWITCH_CONSUMER_GROUP_FOR_SESS(25,49193,'SYS_GROUP');

DBA_RSRC_CATEGORIES
DBA_RSRC_CONSUMER_GROUP_PRIVS;

SELECT * FROM DBA_RSRC_CONSUMER_GROUPS t;

select * from DBA_RSRC_GROUP_MAPPINGS t;

select * from DBA_RSRC_IO_CALIBRATE t;

SELECT * FROM DBA_RSRC_MANAGER_SYSTEM_PRIVS;

select * from DBA_RSRC_MAPPING_PRIORITY t;

select * from DBA_RSRC_PLAN_DIRECTIVES t where T.PLAN='DEFAULT_MAINTENANCE_PLAN';

select * from DBA_RSRC_PLANS t;

select * from DBA_SCHEDULER_WINDOW_GROUPS t;

select t.* from DBA_SCHEDULER_WINDOWS t;

SELECT * FROM DBA_SCHEDULER_WINGROUP_MEMBERS t;

SELECT * FROM DBA_SCHEDULER_WINDOW_LOG t ORDER by t.log_date desc;

--
-- alter system set resource_manager_plan='FORCE:' scope=both;
--Disable|enable windows
EXEC dbms_scheduler.enable('SYS.MAINTENANCE_WINDOW_GROUP');
EXEC dbms_scheduler.enable('SYS.WEEKNIGHT_WINDOW');
EXEC dbms_scheduler.enable('SYS.WEEKEND_WINDOW');
EXEC dbms_scheduler.enable('SYS.MONDAY_WINDOW');
EXEC dbms_scheduler.enable('SYS.TUESDAY_WINDOW');
EXEC dbms_scheduler.enable('SYS.WEDNESDAY_WINDOW');
EXEC dbms_scheduler.enable('SYS.THURSDAY_WINDOW');
EXEC dbms_scheduler.enable('SYS.FRIDAY_WINDOW');
EXEC dbms_scheduler.enable('SYS.SATURDAY_WINDOW');
EXEC dbms_scheduler.enable('SYS.SUNDAY_WINDOW');
COMMIT;

-- Disable DEFAULT_MAINTENANCE_PLAN
execute dbms_scheduler.set_attribute('MONDAY_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('TUESDAY_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('WEDNESDAY_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('THURSDAY_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('FRIDAY_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('SATURDAY_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('SUNDAY_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('WEEKNIGHT_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
execute dbms_scheduler.set_attribute('WEEKEND_WINDOW','RESOURCE_PLAN','DEFAULT_MAINTENANCE_PLAN');
COMMIT;

select *
from V$RSRC_CONS_GROUP_HISTORY t
where T.SQL_CANCELED > 0;

select *
from V$RSRC_SESSION_INFO t
where T.sid=1622;

select * from
V$RSRC_PLAN t;


select * from V$RSRC_PLAN_HISTORY
order by SEQUENCE# desc;

