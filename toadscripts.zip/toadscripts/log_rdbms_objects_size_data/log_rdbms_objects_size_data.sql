/*
--https://ticket.ertelecom.ru/browse/DBA-6573
sed --in-place -e "s/ \{1,\}$//" ./log_rdbms_objects_size_data.csv*
cat ./log_rdbms_objects_size_data.csv* | awk '{ x[$0]++; }END{for(i in x){ print i;}}' > result.txt
cat ./result.txt | awk -F ";" '{if ( $5 == "EXCELLENT" )  {print $0;}}' > ts_stat.txt
cat ./result.txt | awk -F ";" '{if ( $5 == "EXCELLENT_BIG" ) {print $0;}}' >> ts_stat.txt
cat ./result.txt | awk -F ";" '{if ( $5 == "INDEX_ALL" ) {print $0;}}' >> ts_stat.txt
cat ./result.txt | awk -F ";" '{if ( ( $5 != "SYSTEM" ) && ( $5 != "SYSAUX" ) ) {print $0;}}' > ts_stat.txt
sed -i -e "s/\(.*\)/\1;/g" ts_stat.txt

$ORACLE_HOME/bin/sqlplus -S / as sysdba << __EOF__
alter session set current_schema=excellent;
drop table segment_size_log;
create table segment_size_log (time number,owner varchar(40), segment varchar2 (80), size_in_bytes NUMBER, ts VARCHAR2(30));
exit;
__EOF__

(^[^ ]+) +([^ ]+)$
insert into excellent\.top_segments values\('\1','\2'\);
truncate table excellent.top_segments reuse storage;
commit;

$ORACLE_HOME/bin/sqlplus -S / as sysdba << __EOF__
alter session set current_schema=excellent;
drop table top_segments;
create table top_segments (owner varchar(40), segment varchar2 (40));
exit;
__EOF__

echo "load data
 infile 'ts_stat.txt'
 into table excellent.segment_size_log
 fields terminated by \";\" optionally enclosed by '\"'
 ( time,owner, segment, size_in_bytes, ts )" > loader.ctl; cat  loader.ctl

sqlldr \'/ as sysdba\' control=loader.ctl direct=Y

$ORACLE_HOME/bin/sqlplus -S / as sysdba << __EOF__
create index excellent.ssl_seg_name_idx on excellent.segment_size_log(segment);
create index excellent.time_idx on excellent.segment_size_log(time);
exit;
__EOF__
*/
-- truncate table excellent.segment_size_log reuse storage
--

/*
cat /dev/null > /tmp/date_time.txt
v_linenum="1"
v_dbsize="0"
while read line
do
 v_objectsize=$(echo -n $line | cut -f 4 -d ";")
 if [ "$v_linenum" -eq "1" ]
 then
     v_dbsize="$v_objectsize"
     v_timestamp=$(echo -n $line | cut -f 1 -d ";")
 else
     if [ "$v_timestamp" -eq "$(echo -n $line | cut -f 1 -d ";")" ]
     then
         v_dbsize=$((v_objectsize+v_dbsize))
     else
         echo "$v_timestamp $v_dbsize" | tee -a /tmp/date_time.txt
         v_dbsize="$v_objectsize"
     fi
 fi
 v_timestamp=$(echo -n $line | cut -f 1 -d ";")
 v_linenum=$((v_linenum+1))
 #echo "$v_linenum $v_timestamp $v_objectsize $v_dbsize"
done < <(cat /var/log/rias/dba/log_rdbms_objects_size_data.csv | sort -n -k 1 -t ";" )

while read line
do
 v_timestamp=$(echo -n $line | cut -f 1 -d " ")
 echo "`date +'%Y-%m-%d_%H:%M:%S' -d @"$v_timestamp"` $line" 
done < <(cat /tmp/date_time.txt)

*/

-- For espp -------------------------------------------------------------
/*
$ORACLE_HOME/bin/sqlplus -S / as sysdba << __EOF__
alter session set current_schema=excellent;
drop table segment_size_log;
create table segment_size_log (time number, owner varchar(30), segment varchar2 (128), size_in_bytes NUMBER, ts_name varchar2(30) );
exit;
__EOF__

echo "load data
 infile 'ts_stat.txt'
 into table excellent.segment_size_log
 fields terminated by \";\" optionally enclosed by '\"'
 ( time,owner, segment, size_in_bytes )" > loader.ctl; cat  loader.ctl

sqlldr \'/ as sysdba\' control=loader.ctl direct=Y
*/

SELECT *
FROM EXCELLENT.SEGMENT_SIZE_LOG t
WHERE (t.owner||'.'||t.SEGMENT) IN ('EXCELLENT.PK_AS_PARAM_TYPES','EXCELLENT.I_CHECK_SUM','EXCELLENT.I_ETP_EXT_TEMPL','EXCELLENT.PK_MOTIV_CALC_TYPE','EXCELLENT.PK_PROPERTY_FORMS','EXCELLENT.I_BP_STEP_FROM','EXCELLENT.I_REQ_PLAN_EXEC','EXCELLENT.PK_SALARY_SERVICE_NOT_MANUAL','EXCELLENT.I_DATE_FOR_CALC_SERVICE','EXCELLENT.PK_PROTOLOGINS','EXCELLENT.PK_CCPD_PROP_ID','EXCELLENT.I_TEMPLATE_RIGHT_OBJECT','EXCELLENT.PK_PPR_RESERVE_LINE_TYPES','EXCELLENT.I_DSABONPACKS_PLAN_ID','EXCELLENT.PK_DS_ABONENT_PACKETS','EXCELLENT.I_REQ_PROC_ATTR_EN_PROC_STOP','EXCELLENT.I_ETP_REVISION_LOG','EXCELLENT.I_PR_A','EXCELLENT.I_CLIENTS_DS_USER_DATE_ATTRENT','EXCELLENT.PK_PPR_WORK','EXCELLENT.I_FIRST_SESSION_DATE','EXCELLENT.PK_FIRST_SESSIONS','EXCELLENT.I_DSABONPACKS_SALE_PACKAGE_ID','EXCELLENT.PK_PR_OBJECT_TYPE','EXCELLENT.CABLE_CITY_PROP_DICTIONARY','EXCELLENT.RUPD$_NAS_ZONES','EXCELLENT.RUPD$_PLAN_ITEMS','EXCELLENT.FLAG_LINK_PHONES','EXCELLENT.PR_PROC_PROBLEM_LINKS','EXCELLENT.NET_DAMAGE_AUTOLOG','EXCELLENT.PR_BP_STEP_RULES','EXCELLENT.RUPD$_PREFIXES','EXCELLENT.RUPD$_JUR_NEW_AGR_PLANS','EXCELLENT.RUPD$_JUR_NEW_AGR_TABLE','EXCELLENT.AS_REGISTRY_TYPES','EXCELLENT.ETP_TEMPLATES','EXCELLENT.FLAG_COMMENTS','EXCELLENT.PR_OBJECT','EXCELLENT.PR_PROC_ADDENDA_CHANGE','EXCELLENT.MON_NORM_STAT_POINTS','EXCELLENT.RUPD$_PSS_REGISTER_CENTREX','EXCELLENT.B_LIST_EXTR_ERR','EXCELLENT.FIXED_IP')
;

SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(time,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS datetime,
       sizeMb
FROM (
SELECT t.TIME AS time, round( Sum(size_in_bytes)/1024/1024, 2) AS sizeMb
FROM EXCELLENT.SEGMENT_SIZE_LOG t
WHERE (t.owner||'.'||t.SEGMENT) IN ('EXCELLENT.U_ADV_PRD_ACT_ALL','EXCELLENT.I_LICENSE_FEE_ADDEND_TIME','EXCELLENT.I_CH_A_TS','EXCELLENT.PK_ACTIVATE_LICENSEE_FEE','EXCELLENT.I_ACTLF_LADV_FLAG_LINK_ID','EXCELLENT.BILLS','EXCELLENT.I_B_A','EXCELLENT.I_AFL','EXCELLENT.PK_FLAG_LINKS','EXCELLENT.PK_LICENSE_FEE','EXCELLENT.ADV_ACT_LINK_ACTIVATE_LF','EXCELLENT.I_ACTLF_LADV_ACTION_ID','EXCELLENT.LICENSE_FEE','EXCELLENT.I_REQ_PROC_ATTR_EN_PROC_STOP','EXCELLENT.PK_ADV_ACT_LINK_ACTIVATE_LF','EXCELLENT.I_ACT_LIC_FEE_ACTIVE_TO','EXCELLENT.I_AGREEMENT_ID','EXCELLENT.I_ACTIVATE_LICENSE_FEE_ADDENDU','EXCELLENT.ACTIVATE_LICENSE_FEE','EXCELLENT.I_PREPARED_SESSIONS_RP_ADDENDA','EXCELLENT.HOUSE_MATERIAL_COSTS','EXCELLENT.I_RC_R_AF','EXCELLENT.I_PACKET_LINE_LINK')
GROUP BY t.TIME
ORDER BY t.TIME ASC )
;


DROP TABLE excellent.espp_objects;
CREATE TABLE excellent.espp_objects
TABLESPACE excellent
as
SELECT TIME,
       owner,
       obj_name,
       Sum(size_in_bytes) AS size_in_bytes
FROM (
SELECT time, owner,
       CASE WHEN InStr(SEGMENT,'|',1)>0 THEN SubStr(SEGMENT,1,InStr(SEGMENT,'|',1)-1) ELSE SEGMENT  END AS obj_name,
       CASE WHEN InStr(SEGMENT,'|',1)>0 THEN SubStr(SEGMENT,InStr(SEGMENT,'|',1)+1) ELSE NULL END AS part_name,
       size_in_bytes
FROM excellent.segment_size_log t
WHERE NOT regexp_like(t.SEGMENT,'^BIN\$+.*')
--ORDER BY t.TIME, obj_name
 )
 GROUP BY TIME, owner, obj_name
 ORDER BY TIME ASC, owner, obj_name
;

CREATE INDEX excellent.owner_object_idx ON excellent.espp_objects(owner,obj_name) TABLESPACE excellent;

SELECT regexp_replace(SEGMENT,'([^\.]+)\.[^\.]+','\1') AS owner,
       regexp_replace(SEGMENT,'[^\.]+\.([^\.]+)','\1') AS name
from (
SELECT DISTINCT owner||'.'||obj_name AS segment FROM excellent.espp_objects t )
;

SELECT t.TIME, Round( Sum(t.size_in_bytes)/1024/1024/1024, 2) AS SizeGB
FROM excellent.espp_objects t
GROUP BY t.TIME
ORDER BY t.TIME asc
;



SELECT *
FROM excellent.espp_objects t
WHERE t.owner='REPLIC'
  AND regexp_like(t.obj_name,'^C_T_BANK_STATEMENT.*')
;

SELECT t.TIME AS TIME, t.size_in_bytes AS seg_size
FROM excellent.espp_objects t
WHERE t.owner='AUTO_PAY'
  AND regexp_like(t.obj_name,'^IDX_T_CARD_UNIQ.*');

SELECT t.TIME AS TIME, Sum(t.size_in_bytes) AS size_bytes
FROM excellent.espp_objects t
WHERE t.owner||'.'||t.obj_name IN (
'CAMPAIGN.F_PRIORITIZATION','CAMPAIGN.PR_FRONT_COMMUNICATION_HIST','EXCHANGE.COMMUNICATION_TASK','CMDM.AGG_SCORING_RESULT','STAGE.COMMUNICATION_HIST','CMDM.SERVICE','CAMPAIGN.UA_DTLCONTACTHIST','CAMPAIGN.PR_CLEARED_STATUS','STAGE.PRE_COMMUNIC_HIST','EXCHANGE.IDX$$_1B710004','EXCHANGE.CHANNEL_FEEDBACK','EXCHANGE.I_CHANNEL_FEEDBACK','CMDM.AGREEMENT_FLAGS','CAMPAIGN.PR_STATUS','CAMPAIGN.I_DTL_TREATMENT_CUSTOMER_COM_1','EXCHANGE.I_CF_CHAN_ID_ST_DT_CT_RK','EXCHANGE.I_COMMUNICATION_TASK_CAMP_CODE','EXCHANGE.PK_COMMUNICATION_TASK','CMDM.OUT_CONTACT_CLIENT','EXCHANGE.I_CREATION_COM_TASK','CAMPAIGN.PRE_F831_CAMPGN_COMMS_2','STAGE.COMMUNICATION','CMDM.I_START_DTTM_COMM_TASK','STAGE.I_PRE_COMMUNIC_HIST','EXCHANGE.IDX$$_1B710002','EXCHANGE.I_COMMUNICATION_TASK','EXCHANGE.I_CHANNEL_FEEDBACK_SDATE','EXCHANGE.I_CHANNEL_FEEDBACK_CTRK','CAMPAIGN.I_UA_RESPONSEHISTORY_TREATID','CMDM.I_SERV_SERV_CL'
)
GROUP BY t.time
ORDER BY t.time
;

SELECT *
FROM (
SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(t.time,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS datetime,
       t.TIME AS TIME,
       t.size_in_bytes as size_bytes,
       t.owner||'.'||t.obj_name AS segname
FROM excellent.espp_objects t
WHERE t.owner||'.'||t.obj_name IN (
'CAMPAIGN.F_PRIORITIZATION','CAMPAIGN.PR_FRONT_COMMUNICATION_HIST','EXCHANGE.COMMUNICATION_TASK','CMDM.AGG_SCORING_RESULT','STAGE.COMMUNICATION_HIST','CMDM.SERVICE','CAMPAIGN.UA_DTLCONTACTHIST','CAMPAIGN.PR_CLEARED_STATUS','STAGE.PRE_COMMUNIC_HIST','EXCHANGE.IDX$$_1B710004','EXCHANGE.CHANNEL_FEEDBACK','EXCHANGE.I_CHANNEL_FEEDBACK','CMDM.AGREEMENT_FLAGS','CAMPAIGN.PR_STATUS','CAMPAIGN.I_DTL_TREATMENT_CUSTOMER_COM_1','EXCHANGE.I_CF_CHAN_ID_ST_DT_CT_RK','EXCHANGE.I_COMMUNICATION_TASK_CAMP_CODE','EXCHANGE.PK_COMMUNICATION_TASK','CMDM.OUT_CONTACT_CLIENT','EXCHANGE.I_CREATION_COM_TASK','CAMPAIGN.PRE_F831_CAMPGN_COMMS_2','STAGE.COMMUNICATION','CMDM.I_START_DTTM_COMM_TASK','STAGE.I_PRE_COMMUNIC_HIST','EXCHANGE.IDX$$_1B710002','EXCHANGE.I_COMMUNICATION_TASK','EXCHANGE.I_CHANNEL_FEEDBACK_SDATE','EXCHANGE.I_CHANNEL_FEEDBACK_CTRK','CAMPAIGN.I_UA_RESPONSEHISTORY_TREATID','CMDM.I_SERV_SERV_CL'
)
 )
pivot (
max(size_bytes) FOR segname in (
'CAMPAIGN.F_PRIORITIZATION' as q1,
'CAMPAIGN.PR_FRONT_COMMUNICATION_HIST' as q2,
'EXCHANGE.COMMUNICATION_TASK' as q3,
'CMDM.AGG_SCORING_RESULT' as q4,
'STAGE.COMMUNICATION_HIST' as q5,
'CMDM.SERVICE' as q6,
'CAMPAIGN.UA_DTLCONTACTHIST' as q7,
'CAMPAIGN.PR_CLEARED_STATUS' as q8,
'STAGE.PRE_COMMUNIC_HIST' as q9,
'EXCHANGE.IDX$$_1B710004' as q10,
'EXCHANGE.CHANNEL_FEEDBACK' as q11,
'EXCHANGE.I_CHANNEL_FEEDBACK' as q12,
'CMDM.AGREEMENT_FLAGS' as q13,
'CAMPAIGN.PR_STATUS' as q14,
'CAMPAIGN.I_DTL_TREATMENT_CUSTOMER_COM_1' as q15,
'EXCHANGE.I_CF_CHAN_ID_ST_DT_CT_RK' as q16,
'EXCHANGE.I_COMMUNICATION_TASK_CAMP_CODE' as q17,
'EXCHANGE.PK_COMMUNICATION_TASK' as q18,
'CMDM.OUT_CONTACT_CLIENT' as q19,
'EXCHANGE.I_CREATION_COM_TASK' as q20,
'CAMPAIGN.PRE_F831_CAMPGN_COMMS_2' as q21,
'STAGE.COMMUNICATION' as q22,
'CMDM.I_START_DTTM_COMM_TASK' as q23,
'STAGE.I_PRE_COMMUNIC_HIST' as q24,
'EXCHANGE.IDX$$_1B710002' as q25,
'EXCHANGE.I_COMMUNICATION_TASK' as q26,
'EXCHANGE.I_CHANNEL_FEEDBACK_SDATE' as q27,
'EXCHANGE.I_CHANNEL_FEEDBACK_CTRK' as q28,
'CAMPAIGN.I_UA_RESPONSEHISTORY_TREATID' as q29,
'CMDM.I_SERV_SERV_CL' as q30
 )
  )
ORDER BY TIME
;

DECLARE
 v_x    NUMBER;
 v_mint NUMBER;
 v_maxt NUMBER;
 v_fsize NUMBER;
 v_lsize NUMBER;
 v_delta NUMBER;
 CURSOR c1 IS SELECT REPLACE( regexp_substr(obj,'^[^\.]+\.'),'.','') AS obj_owner,
                     REPLACE( regexp_substr(obj,'\..*'), '.', '')  AS obj_name
 FROM (  SELECT DISTINCT t.owner||'.'||t.obj_name AS obj FROM excellent.espp_objects t --WHERE ROWNUM <= 100
       );
BEGIN

 FOR i IN c1
 LOOP
   SELECT Nvl( Variance(t.size_in_bytes), 0)
   INTO v_x
   FROM excellent.espp_objects t
   WHERE t.owner=i.obj_owner AND t.obj_name=i.obj_name;

   IF v_x > 0
   THEN
    SELECT Min(t.TIME) INTO v_mint FROM excellent.espp_objects t WHERE t.owner=i.obj_owner AND t.obj_name=i.obj_name;
    SELECT Max(t.TIME) INTO v_maxt FROM excellent.espp_objects t WHERE t.owner=i.obj_owner AND t.obj_name=i.obj_name;

   begin
    SELECT Nvl(t.size_in_bytes,0) INTO v_fsize FROM excellent.espp_objects t WHERE t.owner=i.obj_owner AND t.obj_name=i.obj_name AND t.TIME=v_mint;
    SELECT Nvl(t.size_in_bytes,0) INTO v_lsize FROM excellent.espp_objects t WHERE t.owner=i.obj_owner AND t.obj_name=i.obj_name AND t.TIME=v_maxt;
    v_delta:=v_lsize-v_fsize;
    IF v_delta > 0
    THEN
     Dbms_Output.put_line(i.obj_owner||'.'||i.obj_name||' '||v_delta);
    END IF;
   EXCEPTION
    WHEN OTHERS THEN Dbms_Output.put_line('ERR: '||i.obj_owner||'.'||i.obj_name);
   END;
   END IF;
 END LOOP;
END;
/

SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(time,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS time,
       obj_size,
       CASE WHEN r_asc > 1 THEN obj_size-prev_obj_size
       ELSE 0
       END AS delta
FROM (
SELECT t.TIME AS time,
       nvl(t.size_in_bytes,0) AS obj_size,
       Lag(t.size_in_bytes,1,0) OVER( ORDER BY t.TIME ASC) AS prev_obj_size,
       Row_Number() OVER( ORDER BY t.TIME ASC) AS r_asc
       --Sum(t.size_in_bytes ) OVER( ORDER BY t.TIME ASC ROWS BETWEEN unbounded preceding AND CURRENT row) AS csum
FROM excellent.espp_objects t
WHERE t.owner='CAMPAIGN' AND t.obj_name='UA_DTLCONTACTHIST'
ORDER BY t.TIME ASC
 )
;
-- ESPP workaround ------------------------------------------------------
-------------------------------------------------------------------------

SELECT Count(*), Min(t.TIME), Max(t.TIME)
FROM excellent.segment_size_log t
;

SELECT *
FROM excellent.segment_size_log t
ORDER BY t.time  desc
;

SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(1540069202,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS datetime FROM dual;

SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(t.time,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS datetime,
       Round(Sum(t.size_in_bytes)/1024/1024,2) AS all_objects_size_Mb
FROM excellent.segment_size_log t
WHERE 1=1 --t.ts='EXCELLENT'
GROUP BY t.time
ORDER BY t.time
;

SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(snap_id,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS datetime, snap_id ,size_of_top_mb
FROM (
SELECT t.TIME AS snap_id,
       Round(Sum(t.size_in_bytes)/1024/1024,2) AS size_of_top_mb
FROM excellent.segment_size_log t
WHERE 1=1 --t.ts='INDEX_ALL'
  --AND t.owner='EXCELLENT' AND t.SEGMENT='SMS_GW_LOGS'
  AND t.owner||'.'||t.SEGMENT IN ( SELECT t1.owner||'.'||t1.segment FROM excellent.top_segments t1 )
GROUP BY t.time
ORDER BY t.TIME
 )
;

CREATE TABLE excellent.top_segments (owner VARCHAR2(30), SEGMENT VARCHAR2(80)) TABLESPACE excellent;


SELECT t.TIME AS snap_id,
       Round(Sum(t.size_in_bytes)/1024/1024,2) AS SizeOfTop_Mb
FROM excellent.segment_size_log t
WHERE 1=1 --t.ts='INDEX_ALL'
  AND t.owner||'.'||t.SEGMENT IN ( SELECT t1.owner||'.'||t1.segment FROM excellent.top_segments t1 )
  --AND t.owner||'.'||t.SEGMENT='RADIUS_TT.ACCT2_DETAIL_PROT'
  --AND t.owner||'.'||t.SEGMENT='RADIUS_TT.IDX_ACCT2_DET_PROT_2'
GROUP BY t.time
ORDER BY t.time
;


SELECT segment_name,
       regexp_substr(segment_name,'^[A-Za-z0-9_$#]+') AS owner,
       regexp_substr(segment_name,'[A-Za-z0-9_$#]+$') AS name
FROM (
SELECT DISTINCT t.owner||'.'||t.SEGMENT AS segment_name
FROM excellent.segment_size_log t
WHERE t.ts='WEB' )
;

SELECT t.TIME, Round(t.size_in_bytes/1024/1024,2) AS sizeMb
FROM excellent.segment_size_log t
WHERE 1=1
  --and t.ts='EXCELLENT'
  AND t.owner='EXCELLENT'
  AND t.SEGMENT='TP_CALLS_SOURCE_RAW'
order by t.time asc
;

select objname,
       round( (endsize-beginsize)/1024/1024/1024,2) as DeltaGb
from (
select t.owner||'.'||t.segment as objname,
       nvl(min(t.size_in_bytes),0) as beginsize,
       nvl(max(t.size_in_bytes),0) as endsize
from excellent.segment_size_log t
where t.ts='INDEX_ALL'
  and t.time in (1613934006,1614020411)
group by t.owner||'.'||t.segment )
order by 2 asc
;


DELETE FROM excellent.segment_size_log t
WHERE t.owner='EXCELLENT'
  AND t.SEGMENT='BIN$zrklWZffUbPgQGMKJOsSYw==$0'
;
COMMIT;

WITH DATA AS
(SELECT
'ALIEN_USERS,ARM_XML,EXCELLENT,EXCELLENT_BIG,INDEX_ALL,MONITOR,MVIEWLOG,SUPPORT_EXCL,SYSAUX,SYSTEM,UNDOTBS1,USERS,WEB'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as o'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;

SELECT ''''||t.owner||'.'||t.SEGMENT||''' as o'||ROWNUM||',' AS col FROM excellent.top_segments t;

SELECT DISTINCT t.ts FROM excellent.segment_size_log t;

-- By ts
SELECT *
FROM (
SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(t.time,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS datetime,
       t.TIME AS TIME,
       t.ts AS ts_name,
       Round(Sum(t.size_in_bytes)/1024/1024,2) AS SizeMb
FROM excellent.segment_size_log t
GROUP BY t.TIME, t.ts
ORDER BY t.time, t.ts)
pivot (
max(SizeMb) FOR ts_name in (
'EXCELLENT' as o3,
'EXCELLENT_BIG' as o4,
'INDEX_ALL' as o5,
'MONITOR' as o6,
'MVIEWLOG' as o7,
'SUPPORT_EXCL' as o8,
'SYSAUX' as o9,
'SYSTEM' as o10,
'UNDOTBS1' as o11,
'USERS' as o12,
'WEB' as o13
 )
)
ORDER BY datetime
;


SELECT *
FROM (
SELECT t.TIME AS datetime,
       to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(t.time,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS date_time,
       t.owner||'.'||t.SEGMENT AS object_name,
       Round(t.size_in_bytes/1024/1024,2) AS object_size_Mbytes
FROM excellent.segment_size_log t
WHERE 1=1 --AND t.ts='WEB'
  --AND t.owner||'.'||t.SEGMENT IN (SELECT t1.owner||'.'||t1.segment FROM excellent.top_segments t1)
  AND t.owner||'.'||t.SEGMENT IN ( 
'EXCELLENT.SAP_MATERIAL_CHAR_LINKS','EXCELLENT.I_SAP_M_CH_L_CHAR_ID','EXCELLENT.I_SAP_M_CH_L_MATERIALS_ID','EXCELLENT.PK_SAP_MATERIAL_CHAR_LINKS'
)
 )
pivot (
max(object_size_Mbytes) FOR object_name in
(
'EXCELLENT.SAP_MATERIAL_CHAR_LINKS' as o1,
'EXCELLENT.I_SAP_M_CH_L_CHAR_ID' as o2,
'EXCELLENT.I_SAP_M_CH_L_MATERIALS_ID' as o3,
'EXCELLENT.PK_SAP_MATERIAL_CHAR_LINKS' as o4
 )
)
ORDER BY datetime
;

SELECT *
FROM sys.dba_objects t
WHERE t.object_name IN ('I_CM_SESSION_EXPIRY_DATE_IN','I_CM_SESSION_EXPIRY_TASK_DATE')
  AND t.owner='WEB'
;

SELECT *
FROM sys.dba_indexes t
WHERE t.index_name IN ('I_CM_SESSION_EXPIRY_DATE_IN','I_CM_SESSION_EXPIRY_TASK_DATE')
  AND t.owner='WEB'
;

CREATE INDEX excellent.segment_size_log_obj ON excellent.segment_size_log(owner,segment) TABLESPACE excellent;

CREATE TABLE excellent.all_segments_stat TABLESPACE excellent
as
SELECT t.time AS time,
       Sum(t.size_in_bytes) AS all_objects_size
FROM excellent.segment_size_log t
WHERE 1=1 --t.ts='EXCELLENT'
GROUP BY t.time
ORDER BY t.time
;

    SELECT ao.TIME, t.TIME, Nvl(t.size_in_bytes,0) AS segment_size, ao.all_objects_size
    FROM excellent.segment_size_log t, excellent.all_segments_stat ao
    WHERE t.owner(+)='OS_EQM' AND t.SEGMENT(+)='DJ_06_2019'
      AND t.TIME(+)=ao.TIME;

SELECT Sqrt( Sum( Power(Nvl(t.size_in_bytes,0) - ao.all_objects_size,2) ) ) AS eqld_distance
FROM excellent.segment_size_log t, excellent.all_segments_stat ao
WHERE t.owner(+)='OS_EQM' AND t.SEGMENT(+)='DJ_06_2019'
  AND t.TIME(+)=ao.TIME;

DECLARE
 v_x    NUMBER;
 v_y    number;
 v_z    number;
 CURSOR c1 IS SELECT REPLACE( regexp_substr(obj,'^[^\.]+\.'),'.','') AS obj_owner,
                     REPLACE( regexp_substr(obj,'\..*'), '.', '')  AS obj_name
 FROM (  SELECT DISTINCT t.owner||'.'||t.SEGMENT AS obj FROM excellent.segment_size_log t --WHERE ROWNUM <= 100
       );
BEGIN
 v_y := 0;
 FOR i IN c1
 LOOP
   SELECT Nvl( Variance(t.size_in_bytes), 0)
   INTO v_x
   FROM excellent.segment_size_log t
   WHERE t.owner=i.obj_owner AND t.SEGMENT=i.obj_name;

   IF v_x > 0
   THEN
    v_y := v_y+1;
    v_z := 0;
    SELECT Round( Sqrt( Sum( Power(Nvl(t.size_in_bytes,0) - ao.all_objects_size,2) ) ), 2) AS eqld_distance
    INTO v_z
    FROM excellent.segment_size_log t, excellent.all_segments_stat ao
    WHERE t.owner(+)=i.obj_owner AND t.SEGMENT(+)=i.obj_name
      AND t.TIME(+)=ao.TIME;
    Dbms_Output.put_line(i.obj_owner||'.'||i.obj_name||' '||v_z);
   END IF;
 END LOOP;
 Dbms_Output.put_line(v_y);
END;
/


SELECT *
FROM sys.dba_jobs t
;

SELECT *
FROM sys.dba_segments t
WHERE t.owner='SYSTEM' AND t.segment_name='SEGMENTS_SIZE'
;

SELECT t.datetime AS dt, Round(Sum(t.bytes)/1024/1024/1024,2) AS metric
FROM SYSTEM.segments_size t
GROUP BY t.datetime
ORDER BY t.datetime asc
;

SELECT DISTINCT t.owner, t.segment_name
FROM SYSTEM.segments_size t
WHERE 1=1
  AND NOT regexp_like(t.segment_name,'^BIN\$.*')
  AND NOT regexp_like(t.segment_name,'^_SYSSMU[0-9]+_[0-9]+\$*')
;

SELECT t.datetime AS dt,
       Round(Sum(t.bytes)/1024/1024/1024,2) AS stat_value
FROM SYSTEM.segments_size t
WHERE 1=1
  --AND t.owner='SYS' AND t.segment_name='SYS_IL0000011222C00008$$'
  AND t.owner||'.'||t.segment_name IN ('ESPP_AUDIT.AUDIT_DDL_TABLE','ESPP.IDX_BO_DOG_TYPE_CRDT','ESPP.T_BUSINESS_OPERATION','ESPP.T_BO_TR_FK_IDX','ESPP.T_TN_PK_IDX','ESPP.T_BO_CREATE_DT_IDX','ESPP.T_TN_PAR_VALUE_IDX','ENJOYMENT_OF_RIGHT.T_DEBUG','ESPP.T_BO_PS_FK_IDX','ESPP.T_BO_PK_IDX','ESPP.T_BO_TYPE_FK_IDX','ESPP.T_BO_DOG_ID_FK_IDX','ESPP.T_TR_SRC_DOG_ID_FK_IDX','ESPP.T_TS_PK_IDX','ESPP_AUDIT.AUDIT_TABLE','ESPP.T_TR_NPARAM','ESPP.T_ESPP_ASR_LOG','ESPP.T_TS_PAR_FK_IDX','ESPP.T_TS_VALUE_IDX','ENJOYMENT_OF_RIGHT.IDX_T_DEBUG_PART_01','ESPP.T_TRANSACTION_ITEM','ESPP.T_TRI_MSTATUS_FK_IDX','ESPP.T_TRANSACTION','ESPP.T_TR_PAY_MSTATUS_FK_IDX','ESPP.T_TR_WORK_MSTATUS_FK_IDX','ESPP_AUDIT.T_BUSINESS_OPERATION','ESPP.T_BO_RS_FK_IDX','ESPP.T_TRI_PK_IDX','REGISTRATION.T_LOGGING','ESPP.T_TR_SPARAM','ESPP.T_TRI_IDX','ESPP_AUDIT.PK_AUDIT_DDL_TABLE','ESPP.T_TRI_SVC_NUM_IDX','DATA_PIPE.T_CD_WIDENING_HST','ESPP.T_TR_PK','ESPP_AUDIT.AUDIT_LOGON_TABLE','ESPP.T_TD_PAR_VALUE_IDX','ENJOYMENT_OF_RIGHT.PK_DEBUG','ESPP.T_TRI_PP_FK_IDX','ESPP_AUDIT.PK_AUDIT_TABLE','ESPP_AUDIT.IDX_T_BUSINESS_OPERATION','ESPP.T_TD_PK_IDX','DATA_PIPE.T_CD_MAIN_HST')
GROUP BY t.datetime
ORDER BY t.datetime asc;

CREATE INDEX SYSTEM.seg_size_owner_segname_idx ON SYSTEM.segments_size(owner, segment_name) TABLESPACE TS_AUDIT;
DROP INDEX SYSTEM.seg_size_owner_segname_idx;

SELECT *
FROM (
SELECT t.datetime AS dt,
       t.owner||'.'||t.segment_name AS seg_name,
       Round(Sum(t.bytes)/1024/1024/1024,2) AS stat_value
FROM SYSTEM.segments_size t
WHERE 1=1
  AND t.owner||'.'||t.segment_name IN ('ESPP_AUDIT.AUDIT_DDL_TABLE','ESPP.IDX_BO_DOG_TYPE_CRDT','ESPP.T_BUSINESS_OPERATION','ESPP.T_BO_TR_FK_IDX','ESPP.T_TN_PK_IDX','ESPP.T_BO_CREATE_DT_IDX','ESPP.T_TN_PAR_VALUE_IDX','ENJOYMENT_OF_RIGHT.T_DEBUG','ESPP.T_BO_PS_FK_IDX','ESPP.T_BO_PK_IDX','ESPP.T_BO_TYPE_FK_IDX','ESPP.T_BO_DOG_ID_FK_IDX','ESPP.T_TR_SRC_DOG_ID_FK_IDX','ESPP.T_TS_PK_IDX','ESPP_AUDIT.AUDIT_TABLE','ESPP.T_TR_NPARAM','ESPP.T_ESPP_ASR_LOG','ESPP.T_TS_PAR_FK_IDX','ESPP.T_TS_VALUE_IDX','ENJOYMENT_OF_RIGHT.IDX_T_DEBUG_PART_01','ESPP.T_TRANSACTION_ITEM','ESPP.T_TRI_MSTATUS_FK_IDX','ESPP.T_TRANSACTION','ESPP.T_TR_PAY_MSTATUS_FK_IDX','ESPP.T_TR_WORK_MSTATUS_FK_IDX','ESPP_AUDIT.T_BUSINESS_OPERATION','ESPP.T_BO_RS_FK_IDX','ESPP.T_TRI_PK_IDX','REGISTRATION.T_LOGGING','ESPP.T_TR_SPARAM','ESPP.T_TRI_IDX','ESPP_AUDIT.PK_AUDIT_DDL_TABLE','ESPP.T_TRI_SVC_NUM_IDX','DATA_PIPE.T_CD_WIDENING_HST','ESPP.T_TR_PK','ESPP_AUDIT.AUDIT_LOGON_TABLE','ESPP.T_TD_PAR_VALUE_IDX','ENJOYMENT_OF_RIGHT.PK_DEBUG','ESPP.T_TRI_PP_FK_IDX','ESPP_AUDIT.PK_AUDIT_TABLE','ESPP_AUDIT.IDX_T_BUSINESS_OPERATION','ESPP.T_TD_PK_IDX','DATA_PIPE.T_CD_MAIN_HST')
GROUP BY t.datetime, t.owner||'.'||t.segment_name )
pivot (
 Max(stat_value)
 FOR seg_name IN (
'ESPP_AUDIT.AUDIT_DDL_TABLE' as s_1,
'ESPP.IDX_BO_DOG_TYPE_CRDT' as s_2,
'ESPP.T_BUSINESS_OPERATION' as s_3,
'ESPP.T_BO_TR_FK_IDX' as s_4,
'ESPP.T_TN_PK_IDX' as s_5,
'ESPP.T_BO_CREATE_DT_IDX' as s_6,
'ESPP.T_TN_PAR_VALUE_IDX' as s_7,
'ENJOYMENT_OF_RIGHT.T_DEBUG' as s_8,
'ESPP.T_BO_PS_FK_IDX' as s_9,
'ESPP.T_BO_PK_IDX' as s_10,
'ESPP.T_BO_TYPE_FK_IDX' as s_11,
'ESPP.T_BO_DOG_ID_FK_IDX' as s_12,
'ESPP.T_TR_SRC_DOG_ID_FK_IDX' as s_13,
'ESPP.T_TS_PK_IDX' as s_14,
'ESPP_AUDIT.AUDIT_TABLE' as s_15,
'ESPP.T_TR_NPARAM' as s_16,
'ESPP.T_ESPP_ASR_LOG' as s_17,
'ESPP.T_TS_PAR_FK_IDX' as s_18,
'ESPP.T_TS_VALUE_IDX' as s_19,
'ENJOYMENT_OF_RIGHT.IDX_T_DEBUG_PART_01' as s_20,
'ESPP.T_TRANSACTION_ITEM' as s_21,
'ESPP.T_TRI_MSTATUS_FK_IDX' as s_22,
'ESPP.T_TRANSACTION' as s_23,
'ESPP.T_TR_PAY_MSTATUS_FK_IDX' as s_24,
'ESPP.T_TR_WORK_MSTATUS_FK_IDX' as s_25,
'ESPP_AUDIT.T_BUSINESS_OPERATION' as s_26,
'ESPP.T_BO_RS_FK_IDX' as s_27,
'ESPP.T_TRI_PK_IDX' as s_28,
'REGISTRATION.T_LOGGING' as s_29,
'ESPP.T_TR_SPARAM' as s_30,
'ESPP.T_TRI_IDX' as s_31,
'ESPP_AUDIT.PK_AUDIT_DDL_TABLE' as s_32,
'ESPP.T_TRI_SVC_NUM_IDX' as s_33,
'DATA_PIPE.T_CD_WIDENING_HST' as s_34,
'ESPP.T_TR_PK' as s_35,
'ESPP_AUDIT.AUDIT_LOGON_TABLE' as s_36,
'ESPP.T_TD_PAR_VALUE_IDX' as s_37,
'ENJOYMENT_OF_RIGHT.PK_DEBUG' as s_38,
'ESPP.T_TRI_PP_FK_IDX' as s_39,
'ESPP_AUDIT.PK_AUDIT_TABLE' as s_40,
'ESPP_AUDIT.IDX_T_BUSINESS_OPERATION' as s_41,
'ESPP.T_TD_PK_IDX' as s_42,
'DATA_PIPE.T_CD_MAIN_HST' as s_43
 )
)

