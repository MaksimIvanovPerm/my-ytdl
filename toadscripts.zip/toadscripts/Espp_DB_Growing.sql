define seg_owner="ENJOYMENT_OF_RIGHT"
define seg_name="T_DEBUG"

SELECT  t.TIME AS datetime,
        Round(Sum(t.size_in_bytes)/1024/1024/1024,2) AS &&seg_owner._&&seg_name
FROM excellent.espp_seg_size t
WHERE t.owner='&&seg_owner' AND t.SEGMENT='&&seg_name'
GROUP BY t.time
ORDER BY t.time
;

SELECT  t.TIME AS datetime,
        Round(Sum(t.size_in_bytes)/1024/1024/1024,2) AS AllSegs
FROM excellent.espp_seg_size t
--WHERE t.owner='&&seg_owner' AND t.SEGMENT='&&seg_name'
GROUP BY t.time
ORDER BY t.time
;

SELECT substr(seg_name,1,InStr(seg_name,'.',1)-1) AS seg_owner
       ,substr(seg_name,InStr(seg_name,'.',1)+1) AS seg_name
FROM (
SELECT DISTINCT t.OWNER||'.'||t.SEGMENT AS seg_name
FROM excellent.espp_seg_size t )
;

define seg_name="ESPP.T_BO_RS_FK_IDX"

SELECT t.TIME,
       Round(Sum(t.size_in_bytes)/1024/1024,2) AS sizemb
       --Sum(t.size_in_bytes) AS sizebytes
FROM excellent.espp_seg_size t
WHERE t.OWNER=substr('&&seg_name',1,InStr('&&seg_name','.',1)-1)
  AND t.SEGMENT=substr('&&seg_name',InStr('&&seg_name','.',1)+1)
GROUP BY t.time
;

SELECT  t.TIME AS datetime,
        Round(Sum(t.size_in_bytes)/1024/1024/1024,2) AS "&&seg_name"
FROM excellent.espp_seg_size t
WHERE t.OWNER=substr('&&seg_name',1,InStr('&&seg_name','.',1)-1)
  AND t.SEGMENT=substr('&&seg_name',InStr('&&seg_name','.',1)+1)
GROUP BY t.time
ORDER BY t.time
;

SELECT *
FROM (
SELECT --t.TIME AS datetime,
      to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(t.time,'SECOND') AS datetime,
      t.owner||'.'||t.SEGMENT AS seg_name,
      Round(Sum(t.size_in_bytes)/1024/1024/1024,2) AS sizemb
FROM excellent.espp_seg_size t
WHERE t.owner||'.'||t.SEGMENT IN ('ESPP.T_TS_PK_IDX','ESPP.T_ESPP_ASR_LOG','EKM.T_ACT_SH_FK_IDX','ESPP.T_BO_RS_FK_IDX','ESPP.T_TS_PAR_FK_IDX','EKM.T_ACT_SERIAL_NUMBER_IDX','ESPP.T_TR_WORK_MSTATUS_FK_IDX','EKM.T_ACTION_PT_INFO','EKM.T_ACT_PT_FK_IDX','ESPP.T_TS_VALUE_IDX','ESPP_AUDIT.AUDIT_DDL_TABLE','EKM.T_ACT_ACC_FK_IDX','ESPP.T_TRI_PK_IDX','ENJOYMENT_OF_RIGHT.T_DEBUG','ESPP.T_TR_SRC_DOG_ID_FK_IDX','EKM.T_ACT_ID_IDX','ENJOYMENT_OF_RIGHT.IDX_T_DEBUG_PART_01','ESPP.T_TRI_MSTATUS_FK_IDX','ESPP.T_TD_PK_IDX')
GROUP BY t.TIME, t.owner||'.'||t.SEGMENT
)
pivot (
 Max(sizemb)
 FOR(seg_name) IN (
'ESPP.T_TS_PK_IDX' as ESPP_T_TS_PK_IDX,
'ESPP.T_ESPP_ASR_LOG' as ESPP_T_ESPP_ASR_LOG,
'EKM.T_ACT_SH_FK_IDX' as EKM_T_ACT_SH_FK_IDX,
'ESPP.T_BO_RS_FK_IDX' as ESPP_T_BO_RS_FK_IDX,
'ESPP.T_TS_PAR_FK_IDX' as ESPP_T_TS_PAR_FK_IDX,
'EKM.T_ACT_SERIAL_NUMBER_IDX' as EKM_T_ACT_SERIAL_NUMBER_IDX,
'ESPP.T_TR_WORK_MSTATUS_FK_IDX' as ESPP_T_TR_WORK_MSTATUS_FK_IDX,
'EKM.T_ACTION_PT_INFO' as EKM_T_ACTION_PT_INFO,
'EKM.T_ACT_PT_FK_IDX' as EKM_T_ACT_PT_FK_IDX,
'ESPP.T_TS_VALUE_IDX' as ESPP_T_TS_VALUE_IDX,
'ESPP_AUDIT.AUDIT_DDL_TABLE' as ESPP_AUDIT_AUDIT_DDL_TABLE,
'EKM.T_ACT_ACC_FK_IDX' as EKM_T_ACT_ACC_FK_IDX,
'ESPP.T_TRI_PK_IDX' as ESPP_T_TRI_PK_IDX,
'ENJOYMENT_OF_RIGHT.T_DEBUG' as ENJOYMENT_OF_RIGHT_T_DEBUG,
'ESPP.T_TR_SRC_DOG_ID_FK_IDX' as ESPP_T_TR_SRC_DOG_ID_FK_IDX,
'EKM.T_ACT_ID_IDX' as EKM_T_ACT_ID_IDX,
'ENJOYMENT_OF_RIGHT.IDX_T_DEBUG_PART_01' as qqq1,
'ESPP.T_TRI_MSTATUS_FK_IDX' as ESPP_T_TRI_MSTATUS_FK_IDX,
'ESPP.T_TD_PK_IDX' as ESPP_T_TD_PK_IDX
 )
)
ORDER BY  datetime
;
