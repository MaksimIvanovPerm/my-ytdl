define v_sid=1317
define v_serial=42095

SELECT Count(*), t.session_id||','||t.session_serial#
FROM sys.wrh$_active_session_history t
WHERE t.session_type=1
  AND t.MODULE LIKE 'dwh_charges_support%'
  AND regexp_like(program,'sqlplus@db[0-9]+ .*')
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  AND t.top_level_sql_id='g0gbbp276s9gm'
GROUP BY t.session_id||','||t.session_serial#
ORDER BY 1 desc;

SELECT *
FROM --sys.wrh$_active_session_history t
      sys.dba_hist_active_sess_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  --AND t.top_level_sql_id='g0gbbp276s9gm'
ORDER BY t.sample_id
;

SELECT t.sample_time, t.sql_id, t.sql_opcode, t.sql_exec_start, t.sql_exec_id
FROM sys.wrh$_active_session_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  --AND t.sql_exec_id=16777217
ORDER BY t.sample_id
;

SELECT To_Date(To_Char(t.sample_time,'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') AS sample_time,
       To_Date(To_Char(t.sql_exec_start,'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') AS sql_exec_start,
       24*60*Round( To_Date(To_Char(t.sample_time,'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') - To_Date(To_Char(t.sql_exec_start,'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss'), 4) AS DELTA,
       t.sql_exec_id
FROM sys.wrh$_active_session_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  AND t.sql_exec_id > 0
--GROUP BY t.sql_exec_id
ORDER BY t.sql_exec_id, t.sample_time
;

--1
SELECT max( 24*60*Round( To_Date(To_Char(t.sample_time,'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') - To_Date(To_Char(t.sql_exec_start,'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss'), 4) ) AS exec_ela_time,
       t.sql_exec_id
FROM sys.wrh$_active_session_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
GROUP BY t.sql_exec_id
ORDER BY exec_ela_time desc
;

--2
SELECT DISTINCT t.sql_id
FROM sys.wrh$_active_session_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  --AND t.top_level_sql_id='33nvhyjsthp0k'
  --AND t.sql_exec_id=16777988
  --AND t.action LIKE 'params$c = %'
  AND t.plsql_object_id=51256 AND t.plsql_subprogram_id=8
--ORDER BY t.sample_id
;

--3
SELECT t.sample_time, t.sql_id, t.MODULE, t.action, t.sql_exec_id, t.plsql_object_id, t.plsql_subprogram_id
FROM sys.wrh$_active_session_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  --AND t.top_level_sql_id='33nvhyjsthp0k'
  AND t.action LIKE 'get_earnings - charges'
  AND t.module LIKE 'dwh_charges_support2 %'
  --AND t.sql_id='88hhr4kc0ztyu'
ORDER BY t.sample_id
;

--3.1
SELECT Min(t.sample_time),Max(t.sample_time),Max(t.sample_time)-Min(t.sample_time), t.MODULE
FROM sys.wrh$_active_session_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  --AND t.top_level_sql_id='33nvhyjsthp0k'
  --AND t.action LIKE 'params$c = %'
  AND t.action LIKE 'get_earnings - charges'
  AND t.module LIKE 'dwh_charges_support2 %'
  --AND t.sql_id='88hhr4kc0ztyu'
GROUP BY t.MODULE
ORDER BY 1
;

SELECT t.line, t.text
FROM sys.dba_source t
WHERE t.name='DWH_CHARGES_SUPPORT2'
  AND t.owner='EXCELLENT'
  AND t.TYPE='PACKAGE BODY'
ORDER BY t.line
;

SELECT *
FROM sys.dba_procedures t
WHERE t.owner='EXCELLENT'
  AND t.object_name='DO_SPESIALIST_SUPPORT'
ORDER BY t.procedure_name
;

SELECT t.*
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  AND t.plsql_object_id=201329
  --AND t.plsql_subprogram_id=10
ORDER BY t.sample_id
;

SELECT DISTINCT t.prod_id
FROM temp_tab t;

SELECT  t.prod_id AS prod_id,
        Trunc(t.datetime,'DD') AS datetime,
        Round(t.rtime/100/60,2) AS ela_min
FROM temp_tab t
WHERE Round(t.rtime/100/60,2) > 0
ORDER BY datetime, ela_min desc
;

SELECT *
FROM (
SELECT  t.prod_id AS prod_id,
        Trunc(t.datetime,'DD') AS datetime,
        Round(t.rtime/100/60,2) AS ela_min
FROM temp_tab t
 )
 pivot (
 Max(ela_min) FOR prod_id IN (
'pid_0' as pid_0,
'pid_1' as pid_1,
'pid_11' as pid_11,
'pid_12' as pid_12,
'pid_13' as pid_13,
'pid_14' as pid_14,
'pid_15' as pid_15,
'pid_16' as pid_16,
'pid_17' as pid_17,
'pid_18' as pid_18,
'pid_19' as pid_19,
'pid_2' as pid_2,
'pid_20' as pid_20,
'pid_26' as pid_26,
'pid_27' as pid_27,
'pid_28' as pid_28,
'pid_29' as pid_29,
'pid_3' as pid_3,
'pid_30' as pid_30,
'pid_31' as pid_31,
'pid_32' as pid_32,
'pid_33' as pid_33,
'pid_34' as pid_34,
'pid_35' as pid_35,
'pid_36' as pid_36,
'pid_37' as pid_37,
'pid_38' as pid_38,
'pid_39' as pid_39,
'pid_4' as pid_4,
'pid_40' as pid_40,
'pid_41' as pid_41,
'pid_42' as pid_42,
'pid_43' as pid_43,
'pid_44' as pid_44,
'pid_46' as pid_46,
'pid_47' as pid_47,
'pid_48' as pid_48,
'pid_49' as pid_49,
'pid_5' as pid_5,
'pid_50' as pid_50,
'pid_52' as pid_52,
'pid_53' as pid_53,
'pid_54' as pid_54,
'pid_55' as pid_55,
'pid_56' as pid_56,
'pid_57' as pid_57,
'pid_58' as pid_58,
'pid_59' as pid_59,
'pid_6' as pid_6,
'pid_60' as pid_60,
'pid_61' as pid_61,
'pid_62' as pid_62,
'pid_63' as pid_63,
'pid_64' as pid_64,
'pid_65' as pid_65,
'pid_66' as pid_66,
'pid_67' as pid_67,
'pid_68' as pid_68,
'pid_69' as pid_69,
'pid_7' as pid_7,
'pid_70' as pid_70,
'pid_71' as pid_71,
'pid_72' as pid_72,
'pid_73' as pid_73,
'pid_8' as pid_8,
'pid_9' as pid_9
  )
 )
ORDER BY datetime;

select l2.day, sum(l2.time)*24
    from
    (
      select l.sl_function_id, trunc(l.time_start) day, max(l.time) time
      from
      (
        select sll.sl_log_id, sll.sl_function_id, time_stop, time_start, time_stop - time_start time
        from excellent.sl_logs sll
            ,excellent.sl_functions slf
        where sll.sl_function_id = slf.sl_function_id
          and slf.stream = 7
          ----
          and sll.time_start >= to_date('03.06.2015','dd.mm.yyyy')
          and sll.time_start <= to_date('03.06.2016','dd.mm.yyyy')
          ----
      ) l
      where l.time >= 0
      group by l.sl_function_id, trunc(l.time_start)
    ) l2
    group by l2.day
    order by l2.DAY
    ;

SELECT * FROM excellent.products t;

SELECT start_time,stop_time,
       Round((stop_time-start_time)*24*60,2) AS ela_min,
       sql_id,sql_exec_id
FROM (
SELECT To_Date(To_char(Min(t.sql_exec_start),'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') AS start_time,
       To_Date(To_Char(Max(t.sample_time),'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') AS stop_time,
       t.sql_id AS sql_id, t.sql_exec_id AS sql_exec_id
FROM sys.wrh$_active_session_history t
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  AND t.sql_opcode IN (2,3,6,7)
  AND t.sql_exec_id!=0
GROUP BY t.sql_id, t.sql_exec_id
 )
 WHERE stop_time-start_time > 0
 ORDER BY ela_min desc
;

SELECT t.sample_time,t.sql_id,t.sql_exec_id,
       obj.owner||'.'||obj.object_name||' '||obj.object_type AS object_data,
       t.MODULE,t.action,t.top_level_sql_id,
       t.plsql_entry_object_id,t.plsql_entry_subprogram_id,
       t.plsql_object_id,t.plsql_subprogram_id
FROM sys.wrh$_active_session_history t, sys.dba_objects obj
WHERE t.session_id=&&v_sid
  AND t.session_serial#=&&v_serial
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap and &&v_esnap
  AND t.current_obj#=obj.object_id(+)
  AND t.sql_id='88hhr4kc0ztyu'
  AND t.sql_exec_id=16780819
ORDER BY t.sample_id
;
