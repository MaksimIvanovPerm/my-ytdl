DECLARE
  v_str     VARCHAR2(4096) := '';
  v_sep     CHAR(1) := ';';
  v_n       NUMBER := 0;

  CURSOR c1 IS
  SELECT *
  FROM sys.dba_users t
  ORDER BY t.username;

  CURSOR c2(p_grantee IN varchar2) IS
  SELECT *
  FROM sys.dba_role_privs t
  WHERE t.grantee=p_grantee;

BEGIN
  dbms_Output.put_line('USERNAME'||v_sep||'USER_ID'||v_sep||'PASSWORD'||v_sep||'ACCOUNT_STATUS'||v_sep||'LOCK_DATE'||v_sep||'EXPIRY_DATE'||v_sep||'DEFAULT_TABLESPACE'||v_sep||'TEMPORARY_TABLESPACE'||v_sep||'CREATED'||v_sep||'PROFILE'||v_sep||'INITIAL_RSRC_CONSUMER_GROUP'||v_sep||'EXTERNAL_NAME'||v_sep||'PASSWORD_VERSIONS'||v_sep||'EDITIONS_ENABLED'||v_sep||'AUTHENTICATION_TYPE');
  FOR i IN c1
  LOOP
      v_str := '';
      v_n := 0;
      FOR j IN c2(i.username)
      LOOP
        IF v_n = 0
        THEN
          v_str := j.granted_role;
        ELSE
          v_str := v_str||','||j.granted_role;
        END IF;
        v_n := v_n + 1;
      END LOOP;
      dbms_Output.put_line(i.USERNAME||v_sep||i.USER_ID||v_sep||i.PASSWORD||v_sep||i.ACCOUNT_STATUS||v_sep||i.LOCK_DATE||v_sep||i.EXPIRY_DATE||v_sep||i.DEFAULT_TABLESPACE||v_sep||i.TEMPORARY_TABLESPACE||v_sep||i.CREATED||v_sep||i.PROFILE||v_sep||i.INITIAL_RSRC_CONSUMER_GROUP||v_sep||i.EXTERNAL_NAME||v_sep||i.PASSWORD_VERSIONS||v_sep||i.EDITIONS_ENABLED||v_sep||i.AUTHENTICATION_TYPE||v_sep||v_str);
  END LOOP;
END;
/
