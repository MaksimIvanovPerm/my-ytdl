DECLARE
  v_str     VARCHAR2(4096) := '';
  v_sep     CHAR(1) := ';';
  v_n       NUMBER := 0;

  CURSOR c1 IS
  SELECT *
  FROM sys.dba_roles t
  ORDER BY t.role;

  CURSOR c2(p_grantee IN varchar2) IS
  SELECT *
  FROM sys.dba_sys_privs t
  WHERE t.grantee=p_grantee;

BEGIN
  Dbms_Output.put_line('ROLE'||v_sep||'PRIVS');
  FOR i IN c1
  LOOP
      v_str := '';
      v_n := 0;
      FOR j IN c2(i.role)
      LOOP
        IF v_n = 0
        THEN
          v_str := j.privilege;
        ELSE
          v_str := v_str||','||j.privilege;
        END IF;
        v_n := v_n + 1;
      END LOOP;
      Dbms_Output.put_line(i.role||v_sep||v_str);
 END LOOP;
END;