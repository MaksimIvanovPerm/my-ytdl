SELECT Count(*) FROM SYS.LOGMNR_CONTENTS_TMP_EXT t
WHERE t.seg_owner='EXCELLENT' AND t.seg_name='PPPOE_LAST_SESSIONS'
;
drop TABLE SYSTEM.temptab_20200327 AS
SELECT * FROM SYS.LOGMNR_CONTENTS_TMP_EXT t
WHERE t.seg_owner='EXCELLENT' AND t.seg_name='PPPOE_LAST_SESSIONS'
;

define table_name="SYSTEM.temptab_20200327"
define table_name="SYS.LOGMNR_CONTENTS_TMP_EXT"
SELECT *
FROM &&table_name t
ORDER BY t.SCN asc;

SELECT Count(*) AS cnt, t.operation_code
FROM &&table_name t
GROUP BY t.operation_code
ORDER BY cnt desc;

SELECT Count(*) AS cnt, t.xid
FROM &&table_name t
GROUP BY t.xid
ORDER BY cnt desc;

SELECT DISTINCT t.data_obj# FROM &&table_name t
WHERE t.operation_code=1
;
SELECT DISTINCT t.operation_code FROM &&table_name t
--WHERE t.data_obj#=4732507
;
SELECT Count(DISTINCT t.xid) FROM &&table_name t;
SELECT Count(DISTINCT t.data_obj#) FROM &&table_name t;

SELECT  Trunc(t.TIMESTAMP,'MI') AS TIMESTAMP,
        --Count(*) AS cnt
        --Count(DISTINCT t.xid) AS cnt
        Count(DISTINCT t.data_obj#) AS cnt
FROM &&table_name t
--WHERE t.data_obj#=4732507
GROUP BY Trunc(t.TIMESTAMP,'MI')
ORDER BY TIMESTAMP asc
;

SELECT *
FROM v$sql_command t;

SELECT *
FROM (
SELECT  Trunc(t.TIMESTAMP,'MI') AS tstmp,
        t.operation_code AS stat_name,
        Count(*) AS stat_value
FROM &&table_name t
WHERE 1=1
  --AND t.data_obj# IN (359119,271431,94394)
  --AND t.operation_code=3
GROUP BY Trunc(t.TIMESTAMP,'MI'), t.operation_code
)
pivot (
Max (stat_value)
FOR stat_name IN (
'0' as o0,
'1' as o1,
'2' as o2,
'3' as o3,
'5' as o5,
'6' as o6,
'7' as o7,
'9' as o9,
'10' as o10,
'24' as o24,
'25' as o25,
'27' as o27,
'31' as o31,
'36' as o36,
'54' as o54,
'55' as o55,
'255' as o255
 )
)
ORDER BY tstmp asc
;

SELECT Count(*)
FROM &&table_name t
WHERE 1=1
  --AND t.TIMESTAMP>=To_Date('30.11.2019 18:08:00','DD.MM.YYYY HH24:MI:SS') AND t.TIMESTAMP < To_Date('30.11.2019 18:11:00','DD.MM.YYYY HH24:MI:SS')
  AND t.operation_code IN (1,2,3)
  AND t.data_obj# NOT IN (58047,98663,73232,58040,58057,100169,232909,441684,73225,1079039,85168,5860825,98661,8301544,98710,98669,61354,58494,58045,796342,73242,98667,58043,232905,60431,1079040,190391,180110,100748,5860823,100167,8846056,100279,100175,76534,73677,73230,796349,100173,73228,85161,72,127376,62038,190389,85178,441676,180112,232907,1079038,68,441680,34196032,75612,5860824,100746,7776678,100795,100754,88476,85615,85166,796356,29408983,100752,85164,406583,190390,180118,29408987,910629,34196030,87552,56617,165,127362,77218,58122,29408959,127369,89160,406565,56621,4393,1355833,29408963,910603,34196031,29408971,161,406574,166,73307,29408975,910616,4,483,1065273,1355803)
;

SELECT t.DATA_OBJ# AS objid,
       sum( Decode(t.operation_code,1,1,0) ) AS opcode1,
       sum( Decode(t.operation_code,2,1,0) ) AS opcode2,
       sum( Decode(t.operation_code,3,1,0) ) AS opcode3
FROM &&table_name t
--WHERE ROWNUM <= 1000
GROUP BY t.DATA_OBJ#
ORDER BY 1 desc
;


SELECT t.DATA_OBJ#, Count(*)
FROM &&table_name t
WHERE 1=1 --t.TIMESTAMP>=To_Date('30.11.2019 18:08:00','DD.MM.YYYY HH24:MI:SS') AND t.TIMESTAMP < To_Date('30.11.2019 18:11:00','DD.MM.YYYY HH24:MI:SS')
  AND t.operation_code=2
GROUP BY t.DATA_OBJ#
ORDER BY 1 desc
;

SELECT *
FROM (
SELECT  Trunc(t.TIMESTAMP,'MI') AS tstmp,
        t.data_obj# AS objid,
        Count(*) AS stat_value
FROM &&table_name t
WHERE 1=1
  AND t.data_obj# IN (58047,98663,73232,58040,58057,100169,232909,441684,73225,1079039,85168,5860825,98661,8301544,98710,98669,61354,58494,58045,796342,73242,98667,58043,232905,60431,1079040,190391,180110,100748,5860823,100167,8846056,100279,100175,76534,73677,73230,796349,100173,73228,85161,72,127376,62038,190389,85178,441676,180112,232907,1079038,68,441680,34196032,75612,5860824,100746,7776678,100795,100754,88476,85615,85166,796356,29408983,100752,85164,406583,190390,180118,29408987,910629,34196030,87552,56617,165,127362,77218,58122,29408959,127369,89160,406565,56621,4393,1355833,29408963,910603,34196031,29408971,161,406574,166,73307,29408975,910616,4,483,1065273,1355803)
  AND t.operation_code IN (1,2,3)
GROUP BY Trunc(t.TIMESTAMP,'MI'), t.data_obj#
)
pivot (
Max (stat_value)
FOR objid IN (
'58047' as o58047,
'98663' as o98663,
'73232' as o73232,
'58040' as o58040,
'58057' as o58057,
'100169' as o100169,
'232909' as o232909,
'441684' as o441684,
'73225' as o73225,
'1079039' as o1079039,
'85168' as o85168,
'5860825' as o5860825,
'98661' as o98661,
'8301544' as o8301544,
'98710' as o98710,
'98669' as o98669,
'61354' as o61354,
'58494' as o58494,
'58045' as o58045,
'796342' as o796342,
'73242' as o73242,
'98667' as o98667,
'58043' as o58043,
'232905' as o232905,
'60431' as o60431,
'1079040' as o1079040,
'190391' as o190391,
'180110' as o180110,
'100748' as o100748,
'5860823' as o5860823,
'100167' as o100167,
'8846056' as o8846056,
'100279' as o100279,
'100175' as o100175,
'76534' as o76534,
'73677' as o73677,
'73230' as o73230,
'796349' as o796349,
'100173' as o100173,
'73228' as o73228,
'85161' as o85161,
'72' as o72,
'127376' as o127376,
'62038' as o62038,
'190389' as o190389,
'85178' as o85178,
'441676' as o441676,
'180112' as o180112,
'232907' as o232907,
'1079038' as o1079038,
'68' as o68,
'441680' as o441680,
'34196032' as o34196032,
'75612' as o75612,
'5860824' as o5860824,
'100746' as o100746,
'7776678' as o7776678,
'100795' as o100795,
'100754' as o100754,
'88476' as o88476,
'85615' as o85615,
'85166' as o85166,
'796356' as o796356,
'29408983' as o29408983,
'100752' as o100752,
'85164' as o85164,
'406583' as o406583,
'190390' as o190390,
'180118' as o180118,
'29408987' as o29408987,
'910629' as o910629,
'34196030' as o34196030,
'87552' as o87552,
'56617' as o56617,
'165' as o165,
'127362' as o127362,
'77218' as o77218,
'58122' as o58122,
'29408959' as o29408959,
'127369' as o127369,
'89160' as o89160,
'406565' as o406565,
'56621' as o56621,
'4393' as o4393,
'1355833' as o1355833,
'29408963' as o29408963,
'910603' as o910603,
'34196031' as o34196031,
'29408971' as o29408971,
'161' as o161,
'406574' as o406574,
'166' as o166,
'73307' as o73307,
'29408975' as o29408975,
'910616' as o910616,
'4' as o4,
'483' as o483,
'1065273' as o1065273,
'1355803' as o1355803
 )
)
ORDER BY tstmp asc
;


SELECT  t.session#||','||t.serial# AS sess_info,
        Count(*) AS cnt
FROM &&table_name t
WHERE t.data_obj#=4732507
GROUP BY t.session#||','||t.serial#
ORDER BY cnt desc
;

SELECT t.TIMESTAMP, t.operation, t.seg_owner, t.seg_name, t.os_username, t.machine_name,
       t.session#||','||t.serial# AS sid_serial,
       t.session_info,
       t.sql_redo, t.sql_undo
FROM &&table_name t
WHERE 1=1
  AND t.data_obj#=271431
  AND t.xid='010016007B999600'
ORDER BY t.timestamp
;


SELECT t.xid, Count(*) AS cnt
FROM &&table_name t
WHERE t.data_obj#=271431
GROUP BY t.xid
ORDER BY 2 DESC;

SELECT  t.data_obj# AS data_obj_num,
        --t.operation_code,
        Count(*) AS cnt
FROM &&table_name t
GROUP BY t.data_obj# --, t.operation_code
ORDER BY cnt desc
;

define rbsize="512"
SELECT NVL(attr,UTL_RAW.CAST_TO_RAW('')) AS attr,
       ROUND(SUM(redo_size)/(1024*1024)) AS SizeMB
FROM
     (SELECT
     xid AS attr,
     LEAD(rbablk*&&rbsize+rbabyte,1,rbablk*&&rbsize+rbabyte) over(PARTITION BY SUBSTR(rs_id,1,9) ORDER BY rs_id, ssn) - (rbablk*&&rbsize+rbabyte) AS redo_size
     FROM &&table_name
     ORDER BY rs_id,ssn)
GROUP BY NVL(attr,UTL_RAW.CAST_TO_RAW(''))
ORDER BY 2 DESC;

SELECT *
FROM &&table_name t
WHERE t.xid='0500280019004503'
ORDER BY t.SCN asc
;

SELECT t.seg_owner||'.'||t.seg_name AS objname,
       t.operation AS operation,
       Count(*) AS cnt
FROM &&table_name t
--WHERE t.session#=520 AND t.serial#=41527
GROUP BY t.seg_owner||'.'||t.seg_name, t.operation
ORDER BY cnt desc
;

SELECT t.session#||','||t.serial# AS sess, Count(*) AS cnt
FROM &&table_name t
WHERE t.seg_owner='OS_USR' AND t.seg_name='CTV_TRACES'
  AND t.operation_code IN (1,2,3)
GROUP BY t.session#||','||t.serial#
ORDER BY cnt desc

---------------------------------------------------------------------------
--DROP TABLE SYSTEM.logminer_stat_20191010
CREATE TABLE SYSTEM.logminer_stat_20191010 TABLESPACE excellent
as
SELECT  Trunc(t.TIMESTAMP,'MI') AS id,
        Count(*) AS cnt
FROM &&table_name t
GROUP BY Trunc(t.TIMESTAMP,'MI')
;

--DROP TABLE SYSTEM.logminer_item_stat_20191010;
CREATE TABLE SYSTEM.logminer_item_stat_20191010 TABLESPACE excellent
as
SELECT Trunc(t.TIMESTAMP,'MI') AS id,
       t.data_obj# AS objid,
       Count(*) AS cnt
FROM &&table_name t
WHERE t.operation_code IN (1,2,3)
GROUP BY Trunc(t.TIMESTAMP,'MI'),  t.data_obj#
;

CREATE INDEX SYSTEM.logminer_item_stat_idx ON SYSTEM.logminer_item_stat_20191010(objid);

DECLARE
CURSOR c1 IS
SELECT DISTINCT t.objid AS objid FROM  SYSTEM.logminer_item_stat_20191010 t;
v_metric NUMBER;
BEGIN
 FOR i IN c1
 LOOP
  v_metric := 0;
  SELECT  --s.id, Nvl(t.cnt,0) AS ocnt, s.cnt AS scnt
         Sqrt(Sum(power(Nvl(t.cnt,0) - s.cnt,2)))
  INTO v_metric
  FROM SYSTEM.logminer_item_stat_20191010 t, SYSTEM.logminer_stat_20191010 s
  WHERE t.objid(+)=i.objid
    AND t.id(+)=s.id
  --ORDER BY s.id
  ;
  Dbms_Output.put_line(i.objid||' '||v_metric);
 END LOOP;
END;
/

