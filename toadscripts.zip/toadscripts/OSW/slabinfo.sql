SELECT *
FROM excellent.slabinfo t
;

ALTER TABLE excellent.slabinfo ADD (datetime DATE);
ALTER SESSION SET NLS_DATE_LANGUAGE='American';

SELECT  regexp_replace(replace(t.sample_time, 'YEKT', ''), '^[a-zA-z ]+', '') AS dt
        ,To_Date(regexp_replace(replace(t.sample_time, 'YEKT', ''), '^[a-zA-z ]+', ''),'DD hh24:mi:ss YYYY') AS dt1
FROM excellent.slabinfo t
;

UPDATE excellent.slabinfo t
SET t.datetime = To_Date(regexp_replace(replace(t.sample_time, 'YEKT', ''), '^[a-zA-z ]+', ''),'DD hh24:mi:ss YYYY');
COMMIT;
ALTER TABLE excellent.slabinfo DROP COLUMN sample_time ;
ALTER TABLE excellent.slabinfo DROP ( sep1,tunables,sep2,slabdata);

CREATE INDEX excellent.slabinfo_name_idx ON excellent.slabinfo(name);
SELECT ''''||v.name||''' as n'||rownum||',' AS str
FROM (SELECT DISTINCT name FROM excellent.slabinfo) v;

SELECT  t.name,
        Sum(t.num_objs*t.objsize) AS size_bytes
FROM excellent.slabinfo t
GROUP BY t.name
ORDER BY size_bytes DESC
;

WITH DATA AS
(SELECT
'virtio_scsi_cmd,buffer_head,radix_tree_node,proc_inode_cache,ext4_inode_cache,dentry,filp,size-4096,kmem_cache,size-1024'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as n'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;


SELECT *
FROM (
SELECT  t.datetime AS datetime,
        t.name AS name,
        t.num_slabs AS num_slabs
FROM excellent.slabinfo t
WHERE t.name IN ('virtio_scsi_cmd','buffer_head','radix_tree_node','proc_inode_cache','ext4_inode_cache','dentry','filp','size-4096','kmem_cache','size-1024'))
pivot (
Max(num_slabs)
FOR name IN (
'virtio_scsi_cmd' as n1,
'buffer_head' as n2,
'radix_tree_node' as n3,
'proc_inode_cache' as n4,
'ext4_inode_cache' as n5,
'dentry' as n6,
'filp' as n7,
'size-4096' as n8,
'kmem_cache' as n9,
'size-1024' as n10
 )
)
ORDER BY datetime asc
;
