define schema_name="SYS"
revoke all on &&schema_name..plsql_profiler_data from public;
revoke all on &&schema_name..plsql_profiler_units from public;
revoke all on &&schema_name..plsql_profiler_runs from public;
revoke all on &&schema_name..plsql_profiler_runnumber from public;


drop table &&schema_name..plsql_profiler_data cascade constraints;
drop table &&schema_name..plsql_profiler_units cascade constraints;
drop table &&schema_name..plsql_profiler_runs cascade constraints;
drop sequence &&schema_name..plsql_profiler_runnumber;

create table &&schema_name..plsql_profiler_runs
(
  runid           number primary key,  -- unique run identifier,
                                       -- from plsql_profiler_runnumber
  related_run     number,              -- runid of related run (for client/
                                       --     server correlation)
  run_owner       varchar2(32),        -- user who started run
  run_date        date,                -- start time of run
  run_comment     varchar2(2047),      -- user provided comment for this run
  run_total_time  number,              -- elapsed time for this run
  run_system_info varchar2(2047),      -- currently unused
  run_comment1    varchar2(2047),      -- additional comment
  spare1          varchar2(256)        -- unused
);

create table &&schema_name..plsql_profiler_units
(
  runid              number references &&schema_name..plsql_profiler_runs,
  unit_number        number,           -- internally generated library unit #
  unit_type          varchar2(32),     -- library unit type
  unit_owner         varchar2(32),     -- library unit owner name
  unit_name          varchar2(32),     -- library unit name
  -- timestamp on library unit, can be used to detect changes to
  -- unit between runs
  unit_timestamp     date,
  total_time         number DEFAULT 0 NOT NULL,
  spare1             number,           -- unused
  spare2             number,           -- unused
  --
  primary key (runid, unit_number)
);

create table &&schema_name..plsql_profiler_data
(
  runid           number,           -- unique (generated) run identifier
  unit_number     number,           -- internally generated library unit #
  line#           number not null,  -- line number in unit
  total_occur     number,           -- number of times line was executed
  total_time      number,           -- total time spent executing line
  min_time        number,           -- minimum execution time for this line
  max_time        number,           -- maximum execution time for this line
  spare1          number,           -- unused
  spare2          number,           -- unused
  spare3          number,           -- unused
  spare4          number,           -- unused
  --
  primary key (runid, unit_number, line#),
  foreign key (runid, unit_number) references &&schema_name..plsql_profiler_units
);

create sequence &&schema_name..plsql_profiler_runnumber start with 1 nocache;

grant all on &&schema_name..plsql_profiler_data to public;
grant all on &&schema_name..plsql_profiler_units to public;
grant all on &&schema_name..plsql_profiler_runs to public;
grant all on &&schema_name..plsql_profiler_runnumber to public;

-- miscellaneous
/*
select * from dba_objects t
where T.OWNER=upper('&&schema_name');

drop table &&schema_name...PLSQL_PROFILER_DATA cascade constraints;
drop sequence &&schema_name..PLSQL_PROFILER_RUNNUMBER;
drop table &&schema_name..PLSQL_PROFILER_RUNS cascade constraints;
drop table &&schema_name..PLSQL_PROFILER_UNITS cascade constraints;

create synonym VLASOVED.plsql_profiler_data for &&schema_name..plsql_profiler_data;
create synonym VLASOVED.plsql_profiler_units for &&schema_name..plsql_profiler_unit;
create synonym VLASOVED.plsql_profiler_runs for &&schema_name..plsql_profiler_runs;
create synonym VLASOVED.plsql_profiler_runnumber for &&schema_name..plsql_profiler_runnumber;

drop synonym &&schema_name...plsql_profiler_data;
drop synonym &&schema_name...plsql_profiler_units;
drop synonym &&schema_name..plsql_profiler_runs;
drop synonym &&schema_name..plsql_profiler_runnumber;
*/

DECLARE
  l_result       BINARY_INTEGER;
  v_iteration    NUMBER := 20;
BEGIN
  l_result := DBMS_PROFILER.start_profiler(run_comment => 'do_something: ' || SYSDATE);
  FOR i IN 1..v_iteration
  LOOP
   os_eqm.schemes_utl.p_generate_group_objects(151499);
   os_eqm.schemes_utl.p_get_objects_links(TRUE,FALSE);
   ROLLBACK;
  END LOOP;
  l_result := DBMS_PROFILER.stop_profiler;
END;
/

SELECT *
from plsql_profiler_runs r
;

define v_runid=1

SELECT u.unit_number, u.unit_type, u.unit_owner, u.unit_name, u.total_time
FROM plsql_profiler_units u
WHERE u.runid=&&v_runid
;

SELECT u.unit_owner||'.'||u.unit_name AS object,
       u.unit_type AS object_type,
       d.line#, d.total_occur, d.total_time, d.min_time, d.max_time, s.text
FROM plsql_profiler_data d, plsql_profiler_units u, user_source s
WHERE u.runid=&&v_runid
  AND u.runid=d.runid
  AND u.unit_number=d.unit_number
  AND u.unit_name=s.name AND d.line#=s.line AND s.name IN ('TEST_MEMCACHED','MEMCACHED')
ORDER BY d.total_time desc
;