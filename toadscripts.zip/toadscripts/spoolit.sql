set colsep '|' echo off feedback off linesize 10000 pagesize 20000 sqlprompt '' trimspool on headsep off
set numwidth 20 underline off timing off

spool /tmp/joined_data2.dat replace

SELECT To_Date(completion_time,'dd.mm.yyyy hh24:mi') AS ctime,
completion_time, size_mb, arclog_count
FROM (
SELECT  To_Char( Trunc(t.first_time, 'HH24'),'DD.MM.YYYY HH24:MI') AS completion_time,
        round( Sum(t.blocks*t.block_size)/1024/1024,2) AS size_mb,
        Count(*) AS arclog_count
FROM v$archived_log t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
  --and t.next_change#>14136364624663
  AND t.dest_id=1
  AND t.first_time>=(SYSDATE-14)
GROUP BY Trunc(t.first_time, 'HH24')
 )
 ORDER BY ctime asc
;

spool off
!sed -i -e "s/ \{1,\}//g" /tmp/joined_data2.dat
!sed -i -e "s/|/\t/g" /tmp/joined_data2.dat

/*
SET LONG 1000000 LONGCHUNKSIZE 1000000 LINESIZE 1000 PAGESIZE 0 TRIM ON TRIMSPOOL ON ECHO OFF FEEDBACK OFF

define v_owner="EXCELLENT3"
define v_objname="ML_BP_MAGISTRAL_WEB"
define v_objtype="PACKAGE BODY"

SPOOL /tmp/joined_data2.dat replace
SELECT t.line||' '||t.text as code_line
FROM sys.dba_source t
WHERE t.owner='&&v_owner' AND t.name='&&v_objname' AND t.TYPE='&&v_objtype'
ORDER BY line asc
;

spool off
*/

/*
SET LONG 10000000 LONGCHUNKSIZE 1000000 LINESIZE 1000 PAGESIZE 0 TRIM ON TRIMSPOOL ON ECHO OFF FEEDBACK OFF

define v_dbid="3252500659"
define v_ph="1512408454"
define sqlid="1tmdz84w01rrk"
define vname=""
SPOOL /tmp/report_&&vname._&&sqlid..txt replace
--SELECT * FROM table (DBMS_XPLAN.DISPLAY_CURSOR(null, null, format=>'ALLSTATS LAST'));
--SELECT * FROM table (DBMS_XPLAN.DISPLAY_CURSOR(sql_id=>'&&sqlid',format=>'ALL'));
--SELECT * FROM table (DBMS_XPLAN.DISPLAY_CURSOR(sql_id=>'&&sqlid',cursor_child_no=>1,format=>'ALL'));
SELECT * FROM table (DBMS_XPLAN.DISPLAY_AWR(sql_id=>'&&sqlid',plan_hash_value=>&&v_ph,db_id=>&&v_dbid,format=>'ALL'));
--SELECT * FROM table (DBMS_XPLAN.DISPLAY_AWR(sql_id=>'&&sqlid',plan_hash_value=>&&v_ph,format=>'ALL'));
SELECT * FROM table (DBMS_XPLAN.DISPLAY_AWR(sql_id=>'&&sqlid',format=>'ALL'));
SPOOL OFF
*/


