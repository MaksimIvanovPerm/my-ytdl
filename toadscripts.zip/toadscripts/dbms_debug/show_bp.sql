declare
 brkpts      dbms_debug.breakpoint_table;
 i           number;

function  bp_status_as_string(bps binary_integer) return varchar2 is
begin
    if bps = dbms_debug.breakpoint_status_unused   then return 'unused'  ; end if;
    if bps = dbms_debug.breakpoint_status_active   then return 'active'  ; end if;
    if bps = dbms_debug.breakpoint_status_disabled then return 'disabled'; end if;
    if bps = dbms_debug.breakpoint_status_remote   then return 'remote'  ; end if;
    return '???';
end bp_status_as_string;

begin
 dbms_debug.show_breakpoints(brkpts);
 if nvl(brkpts.count,0)>0 then
     dbms_output.put_line('There is|are '||brkpts.count||' breakpoint(s)');
     i := brkpts.first();
     while i is not null 
     loop
         dbms_output.put_line(i||': '||brkpts(i).owner||'.'||brkpts(i).name||' '||brkpts(i).line#||' '||bp_status_as_string(brkpts(i).status));
         i := brkpts.next(i);
     end loop;
 else
     dbms_output.put_line('There is no breakpoints');
 end if;
end;
/

