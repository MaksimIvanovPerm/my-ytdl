set echo off 
--PACKAGE DBMS_DEBUG Specification (Doc ID 67899.1)
--https://github.com/ReneNyffenegger/oracle_scriptlets/tree/master/ash-awr/Introduction-Nov-3rd-14
--http://www.adp-gmbh.ch/ora/plsql/debug.html1
--http://mrxiesdatabase.blogspot.com/2009/04/examples-of-debugging-plsql-with.html


--in sql-session which shuold be debugged
-- compile with debug option all plsql objects, which should be debugged and|or should be used in callstack
conn excellent/excellent_8@predproduction
set newp none feedback off pagesize 2000 linesize 128 echo off serveroutput on size unlimited
select distinct sid from v$mystat;
select dbms_debug.initialize from dual;
exec dbms_debug.debug_on;
alter session set plsql_debug=true;


--in debug session
--define SPATH="/home/maksim/toadscripts/dbms_debug"
conn sys@predproduction AS SYSDBA
set newp none feedback off pagesize 2000 linesize 128 echo off serveroutput on size unlimited
select distinct sid from v$mystat;
define v_did="01CC014B0001"
exec debugger.start_debugger('&&v_did');

--in test session
exec DEBUG_PROC;

--be
--breakpoint
/*
cursor:       dbms_debug.namespace_cursor;
toplevel:     dbms_debug.namespace_pkgspec_or_toplevel;
body:         dbms_debug.namespace_pkg_body;
trigger:      dbms_debug.namespace_trigger;
current line: null;
*/
define v_unitname="DEBUG_PROC"
define v_owner="EXCELLENT"
define v_linenum="6"
exec debugger.set_breakpoint(p_line=>&&v_linenum, p_name=>'&&v_unitname', p_owner=>'&&v_owner', p_toplevel=>true);
--exec debugger.set_breakpoint(p_line=>&&v_linenum, p_name=>'&&v_unitname', p_owner=>'&&v_owner', p_body=>true);
exec debugger.breakpoints;
define v_bpnum="3"
exec debugger.delete_bp(breakpoint=>&&v_bpnum);

select t.line, t.text 
from sys.dba_source t
where t.owner = '&&v_owner' and t.name = '&&v_unitname'
order by t.line asc;


define v_varname="v_var"
exec debugger.print_var(name=>'&&v_varname');

exec debugger.backtrace;

--continue to setted breakpoint
exec debugger.continue;
exec debugger.step_into;
exec debugger.current_prg;

exec debugger.detach;

/*
create or replace procedure DEBUG_PROC
is
  v_result integer := 0;
begin
  --v_result:= PKG_DBGD.TST_1(4);
  select PKG_DBGD.TST_1(4) into v_result from dual; 
end;
/

alter procedure DEBUG_PROC compile debug;

create or replace function loop_tester(ctr number) return number
is
ret number:=0;
begin
 for i in 1..ctr loop
  ret := ret + 1;
 end loop;
return ret;
end;
/

create or replace package pkg_dbgd as
v_var number := 1;
function tst_1(i in integer) return integer;
function tst_2(i in integer) return integer;
end pkg_dbgd;
/

create or replace package body PKG_DBGD as
  function tst_1(i in integer) return integer is
  begin
    v_var := 5;
    if i between 5 and 10 then 
      v_var := 2*i;
      return v_var; 
    end if;
    
    if i between 0 and 4 then
      return tst_2(3+i);
    end if;

    if i between 6 and 10 then
      return tst_2(i-2);
    end if;

    return i;
  end tst_1;

  function tst_2(i in integer) return integer is
  begin
    if i between 6 and 8 then
      return tst_1(i-1);
    end if;

    if i between 1 and 5 then
      return i*2;
    end if;

    return i-1;
  end tst_2;
end pkg_dbgd;
/


*/
