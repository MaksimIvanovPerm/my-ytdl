declare
    v_mode  varchar2(8) := '&&v_mode'; --frame|handler
    v_owner varchar2(30) := '&&v_owner';
    v_oname varchar2(30) := '&&v_unitname';
    v_pi    dbms_debug.program_info;
    v_name  varchar2(30) := '&&v_varname';
    ret     binary_integer;
    val     varchar2(4000);
    frame   number :=  0; --current procedure in plsql callstack;
begin
   if v_mode = 'handler' then
       v_pi.name:=v_oname;
       v_pi.owner:=v_owner;
       v_pi.namespace := &&v_nsps;
       dbms_output.put_line('with handle: '||v_pi.owner||'.'||v_pi.name||' '||&&v_nsps);
       ret := dbms_debug.get_value (variable_name=>v_name, handle=>v_pi, scalar_value=>val, format=>null);
   else
       dbms_output.put_line('with frame: '||frame);
       ret := dbms_debug.get_value(variable_name=>v_name, frame#=>frame, scalar_value=>val, format=>null); 
   end if;

    if    ret = dbms_debug.success              then 
          dbms_output.put_line('  ' || v_name || ' = ' || val);
    elsif ret = dbms_debug.error_bogus_frame    then 
          dbms_output.put_line('  frame does not exist');
    elsif ret = dbms_debug.error_no_debug_info  then 
          dbms_output.put_line('  entrypoint has no debug info');
    elsif ret = dbms_debug.error_no_such_object then 
          dbms_output.put_line('  variable ' || v_name || ' does not exist in in frame ' || frame);
    elsif ret = dbms_debug.error_unknown_type   then 
          dbms_output.put_line('  the type information in the debug information is illegible');
    elsif ret = dbms_debug.error_nullvalue      then 
          dbms_output.put_line('  ' || v_name || ' = NULL');
    elsif ret = dbms_debug.error_indexed_table  then 
          dbms_output.put_line('  the object is a table, but no index was provided.');
    else  dbms_output.put_line('  unknown error: '||ret);
    end if;
end;
/

