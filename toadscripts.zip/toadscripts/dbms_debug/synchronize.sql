declare
  info dbms_debug.runtime_info;
  ret binary_integer;
  source varchar2(4000);
begin
  -- Start the interpreter
  ret := dbms_debug.synchronize(info,0);
  if    ret = dbms_debug.success then
        dbms_output.put_line('Synchronized successfully');
  elsif ret = dbms_debug.error_timeout then
        dbms_output.put_line('Synchronize failed due to timeout of connection to debugged sql-session');
  elsif ret = dbms_debug.error_communication then
        dbms_output.put_line('Synchronize failed due to communication err with debugged sql-session');
  else  dbms_output.put_line('Synchronize failed due to unknown error: '||ret);
  end if;
  if info.reason = dbms_debug.reason_interpreter_starting 
  then
    dbms_output.put_line('Interpreter starting');
  end if;
end;
/


/*
Synchronization is the process of the debug session waiting for the target session (the same: debugged) to execute and hit a breakpoint. 
The following code will be executed from the debug session and will hang until a breakpoint occurs.
*/
