declare
  info dbms_debug.program_info;
  bnum binary_integer;
  ret binary_integer;
  v_lnum   number := &&v_linenum;
  v_name   varchar2(30) := '&&v_unitname';
  v_owner  varchar2(30) := '&&v_owner';
  v_namesp varchar2(64) := lower('&&v_nsps');
begin
    if    v_namesp = 'dbms_debug.namespace_cursor' then info.namespace := dbms_debug.namespace_cursor;
    elsif v_namesp = 'dbms_debug.namespace_pkgspec_or_toplevel' then info.namespace := dbms_debug.namespace_pkgspec_or_toplevel;
    elsif v_namesp = 'dbms_debug.namespace_pkg_body' then info.namespace := dbms_debug.namespace_pkg_body;
    elsif v_namesp = 'dbms_debug.namespace_trigger'  then info.namespace := dbms_debug.namespace_trigger;
    else  info.namespace := null;
    end if;
    
    if nvl(v_name,'') in ('','null') then v_name := null; end if;
    if nvl(v_owner,'') in ('','null') then v_owner := null; end if;
    info.name           := v_name;
    info.owner          := v_owner;
    info.dblink         := null;
    info.entrypointname := null;


    ret := dbms_debug.set_breakpoint(program=>info, line#=>v_lnum, breakpoint#=>bnum);
    if    ret = dbms_debug.success            then dbms_output.put_line('  breakpoint set: ' || bnum);
    elsif ret = dbms_debug.error_illegal_line then dbms_output.put_line('  set_breakpoint: error_illegal_line');
    elsif ret = dbms_debug.error_bad_handle   then dbms_output.put_line('  set_breakpoint: error_bad_handle');
    else                                           dbms_output.put_line('  set_breakpoint: unknown error (' || ret || ')');
    end if;

/*  if ret = dbms_debug.success then
    dbms_output.put_line('Successfully set breakpoint# '||bnum||' at: '||info.owner||'.'||info.name||' '||v_lnum);
  elsif ret = dbms_debug.error_illegal_line then 
    dbms_output.put_line('Failed because illegal line#: '||info.owner||'.'||info.name||' '||v_lnum);
  elsif ret = dbms_debug.error_bad_handle then
    dbms_output.put_line('Failed because no such unit: '||info.owner||'.'||info.name||' '||v_lnum);
  else
    dbms_output.put_line('Failed unknown reason: '||ret||' '||info.owner||'.'||info.name||' '||v_lnum);
  end if; */
end;
/


/*
https://github.com/ReneNyffenegger/oracle_scriptlets/blob/master/debugger/body.plsql
if  p_cursor   then proginfo.namespace := dbms_debug.namespace_cursor;
    elsif p_toplevel then proginfo.namespace := dbms_debug.namespace_pkgspec_or_toplevel;
    elsif p_body     then proginfo.namespace := dbms_debug.namespace_pkg_body;
    elsif p_trigger  then proginfo.namespace := dbms_debug.namespace_trigger;
    else                  proginfo.namespace := null;
    end if;

Note: in case dbms_debug.namespace_pkg_body - you have to user line# as sorce-code line#, 
without specifying package-subprogram name
*/
