declare
  v_breakflag binary_integer;
  v_bflag     varchar2(64) := lower('&&v_breakflag');
  cont_lines_before_  integer := 1;
  cont_lines_after_   integer := 1;

function  general_error(e in binary_integer) return varchar2 is
begin
    if e = dbms_debug.error_unimplemented then return 'unimplemented'       ; end if;
    if e = dbms_debug.error_deferred      then return 'deferred'            ; end if;
    if e = dbms_debug.error_exception     then return 'probe exception'     ; end if;
    if e = dbms_debug.error_communication then return 'communication error' ; end if;
    if e = dbms_debug.error_unimplemented then return 'unimplemented'       ; end if;
    if e = dbms_debug.error_timeout       then return 'timeout'             ; end if;
    return '???';
end general_error;

procedure print_source (runinfo       dbms_debug.runtime_info,
                        lines_before  number default 0,
                        lines_after   number default 0
                       ) is
    first_line binary_integer;
    last_line  binary_integer;

    prefix varchar2(  99);
    suffix varchar2(4000);

    --source_lines                 vc2_table;
    source_lines dbms_debug.vc2_table;

    cur_line         binary_integer;
    cur_real_line    number;
begin
    first_line := greatest(runinfo.line# - cont_lines_before_,1);
    last_line  :=          runinfo.line# + cont_lines_after_    ;

    if first_line is null or last_line is null then
      dbms_output.put_line('first_line or last_line is null');
      --print_runtime_info(runinfo);
      return;
    end if;

    if runinfo.program.name is not null and runinfo.program.owner is not null then

      dbms_output.put_line('');
      dbms_output.put_line('  ' || runinfo.program.owner || '.' || runinfo.program.name);

        --select 
        --   cast(multiset(
          for r in (
                select
                  -- 90 is the length in dbms_debug.vc2_table....
                  rownum line,
                  substr(text,1,90) text
                from 
                  all_source 
                where 
                  name   = runinfo.program.name   and
                  owner  = runinfo.program.owner  and
                  type  <> 'PACKAGE'              and
                  line  >= first_line             and 
                  line  <= last_line
                order by 
                  line )-- as vc2_table)
              loop 
--        into
--          source_lines
--        from 
--          dual;
        source_lines(r.line) := r.text;      

      end loop;

    else
     
      dbms_debug.show_source(first_line, last_line, source_lines);

--      select
--        cast(
--          multiset(
--            select culumn_value from 
--              table(
--                cast(source_lines_dbms as dbms_debug.vc2_table)
--              )
--        )as vc2_table)
--      into
--        source_lines
--      from 
--        dual;
    
    end if;

    dbms_output.put_line('');

    cur_line := source_lines.first();
    while cur_line is not null loop
      cur_real_line := cur_line + first_line -1;
    
   -- for r in (select column_value text from table(source_lines)) loop
        prefix := to_char(cur_real_line,'9999');

        if cur_real_line = runinfo.line# then 
           prefix := prefix || ' -> ';
        else
           prefix := prefix || '    ';
        end if;
  
  
        -- TODO, most probably superfluos, 90 is the max width.... (ts, ts)
        --if length(r.text) > v_lines_width then
        --  suffix := substr(r.text,1,v_lines_width);
        --else
        --  suffix := r.text;
        --end if;
  
        suffix := source_lines(cur_line);
        suffix := translate(suffix,chr(10),' ');
        suffix := translate(suffix,chr(13),' ');
        
        --dbms_output.put_line(prefix || suffix);
        dbms_output.put_line(prefix || suffix);
  
    --    line_printed := 'Y';
      
      cur_line := source_lines.next(cur_line);
      --cur_line := cur_line + 1;
    end loop;

    dbms_output.put_line('');

  end print_source;

function  str_for_reason_in_runtime_info(rsn in binary_integer) return varchar2 is
    rsnt varchar2(40);
begin
    if rsn = dbms_debug.reason_none                    then rsnt := 'none';
    elsif rsn = dbms_debug.reason_interpreter_starting then rsnt := 'Interpreter is starting.';
    elsif rsn = dbms_debug.reason_breakpoint           then rsnt := 'Hit a breakpoint';
    elsif rsn = dbms_debug.reason_enter                then rsnt := 'Procedure entry';
    elsif rsn = dbms_debug.reason_return               then rsnt := 'Procedure is about to return';
    elsif rsn = dbms_debug.reason_finish               then rsnt := 'Procedure is finished';
    elsif rsn = dbms_debug.reason_line                 then rsnt := 'Reached a new line';
    elsif rsn = dbms_debug.reason_interrupt            then rsnt := 'An interrupt occurred';
    elsif rsn = dbms_debug.reason_exception            then rsnt := 'An exception was raised';
    elsif rsn = dbms_debug.reason_exit                 then rsnt := 'Interpreter is exiting (old form)';
    elsif rsn = dbms_debug.reason_knl_exit             then rsnt := 'Kernel is exiting';
    elsif rsn = dbms_debug.reason_handler              then rsnt := 'Start exception-handler';
    elsif rsn = dbms_debug.reason_timeout              then rsnt := 'A timeout occurred';
    elsif rsn = dbms_debug.reason_instantiate          then rsnt := 'Instantiation block';
    elsif rsn = dbms_debug.reason_abort                then rsnt := 'Interpreter is aborting';
    else                                                    rsnt := 'Unknown reason';
    end if;
    return rsnt;
end str_for_reason_in_runtime_info;

procedure continue_(break_flags in number) is
    cur_line_           dbms_debug.runtime_info;
    ret                 binary_integer;
    v_err               varchar2(100);
begin
    ret := dbms_debug.continue(cur_line_, break_flags, 0 + dbms_debug.info_getlineinfo +
       dbms_debug.info_getbreakpoint +
       dbms_debug.info_getstackdepth +
       dbms_debug.info_getoerinfo    + 0);
  
     if ret = dbms_debug.success then
       dbms_output.put_line('  reason for break: ' ||   str_for_reason_in_runtime_info(cur_line_.reason));
       if cur_line_.reason  = dbms_debug.reason_knl_exit then
         return;
       end if;
       if cur_line_.reason  = dbms_debug.reason_exit then
         return;
       end if;
       --print_runtime_info_with_source(cur_line_,cont_lines_before_, cont_lines_after_,cont_lines_width_);
       print_source(cur_line_, cont_lines_before_, cont_lines_after_);
     elsif ret = dbms_debug.error_timeout then 
       dbms_output.put_line('  continue: error_timeout');
     elsif ret = dbms_debug.error_communication then
       dbms_output.put_line('  continue: error_communication');
     else
       v_err := general_error(ret);
       dbms_output.put_line('  continue: general error' || v_err);
     end if;
  end continue_;

begin
 case 
 when v_bflag in ('break_next_line','dbms_debug.break_next_line') then v_breakflag:=dbms_debug.break_next_line; --step
 when v_bflag in ('break_any_call','dbms_debug.break_any_call') then v_breakflag:=dbms_debug.break_any_call;    --step in
 else v_breakflag:=0;
 end case;
 dbms_output.put_line('v_breakflag: '||v_breakflag);
 continue_(v_breakflag);
end;
/

/*
continue (calling continue_ with break_flags = 0 ) will run until
the program hits a breakpoint
*/
