declare
    pkgs dbms_debug.backtrace_table;
    i    number;
function namespace2str(p1 in number) return varchar2 is
begin
    case p1 
    when dbms_debug.namespace_cursor then return 'cursor';
    when dbms_debug.namespace_pkgspec_or_toplevel then return 'pkgspec_or_toplevel';
    when dbms_debug.namespace_pkg_body then return 'package_body';
    when dbms_debug.namespace_trigger then return 'trigger';
    when dbms_debug.namespace_none then return 'none';
    else return 'unknown';
    end case;
end namespace2str;

begin
    dbms_debug.print_backtrace(pkgs);
    i := pkgs.first();
    dbms_output.put_line('calldepth: namespace#(namespace name) owner.name line#');
    while i is not null loop
         dbms_output.put_line(i||': '||pkgs(i).namespace||'('||namespace2str(pkgs(i).namespace)||') '||pkgs(i).owner||'.'||pkgs(i).name||' '||pkgs(i).line#);
      i := pkgs.next(i);
    end loop;
   exception
    when others then
     dbms_output.put_line('  backtrace exception: ' || sqlcode);
     dbms_output.put_line('                       ' || sqlerrm(sqlcode));
end;
/

