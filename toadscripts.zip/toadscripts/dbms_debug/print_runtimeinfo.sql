declare
    ri dbms_debug.runtime_info;
    pi dbms_debug.program_info;
    ret binary_integer;
 begin
    ret := dbms_debug.get_runtime_info(0 + dbms_debug.info_getlineinfo   +
               dbms_debug.info_getbreakpoint +
               dbms_debug.info_getstackdepth +
               dbms_debug.info_getoerinfo    + 0, ri);

     pi := ri.program;

     --print_proginfo(pi);
end;
/

