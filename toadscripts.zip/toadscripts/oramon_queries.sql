define backup_type="BACKUPSET"
define inc_level="0"
define sess_key="1028890785"

DECLARE
 v_db_data             RC_DATABASE%rowtype;
 v_rc_backup_files_r   RC_BACKUP_FILES%ROWTYPE;
 v_rdndc_policy        NUMBER;
 v_backed_up_files     NUMBER;
 v_db_files            NUMBER;
 v_session_key         NUMBER;

BEGIN
SELECT * INTO v_db_data FROM RC_DATABASE;
SELECT Count(*) INTO v_db_files FROM RC_DATAFILE f where f.dbinc_key=v_db_data.dbinc_key;
dbms_rcvman.setDatabase(v_db_data.name,v_db_data.resetlogs_change#,v_db_data.resetlogs_time,v_db_data.dbid,null);
END;
/

SELECT * FROM RC_DATABASE
;

SELECT *
FROM RC_SITE t
;

SELECT i.*
FROM RC_DATABASE_INCARNATION i WHERE i.current_incarnation='YES';

SELECT *
FROM RC_DATAFILE f
where f.dbinc_key=(SELECT dbinc_key FROM RC_DATABASE)
  --AND f.file# NOT IN (37,36,314,315,316,317,2,318,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,392,394,393,395,396,398,397,24,25,26,27,28,29,30,31,32,33,35,34,38,39,40,41,42,43,391,44,45,46,47,49,48,50,51,52,53,54,55,56,57,58,59,61,60,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,378,377,379,380,381,382,383,384,385,386,387,388,389,390,273,274,275,276,277,278,279,280,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,272,308,309,310,311,312,313,319,321,320,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,341,342,343,344,339,97,95,96,98,100,74,75,76,77,78,80,79,81,82,83,84,85,86,87,88,89,90,91,92,93,94,99,101,102,103,104,105,106,122,124,123,125,126,128,127,129,130,131,132,133,135,134,136,137,138,139,140,142,143,144,145,146,141,148,147,149,150,151,152,153,156,155,154,157,160,158,159,161,162,164,163,165,166,167,168,169,170,171,172,173,174,176,175,177,179,180,178,181,182,185,186,188,187,189,190,183,184,191,192,193,194,195,196,197,198,199,200,201,202,204,203,205,206,207,208,209,210,63,406,62,407,399,400,401,402,68,65,1,340,69,211,212,216,213,214,4,72,108,71,215,109,110,107,111,112,113,114,116,117,118,119,281,64,282,283,120,284,121,285,286,287,288,290,289,405,403,404,115,73,67,70,66,223,224,226,225,227,228,230,229,231,232,233,234,235,236,237,238,239,240,242,241,243,244,271,249,246,245,247,248,250,251,252,254,253,255,256,258,257,259,260,261,262,263,264,265,266,267,268,269,270)
  --AND f.site_key=(SELECT rcs.site_key FROM RC_SITE rcs WHERE rcs.database_role='STANDBY') -- for honest standby only
;

SELECT Count(*)
FROM RC_DATAFILE f
where f.dbinc_key=(SELECT dbinc_key FROM RC_DATABASE);


SELECT *
FROM RC_BACKUP_FILES t
WHERE t.OBSOLETE='NO' AND
      t.file_type='DATAFILE'
      AND t.BACKUP_TYPE IN ('BACKUP SET', 'COPY')
      AND Nvl(t.status,'NULL') NOT IN ('UNAVAILABLE', 'EXPIRED')
      AND Nvl(t.BS_INCR_TYPE,'NULL') NOT IN ('INCR1')
ORDER BY t.df_checkpoint_change# desc
;

SELECT --t.bs_stamp, t.bs_count, t.df_file#, b.session_key
       DISTINCT b.session_key
FROM RC_BACKUP_FILES t, RC_BACKUP_DATAFILE_DETAILS b
WHERE t.OBSOLETE='NO' AND
      t.file_type='DATAFILE'
      AND t.BACKUP_TYPE IN ('BACKUP SET', 'COPY')
      AND Nvl(t.status,'NULL') NOT IN ('UNAVAILABLE', 'EXPIRED')
      AND Nvl(t.BS_INCR_TYPE,'NULL') NOT IN ('INCR1')
      AND b.id1=t.bs_stamp AND b.id2=t.bs_count  AND t.df_file#=b.file#
ORDER BY b.session_key
;

SELECT regexp_substr(t.Value,'[0-9]+') AS redundancy
FROM RC_RMAN_CONFIGURATION t
WHERE t.name='RETENTION POLICY';

SELECT t.*
FROM RC_BACKUP_DATAFILE_DETAILS t
ORDER BY t.checkpoint_time DESC
;


SELECT *
FROM RC_BACKUP_COPY_DETAILS t
ORDER BY t.completion_time;


SELECT t.session_key, Count(*)
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE t.btype='&&backup_type'
  AND t.incremental_level=&&inc_level
GROUP BY t.session_key
ORDER BY t.session_key DESC
;

SELECT t.*
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE t.btype='&&backup_type'
  AND t.incremental_level=&&inc_level
  --AND t.session_key='1020960910'
ORDER BY t.checkpoint_change# DESC
;


SELECT t.*
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE t.btype='&&backup_type'
  AND t.incremental_level=1
  AND t.session_key=&&sess_key
ORDER BY t.file#
;

SELECT t.session_key, Count(t.file#)
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE t.btype='&&backup_type'
  AND t.incremental_level=1
GROUP BY t.session_key
ORDER BY t.session_key desc
;


SELECT *
      --Round( Sum(bytes)/1024/1024/1024, 2) AS size_gb
FROM RC_BACKUP_PIECE bpc
WHERE (bpc.set_stamp,bpc.set_count) IN (SELECT t.id1, t.id2
                                        FROM RC_BACKUP_DATAFILE_DETAILS t
                                        WHERE t.incremental_level=1 AND t.btype='&&backup_type' AND t.session_key=&&sess_key)
ORDER BY bpc.completion_time
;

-- BS_KEY: primary_key for validate rman-statements
SELECT *
FROM RC_BACKUP_PIECE_DETAILS bpc
WHERE (bpc.set_stamp,bpc.set_count) IN (SELECT t.id1, t.id2
                                        FROM RC_BACKUP_DATAFILE_DETAILS t
                                        WHERE t.incremental_level=1 AND t.btype='&&backup_type' AND t.session_key=&&sess_key)
;


SELECT min(sequence#) AS start_seq
       --*
FROM RC_BACKUP_ARCHIVELOG_DETAILS t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM RC_DATABASE)
  AND t.next_change# > 14139279742422
ORDER BY t.sequence#
;

SELECT --Min(sequence#) AS end_seq
       *
FROM RC_BACKUP_ARCHIVELOG_DETAILS t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM RC_DATABASE)
  --AND t.first_change# >= 14139279742422
ORDER BY t.sequence# desc
;

SELECT t.*
FROM RC_BACKUP_ARCHIVELOG_DETAILS t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM RC_DATABASE)
  AND t.next_change#>14287509822660
ORDER BY t.sequence# asc
;


SELECT *
       --rbp.handle
FROM RC_BACKUP_PIECE rbp
WHERE rbp.backup_type='L'
  AND (rbp.set_stamp,rbp.set_count) IN (SELECT t.id1,t.id2
                                        FROM RC_BACKUP_ARCHIVELOG_DETAILS t
                                        WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM RC_DATABASE)
                                          --AND t.sequence# between  668 AND 675
                                          AND t.sequence# >= 33331
                                        )
ORDER BY rbp.completion_time
;

SELECT *
FROM RC_BACKUP_PIECE_DETAILS bpc
WHERE bpc.backup_type='D' AND bpc.incremental_level=0
;

SELECT Round( Sum(bytes)/1024/1024/1024,2 )
FROM RC_BACKUP_PIECE_DETAILS bpc
WHERE bpc.backup_type='D' AND bpc.incremental_level=0
;

SELECT t.name as name,
       Row_Number() OVER(ORDER BY null) AS rnum,
       Count(*) OVER(ORDER BY null) AS lines_count
FROM RC_BACKUP_COPY_DETAILS t, RC_DATAFILE d
WHERE t.session_key=(&&sess_key)
  AND t.file#=d.file#;


SELECT session_key
FROM (
SELECT t.session_key AS session_key, Count(t.file#) AS file_count
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE t.incremental_level=1
GROUP BY t.session_key
ORDER BY t.session_key DESC
 )
 WHERE file_count=(SELECT Count(*) FROM RC_DATAFILE f where f.dbinc_key=2091113)
   AND ROWNUM=1;

SELECT t.*
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE t.incremental_level=1 AND t.session_key=&&sess_key;

SELECT t.*
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE t.incremental_level=1 AND t.session_key=&&sess_key;

SELECT t.*
FROM RC_BACKUP_DATAFILE_DETAILS t
WHERE --t.file#=11
--AND t.incremental_level=1
  (t.id1,t.id2) IN (SELECT bf.BS_STAMP, bf.BS_COUNT FROM RC_BACKUP_FILES bf WHERE bf.tag=Upper('INC_LV1_2016_29_07_04_10_02') --AND bf.bs_incr_type='INCR1'
  )
ORDER BY t.checkpoint_change# desc
;

SELECT t.tag, t.start_time, Round(t.elapsed_seconds,2) AS elapsed_seconds, t.handle
FROM RC_BACKUP_PIECE t
WHERE t.backup_type='I'
  AND t.incremental_level=1
  AND (t.set_stamp,t.set_count) IN (SELECT DISTINCT t1.id1,t1.id2
FROM RC_BACKUP_DATAFILE_DETAILS t1
WHERE t1.incremental_level=1 AND t1.session_key=109195713);

-- Last backupset

SELECT *
FROM RC_DATAFILE t
WHERE t.dbinc_key=(SELECT dbinc_key FROM rc_database)
  --AND t.file# NOT IN (75,25,47,99,98,77,21,27,62,23,39,37,69,42,40,38,88,89,35,34,87,67,16,32,33,86,36,71,76,72,78,96,73,74,97,93,95,92,52,50,94,65,59,41,46,43,91,48,45,90,44)
ORDER BY t.creation_time;


-- Backup size stat
SELECT --Round( Sum(t.bytes)/1024/1024/1024, 2) AS size_gb
       t.*
FROM RC_BACKUP_FILES t
WHERE t.backup_type='BACKUP SET'
  AND regexp_like(t.tag,'INC_LV1_.*')
  --AND t.file_type='DATAFILE'
  --AND t.bs_tag='BACKUP_CUM_INC_LVL1_NFS_STB'
ORDER BY t.bs_completion_time asc
;

SELECT  Trunc(t.completion_time,'DD') AS completion_time,
        Round( Sum(t.bytes)/1024/1024/1024, 2) AS size_gb
FROM RC_BACKUP_FILES t
WHERE t.backup_type='BACKUP SET'
  AND regexp_like(t.tag,'BKP_ARCLOG_.*')
GROUP BY Trunc(t.completion_time,'DD')
ORDER BY Trunc(t.completion_time,'DD') asc
;

SELECT  Trunc(t.completion_time,'DD') AS completion_time,
        Round( Sum(t.bytes)/1024/1024/1024, 2) AS size_gb
FROM RC_BACKUP_FILES t
WHERE t.backup_type='BACKUP SET'
  AND regexp_like(t.tag,'INC_LV1_.*')
GROUP BY Trunc(t.completion_time,'DD')
ORDER BY Trunc(t.completion_time,'DD') asc
;

SELECT t.*
FROM RC_BACKUP_FILES t
WHERE t.backup_type='BACKUP SET'
  AND t.file_type='DATAFILE'
  --AND t.bs_incr_type='INCR1'
  AND t.bs_tag='INC_LV1_2016_08_09_04_10_02'
  --AND t.bs_incr_type=''
ORDER BY t.completion_time asc
;

-- EE environment --------------------------------------------------------------
SELECT t.*
FROM RC_BACKUP_FILES t
WHERE t.tag='IMAGECOPY4CLONEDB'
  AND t.backup_type='COPY'
  AND t.status='AVAILABLE'
ORDER BY t.df_file# asc
;

SELECT *
FROM RC_BACKUP_COPY_DETAILS t
ORDER BY t.completion_time;

SELECT *
FROM RC_DATAFILE_COPY t
WHERE t.site_key=(SELECT rcs.site_key FROM RC_SITE rcs WHERE rcs.database_role='STANDBY')
  AND t.status='A'
  AND t.tag='IMAGECOPY4CLONEDB'
  --AND t.file# IN (217,218,219,220,221,222)
;

SELECT *
FROM RC_SITE t
WHERE t.database_role='PRIMARY'
;

SELECT t.*
FROM RC_BACKUP_FILES t
WHERE t.backup_type='BACKUP SET'
  AND t.file_type='ARCHIVED LOG'
  AND Upper(t.bs_tag) LIKE 'BKP\_ARCLOG%' ESCAPE '\'
;

SELECT Max(t.sequence#) AS max_sequence
FROM RC_BACKUP_ARCHIVELOG_DETAILS t
WHERE (t.id1,t.id2) IN (SELECT bf.BS_STAMP, bf.BS_COUNT FROM RC_BACKUP_FILES bf WHERE bf.backup_type='BACKUP SET' AND bf.file_type='ARCHIVED LOG' AND Upper(bf.bs_tag) LIKE 'BKP\_ARCLOG%' ESCAPE '\'
  )
;
--------------------------------------------------------------------------------

SELECT *
FROM RC_BACKUP_DATAFILE t
WHERE (t.bs_key,t.set_stamp) IN ( SELECT bf.bs_key,bf.bs_stamp
                                  FROM RC_BACKUP_FILES bf
                                  WHERE bf.tag=Upper('BACKUP_DB_NFS')
                                )
  AND t.checkpoint_time >  To_Date('20.02.2017 00:00:00','dd.mm.yyyy hh24:mi:ss')
ORDER BY t.checkpoint_change# desc
;

SELECT 'nohup echo "restore datafile '||file#||';" |  $ORACLE_HOME/bin/rman target "/" log=/tmp/rman_'||rownum||'.log &' AS col
FROM (
SELECT t.bs_key AS bs_key, listagg(t.file#,',') within GROUP (ORDER BY t.bs_key) AS file#
FROM RC_BACKUP_DATAFILE t
WHERE --t.backup_type='D'
     (t.bs_key,t.set_stamp) IN ( SELECT bf.bs_key,bf.bs_stamp FROM RC_BACKUP_FILES bf WHERE bf.tag=Upper('QQQ4'))
  AND t.checkpoint_time >  To_Date('01.05.2017 00:00:00','dd.mm.yyyy hh24:mi:ss')
GROUP BY t.bs_key
       )
;

SELECT 'nohup echo "recover datafile '||file#||' noredo;" |  $ORACLE_HOME/bin/rman target "/" log=/tmp/rman_'||rownum||'.log &' AS col
FROM (
SELECT  t.bs_key AS bs_key, listagg(t.file#,',') within GROUP (ORDER BY t.bs_key) AS file#
FROM RC_BACKUP_DATAFILE t
WHERE --t.backup_type='D'
      (t.bs_key,t.set_stamp) IN ( SELECT bf.bs_key,bf.bs_stamp FROM RC_BACKUP_FILES bf WHERE bf.tag=Upper('QQQ4') )
      AND t.checkpoint_time >  To_Date('01.10.2018 00:00:00','dd.mm.yyyy hh24:mi:ss')
GROUP BY t.bs_key )
;

SELECT '$ORACLE_HOME/bin/rman target "/" << __EOFF__' AS cmd FROM dual
UNION ALL
SELECT 'catalog backuppiece '''||bf.fname||''';'
FROM RC_BACKUP_FILES bf WHERE bf.tag=Upper('INC_LV1_2016_09_11_04_10_01')
UNION ALL
SELECT 'exit;' AS cmd FROM dual
UNION ALL
SELECT '__EOFF__' AS cmd FROM dual
;

SELECT 'nohup echo "recover datafile '||file#||' noredo;" |  $ORACLE_HOME/bin/rman target "/" log=/tmp/rman_'||rownum||'.log &' AS col
FROM (
SELECT --t.bs_key AS bs_key,
        listagg(t.file#,',') within GROUP (ORDER BY t.bs_key) AS file#
FROM RC_BACKUP_DATAFILE t
WHERE t.dbinc_key=2091113
  AND t.incremental_level=1
  AND  (t.set_stamp,t.set_count) IN (SELECT DISTINCT t1.id1,t1.id2
FROM RC_BACKUP_DATAFILE_DETAILS t1
WHERE t1.incremental_level=1 AND t1.session_key=109195713)
GROUP BY t.bs_key
ORDER BY bs_key
 )
UNION ALL
SELECT 'wait' FROM dual;


DECLARE
 v_inckey    NUMBER;
 v_df_count  NUMBER;
 v_sess_key  NUMBER;

CURSOR c1(p_dbinc_key IN NUMBER, p_sess_key IN number) IS
 SELECT 'nohup echo "recover datafile '||file#||' noredo;" |  $ORACLE_HOME/bin/rman target "/" log=/tmp/rman_'||rownum||'.log &' AS col
 FROM (
 SELECT --t.bs_key AS bs_key,
         listagg(t.file#,',') within GROUP (ORDER BY t.bs_key) AS file#
 FROM RC_BACKUP_DATAFILE t
 WHERE t.dbinc_key=p_dbinc_key
   AND t.incremental_level=1
   AND  (t.set_stamp,t.set_count) IN (SELECT DISTINCT t1.id1,t1.id2
 FROM RC_BACKUP_DATAFILE_DETAILS t1
 WHERE t1.incremental_level=1 AND t1.session_key=p_sess_key)
 GROUP BY t.bs_key
 ORDER BY bs_key
  )
 UNION ALL
 SELECT 'wait' FROM dual;


BEGIN
 SELECT i.dbinc_key
 INTO v_inckey
 FROM RC_DATABASE_INCARNATION i
 WHERE i.current_incarnation='YES';
 --dbms_output.put_line('v_inckey: '||v_inckey);

 SELECT Count(*)
 INTO v_df_count
 FROM RC_DATAFILE f
 where f.dbinc_key=v_inckey;
 --dbms_output.put_line('v_df_count: '||v_df_count);

 SELECT session_key
 INTO v_sess_key
 FROM (
 SELECT t.session_key AS session_key, Count(t.file#) AS file_count
 FROM RC_BACKUP_DATAFILE_DETAILS t
 WHERE t.incremental_level=1
 GROUP BY t.session_key
 ORDER BY t.session_key DESC
  )
 WHERE file_count=v_df_count AND ROWNUM=1;
 --dbms_output.put_line('v_sess_key: '||v_sess_key);

 FOR i IN c1(v_inckey, v_sess_key)
 LOOP
  dbms_output.put_line(i.col);
 END LOOP;

EXCEPTION
 WHEN others THEN dbms_output.put_line('#THERE IS NO FULL L1 BACKUP');
END;
/

SELECT *
FROM RC_BACKUP_ARCHIVELOG_DETAILS t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM rc_database)
  AND t.next_change# > 14265263863917
ORDER BY t.sequence#
;

SELECT min(t.sequence#)
FROM RC_BACKUP_ARCHIVELOG_DETAILS t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM RC_DATABASE)
  AND t.next_change# > 14265263863917
;

SELECT *
FROM RC_BACKUP_PIECE_DETAILS bpc
WHERE (bpc.set_stamp,bpc.set_count) IN (SELECT t.id1, t.id2
                                        FROM RC_BACKUP_ARCHIVELOG_DETAILS t
                                        WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM rc_database)
                                          AND t.next_change# > 14252663455949 )
;

SELECT *
FROM RC_BACKUP_PIECE_DETAILS bpc
WHERE (bpc.set_stamp,bpc.set_count) IN (SELECT t.id1, t.id2
                                        FROM RC_BACKUP_ARCHIVELOG_DETAILS t
                                        WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM rc_database)
                                          AND t.sequence# BETWEEN 67972 and 68010 )
  AND bpc.status='A'
ORDER BY bpc.start_time
;

SELECT *
FROM v$archived_log t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
  AND t.dest_id=1
  --and t.next_change#>14307590326024
   AND t.completion_time>=(SYSDATE-14)
ORDER BY t.sequence# desc;

SELECT To_Date(completion_time,'dd.mm.yyyy hh24:mi') AS ctime,
completion_time, size_mb, arclog_count
FROM (
SELECT  To_Char( Trunc(t.first_time, 'HH24'),'DD.MM.YYYY HH24:MI') AS completion_time,
        round( Sum(t.blocks*t.block_size)/1024/1024,2) AS size_mb,
        Count(*) AS arclog_count
FROM v$archived_log t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
  --and t.next_change#>14136364624663
  AND t.dest_id=1
  AND t.first_time>=(SYSDATE-14)
GROUP BY Trunc(t.first_time, 'HH24')
 )
 ORDER BY ctime asc
;

SELECT completion_time,
       prev_ctime,
       CASE
       WHEN prev_ctime IS NOT NULL THEN Round(24*60*(completion_time-prev_ctime),2)
       END AS circle_time
from (
SELECT  t.completion_time AS completion_time,
        Lag(t.completion_time,4,null) OVER (ORDER BY t.sequence# asc) AS prev_ctime
FROM v$archived_log t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
  --and t.next_change#>14136364624663
  AND t.dest_id=1
  AND t.completion_time>=(SYSDATE-14)
ORDER BY t.sequence# asc
 );


SELECT *
FROM sys.dba_temp_files t;

SELECT * FROM database_properties t ORDER BY t.property_name;

-- ALTER TABLESPACE temp ADD TEMPFILE '/db/u12/oradata/billing/temp04.dbf' SIZE 128M AUTOEXTEND ON NEXT 128M MAXSIZE 10G;
--ALTER DATABASE TEMPFILE 1,2,3 AUTOEXTEND ON NEXT 128M MAXSIZE 7G;
--ALTER DATABASE TEMPFILE 1,2,3 RESIZE 7G;
--ALTER DATABASE TEMPFILE 1,2,3 AUTOEXTEND OFF;

SELECT *
FROM sys.dba_tablespaces t
WHERE 1=1
  --AND t.CONTENTS='TEMPORARY'
  --AND t.CONTENTS='UNDO'
;

SELECT  t.tablespace_name,
        Round(Sum(bytes)/1024/1024/1024,2) AS size_gb
       --*
FROM sys.dba_data_files t
GROUP BY t.tablespace_name
ORDER BY size_gb desc
;

SELECT 'ln -s '||file_name||' '||fname AS col
FROM (
SELECT t.file_name,
       regexp_substr(t.file_name,'/db/u[0-9]{2}/oradata/billing/') AS path,
       REPLACE(t.file_name,regexp_substr(t.file_name,'/db/u[0-9]{2}/oradata/billing/'),'') AS fname
FROM sys.dba_data_files t
WHERE not regexp_like(t.file_name,'/db/u15')
ORDER BY path
 );

SELECT t.file_id,
       t.file_name,
       t.status,
       t.autoextensible,
       Round(t.bytes/1024/1024/1024,2) AS size_GB,
       Round(t.increment_by*8192/1024/1024,2) AS incremet_MB,
       Round(t.maxbytes/1024/1024/1024,2) AS maxbytes_GB,
       --Round(t.bytes/t.maxbytes*100,2),
       --'ALTER DATABASE DATAFILE '||t.file_id||'  autoextend ON NEXT 128M MAXSIZE unlimited;' AS cmd,
       t.tablespace_name
FROM sys.dba_data_files t
WHERE 1=1
  AND t.tablespace_name IN ('SYSAUX')
  --AND t.FILE_id IN (5,10,11,12,13,14,15,16)
  --AND regexp_like(t.file_name,'^/db/u13')
  --AND t.file_name LIKE '%data\_slow\_tst%' ESCAPE '\'
  --AND t.autoextensible='YES'
ORDER BY t.file_id
;

SELECT *
FROM sys.v_$datafile_header  t
WHERE t.tablespace_name='UNDOTBS1'
ORDER BY t.file# asc
;

--ALTER DATABASE DATAFILE 15 RESIZE 128M;
--ALTER DATABASE DATAFILE 3 autoextend ON NEXT 128M MAXSIZE unlimited;
--ALTER DATABASE DATAFILE 200,201,202 autoextend ON NEXT 128M MAXSIZE 30G;
-- alter database datafile 84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,114,116,118,120,122,125,127,129,131,133,135,139,145,147,149,152 autoextend off;
--ALTER DATABASE tempFILE 1 autoextend ON NEXT 128M MAXSIZE unlimited;
--ALTER TABLESPACE EXCELLENT ADD DATAFILE '/db/u13/oradata/billing/excellent_61.dbf' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE 30G;
--ALTER TABLESPACE SYSAUX ADD DATAFILE '/db/u11/oradata/billing/sysaux_02.dbf' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE unlimited;
--ALTER TABLESPACE SUPPORT_EXCL ADD DATAFILE '/db/u11/testdb0/oradata/billing/support_excl_06.dbf' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE unlimited;
--ALTER TABLESPACE W6 ADD DATAFILE '/db/u11/oradata/DB/W6_1.DBF' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE unlimited;
--ALTER TABLESPACE DBA11248 ADD DATAFILE '/db/u11/oradata/testdb0/billing/dba11248_02.dbf' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE unlimited;
--ALTER TABLESPACE EXCELLENT_BIG ADD DATAFILE '/db/u13/oradata/billing/excellent_big_11.dbf' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE 30G;
--ALTER TABLESPACE SYSAUX ADD DATAFILE '/db/u11/oradata/billing/sysaux_02.dbf' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE unlimited;
--ALTER TABLESPACE UNDOTBS ADD DATAFILE '/db/u13/oradata/ORANGE/undotbs_02.dbf' SIZE 128M AUTOEXTEND ON next 128M MAXSIZE unlimited;
-- create tablespace DBA11248 datafile '/db/u11/oradata/billing/dba11248_01.dbf' size 128M autoextend on next 128M maxsize unlimited;
-- create undo tablespace UNDOTBS datafile '/db/u11/oradata/testdb0/billing/undotbs_01.dbf' size 32M autoextend on next 32M maxsize 10G;
-- create temporary tablespace TEMP1 tempfile '/db/u11/oradata/testdb0/billing/temp1_01.dbf' size 32M autoextend on next 32M maxsize 8G;
-- alter database default temporary tablespace TEMP1;
-- alter system set undo_tablespace='UNDOTBS' scope=both;
-- drop tablespace UNDOTBS1 including contents and datafiles;
-- drop tablespace TEMP including contents and datafiles;

-- alter tablespace CM_TEMP add tempfile '/db/u11/oradata/dwh/cm_temp_06.dbf' size 128M reuse autoextend on next 128M maxsize unlimited;

SELECT *
--t.tablespace_name||' '||t.status||' '||t.file_name||' '||t.autoextensible||' '||t.user_bytes||' '||t.maxbytes AS col
FROM sys.dba_temp_files t
WHERE t.tablespace_name IN (SELECT dp.property_value FROM database_properties dp WHERE dp.property_name='DEFAULT_TEMP_TABLESPACE')
--WHERE t.tablespace_name IN (SELECT tg.tablespace_name FROM sys.dba_tablespace_groups tg)
;

select * 
from sys.v_$tempfile t
;

--alter database tempfile '/db/u13/oradata/ORANGE/temp01.dbf' AUTOEXTEND ON next 128M MAXSIZE unlimited;
--alter database tempfile 1,2,3,4 autoextend on next 128M maxsize 20G;
--alter database tempfile 1,2,3,4 resize 10G;

SELECT *
FROM v$datafile t
WHERE file# IN (173)
;

--CREATE TABLESPACE monit DATAFILE '/db/u11/oradata/eqmmon/monit_01.dbf' SIZE 128M AUTOEXTEND ON NEXT 128M MAXSIZE 20G;
-- alter tablespace sysaux add datafile '/db/u11/oradata/eqmmon/sysaux_12.dbf' size 128M autoextend on next 128M maxsize 32G;

SET pagesize 0
spool /tmp/tempseg_usage.spool replace
select USERNAME||' '||USER||' '||SESSION_ADDR||' '||SESSION_NUM||' '||SQL_ID||' '||TABLESPACE||' '||CONTENTS||' '||SEGTYPE||' '||BLOCKS from v$tempseg_usage order by BLOCKS desc;
spool off;

SELECT *
FROM v$controlfile t
;

SELECT *
FROM v$log t
ORDER BY t.group#;

SELECT *
FROM v$logfile t
ORDER BY t.group#
;

-- find out maxXXXX limits
select t.TYPE,t.RECORDS_TOTAL
from v$controlfile_record_section t
ORDER BY t.type
;

-- alter database backup controlfile to trace as '/home/oracle/temp/ctrl.sql' reuse;
SELECT dest_id FROM v$archive_dest d WHERE d.destination='/db/archive/orange';
SELECT * FROM sys.v_$logfile m;
SELECT * FROM v$log t WHERE t.archived='YES'  ORDER BY t.sequence# desc;


SELECT *
FROM sys.v_$log_history t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
ORDER BY t.sequence# desc
;


SELECT To_char(SYSDATE,'yyyy.mm.dd hh24:mi:ss') AS datetime, l.group#, Round(l.bytes/1024/1024,0) AS size_MB, l.status, l.sequence#, l.archived,
       m.member AS log_file, m.status
FROM sys.v_$log l, sys.v_$logfile m
WHERE l.group#=m.group#
ORDER BY l.sequence# desc
;

SELECT l.group#, Round(l.bytes/1024/1024,0) AS size_MB, l.status, l.first_time, l.next_time, l.sequence#, l.archived,
       m.member AS log_file, m.status
FROM sys.v_$log l, sys.v_$logfile m
WHERE l.group#=m.group#
  --AND m.member LIKE '/db/u01%'
ORDER BY l.group# asc
;

select * from v$logfile;
select * from v$log;
select * from v$standby_log;
alter database drop standby logfile group 13;

-- after reboot of primary-site server
-- drbdadm -- --overwrite-data-of-peer primary all
-- /etc/init.d/rias-drbd start
ALTER SYSTEM SWITCH logfile;
ALTER SYSTEM CHECKPOINT;
ALTER SYSTEM ARCHIVE Log CURRENT;

ALTER DATABASE drop LOGFILE member '+DATA/redo08_02.dbf';
ALTER DATABASE drop LOGFILE member '+DATA/redo07_02.dbf';
ALTER DATABASE drop LOGFILE member '+DATA/redo06_02.dbf';
ALTER DATABASE drop LOGFILE member '+DATA/redo10_02.dbf';

ALTER DATABASE add LOGFILE member '+REDO2/redo10_03.dbf' REUSE TO GROUP 10;
ALTER DATABASE add LOGFILE member '/db/u01/oradata/billing/redo02_01.dbf' REUSE TO GROUP 2;
ALTER DATABASE add LOGFILE member '/db/u01/oradata/billing/redo03_01.dbf' REUSE TO GROUP 3;
ALTER DATABASE add LOGFILE member '/db/u01/oradata/billing/redo04_01.dbf' REUSE TO GROUP 4;
ALTER DATABASE add LOGFILE member '/db/u01/oradata/billing/redo05_01.dbf' REUSE TO GROUP 5;
ALTER DATABASE add LOGFILE member '+REDO2/redo06_03.dbf' REUSE TO GROUP 6;
ALTER DATABASE add LOGFILE member '+REDO2/redo07_03.dbf' REUSE TO GROUP 7;
ALTER DATABASE add LOGFILE member '+REDO2/redo08_03.dbf' REUSE TO GROUP 8;


ALTER DATABASE drop LOGFILE member '/db/u13/oradata/billing/redo02_01.dbf';
ALTER DATABASE RENAME FILE '/db/u00/oradata/billing/redo02_03.dbf' TO '/db/u00/oradata/billing/redo03_03.dbf';

ALTER DATABASE ADD LOGFILE GROUP 6 '/u02/oracle/oradata/rbm01/redo06.log' SIZE 128M;

ALTER DATABASE DROP LOGFILE GROUP 5;
ALTER DATABASE DROP LOGFILE GROUP 6;
ALTER DATABASE DROP LOGFILE GROUP 9;
ALTER DATABASE DROP LOGFILE GROUP 6;

ALTER DATABASE ADD LOGFILE GROUP 10 ('/db/u00/oradata/dwh/redo10_01.dbf','/db/u01/oradata/dwh/redo10_02.dbf') SIZE 3G;
ALTER DATABASE ADD LOGFILE GROUP  6 ('/db/u00/oradata/dwh/redo06_01.dbf','/db/u01/oradata/dwh/redo06_02.dbf') SIZE 3G reuse;
ALTER DATABASE ADD LOGFILE GROUP  8 ('/db/u00/oradata/dwh/redo08_01.dbf','/db/u01/oradata/dwh/redo08_02.dbf') SIZE 3G reuse;
ALTER DATABASE ADD LOGFILE GROUP  9 ('/db/u00/oradata/dwh/redo09_01.dbf','/db/u01/oradata/dwh/redo09_02.dbf') SIZE 3G reuse;

select a.STATUS, a.LOG_SEQUENCE, a.ARCHIVER, a.PROCESS, (d.current_scn-a.APPLIED_SCN) as info
from v$archive_dest a, v$database d
where dest_id=2;

select STATUS, DATABASE_MODE, RECOVERY_mODE, PROTECTION_mODE, APPLIED_THREAD#, APPLIED_SEQ#, ERROR, DB_UNIQUE_NAME, SYNCHRONIZATION_STATUS, SYNCHRONIZED as col
from V$ARCHIVE_DEST_STATUS where dest_id=2;


SELECT *
FROM v$archived_log t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
  AND t.dest_id=1
  --AND t.first_time>=To_Date('2019.05.31 08.00','yyyy.mm.dd hh24:mi') AND t.next_time<=To_Date('2019.05.31 10.00','yyyy.mm.dd hh24:mi')
  --AND t.sequence#>=244262
  --AND t.first_change#>=14546009551338
                     --14375558110908
ORDER BY t.sequence# desc
;

SELECT *
FROM v$archived_log t
WHERE t.resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
      --t.dictionary_begin='YES' AND t.dictionary_end='YES'
  --AND t.sequence# BETWEEN 42229 AND 42294
  --AND t.name IS NOT null
ORDER BY t.sequence# asc
;

SELECT * FROM v$archive_dest_status t
;

SELECT * FROM v$archive_dest t
;


ALTER SYSTEM SET  LOG_ARCHIVE_DEST_state_3='defer' scope=both;
ALTER SYSTEM SET  LOG_ARCHIVE_DEST_state_3='enable' scope=both;
ALTER SYSTEM SET  fal_client=standby_db2 scope=both;


SELECT  *
FROM sys.DBA_RESUMABLE t
;

SELECT *
FROM sys.dba_tablespaces t
;

SELECT *
FROM sys.v_$controlfile t
;

--fra
--flashback
select round(t.flashback_size/1024/1024,2)||'' as used_size_mb,
       round(t.estimated_flashback_size/1024/1024, 2) as estimated_size_mb
from sys.V_$FLASHBACK_DATABASE_LOG t
;

select name
,      round(space_limit / 1024 / 1024) size_mb
,      round(space_used  / 1024 / 1024) used_mb
,      decode(nvl(space_used,0),0,0,round((space_used/space_limit) * 100)) pct_used
from v$recovery_file_dest
order by name
;

--drop restore point R1;th fra_stat as (
select name
,      round(f.space_limit / 1024 / 1024) size_mb
,      round(f.space_used  / 1024 / 1024) used_mb
,      decode(nvl(f.space_used,0),0,0,round((f.space_used/f.space_limit) * 100)) pct_used
from sys.v_$recovery_file_dest f
)
select t.guarantee_flashback_database, t.scn||'' as scn, t.time,
       round(t.storage_size/1024/1024, 2) as used_space_mb,
       fra_stat.size_mb as fra_size_mb,
       round( (t.storage_size/1024/1024)/fra_stat.size_mb, 2)*100 as pct_of_fra, 
       t.name
from sys.v_$restore_point t, fra_stat
;

select * from sys.V_$RECOVERY_AREA_USAGE t;
select * from sys.V_$FLASHBACK_DATABASE_LOG t;
select * from sys.V_$RECOVERY_FILE_STATUS t;
select * from V$FLASHBACK_DATABASE_LOGFILE t;
--drop restore point R1;
--stat gathering
exec dbms_stats.gather_table_stats(ownname=>'&&v_owner', tabname=>'&&v_tabname', method_opt=>'for all indexed columns size 250', cascade=>true, force=>true);
exec dbms_stats.gather_table_stats(ownname=>'&&v_owner', tabname=>'&&v_tabname', method_opt=>'for all columns size auto', cascade=>true);
exec dbms_stats.gather_table_stats(ownname=>'&&v_owner', tabname=>'&&v_tabname', method_opt=>'for all columns size skewonly', cascade=>true, force=>true);
exec dbms_stats.gather_table_stats(ownname=>'&&v_owner', tabname=>'&&v_tabname', method_opt=>'for all columns size 1', cascade=>true, force=>true);
exec dbms_stats.gather_table_stats(ownname=>'&&v_owner', tabname=>'&&v_tabname', cascade=>true, force=>true);
exec dbms_stats.delete_table_stats(ownname=>'&&v_owner', tabname=>'&&v_tabname', force=>true);
exec dbms_stats.unlock_table_stats(ownname=>'&&v_owner', tabname=>'&&v_tabname');

select t.owner, t.table_name, t.column_name, t.num_distinct, t.histogram, t.num_buckets
from sys.dba_tab_col_statistics t
where t.owner='&&v_owner' and t.table_name='&&v_tabname'
order by t.column_name
;

select *
from sys.dba_tab_histograms t
where t.owner='&&v_owner' and t.table_name='&&v_tabname'
  --and t.column_name='VAL2'
order by t.column_name
;

select *
from sys.dba_tables t
where t.owner='&&v_owner' and t.table_name='&&v_tabname'
;

--objects_size
define v_owner="EXCELLENT"
define v_tabname="CHARGES"
select OBJ_OWNER, OBJ_NAME, SOBJ_NAME, SEG_TYPE, SIZEMB, csizemb,
       round(SIZEMB/TOTAL_SIZEMB,2) as pct_from_total,
       round(csizemb/TOTAL_SIZEMB,2) as cpct_from_total
from (
with dbo as (
select t1.owner as obj_owner, t1.table_name as obj_name, null as sobj_name, 'TABLE' as seg_type
from sys.dba_tables t1
where t1.owner='&&v_owner' and t1.table_name='&&v_tabname' and t1.segment_created='YES'
union all
select t.table_owner as obj_owner, '&&v_tabname' as obj_name, t.partition_name as sobj_name, 'TABLE PARTITION' as seg_type
from sys.dba_tab_partitions t
where t.table_owner='&&v_owner' and t.table_name='&&v_tabname' and t.segment_created='YES'
union all
select t2.table_owner as obj_owner, '&&v_tabname' as obj_name, t2.subpartition_name as sobj_name, 'TABLE SUBPARTITION' as seg_type
from sys.dba_tab_subpartitions t2
where t2.table_owner='&&v_owner' and t2.table_name='&&v_tabname' and t2.segment_created='YES'
union all
select i.owner as obj_owner, i.index_name as obj_name, null as sobj_name, 'INDEX' as seg_type
from sys.dba_indexes i
where i.table_owner='&&v_owner' and i.table_name='&&v_tabname' and i.segment_created='YES'
union all
select ip.index_owner as obj_owner, ip.index_name as obj_name, ip.partition_name as sobj_name, 'INDEX PARTITION' as seg_type
from sys.dba_ind_partitions ip, sys.dba_indexes i
where ip.index_owner=i.owner  and ip.index_name=i.index_name and ip.segment_created='YES'
  and i.table_owner='&&v_owner' and i.table_name='&&v_tabname'
union all
select isp.index_owner as obj_owner, isp.index_name as obj_name, isp.subpartition_name as sobj_name, 'INDEX SUBPARTITION' as seg_type
from sys.dba_ind_subpartitions isp, sys.dba_indexes i
where i.table_owner='&&v_owner' and i.table_name='&&v_tabname'
  and isp.index_owner=i.owner and isp.index_name=i.index_name and isp.segment_created='YES'
union all
select '&&v_owner' as obj_owner, l.segment_name as obj_name, null as sobj_name, 'LOBSEGMENT' as seg_type
from sys.dba_lobs l
where l.owner='&&v_owner' and l.table_name='&&v_tabname'
)
select dbo.*, round(s.bytes/1024/1024,2) as sizemb,
       round(sum(bytes) over (order by bytes desc rows between unbounded preceding and current row)/1024/1024,2) as csizemb,
       round(sum(bytes) over (order by null)/1024/1024,2) as total_sizemb
from sys.dba_segments s, dbo
where dbo.obj_owner=s.owner
  and dbo.obj_name=s.segment_name and nvl(dbo.sobj_name,' ')=nvl(s.partition_name,' ')
  and dbo.seg_type=s.segment_type
order by s.bytes desc )
;

select *
from sys.dba_tab_cols t
where t.owner='&&v_owner' and t.table_name='&&v_tabname' and t.owner
order by t.column_name
;


--column usage
exec DBMS_STATS.SEED_COL_USAGE (null,null,300);
set long 10000000 longchunksize 1000000 linesize 1000 pagesize 0 trim on trimspool on echo off feedback off
spool /tmp/spool.log replace
SELECT dbms_stats.report_col_usage('EXCELLENT', null) FROM dual;
spool off
!vim /tmp/spool.log

SELECT  t.owner, t.segment_name, t.segment_type, t.tablespace_name,
        Round(t.bytes/1024/1024,2) AS size_MB
FROM sys.dba_segments t
WHERE 1=1
 -- and t.segment_name='SA_F848_SPEED_SITE' 
  and t.owner='EXCELLENT'
  and Round(t.bytes/1024/1024,2) between 2048 and 3000
  and t.segment_type='TABLE'
  --t.tablespace_name='SYSAUX'
ORDER BY t.bytes DESC
;

SELECT  t.owner, Round(Sum(t.bytes)/1024/1024/1024,2) AS SchemaSize_GB
FROM sys.dba_segments t
GROUP BY t.owner
ORDER BY 2 DESC
;

SELECT  Round(Sum(t.bytes)/1024/1024/1024,2) AS SchemaSize_GB
FROM sys.dba_segments t
WHERE t.segment_name='SA_F848_SPEED_SITE' and t.owner='EXCELLENT'
;

SELECT *
FROM sys.dba_lobs t
WHERE t.segment_name='SYS_LOB0000069868C00038$$'
;

select owner||'.'||segment_name, segment_type as col
from sys.dba_extents
where file_id = 14 and 3693691 between block_id and block_id + blocks - 1;

select *
       --'alter index '||t.owner||'.'||t.index_name||' rebuild;' as cmd
from sys.dba_indexes t
where 1=1
  and t.table_owner='&&v_owner' and t.table_name='&&v_tabname'
;

select p.*    
from sys.dba_indexes t, sys.dba_ind_partitions p
where t.table_owner ='&&v_owner' and t.table_name='&&v_tabname'
  and p.index_owner = t.owner and p.index_name = t.index_name
order by p.index_name, p.partition_name
;

select *
from sys.dba_objects t
where 1=1
  --and t.owner='EXCELLENT' 
  and t.object_name='CHARGES__MV'
;

--constraints
select *
from sys.dba_constraints t
where t.owner='&&v_owner' and t.table_name='&&v_tabname'
order by t.constraint_name
;

--column usage preducate
define v_username="BITEST"
select * from (
select oo.name owner,
       o.name,
       c.name column_name,
       u.equality_preds,
       u.equijoin_preds,
       u.nonequijoin_preds,
       u.range_preds,
       u.like_preds,
       u.null_preds,
       u.timestamp,
       sqrt(nvl(u.null_preds*u.null_preds,0)+nvl(u.like_preds*u.like_preds,0)+nvl(u.range_preds*u.range_preds,0)+nvl(u.nonequijoin_preds*u.nonequijoin_preds,0)+nvl(u.equality_preds*u.equality_preds,0)+nvl(u.equijoin_preds*u.equijoin_preds,0)) as metric
from sys.col_usage$ u, sys.obj$ o, sys.user$ oo, sys.col$ c
where o.obj# = u.obj#
  and o.owner#=(select usr.user_id from sys.dba_users usr where usr.username='&&v_username')
  and o.name not in (select rb.object_name from sys.dba_recyclebin rb where rb.owner='&&v_username')
  and oo.user# = o.owner# and oo.name='&&v_owner'
  and c.obj# = u.obj#
  and c.intcol# = u.intcol#
--order by metric desc 
  order by u.equijoin_preds desc
)
where rownum <= 1000
;


set long 1000000 longchunksize 1000000 linesize 1000 pagesize 0 trim on trimspool on echo off feedback off
define v_owner="SYSTEM"
define v_objname="RIAS_SCHEMA_FOR_SERVICE"
define v_objtype="FUNCTION"

SPOOL /tmp/output.log replace
SELECT t.line||' '||t.text as code_line
FROM sys.dba_source t
WHERE t.owner='&&v_owner' AND t.name='&&v_objname' AND t.TYPE='&&v_objtype'
ORDER BY line asc
;
spool off


define v_sid="sid3"
explain plan set statement_id='&&v_sid' into dev_bitest.plan_table 
for
select /*+ full(t) */  * from &&v_owner..&&v_tabname partition (SYS_P126737) t;
;

SELECT t.id, t.parent_id, LPAD(' ',2*(LEVEL-1))||t.operation operation, t.options, t.object_name, t.qblock_name, t.object_alias
       ,t.ACCESS_PREDICATES
       ,t.cost, t.TEMP_SPACE
FROM dev_bitest.plan_table t
START WITH t.id = 0 AND t.statement_id = '&&v_sid'
CONNECT BY PRIOR t.id = t.parent_id AND t.statement_id = '&&v_sid'
ORDER BY t.id;

--audit
select *
from sys.DBA_OBJ_AUDIT_OPTS t
where 1=1
  and t.owner='&&v_owner' and t.object_name='&&v_tabname'
;

--undo
-- who use undo
SELECT b.start_time, a.sid, a.username, a.program, b.used_urec, b.used_ublk
FROM sys.v_$session a, sys.v_$transaction b
WHERE a.saddr = b.ses_addr
ORDER BY b.used_ublk DESC
;

ALTER SYSTEM SET undo_retention=900 scope=both;
ALTER SYSTEM SET session_cached_cursors = 400 scope=spfile;

SELECT --t.name||' '||t.Value||' '||t.isdefault AS col
       t.*
FROM v$parameter t
WHERE t.name LIKE '%\_peek%' ESCAPE '\'
      --t.isdefault!='TRUE'
ORDER BY t.name
;

-- hidden parameter
SELECT
a.ksppinm Param,
b.ksppstvl SessionVal ,
c.ksppstvl InstanceVal,
a.ksppdesc Descr
FROM x$ksppi a, x$ksppcv b, x$ksppsv c
WHERE a.indx = b.indx AND a.indx = c.indx
 AND a.ksppinm LIKE '%feedback%' escape '\'
ORDER BY 1
;

select *
from sys.V$SERVICES t
WHERE 1=1
  --and Lower(t.name) LIKE '%ihome%'
ORDER BY t.name
;

SELECT *
from v$active_services t
WHERE 1=1
--and Lower(t.name) LIKE '%ihome%'
ORDER BY t.name
--t.creation_date desc
;

SELECT *
FROM V$SHARED_SERVER t
;

SELECT *
FROM V$SHARED_SERVER_MONITOR t
;

SELECT *
FROM V$RESOURCE_LIMIT t
;

SELECT Count(*), t.server
FROM v$session t
GROUP BY t.server
;

SELECT t.component,
      Round(t.current_size/1024/1024,2) AS current_size,
      Round(t.user_specified_size/1024/1024,2) AS user_specified_size,
      t.oper_count,
      t.last_oper_type,
      t.last_oper_mode,
      t.last_oper_time,
      Round(t.granule_size/1024/1024,2) AS granule_size
FROM v$sga_dynamic_components t
;

SELECT *
FROM sys.v_$sgastat t
WHERE t.pool='large pool'
;

ALTER SYSTEM SET db_cache_advice=ready scope=both;
ALTER SYSTEM SET db_cache_size=71940702208 scope=both;
ALTER SYSTEM SET db_cache_size=73013395456 scope=both;
ALTER SYSTEM SET streams_pool_size=536870912 scope=both;
ALTER SYSTEM SET large_pool_size=2684354560 scope=both;
ALTER SYSTEM SET undo_retention=600 scope=memory;

EXECUTE DBMS_RESULT_CACHE.MEMORY_REPORT;
SELECT * FROM V$RESULT_CACHE_DEPENDENCY;
SELECT * FROM V$RESULT_CACHE_MEMORY;
SELECT * FROM V$RESULT_CACHE_OBJECTS;
SELECT * FROM V$RESULT_CACHE_STATISTICS;

SELECT Count(*), t.scan_count
FROM V$RESULT_CACHE_OBJECTS t
WHERE t.name LIKE 'SELECT /*+ result_cache */ DISTINCT T.ACTION_ID%'
  AND t.TYPE='Result'
  AND t.status='Published'
GROUP BY t.scan_count
ORDER BY 2 desc
;

-- Standby
select *
from v$archive_dest
where dest_id=2
;

select *
from V$ARCHIVE_DEST_STATUS
where d5EF51E3D4EFF37D8;S:4F3AD683E011946A97F7F2C43388E7B53BF98D389FC2698015EAD1123106\est_id=2
;

SELECT *
FROM sys.dba_directories t
ORDER BY t.directory_name
;

-- grant read,write on directory PLSHPROF_DIR to excellent;
-- create or replace directory AWR_DUMP_DIR as '/db/u01/backup/parser/';
-- create or replace directory AWR_DUMP_DIR as '/tmp';
-- create or replace directory TMP_DIR as '/tmp';
-- create or replace directory TESTCACHE_DIR as '/tmp';
-- grant read, write on directory TESTCACHE_DIR to testcache;

SELECT s.owner, m.master, s.segment_name, Round(s.bytes/1024/1024,2) AS size_mb
FROM sys.dba_mview_logs m, sys.dba_segments s
WHERE s.owner=m.log_owner AND m.log_table=s.segment_name AND s.segment_type='TABLE'
  AND s.owner||'.'||m.master NOT IN (SELECT cr.table_name FROM rias.cr_mviews cr WHERE cr.get_data='Y')
ORDER BY s.bytes DESC
;

select  MV.LAST_REFRESH_TYPE, MV.LAST_REFRESH_DATE, RF.RNAME, MV.OWNER||'.'||MV.MVIEW_NAME as mv_info
from dba_mviews mv, sys.DBA_REFRESH_CHILDREN rf
where mv.OWNER='EXCELLENT'
  and MV.CONTAINER_NAME=RF.NAME
  and MV.OWNER=RF.OWNER
  --and RF.RNAME in ('RADIUS_VERY_FAST_LIGHT')
  AND MV.MVIEW_NAME='CHARGES_MV'
order by RF.RNAME, MV.MVIEW_NAME;

SELECT * from AWR_PUBLISHER.MLOG_STAT t
ORDER BY id desc
;

DELETE FROM AWR_PUBLISHER.MLOG_STAT t WHERE t.id IN (32918,32917);
COMMIT;

select '||City||Mlogs processed||Released, mb||Mlogs skipped||Retained, mb||' as col from dual
union all
select '|'||city||'|'||mlogs_processed||'|'||released_space_mb||'|'||mlogs_skipped||'|'||retained_space_mb||'|' as col
from (
select  t.city as city,
        round(sum( decode( nvl(t.skipped,0), 0, T.LOG_SIZE, 0 )  )/1024/1024,2) as released_space_mb,
        round(sum( decode( nvl(t.skipped,0), 0, 0, T.LOG_SIZE )  )/1024/1024,2) as retained_space_mb,
        sum( decode( nvl(t.skipped,0), 0,1,0 ) ) as mlogs_processed,
        sum( decode( nvl(t.skipped,0), 0,0,1 ) ) as mlogs_skipped
from AWR_PUBLISHER.MLOG_STAT t
where trunc(t.DATETIME,'DD')=trunc(sysdate,'DD')
--and t.city='kzn'
group by t.city
order by t.city, released_space_mb desc
) v;


select  t.*
from AWR_PUBLISHER.MLOG_STAT t
where trunc(t.DATETIME,'DD')=trunc(sysdate,'DD')
  --AND t.city IN ('tmn','ryazan')
;

select  datetime - ( min(datetime) over (order by datetime) ) as observation_number,
        DB_SIZE
from (
select  trunc(P.DATE_TIME,'DD') as datetime,
        sum(P.USED_SIZE) as DB_SIZE
from AWR_PUBLISHER.DB_PHYS_COMP_SIZE p, AWR_PUBLISHER.DB_HOSTS h
where P.RESOURCE_ID=H.ID
  and h.DOMAIN_NAME='kzn' and h.DB='billing' and H.RESOURCE_TYPE='TABLESPACE'
  --AND h.resource_name='WEB'
group by trunc(P.DATE_TIME,'DD')
order by datetime
 ) v;

SELECT  --DISTINCT h.db
        --DISTINCT h.domain_name
        --DISTINCT h.resource_name AS ts
        *
FROM AWR_PUBLISHER.DB_HOSTS h
WHERE H.RESOURCE_TYPE='TABLESPACE'
  AND h.db='dwh'
;

SELECT listagg(ts,',') WITHIN GROUP (ORDER BY NULL) AS ts_list
FROM (
SELECT --DISTINCT h.db
       --*
      DISTINCT h.resource_name AS ts
FROM AWR_PUBLISHER.DB_HOSTS h
WHERE H.RESOURCE_TYPE='TABLESPACE'
  AND h.db='billing'
  AND h.DOMAIN_NAME='ekat'
  AND h.resource_type='TABLESPACE'
  )
;

WITH DATA AS
(SELECT
'BI12CREP2_BIPLATFORM,BI12CREP2_IAS_OPSS,BI12CREP2_IAS_UMS,BI12CREP2_MDS,BI12CREP2_STB,BI12CREP2_WLS,BI12CREP_BIPLATFORM,BI12CREP_IAS_OPSS,BI12CREP_IAS_UMS,BI12CREP_IAU,BI12CREP_MDS,BI12CREP_STB,BI12CREP_WLS,BI12CTST_STB,BI12CREP2_IAU,BI12CTST_BIPLATFORM,BI12CTST_IAS_OPSS,BI12CTST_IAS_UMS,BI12CTST_IAU,BI12CTST_MDS,BI12CTST_WLS,BI12C_IAU,BI12C_BIPLATFORM,BI12C_IAS_OPSS,BI12C_IAS_UMS,BI12C_MDS,BI12C_STB,BI12C_WLS,BI12TST_IAU,BI12TST_BIPLATFORM,BI12TST_IAS_OPSS,BI12TST_IAS_UMS,BI12TST_STB,BI12TST_WLS,BI3V3_IAU,BI12TST_MDS,BI3V3_BIPLATFORM,BI3V3_IAS_OPSS,BI3V3_IAS_TEMP,BI3V3_IAS_UMS,BI3V3_MDS,BI3V3_STB,BI3V3_WLS,BI3_IAU,BI3_BIPLATFORM,BI3_IAS_OPSS,BI3_IAS_UMS,BI3_MDS,BI3_STB,BI3_WLS,DEVBI_IAS_IAU,DEVBI_IAS_TEMP,FDA_TB,GGS_DATA,IDX_STORAGE_FAST,IDX_STORAGE_MEDIUM,IDX_STORAGE_SLOW,OWBDATA,BICLSTR_BIPLATFORM,BICLSTR_IAS_OPSS,BICLSTR_IAS_TEMP,CM_TEMP,BICLSTR_IAS_UMS,BICLSTR_IAU,BICLSTR_MDS,BICLSTR_STB,BICLSTR_WLS,MONITOR,OLAP,OWBIDX,OWBREP,OWBSNPSHT,RCU,RMREP_TS,SSD_TEMP,SYSAUX,SYSTEM,TAB_STORAGE_FAST,TAB_STORAGE_MEDIUM,TAB_STORAGE_SLOW,TEMP,TEMP1,TEMP_CM,TS_CAMPAIGN,TS_CMDM,UNDOTBS,USERS'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as ts_'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;


SELECT *
FROM (
select  trunc(P.DATE_TIME,'DD') as datetime,
        h.resource_name AS ts,
        sum(P.USED_SIZE) as DB_SIZE
from AWR_PUBLISHER.DB_PHYS_COMP_SIZE p, AWR_PUBLISHER.DB_HOSTS h
where P.RESOURCE_ID=H.ID
  and h.DOMAIN_NAME='ertelecom' and h.DB='dwh' and H.RESOURCE_TYPE='TABLESPACE'
group by trunc(P.DATE_TIME,'DD'), h.resource_name
 )
pivot (
 Max(db_size)
 FOR ts IN (
'BI12CREP2_BIPLATFORM' as ts_1,
'BI12CREP2_IAS_OPSS' as ts_2,
'BI12CREP2_IAS_UMS' as ts_3,
'BI12CREP2_MDS' as ts_4,
'BI12CREP2_STB' as ts_5,
'BI12CREP2_WLS' as ts_6,
'BI12CREP_BIPLATFORM' as ts_7,
'BI12CREP_IAS_OPSS' as ts_8,
'BI12CREP_IAS_UMS' as ts_9,
'BI12CREP_IAU' as ts_10,
'BI12CREP_MDS' as ts_11,
'BI12CREP_STB' as ts_12,
'BI12CREP_WLS' as ts_13,
'BI12CTST_STB' as ts_14,
'BI12CREP2_IAU' as ts_15,
'BI12CTST_BIPLATFORM' as ts_16,
'BI12CTST_IAS_OPSS' as ts_17,
'BI12CTST_IAS_UMS' as ts_18,
'BI12CTST_IAU' as ts_19,
'BI12CTST_MDS' as ts_20,
'BI12CTST_WLS' as ts_21,
'BI12C_IAU' as ts_22,
'BI12C_BIPLATFORM' as ts_23,
'BI12C_IAS_OPSS' as ts_24,
'BI12C_IAS_UMS' as ts_25,
'BI12C_MDS' as ts_26,
'BI12C_STB' as ts_27,
'BI12C_WLS' as ts_28,
'BI12TST_IAU' as ts_29,
'BI12TST_BIPLATFORM' as ts_30,
'BI12TST_IAS_OPSS' as ts_31,
'BI12TST_IAS_UMS' as ts_32,
'BI12TST_STB' as ts_33,
'BI12TST_WLS' as ts_34,
'BI3V3_IAU' as ts_35,
'BI12TST_MDS' as ts_36,
'BI3V3_BIPLATFORM' as ts_37,
'BI3V3_IAS_OPSS' as ts_38,
'BI3V3_IAS_TEMP' as ts_39,
'BI3V3_IAS_UMS' as ts_40,
'BI3V3_MDS' as ts_41,
'BI3V3_STB' as ts_42,
'BI3V3_WLS' as ts_43,
'BI3_IAU' as ts_44,
'BI3_BIPLATFORM' as ts_45,
'BI3_IAS_OPSS' as ts_46,
'BI3_IAS_UMS' as ts_47,
'BI3_MDS' as ts_48,
'BI3_STB' as ts_49,
'BI3_WLS' as ts_50,
'DEVBI_IAS_IAU' as ts_51,
'DEVBI_IAS_TEMP' as ts_52,
'FDA_TB' as ts_53,
'GGS_DATA' as ts_54,
'IDX_STORAGE_FAST' as ts_55,
'IDX_STORAGE_MEDIUM' as ts_56,
'IDX_STORAGE_SLOW' as ts_57,
'OWBDATA' as ts_58,
'BICLSTR_BIPLATFORM' as ts_59,
'BICLSTR_IAS_OPSS' as ts_60,
'BICLSTR_IAS_TEMP' as ts_61,
'CM_TEMP' as ts_62,
'BICLSTR_IAS_UMS' as ts_63,
'BICLSTR_IAU' as ts_64,
'BICLSTR_MDS' as ts_65,
'BICLSTR_STB' as ts_66,
'BICLSTR_WLS' as ts_67,
'MONITOR' as ts_68,
'OLAP' as ts_69,
'OWBIDX' as ts_70,
'OWBREP' as ts_71,
'OWBSNPSHT' as ts_72,
'RCU' as ts_73,
'RMREP_TS' as ts_74,
'SSD_TEMP' as ts_75,
'SYSAUX' as ts_76,
'SYSTEM' as ts_77,
'TAB_STORAGE_FAST' as ts_78,
'TAB_STORAGE_MEDIUM' as ts_79,
'TAB_STORAGE_SLOW' as ts_80,
'TEMP' as ts_81,
'TEMP1' as ts_82,
'TEMP_CM' as ts_83,
'TS_CAMPAIGN' as ts_84,
'TS_CMDM' as ts_85,
'UNDOTBS' as ts_86,
'USERS' as ts_87
 )
)
order by datetime
;

SELECT to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(1523860561,'SECOND'),'YYYY-MM-DD HH24:MI:SS') AS datetime FROM dual;
SELECT *
FROM AWR_PUBLISHER.DB_HOSTS t
WHERE t.db='sa'
;

SELECT Row_Number() OVER (ORDER BY v.datetime asc) AS snap_id,
       v.*
FROM (
SELECT t.datetime AS datetime,
       Round(Sum(t.total)/1024/1024/1024,2) AS DBSizeGB,
       Round(Sum(t.free)/1024/1024/1024,2) AS FreeSpaceGB
FROM SYSTEM.SIZE_TS t
GROUP BY t.datetime
ORDER BY t.datetime ASC ) v
;

SELECT datetime,
       Sum(days) OVER (ORDER BY datetime ASC) AS num_of_observation_day,
       DBSizeGD
FROM (
SELECT  datetime,
        CASE WHEN prev_datetime IS NULL THEN 1
        ELSE Trunc(datetime-prev_datetime,0)
        END AS days,
        DBSizeGD
FROM (
SELECT  datetime,
        Lag(datetime,1,NULL) OVER (ORDER BY datetime asc) AS prev_datetime,
        DBSizeGD
FROM (
SELECT t.datetime AS datetime, Round(Sum(t.ts_size)/1024/1024/1024,2) AS DBSizeGD
FROM zabbix.size_ts t
GROUP BY t.datetime
ORDER BY t.datetime ASC
 )
  )
   );

-- SA|DWH ---------------------------------
define v_schema="bitest"
define v_collect_time="17.11.2017 00:00:00"
define v_ts="TAB_STORAGE_SLOW"

SELECT DISTINCT t.tablespace_name
FROM &&v_schema..data_volume_hist t
;

SELECT t.collection_date AS collection_date,
       Sum(t.Value) AS sizemb
FROM &&v_schema..data_volume_hist t
GROUP BY t.collection_date
order BY t.collection_date
;

SELECT t.collection_date,
       Sum(t.Value) AS total_size
FROM &&v_schema..data_volume_hist t
WHERE t.tablespace_name='DATA_SLOW'
  AND regexp_like(t.segment_name,'^[A-Za-z0-9_\$\#]+$')
GROUP BY t.collection_date
ORDER BY t.collection_date asc
;

SELECT --DISTINCT t.owner||'.'||t.segment_name AS obj
       t.segment_name
FROM &&v_schema..data_volume_hist t
WHERE t.tablespace_name='&&v_ts'
  AND regexp_like(t.segment_name,'^[A-Za-z0-9_\$\#]+$')
  AND t.collection_date=To_Date('17.11.2017 00:00:00','dd.mm.yyyy hh24:mi:ss')
;

CREATE TABLE &&v_schema..data_volume_hist_sub TABLESPACE &&v_ts
AS
SELECT t.owner||'.'||t.segment_name AS obj, t.collection_date AS collection_date,
       t.Value AS value
FROM &&v_schema..data_volume_hist t
where t.tablespace_name='&&v_ts'
  AND t.collection_date>=To_Date('&&v_collect_time','dd.mm.yyyy hh24:mi:ss')
  and regexp_like(t.segment_name,'^[A-Za-z0-9_\$\#]+$')
;

CREATE INDEX &&v_schema..i_data_volume_hist_sub ON &&v_schema..data_volume_hist_sub (obj) TABLESPACE &&v_ts;
--DROP TABLE  &&v_schema..data_volume_hist_sub purge;

SELECT t.collection_date AS collection_date,
       sum(Nvl(t.Value,0)) AS sizemb
FROM &&v_schema..data_volume_hist_sub t
WHERE t.obj IN ('BITEST.F_DWH_CHARGES2')
GROUP BY t.collection_date
order BY t.collection_date asc
;

SELECT Count (DISTINCT obj) FROM   &&v_schema..data_volume_hist_sub t;

SELECT --DISTINCT t.obj
       --t.*
       (t.Value)
FROM &&v_schema..data_volume_hist_sub t
WHERE t.obj='BI_TMP_SERVICE.TTK6E787GNUASDM6070O42K06032'
  AND t.Value IS NOT null
      --t.obj LIKE 'EXCELLENT.IDX$$_%'
      --t.obj IN ('EXCELLENT.SA_EQL_RAW_WIFI_CATS_INT','EXCELLENT.IDX$$_64E60002','EXCELLENT.CALLS_VALUE_ALL','EXCELLENT.I_TERMCALLS_DATETIME','EXCELLENT.SA_DTV2_TV_ALL_PK','EXCELLENT.I_SA_DTV2_TV_ALL','EXCELLENT.IDX_DSLP_ID','EXCELLENT.PK_QS_QST_EXPL_PARAMS','EXCELLENT.I_AGENTINTERVAL_DATETIME','EXCELLENT.ACTIVATE_LICENSE_FEE_ALL','EXCELLENT.T_AGENT_SKILL_GROUP_INTERVAL','EXCELLENT.RBS_PAYMENTS_ALL','EXCELLENT.F190_CLIENT_SEGMENTS','EXCELLENT.SA_DTV_EQUIPTS','EXCELLENT.PK_PR_REQUEST_STATE_ATTRA_ALL','EXCELLENT.SA_REACTIVE_AGREEMENTS_DEL','EXCELLENT.I_PAYMENTS_ALL_TMESTAMP','EXCELLENT.I_SA_F707_INT_PROBLEMS_REQ_CL','EXCELLENT.PK_FACT_CITIES_ALL','EXCELLENT.EQL_GENERATE_ACTIONS_ALL','EXCELLENT.CCS_EXEC_ALL','EXCELLENT.MANAGER_SALE_ATTR_LINKS_ALL','EXCELLENT.PR_PROC_REQUEST_STATE_ALL','EXCELLENT.SA_EQL_RAW_FROM_XML_GAMES_INT','EXCELLENT.PR_PLAN_EXEC_DATES_ALL','EXCELLENT.CLIENT_MAIN_SEGMENTS_HIST','EXCELLENT.I_STEP_FROM_TO','EXCELLENT.SA_EQL_RAW_WIFI_GAMES','EXCELLENT.CALLS_VALUE_MP_ALL')
--ORDER BY t.collection_date asc
;

SELECT t.collection_date as snap_id,  sum(t.Value) AS stat_value
FROM excellent.data_volume_hist_sub t
WHERE 1=1
      --t.obj='EXCELLENT.IDX.._64E60002'
  AND t.obj IN ('EXCELLENT.I_PR_RQ_ADD_ATTR_ALL_TYPE_ID','EXCELLENT.I_PR_PROC_REQUESTS_AGR_PROC_ID','EXCELLENT.PK_IA_PAYMENTS_ALL','EXCELLENT.I_QS_RAL_REQ_ID','EXCELLENT.I_RBS_PAYM_ALL_AGR_VALUE','EXCELLENT.I_RBS_PAYM_ALL_REQUEST_DATE','EXCELLENT.PK_PR_REQUEST_ADD_ATTR_ALL','EXCELLENT.PK_FIRST_SESSIONS_ALL','EXCELLENT.I_FLAG_LINKS_ALL_AGR_ID','EXCELLENT.PK_NET_DAMAGE_AUTOLOG','EXCELLENT.I_REQUEST_ID','EXCELLENT.I_LAST_STEP_ACTIVE','EXCELLENT.PK_FLAG_LINKS_ALL','EXCELLENT.PK_PR_OBJECT_PROBLEM_LINKS','EXCELLENT.I_RBS_PAYM_ALL_ORDER_NUMBER','EXCELLENT.I_RBS_PAYM_ALL_STATUS_DATE','EXCELLENT.PK_PR_PROC_REQUESTS_ALL','EXCELLENT.I_FIRST_SESSIONS_FIRST_DATE','EXCELLENT.I_RBS_PAYM_ALL_PAYMENT_SRC_ID','EXCELLENT.PK_PR_PROC_RQ_CHANGE_LOG_ALL','EXCELLENT.I_RAL_ANSW_ID','EXCELLENT.I_PR_PROC_REQUESTS_ALL_AGR_ID','EXCELLENT.PK_CHARGES_ALL','EXCELLENT.I_ADDENDA_SA_IMPORT_DATE','EXCELLENT.I_RBS_PAYM_ALL_ORDER_STATUS','EXCELLENT.I_EXECUTER_LINKS_ALL_REQ_ST_ID','EXCELLENT.PK_CLIENT_PHONES_ALL')
GROUP BY t.collection_date
ORDER BY t.collection_date asc
;

SELECT *
FROM (
SELECT t.collection_date as collection_date,  t.obj AS obj, sum(t.Value) AS stat_value
FROM &&v_schema..data_volume_hist_sub t
WHERE t.obj IN ('BITEST.F_DWH_CHARGES2','BITEST.F_DTV2_CONTENT_VIEW_TV','BITEST.F_RESPONSES_SRC1','BITEST.F_BALANCE_MONTHLY','BITEST.F_PHONE_CALLS','BITEST.MA_CAMPAIGNS','BITEST.F001_DWH_CHARGES2_VAS','BITEST.F_PROC_REQUEST_STATES','BITEST.SYS_LOB0004533006C00012..','BITEST.F_DWH_CHARGES2_AGR2','BITEST.F_CISCO_CALLS','BITEST.F_SMS','BITEST.F_AA_B2B_TECH_CHARGES','BITEST.PK_F_DTV2_CONTENT_VIEW_TV','BITEST.F_AA_B2B_COMM_CHARGES','BITEST.F_PRIORITIZATION','BITEST.F_CISCO_AGENT_STATE_TRACE','BITEST.F211_CISCO_CALLS','BITEST.F_TV_STAT_POWER_BALL','BITEST.F_CC_ISSUES_STEPS','BITEST.F_B2B_ACTIVE_POINTS_CHARGES','BITEST.I_F_PRIORITIZATION_U01','BITEST.F251_QUALITY_SERV_AGR3','DEV_BITEST.F_DWH_CHARGES2','BITEST.F001_DWH_CHARGES2_VAS_AGR2','BITEST.F_DWH_CHARGES2_AGR3','BITEST.F_KANNEL_SMS','BITEST.F_DWH_CHARGES_FACTORS','BITEST.F_NOTICE_CAMP','BITEST.F227_B2C_RETENT_DISC')
GROUP BY t.collection_date, t.obj
)
pivot (
max(stat_value)
FOR (obj) IN (
'BITEST.F_DWH_CHARGES2' as q1,
'BITEST.F_DTV2_CONTENT_VIEW_TV' as q2,
'BITEST.F_RESPONSES_SRC1' as q3,
'BITEST.F_BALANCE_MONTHLY' as q4,
'BITEST.F_PHONE_CALLS' as q5,
'BITEST.MA_CAMPAIGNS' as q6,
'BITEST.F001_DWH_CHARGES2_VAS' as q7,
'BITEST.F_PROC_REQUEST_STATES' as q8,
'BITEST.SYS_LOB0004533006C00012..' as q9,
'BITEST.F_DWH_CHARGES2_AGR2' as q10,
'BITEST.F_CISCO_CALLS' as q11,
'BITEST.F_SMS' as q12,
'BITEST.F_AA_B2B_TECH_CHARGES' as q13,
'BITEST.PK_F_DTV2_CONTENT_VIEW_TV' as q14,
'BITEST.F_AA_B2B_COMM_CHARGES' as q15,
'BITEST.F_PRIORITIZATION' as q16,
'BITEST.F_CISCO_AGENT_STATE_TRACE' as q17,
'BITEST.F211_CISCO_CALLS' as q18,
'BITEST.F_TV_STAT_POWER_BALL' as q19,
'BITEST.F_CC_ISSUES_STEPS' as q20,
'BITEST.F_B2B_ACTIVE_POINTS_CHARGES' as q21,
'BITEST.I_F_PRIORITIZATION_U01' as q22,
'BITEST.F251_QUALITY_SERV_AGR3' as q23,
'DEV_BITEST.F_DWH_CHARGES2' as q24,
'BITEST.F001_DWH_CHARGES2_VAS_AGR2' as q25,
'BITEST.F_DWH_CHARGES2_AGR3' as q26,
'BITEST.F_KANNEL_SMS' as q27,
'BITEST.F_DWH_CHARGES_FACTORS' as q28,
'BITEST.F_NOTICE_CAMP' as q29,
'BITEST.F227_B2C_RETENT_DISC' as q30
 )
)
ORDER BY collection_date asc
;

SELECT DISTINCT t.owner||'.'||t.segment_name AS obj
FROM excellent.data_volume_hist t
WHERE t.tablespace_name='DATA_SLOW'
MINUS
SELECT DISTINCT t1.owner||'.'||t1.segment_name AS obj
FROM excellent.data_volume_hist t1
WHERE t1.tablespace_name='DATA_SLOW'
  AND regexp_like(t1.segment_name,'^[A-Za-z0-9_\$\#]+$')
;

---------------------------------------

--describes auditing options on all objects
SELECT *
FROM sys.DBA_OBJ_AUDIT_OPTS t
WHERE t.owner='TPCC'
;

SELECT *
FROM sys.DBA_PRIV_AUDIT_OPTS t
;

SELECT *
FROM sys.DBA_STMT_AUDIT_OPTS t
;

--NOAUDIT DIRECTORY by ACCESS;

SELECT  t.*
        --t.begin_time, t.undoblks, t.maxconcurrency, t.unxpstealcnt, t.expstealcnt, t.activeblks, t.expiredblks, t.unexpiredblks, t.tuned_undoretention
FROM sys.dba_hist_undostat t
WHERE t.dbid=&&v_dbid
  AND t.undotsn=(SELECT ts.ts# FROM sys.v_$tablespace ts WHERE ts.name=(SELECT p.value FROM sys.v_$parameter p WHERE p.name='undo_tablespace' ))
ORDER BY t.begin_time asc
;

--traces
select t.line_number, t.timestamp,
       case t.record_type
        when 1 then 'Regular trace record'
        when 2 then 'Freeform trace record'
        when 3 then 'Begin Section trace record'
        when 4 then 'Begin Dump trace record'
        when 5 then 'Bucket Dump Begin trace record'
        when 6 then 'Section End trace record'
        when 7 then 'Dump End trace record'
        when 8 then 'Bucket Dump End trace record'
        else 'Unknown record type'
       end as record_type,
       t.function_name, t.payload as trace_line
from V$DIAG_TRACE_FILE_CONTENTS t
where 1=1
  and t.TRACE_FILENAME='sa_ora_75502.trc'
order by t.line_number asc
;



