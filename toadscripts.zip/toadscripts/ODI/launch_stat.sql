--http://odi-usage.blogspot.com/2010/09/snpsession.html
SELECT *
FROM excellent.snp_session t
WHERE t.sess_status='D'
;

CREATE INDEX snp_session_sess_name_idx ON excellent.snp_session(sess_name );

SELECT Count(DISTINCT sess_name)
FROM excellent.snp_session t
;

SELECT sess_name--, Count(*)
FROM excellent.snp_session t
WHERE t.sess_beg>=To_Date('05.02.2020 00:00','dd.mm.yyyy hh24:mi')
  AND t.sess_status='D'
GROUP BY sess_name
HAVING Count(*) >= 70
--ORDER BY 2 desc
;


DROP TABLE excellent.etl_dates;
CREATE TABLE excellent.etl_dates (launch_date DATE);
DECLARE
v_start_date DATE := To_Date('05.02.2020','dd.mm.yyyy');
v_stop_date DATE;
BEGIN
IF IS NULL v_start_date
THEN
 SELECT Min(Trunc(t.sess_beg,'DD')) INTO v_start_date FROM excellent.snp_session t;
END IF;
IF IS NULL v_stop_date
THEN
 SELECT Max(Trunc(t.sess_beg,'DD')) INTO v_stop_date FROM excellent.snp_session t;
END IF;
WHILE v_start_date<=v_stop_date
LOOP
 INSERT INTO excellent.etl_dates VALUES(v_start_date);
 v_start_date:=v_start_date+1;
END LOOP;
COMMIT;
END;
/

SELECT * FROM  excellent.etl_dates ORDER BY launch_date desc;

SELECT d.launch_date AS launch_date, etl_names
FROM (
SELECT Trunc(t.sess_beg,'DD') AS launch_date, Count(DISTINCT t.sess_name) AS etl_names
FROM excellent.snp_session t
GROUP BY Trunc(t.sess_beg,'DD') ) v, excellent.etl_dates d
WHERE d.launch_date=v.launch_date(+)
ORDER BY d.launch_date asc
;

SELECT --t.*
       t.sess_beg AS launch_time, t.sess_dur AS ela_time
FROM excellent.snp_session t
WHERE t.sess_name='PKG_F140_RELOAD_OUTFLOW_QT_INFOC'
  AND t.sess_beg>=To_Date('05.02.2020 00:00','dd.mm.yyyy hh24:mi')
  --AND t.sess_status='D'
ORDER BY t.sess_beg ASC
;

DROP TABLE excellent.basepoints;
CREATE TABLE excellent.basepoints (point DATE, ts number);

DECLARE
v_start_datetime DATE := To_Date('06.05.2019 12:00','dd.mm.yyyy hh24:mi');
v_stop_datetime DATE := To_Date('06.05.2020 12:00','dd.mm.yyyy hh24:mi');
BEGIN
WHILE v_start_datetime < v_stop_datetime
LOOP
 INSERT INTO excellent.basepoints(point) VALUES(v_start_datetime);
 v_start_datetime := v_start_datetime + 1/24;
END LOOP;
COMMIT;
END;
/

UPDATE excellent.basepoints t
SET t.ts=substr(extract(day from (t.point - timestamp '1970-01-01 00:00:00')) * 24 * 60 * 60 +
       extract(hour from (t.point - timestamp '1970-01-01 00:00:00')) * 60 * 60 +
       extract(minute from (t.point - timestamp '1970-01-01 00:00:00')) * 60 +
       trunc(extract(second from (t.point - timestamp '1970-01-01 00:00:00')),0),0,15);
COMMIT;

SELECT * FROM excellent.basepoints t
--WHERE Trunc(t.point,'DD')=To_Date('17.04.2019','dd.mm.yyyy')
ORDER BY t.ts asc;

SELECT t.sess_beg,
       substr(extract(day from (t.sess_beg - timestamp '1970-01-01 00:00:00')) * 24 * 60 * 60 +
       extract(hour from (t.sess_beg - timestamp '1970-01-01 00:00:00')) * 60 * 60 +
       extract(minute from (t.sess_beg - timestamp '1970-01-01 00:00:00')) * 60 +
       trunc(extract(second from (t.sess_beg - timestamp '1970-01-01 00:00:00')),0),0,15) AS ts,
       t.sess_dur AS ela_time
FROM excellent.snp_session t
WHERE t.sess_name='PKG_F140_MA_KPI_DSI_STC_ONE_DAY'
  AND t.sess_beg>=To_Date('05.02.2020 00:00','dd.mm.yyyy hh24:mi')
  --AND t.sess_status='D'
ORDER BY ts ASC
;

--
SELECT scen_no as SESS_NAME, Count(*) AS cnt
FROM (
SELECT t.scen_no, Trunc(t.sess_beg,'DD') AS ldate, Count(*) AS howmanytimesitlaunced
FROM excellent.snp_scen_report t
WHERE t.sess_beg >= To_Date('06.05.2019 12:00','dd.mm.yyyy hh24:mi')
GROUP BY t.scen_no, Trunc(t.sess_beg,'DD')
 )
 GROUP BY scen_no
 HAVING Count(*) >= 350
 ORDER BY cnt DESC
;
----------------------------------------------------------------------------------
--Session And Scenario Execution Log Tables Used By ODI (Doc ID 424663.1)

SELECT *
FROM sys.dba_objects t
WHERE t.object_name='SNP_SCEN_REPORT'
;

SELECT *
FROM sys.dba_segments t
WHERE t.segment_name IN ('SNP_SCEN_REPORT','SNP_SCEN')
ORDER BY t.bytes desc
;

SELECT --Count(*)
       --t.scen_no, t.sess_beg, t.sess_dur
       t.*
FROM DEV1_ODI_REPO.SNP_SCEN_REPORT t
WHERE t.sess_status='D'
--ORDER BY t.sess_beg asc
;

select ETL_NAME
from DEV1_ODI_REPO.ODI_ETL_DUTY_MONITORING_2 t;

SELECT --t.scen_no
       t.*
FROM DEV1_ODI_REPO.SNP_SCEN t
WHERE 1=1
  --AND t.scen_name = 'PKG_F824_AVAILABLE_SERVICES'
  --AND t.scen_no IN (1101002,1579002)
  AND t.scen_name IN ('PKG_CISCO_FULL_COLLECT','PKG_F001_DWH_CHARGES2_FULL','PKG_F001_DWH_CHARGES2_GATHER_BILLS','PKG_F003_AA_B2C','PKG_F010_PAYMENTS','PKG_F014_PRODUCT_PLANS','PKG_F016_B2B_REQUESTS','PKG_F016_PROC_REQUESTS','PKG_F017_GATHER','PKG_F030_B2B_SALES','PKG_F044_SALE_PLANS','PKG_F057_KPI_TECH_SERVICE_NEW','PKG_F072_AA_B2C_ALF','PKG_F078_F079_F093_REACT_DEACT_OUTFLOW_AGREEMENTS','PKG_F095_DEBT_B2C','PKG_F097_B2B_CHARGE_CHANGES','PKG_F097_B2B_CHARGE_CHANGES_MAIN','PKG_F136_AA_B2B_COMMERCIAL','PKG_F136_AA_B2B_COMMERCIAL_MAIN','PKG_F156_B2C_SALES','PKG_F236_CRASHES','PKG_F258_B2R_APPEAL_PLANS','PKG_F258_B2R_APPEAL_PLANS_MAIN','PKG_F260_MATERIAL_ENS_REQUEST')
ORDER BY t.first_date asc
;

SELECT ss.scen_name,
       TRUNC (ssc.SESS_BEG)          scen_date,
       ROUND (ssc.SESS_DUR / 60)     PKG_dur_minutes
  FROM ODI_REPO_12.SNP_SCEN_REPORT  ssc,
       SNP_SCEN        ss
 WHERE     ssc.scen_no = ss.scen_no
       AND ss.scen_name = 'PKG_F072_AA_B2C_ALF'
       AND ssc.SESS_BEG >= TRUNC (CURRENT_DATE,'yyyy')
;

drop table excellent.snp_scen_report;
create table excellent.snp_scen_report (scen_no number, sess_beg date, sess_dur number);

CREATE INDEX snp_scen_report_idx ON excellent.snp_scen_report(sess_beg);
CREATE INDEX scen_no_idx ON excellent.snp_scen_report(scen_no);

SELECT --Count(DISTINCT t.scen_no)
       t.*
FROM excellent.snp_scen_report t
WHERE t.sess_beg >= To_Date('10.04.2019','dd.mm.yyyy')
--ORDER BY t.sess_beg asc
;

SELECT Min(sess_beg), Max(sess_beg)
FROM excellent.snp_scen_report t
WHERE t.sess_beg >= To_Date('10.04.2019','dd.mm.yyyy')
;

SELECT Trunc(t.sess_beg,'DD'), Count(*)
FROM excellent.snp_scen_report t
WHERE 1=1
  --AND t.scen_no=1228002
  AND t.sess_beg >= To_Date('10.04.2019','dd.mm.yyyy')
GROUP BY Trunc(t.sess_beg,'DD')
ORDER BY 1 ASC
;

SELECT  Trunc(sess_beg, 'DD') AS launch_date,
        Count(*)
FROM excellent.snp_scen_report t
WHERE t.scen_no IN (4812002,3004002,4811002,1273002,3791002,2419002,1750002,2926002,4290002,2553002,1599002,1579002,1084002,4486002,1101002,2641002,1228002,1227002,3050002,5381002,2328002,1102002,1278002,5401002)
GROUP BY Trunc(sess_beg, 'DD')
ORDER BY Trunc(sess_beg, 'DD') ASC
;

SELECT t.scen_no, Count(*)
FROM excellent.snp_scen_report t
WHERE t.sess_beg >= To_Date('10.04.2019','dd.mm.yyyy')
GROUP BY t.scen_no
HAVING Count(*)>=350
ORDER BY 2 desc
;

SELECT substr(extract(day from (t.sess_beg - timestamp '1970-01-01 00:00:00')) * 24 * 60 * 60 +
       extract(hour from (t.sess_beg - timestamp '1970-01-01 00:00:00')) * 60 * 60 +
       extract(minute from (t.sess_beg - timestamp '1970-01-01 00:00:00')) * 60 +
       trunc(extract(second from (t.sess_beg - timestamp '1970-01-01 00:00:00')),0),0,15) AS ts,
       nvl(t.sess_dur,0) AS ela_time
FROM excellent.snp_scen_report t
WHERE t.scen_no=1718
ORDER BY ts ASC
;

SELECT Count(*)
FROM excellent.snp_scen_report t
WHERE t.scen_no=1718
;