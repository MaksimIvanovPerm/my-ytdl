define service_name="private_web.spb.ertelecom.ru"
EXEC DBMS_SERVICE.STOP_SERVICE('&&service_name');
exec DBMS_SERVICE.DISCONNECT_SESSION('&&service_name',1);
DECLARE
 CURSOR c1 is
 SELECT p.spid AS spid, t.*
 FROM sys.v_$session t, sys.v_$process p
 WHERE t.paddr=p.addr --t.event IN ( 'cursor: pin S','latch: cache buffers chains','latch: shared pool')
   --AND t.action='RPC POST'
   AND t.module='pe_web_interface_archive.show_rq_list_step_2'
   AND t.sql_id='c0bz5vyytsb0z'
   --AND t.event = 'latch: cache buffers chains'
   ;
BEGIN
WHILE 1=1
LOOP
 FOR i IN c1
 LOOP
  begin
   EXECUTE IMMEDIATE 'alter system kill session '''||i.sid||','||i.serial#||''' immediate';
  EXCEPTION
   WHEN OTHERS THEN NULL;
  END;
 END LOOP;
 Dbms_Lock.sleep(1);
END LOOP;
END;
/

EXEC DBMS_SERVICE.START_SERVICE('&&service_name');
ALTER SYSTEM register;
SELECT * FROM sys.v_$ACTIVE_SERVICES T ORDER BY t.network_name;


DECLARE
 CURSOR c1 IS
 SELECT * FROM sys.v_$session t1 WHERE t1.sid IN (
 SELECT DISTINCT t.blocking_session
 FROM sys.v_$session t
 WHERE 1=1 --t.event = 'enq: TX - row lock contention'
   AND t.module='eql_params_pub.params_data_xml'
   );
BEGIN
 FOR i IN c1
 LOOP
  EXECUTE IMMEDIATE 'alter system kill session '''||i.sid||','||i.serial#||''' immediate';
 END LOOP;
END;
/

DECLARE
 CURSOR c1 is
 SELECT t.*
 FROM sys.v_$session t
 WHERE 1=1 --t.event = 'enq: TX - row lock contention'
       --t.action='webcab_content_procs.get_state_s'
   --AND t.module='wcc2_main.frame_left_reasons'
   AND t.sql_id='7f0t274ab555d'
   --AND t.event = 'latch: cache buffers chains'
   ;
BEGIN
 FOR i IN c1
 LOOP
  EXECUTE IMMEDIATE 'alter system kill session '''||i.sid||','||i.serial#||''' immediate';
 END LOOP;
END;
/

/*
#!/bin/bash
$ORACLE_HOME/bin/sqlplus -S / as sysdba << __EOFF__
set pagesize 0
set feedback off
set head off

 SELECT p.spid AS spid
 FROM sys.v_\$session t, sys.v_\$process p
 WHERE t.paddr=p.addr
   --AND t.module='mx_rq_interface.get_count_search_req'
   AND t.sql_id='9jcvzrrbucgdu'
   AND t.event = 'latch: cache buffers chains'
   ;

exit
__EOFF__

while [ "1" == "1" ]
do
 ./temp.sh | xargs -n 1 -P 2 -I {} -t bash -c 'kill -9 {}'
 sleep 60
done
*/