tounixtime=function(p1)
{
 #2017-06-15_16:45
 yyyy=as.integer( substr(p1,1,4) )*31556926
 mm=as.integer( substr(p1,6,7) )*2629743
 dd=as.integer( substr(p1,9,10) )*24*60*60
 hh24=as.integer( substr(p1,12,13) )*60*60
 mi=as.integer( substr(p1,15,16) )*60
 #print (yyyy+mm+dd+hh24+mi)
 return (yyyy+mm+dd+hh24+mi)
}

x=NULL
v_data_file=paste('C:\\Temp\\data1.dat',sep="")
x=read.table(v_data_file, header = TRUE, sep = "\t", dec=",", quote = "\"'", stringsAsFactors=FALSE, )
str(x)
head(x)

#summary(x$STAT_VALUE)
x$STAT_VALUE[x$STAT_VALUE<quantile(x$STAT_VALUE,0.0001,na.rm=T)]=NA
x$STAT_VALUE[x$STAT_VALUE>quantile(x$STAT_VALUE,0.99,na.rm=T)]=NA

y=NULL
v_data_file=paste('C:\\Temp\\data2.dat',sep="")
y=read.table(v_data_file, header = TRUE, sep = "\t", dec=",", quote = "\"'", stringsAsFactors=FALSE, )
str(y)
head(y)


z=NULL
z=merge(x=x,y=y,by.x="DATETIME",by.y="DATETIME",all.y=T)
z$ID=tounixtime(z$DATETIME)
z=z[order(z$ID),]
head(z)

z$line_approx=approx(x=z$ID, y=z$STAT_VALUE, xout=z$ID, method = "linear")$y
z$smoothed=ksmooth(x=z$ID, y=z$line_approx, kernel="normal", bandwidth =  20)$y

v_data_file=paste('C:\\Temp\\joined_data2.dat',sep="")
options(scipen=10)
write.table(z,file=v_data_file,quote=T,sep="\t",dec=",",col.names=TRUE, row.names=F, na="")
options(scipen=0)  # restore the default
head(z)

-- For R at radius3.spb -----------------------------------------------------------------------------------------------------
v_data_file=paste('/db/u01/dba_4797/from20170610_2113_to20170612_1440.dat',sep="")
#v_data_file=paste('/db/u01/dba_4797/datfile.dat',sep="")
x=read.table(v_data_file, header = T, sep = " ", stringsAsFactors=FALSE)
#str(x)
head(x)
summary(x$TIME)

z=unique( substr(x$DATETIME,1,16) )
y=data.frame(DATETIME=as.character(),TIME=as.numeric(), stringsAsFactors=FALSE)
v_count=1
for (i in z)
{
 #print(i)
 #i="2017-06-12_14:37"
 h=subset(x, substr(DATETIME,1,16)==i & OPCODE=="auth+reply" )
 y[v_count,1]=i
 #y[v_count,2]=(quantile(h$TIME,0.25)+quantile(h$TIME,0.75))/2
 h=summary(h$TIME)
 y[v_count,2]=(h[2]+h[5])/2
 print( paste( y[v_count,1],' ',y[v_count,2],sep="") )
 v_count=v_count+1
}

v_data_file=paste('/db/u01/dba_4797/from20170610_2113_to20170612_1440_out.dat',sep="")
options(scipen=10)
write.table(y,file=v_data_file,quote=T,sep="\t",dec=",",col.names=TRUE, row.names=F, na="")
options(scipen=0)

-- SQL-way dataa manipulation  ----------------------------------------------------------------------------------------------
truncate table net_devices_stat;
drop table net_devices_stat;
CREATE TABLE net_devices_stat (
 city  VARCHAR2(8),
 dev_name VARCHAR2(8) NOT NULL,
 datetime DATE NOT null,
 id NUMBER NOT NULL,
 stat_name  varchar2(16) not null,
 stat_value NUMBER NOT null
)
TABLESPACE excellent;

drop INDEX net_devices_stat_idx;
CREATE UNIQUE INDEX net_devices_stat_idx ON net_devices_stat(dev_name,stat_name,datetime) TABLESPACE excellent;

SELECT *
FROM net_devices_stat t
ORDER BY t.dev_name, t.datetime;

define v_dt_from="2017-06-07_18:31"
define v_dt_to="2017-06-08_15:37"

SELECT *
FROM net_devices_stat t
WHERE t.id=1496419874
  AND t.dev_name='bsr01'
;

SELECT DISTINCT t.stat_name
FROM net_devices_stat t
WHERE t.dev_name='bsr02'
  --AND t.stat_name='pppoe'
  --AND t.datetime=to_date('05.06.2017 22:04:39','dd.mm.yyyy hh24:mi:ss')
  AND t.city='perm'
--ORDER BY t.datetime, t.stat_name
;

select to_char(datetime,'yyyy-mm-dd_hh24:mi') as datetime,
       stat_value
from (
SELECT t.datetime AS datetime,
       Sum(t.stat_value) AS stat_value
FROM net_devices_stat t
WHERE t.dev_name='bsr02'
  --and t.datetime>to_date('2017-06-09_20:39','yyyy-mm-dd_hh24:mi')
  AND t.city='spb'
HAVING Count(*) = 4
GROUP BY t.datetime
ORDER BY t.datetime
 )
;



SELECT --to_char(datetime,'yyyy-mm-dd_hh24:mi') AS datetime,  t.stat_value AS stat_value, t.stat_name
       to_char(datetime,'yyyy-mm-dd_hh24:mi') AS datetime,  t.stat_value AS stat_value
       --*
       --DISTINCT t.stat_name
FROM net_devices_stat t
WHERE t.dev_name = 'bng04'
  AND t.city='spb'
  --AND t.stat_name='pppoe'
ORDER BY t.datetime
;

DELETE FROM net_devices_stat t
WHERE t.dev_name LIKE 'bng%'
AND t.city='spb'
--AND t.stat_name='pppoe'
;

COMMIT;


SELECT LEVEL-1 AS id,
       To_Date('&&v_dt_from','yyyy-mm-dd_hh24:mi')+(LEVEL-1)/1440 AS datetime
FROM DUAL
CONNECT BY LEVEL <= (SELECT 1+( abs(To_Date('&&v_dt_from','yyyy-mm-dd_hh24:mi') - To_Date('&&v_dt_to','yyyy-mm-dd_hh24:mi'))*24*60 ) FROM dual);


CREATE TABLE inet_auth_time (datetime DATE, elatime number) TABLESPACE excellent;
ALTER SESSION SET nls_date_format='yyyy-mm-dd_hh24:mi';
SELECT v1.datetime AS datetime,
       v2.elatime AS elatime
FROM (
SELECT LEVEL-1 AS id, To_Date('&&v_dt_from','yyyy-mm-dd_hh24:mi')+(LEVEL-1)/1440 AS datetime
FROM DUAL
CONNECT BY LEVEL <= (SELECT 1+( abs(To_Date('&&v_dt_from','yyyy-mm-dd_hh24:mi') - To_Date('&&v_dt_to','yyyy-mm-dd_hh24:mi'))*24*60 ) FROM dual)
 ) v1,
(
 SELECT t.datetime AS datetime, t.elatime AS elatime FROM inet_auth_time t
) v2
WHERE v1.datetime=v2.datetime(+)
ORDER BY v1.datetime
;

--------------------------------------------------------------------------------
define v_dt_from="2017-06-13_16:53"
define v_dt_to="2017-06-27_16:48"

select abs(To_Date('&&v_dt_from','yyyy-mm-dd_hh24:mi') - To_Date('&&v_dt_to','yyyy-mm-dd_hh24:mi'))*24*60 AS delta from dual;

SELECT to_char( To_Date('&&v_dt_from','yyyy-mm-dd_hh24:mi')+(LEVEL-1)/1440, 'yyyy-mm-dd_hh24:mi') AS datetime
FROM DUAL
CONNECT BY LEVEL <= (SELECT 1+( abs(To_Date('&&v_dt_from','yyyy-mm-dd_hh24:mi') - To_Date('&&v_dt_to','yyyy-mm-dd_hh24:mi'))*24*60 ) FROM dual)
;

declare
 v_date_from  date := to_date('2017-06-07_18:31','yyyy-mm-dd_hh24:mi');
 v_date_to    date := to_date('2017-06-14_15:19','yyyy-mm-dd_hh24:mi');
begin
 while v_date_from < v_date_to
 loop
  dbms_output.put_line( to_char(v_date_from,'yyyy-mm-dd_hh24:mi') );
  v_date_from := v_date_from+1/(24*60);
 end loop;
end;
/

-- Load data routine -----------------------------------------------------------
DECLARE
v_dev_name  VARCHAR2(8);
v_stat_name VARCHAR2(16);
v_city_name VARCHAR2(128);

 PROCEDURE pap(p_line IN VARCHAR2 DEFAULT null)
 IS
  v_datetime   VARCHAR2(32);
  v_id   VARCHAR2(16);
  v_stat   VARCHAR2(16);
 BEGIN
   IF p_line IS NULL
   THEN
    RETURN;
   END IF;

   IF regexp_like(p_line,'b[^\.]+\.[^\.]+\.ertelecom\.ru')
   THEN
     v_city_name := regexp_substr(p_line,'b[^\.]+\.[^\.]+\.ertelecom\.ru');
     v_city_name := regexp_replace(v_city_name,'^[^\.]+\.([^\.]+)\..*','\1');
     Dbms_Output.put_line('city name is: '||v_city_name);
   END IF;

   IF v_city_name IS NULL
   THEN
    RETURN;
   END IF;

   IF regexp_like(p_line,'b[^\.]+\.[^\.]+\.ertelecom\.ru')
   THEN
     v_dev_name := regexp_substr(p_line,'^[^\.]+');
     Dbms_Output.put_line('Dev name is: '||v_dev_name);
   END IF;

   IF v_dev_name IS NULL
   THEN
    RETURN;
   END IF;

   IF regexp_like(p_line,'b[^\.]+\.[^\.]+\.ertelecom\.ru')
   THEN
     v_stat_name := regexp_substr(p_line,'\S+$');
     Dbms_Output.put_line('Dev name is: '||v_stat_name);
   END IF;

   IF v_stat_name IS NULL
   THEN
    RETURN;
   END IF;

   IF regexp_like(p_line,'^\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}:\d{2}')
   THEN
      v_datetime := regexp_substr(p_line,'\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}:\d{2}');
      v_id := regexp_substr(p_line,'\d{10}');
      v_stat := regexp_substr(p_line,'\d{1,}$');
      BEGIN
       EXECUTE IMMEDIATE 'insert into net_devices_stat values( '''||v_dev_name||''' ,to_date('''||v_datetime||''',''dd.mm.yyyy hh24:mi:ss''), '||v_id||', '''||v_stat_name||''', '||v_stat||', '''||v_city_name||''')';
       --Dbms_Output.put_line('insert into net_devices_stat values( '''||v_dev_name||''' ,to_date('''||v_datetime||''',''dd.mm.yyyy hh24:mi:ss''), '||v_id||',  '||v_stat||', '''||v_city_name||''');');
       NULL;
      EXCEPTION
      WHEN others THEN
       --Dbms_Output.put_line('err: insert into net_devices_stat values( '''||v_dev_name||''' ,to_date('''||v_datetime||''',''dd.mm.yyyy hh24:mi:ss''), '||v_id||', '''||v_stat_name||''', '||v_stat||', '''||v_city_name||''');');
         NULL;
      END;
   END IF;
 END;
BEGIN

pap('');
pap('bsr03.nn.ertelecom.ru: pppoe');
pap('');
pap('21.06.2017 16:15:29 1498043729 59684');
pap('21.06.2017 16:10:29 1498043429 59397');

--ROLLBACK;
COMMIT;
END;
/
