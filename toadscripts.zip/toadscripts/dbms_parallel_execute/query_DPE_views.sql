define task_name="SPL_OATS_LOGINS_1270873"

SELECT t.task_owner,
       t.task_name,
       regexp_substr(t.task_name,'\d+$') AS task_id,
       t.status
FROM sys.DBA_PARALLEL_EXECUTE_TASKS t
WHERE t.table_owner='EXCELLENT'
ORDER BY task_id desc
;

SELECT *
FROM sys.DBA_PARALLEL_EXECUTE_TASKS t
where t.task_name='&&task_name'
--  AND t.status != 'FINISHED'
--AND t.status='PROCESSING'
;

define job_prefix="TASK$_196330"

SELECT *
FROM sys.DBA_SCHEDULER_JOB_LOG t
WHERE t.job_name LIKE '&&job_prefix%'
ORDER BY t.log_id
;

SELECT *
FROM sys.DBA_SCHEDULER_JOB_RUN_DETAILS t
WHERE t.job_name LIKE '&&job_prefix%'
ORDER BY t.log_id
;

SELECT *
FROM sys.DBA_SCHEDULER_JOBS t
WHERE t.job_name LIKE '&&job_prefix%'
--ORDER BY t.log_id
;


-- EXEC DBMS_PARALLEL_EXECUTE.DROP_TASK('&&task_name');

SELECT *
FROM sys.DBA_PARALLEL_EXECUTE_CHUNKS t
WHERE t.task_name='&&task_name'
ORDER by t.chunk_id desc;

SELECT Round(Min(task_elatime_seconds),2) AS min_elatime_sec,
       Round(percentile_disc(0.25) within GROUP (ORDER BY task_elatime_seconds asc),2) AS first_quartile,
       Round(avg(task_elatime_seconds),2) AS avg_elatime_sec,
       Round(percentile_disc(0.75) within GROUP (ORDER BY task_elatime_seconds asc),2) AS third_quartile,
       Round(Max(task_elatime_seconds),2) AS max_elatime_sec
FROM (
SELECT extract(SECOND FROM task_ela_time) + ( extract(minute FROM task_ela_time)*60 ) + ( extract(hour FROM task_ela_time)*3600 ) AS task_elatime_seconds
FROM (
SELECT t.end_ts-t.start_ts AS task_ela_time
FROM sys.DBA_PARALLEL_EXECUTE_CHUNKS t
WHERE t.task_name='&&task_name'
  AND t.status='PROCESSED' )
  )
;


SELECT Count(*), t.status
FROM sys.DBA_PARALLEL_EXECUTE_CHUNKS t
WHERE t.task_name='&&task_name'
GROUP BY t.status
ORDER BY 1 DESC;

SELECT Max(t.end_ts)-Min(t.start_ts) AS task_ela_time
FROM sys.DBA_PARALLEL_EXECUTE_CHUNKS t
WHERE t.task_name='&&task_name';


SELECT Sum ( extract(SECOND FROM DELTA) + ( extract(minute FROM DELTA)*60 ) + ( extract(hour FROM DELTA)*3600 ) ) AS total_seconds
FROM ( SELECT t.end_ts-t.start_ts AS DELTA
       FROM sys.DBA_PARALLEL_EXECUTE_CHUNKS t
       WHERE t.task_name='&&task_name');

-- Demo
CREATE OR REPLACE PROCEDURE excellent.demo_task
as
  v_task_name    VARCHAR2(30) := 'MYTASK';
  l_try          NUMBER;
  l_status       NUMBER;
begin
   begin
    DBMS_PARALLEL_EXECUTE.DROP_TASK(task_name => v_task_name);
   exception when others then null;
   end;
   DBMS_PARALLEL_EXECUTE.CREATE_TASK(task_name => v_task_name);
   DBMS_PARALLEL_EXECUTE.CREATE_CHUNKS_BY_SQL(task_name => v_task_name,
   sql_stmt =>'select Row_Number() OVER (ORDER BY null) AS start_id, 1+Row_Number() OVER (ORDER BY null) AS stop_id FROM all_objects WHERE ROWNUM <= 10', by_rowid => false);

  L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS(v_task_name);
  IF L_status IN (DBMS_PARALLEL_EXECUTE.CHUNKED)
  THEN
   DBMS_PARALLEL_EXECUTE.RUN_TASK(task_name => v_task_name, sql_stmt=>'begin excellent.worker(:start_id , :end_id); end;',language_flag => DBMS_SQL.NATIVE, parallel_level => 10);
   L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS(v_task_name);
  END IF;

  L_try := 0;
  WHILE(l_try < 2 and L_status != DBMS_PARALLEL_EXECUTE.FINISHED)
  Loop
    L_try := l_try + 1;
    DBMS_PARALLEL_EXECUTE.RESUME_TASK(v_task_name);
    Dbms_Lock.sleep(2);
    L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS(v_task_name);
  END LOOP;
end;
/

EXEC excellent.demo_task;

CREATE OR REPLACE PROCEDURE excellent.worker(p1 IN NUMBER, p2 IN number)
IS
 v_file_name      VARCHAR2(30) := Nvl(p1,0)||'_'||Nvl(p2,0)||'.txt';
 v_fh             Utl_File.file_type;
 v_dirname        VARCHAR2(30) := 'AWR_DUMP_DIR';
BEGIN
 v_fh:=Utl_File.fopen(v_dirname, v_file_name, 'w');
 --utl_file.put_line(v_fh,To_Char(SYSDATE,'yyyy.mm.dd:hh24:mi:ss'));
 Dbms_Lock.sleep(5);
 --utl_file.put_line(v_fh,To_Char(SYSDATE,'yyyy.mm.dd:hh24:mi:ss'));
 INSERT INTO test_tab VALUES(10);
 COMMIT;
END;
/
SELECT * FROM excellent.test_tab;

revoke ALL on DIRECTORY AWR_DUMP_DIR from excellent;
EXEC excellent.worker(1,1);

drop TABLE excellent_test_tab;
CREATE TABLE excellent.test_tab(col number);
