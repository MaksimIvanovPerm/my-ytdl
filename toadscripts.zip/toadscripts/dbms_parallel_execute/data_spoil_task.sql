DECLARE

PROCEDURE PEXEC(p_table_owner IN VARCHAR2, p_table_name IN VARCHAR2, p_sql_text IN VARCHAR2, p_dop IN NUMBER DEFAULT 10, p_cycles IN NUMBER DEFAULT 300)
is
 v_table_owner  VARCHAR2(30) := Upper(p_table_owner);
 v_table_name   VARCHAR2(30) := Upper(p_table_name);
 v_x            NUMBER;
 v_chunk_number NUMBER := 10;
 v_chunk_size   NUMBER;
 v_task_name 	  VARCHAR2(128) := DBMS_PARALLEL_EXECUTE.GENERATE_TASK_NAME(prefix=>'SPL_'||v_table_name||'_');
 l_sql_stmt     VARCHAR2(32767) := p_sql_text;
 v_dop          NUMBER := p_dop;
 v_mode         VARCHAR2(6) := 'SYNCH'; -- SYNCH: try to wait when the task will be completed; ASYNCH - just launch the task and go on;
 v_task_status  VARCHAR2(25);
 v_sleep_tm     NUMBER := 2;
 v_cycle_count  NUMBER := p_cycles;

 num_or_rows_unknown EXCEPTION;
 table_doesnot_exist EXCEPTION;
 empty_sql_text      EXCEPTION;
 too_long_processing EXCEPTION;

BEGIN
 --DBMS_STATS.GATHER_TABLE_STATS(v_table_owner,v_table_name,'',estimate_percent=>10,block_sample=>TRUE,method_opt=>'for all indexed columns size SKEWONLY',CASCADE=>TRUE,FORCE=>TRUE);
 IF Length(l_sql_stmt) <= 5
 THEN
    RAISE empty_sql_text;
 END IF;

 SELECT Count(*)
 INTO v_x
 FROM sys.dba_tables t WHERE t.owner=v_table_owner AND t.table_name=v_table_name;

 IF v_x = 0
 THEN
  RAISE table_doesnot_exist;
 END IF;

 SELECT t.num_rows
 INTO v_x
 FROM sys.dba_tables t
 WHERE t.owner=v_table_owner AND t.table_name=v_table_name;

 IF v_x IS NULL
 THEN
    --Dbms_Output.put_line('ERROR: Can not get out information about count of records in '||v_table_owner||'.'||v_table_name);
    Dbms_Output.put_line('It looks like table '||v_table_owner||'.'||v_table_name||' has not been analysed yet; Try to analyze it;');
    DBMS_STATS.GATHER_TABLE_STATS(v_table_owner,v_table_name,'',estimate_percent=>DBMS_STATS.AUTO_SAMPLE_SIZE,block_sample=>TRUE,method_opt=>'for all indexed columns size SKEWONLY',CASCADE=>FALSE,FORCE=>TRUE);
    -- Do conventional spoil-action for the given table
    --RAISE num_or_rows_unknown;
 END IF;

 SELECT t.num_rows
 INTO v_x
 FROM sys.dba_tables t
 WHERE t.owner=v_table_owner AND t.table_name=v_table_name;

 IF v_x IS NULL
 THEN
    RAISE num_or_rows_unknown;
 END IF;

 v_chunk_size := Round(v_x/v_chunk_number+1,0);
 Dbms_Output.put_line('OK: number of records in '||v_table_owner||'.'||v_table_name||' was found as: '||v_x);
 Dbms_Output.put_line('Size of chunk is: '||v_chunk_size||' rows');
 Dbms_Output.put_line('Task name is :'||v_task_name);
 DBMS_PARALLEL_EXECUTE.CREATE_TASK(task_name=>v_task_name);
 DBMS_PARALLEL_EXECUTE.CREATE_CHUNKS_BY_ROWID(task_name=>v_task_name, table_owner=>v_table_owner, table_name=>v_table_name, by_row=>TRUE, chunk_size=>v_chunk_size);
 DBMS_PARALLEL_EXECUTE.run_task(task_name=>v_task_name, sql_stmt=>l_sql_stmt,language_flag=>DBMS_SQL.NATIVE,parallel_level=>v_dop);
 IF v_mode = 'SYNCH'
 THEN
   --v_x := 1;
   WHILE --v_x < v_cycle_count and
        DBMS_PARALLEL_EXECUTE.task_status(v_task_name) NOT IN ( DBMS_PARALLEL_EXECUTE.FINISHED, DBMS_PARALLEL_EXECUTE.FINISHED_WITH_ERROR, DBMS_PARALLEL_EXECUTE.CRASHED)
   LOOP
       Dbms_Lock.sleep(v_sleep_tm);
       --v_x := v_x + 1;
   END LOOP;

/*   IF v_x >= v_cycle_count
   THEN
    raise too_long_processing;
   END IF; */

   v_task_status := DBMS_PARALLEL_EXECUTE.task_status(v_task_name);
   IF v_task_status = DBMS_PARALLEL_EXECUTE.FINISHED
   THEN
      v_task_status := 'FINISHED';
   ELSIF v_task_status = DBMS_PARALLEL_EXECUTE.FINISHED_WITH_ERROR
   THEN
      v_task_status := 'FINISHED_WITH_ERROR';
   ELSIF v_task_status = DBMS_PARALLEL_EXECUTE.CRASHED
   THEN
      v_task_status := 'CRASHED';
   END IF;
   Dbms_Output.put_line(v_task_name||' has just been completed with staus: '||v_task_status);
 END IF;

EXCEPTION
 WHEN num_or_rows_unknown THEN Dbms_Output.put_line('Can not determ size of chunk for table '||p_table_owner||'.'||p_table_name||'; Please gather table stat for the table;');
 WHEN table_doesnot_exist THEN Dbms_Output.put_line('table '||p_table_owner||'.'||p_table_name||' does not exist');
 WHEN empty_sql_text THEN Dbms_Output.put_line('Routine was provided with mailformed or empty sql-text in p_sql_text parameter;');
 WHEN too_long_processing THEN Dbms_Output.put_line('Exited by insuranse from cycling;');
END; -- EOF PEXEC routine

BEGIN -- Block

 --PEXEC(p_table_owner IN VARCHAR2, p_table_name IN VARCHAR2, p_sql_text IN varchar2)
 PEXEC('excellent','logins','UPDATE excellent.logins set login_password=login_name WHERE rowid BETWEEN :start_id AND :end_id');
 PEXEC('excellent','CLIENTS','update excellent.clients
set passport=null,
contact_phone=null,
contact_email=null,
client_name=case
when SUBSTR(client_name, 1, INSTR(client_name, '' '',1)) is null then client_name
else SUBSTR(client_name, 1, INSTR(client_name, '' '',1))||rawtohex( utl_raw.cast_to_raw(excellent.md5(SUBSTR(client_name, INSTR(client_name, '' '',1),length(client_name)))))
end
WHERE rowid BETWEEN :start_id AND :end_id');

  PEXEC('excellent','clients_passport_info','update excellent.clients_passport_info set passport_number=null,who_issue=null,date_issue=null,birthplace=null,birthdate=null,r_area=null,r_street=null,r_house=null,r_building=null,r_office=null WHERE rowid BETWEEN :start_id AND :end_id');
  PEXEC('excellent','Client_Phones','update excellent.Client_Phones set phone_number=''8''||substr(client_phone_id||''0000000000'',1,10) WHERE rowid BETWEEN :start_id AND :end_id');
  PEXEC('excellent','contact_emails','update excellent.contact_emails set email=contact_email_id WHERE rowid BETWEEN :start_id AND :end_id');
  PEXEC('excellent','sms_queue','update excellent.sms_queue set phone_number=''7''||substr(sms_queue_id||''0000000000'',1,10),message=sms_queue_id WHERE rowid BETWEEN :start_id AND :end_id',15);
  PEXEC('excellent','pins','update excellent.pins set pin=terminal_resource_id WHERE rowid BETWEEN :start_id AND :end_id');

EXECUTE IMMEDIATE 'alter trigger excellent.tr_phone_ext_change disable';
PEXEC('excellent','phone_ext','update excellent.phone_ext set pin=substr(terminal_resource_id||''0000000'',1,8), pin_pc=substr(terminal_resource_id||''0000000'',1,8) WHERE rowid BETWEEN :start_id AND :end_id');
EXECUTE IMMEDIATE 'alter trigger excellent.tr_phone_ext_change ENABLE';

 PEXEC('excellent','agreement_pwd','update excellent.agreement_pwd p set
password=(select agreement_number from excellent.agreements a where a.agreement_id=p.agreement_id)
WHERE rowid BETWEEN :start_id AND :end_id');

END; -- EOF block
/

