select *
from REDMINE.REDMINE2JIRA t;
-- delete from REDMINE.REDMINE2JIRA t where t.id=9; commit;
-- delete from REDMINE.REDMINE2JIRA t where t.redmine_id=314017; commit;

select  I.SUBJECT as SUBJECT,
        I.DESCRIPTION as DESCRIPTION,
        I.PARENT_ID as PARENT_ID,
        I.DONE_RATIO as DONE_RATIO 
from redmine.issues i
where i.ID=314017;

select *
from REDMINE.CUSTOM_FIELDS t
where T.NAME='';

-- Server with which task is assigned
select CSV.VALUE as server
from REDMINE.CUSTOM_VALUES csv
where CSV.CUSTOM_FIELD_ID=10 and CSV.CUSTOMIZED_TYPE='Issue' and CSV.CUSTOMIZED_ID=314017;


-- Watchers
select US.FIRSTNAME as FIRSTNAME,
        US.LASTNAME as LASTNAME,
        US.MAIL as email,
        US.ID as ruser_id
from REDMINE.users us
where US.ID in (
select W.USER_ID
from REDMINE.WATCHERS w
where W.WATCHABLE_TYPE='Issue' and W.WATCHABLE_ID=314017);

-- Task status
select *
from REDMINE.ISSUE_STATUSES st
where ST.ID=( select I.STATUS_ID from redmine.issues i where i.ID=314017 );

-- Author
select  US.FIRSTNAME as FIRSTNAME,
        US.LASTNAME as LASTNAME,
        US.MAIL as email
from REDMINE.USERS us
where US.ID=( select I.AUTHOR_ID from redmine.issues i where i.ID=314017 )
  and US.TYPE='User';

-- Assigne to:
select  US.FIRSTNAME as FIRSTNAME,
        US.LASTNAME as LASTNAME,
        US.MAIL as email
from REDMINE.USERS us
where US.ID=( select I.ASSIGNED_TO_ID from redmine.issues i where i.ID=314017 );

-- Category
select C.NAME as tracker_name
from REDMINE.ISSUE_CATEGORIES c
where c.id=( select I.CATEGORY_ID from redmine.issues i where i.ID=314017 );

-- Tracker name
select T.NAME as tracker_name
from REDMINE.TRACKERS t
where t.id=( select I.TRACKER_ID from redmine.issues i where i.ID=314017 );

-- Projects_name
select P.NAME as project_name
from REDMINE.PROJECTS p
where p.id=( select I.PROJECT_ID from redmine.issues i where i.ID=314017 );

-- Task Comments
select J.NOTES as notes
from REDMINE.JOURNALS j
where J.JOURNALIZED_ID=314017 and J.JOURNALIZED_TYPE='Issue'
order by j.id;

select RA.ID||'/'||RA.FILENAME as attachment
from REDMINE.ATTACHMENTS ra
where RA.CONTAINER_TYPE='Issue' and RA.CONTAINER_ID=314017
order by ra.id;

/*select *
from REDMINE.JOURNAL_DETAILS jd
where JD.JOURNAL_ID=979547
order by JD.ID*/

