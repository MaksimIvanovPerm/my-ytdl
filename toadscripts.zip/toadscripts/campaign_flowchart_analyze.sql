z=data.frame(hash=as.character(),mb=as.numeric(),ma=as.numeric(),q1b=as.numeric(),q3b=as.numeric(),q1a=as.numeric(),q3a=as.numeric(),stringsAsFactors=FALSE)
for(i in 1:length(unique(x$flowchart_name)))
{
 print(i)
 z[i,1]=unique(x$flowchart_name)[i]
 y=subset(x, flowchart_name==z[i,1])
 z[i,2]=mean(y$before_elatime)
 z[i,3]=mean(y$after_elatime)
 z[i,4]=quantile(y$before_elatime,0.25)
 z[i,5]=quantile(y$before_elatime,0.75)
 z[i,6]=quantile(y$after_elatime,0.25)
 z[i,7]=quantile(y$after_elatime,0.75)
}

v_data_file=paste('/tmp/joined_data2.dat',sep="")
options(scipen=10)
write.table(z,file=v_data_file,quote=T,sep="\t",dec=",",col.names=TRUE, row.names=F, na="")
options(scipen=0)


select smfd.*, optimal_running_time
from CAMPAIGN.sys_monit_flowchart_delta_time smfd, CAMPAIGN.sys_monit_flowchart smf
where smfd.flowchart_name = smf.flowchart_name
--and optimal_running_time < worktime
and worktime > 0
and runstarttime >=SYSDATE-31
order by 1, 2;

define v_border_date="2019.11.21"
define v_date_format="YYYY.MM.DD"
define days_ago="30"
--CREATE TABLE SYSTEM.temp_20191128 as
SELECT flowchart_name, Sum(before_run) AS before_runs,Sum(after_run) AS after_runs
FROM (SELECT t.flowchart_name AS flowchart_name,
       CASE when t.runstarttime < To_Date('&&v_border_date','&&v_date_format') THEN 1
       ELSE 0
       END AS before_run,
       CASE when t.runstarttime > To_Date('&&v_border_date','&&v_date_format') THEN 1
       ELSE 0
       END AS after_run
from CAMPAIGN.sys_monit_flowchart_delta_time t
WHERE t.runstarttime >=SYSDATE-&&days_ago )
 GROUP BY flowchart_name
 HAVING Sum(before_run) >=14 AND Sum(after_run) >= 14
;


SELECT flowchart_name,
       Round(avg(before_elatime),2) AS before_time_stat,
       Round(avg(after_elatime),2)  AS after_time_stat
FROM (
SELECT t.flowchart_name AS flowchart_name,
       --ora_hash(t.flowchart_name) AS hash_flowchart_name,
       CASE when t.runstarttime < To_Date('&&v_border_date','&&v_date_format') THEN 60*extract(hour FROM t.runendtime-t.runstarttime) + extract(MINUTE FROM t.runendtime-t.runstarttime)
       ELSE 0
       END AS before_elatime,
       CASE when t.runstarttime > To_Date('&&v_border_date','&&v_date_format') THEN 60*extract(hour FROM t.runendtime-t.runstarttime) + extract(MINUTE FROM t.runendtime-t.runstarttime)
       ELSE 0
       END AS after_elatime
from CAMPAIGN.sys_monit_flowchart_delta_time t
WHERE t.flowchart_name IN (SELECT t1.flowchart_name FROM SYSTEM.temp_20191128 t1)
  AND t.runstarttime >=SYSDATE-&&days_ago
  --ORDER BY hash_flowchart_name
   )
  GROUP BY flowchart_name
;

SELECT t1.flowchart_name, ora_hash(t1.flowchart_name) FROM SYSTEM.temp_20191128 t1
;

SELECT t.flowchart_name AS flowchart_name,
       t.runstarttime AS runstarttime,
       CASE when t.runstarttime < To_Date('&&v_border_date','&&v_date_format') THEN 60*extract(hour FROM t.runendtime-t.runstarttime) + extract(MINUTE FROM t.runendtime-t.runstarttime)
       ELSE 0
       END AS before_elatime,
       CASE when t.runstarttime > To_Date('&&v_border_date','&&v_date_format') THEN 60*extract(hour FROM t.runendtime-t.runstarttime) + extract(MINUTE FROM t.runendtime-t.runstarttime)
       ELSE 0
       END AS after_elatime
from CAMPAIGN.sys_monit_flowchart_delta_time t
WHERE 1=1 --t.flowchart_name IN (SELECT t1.flowchart_name FROM SYSTEM.temp_20191128 t1)
  AND t.runstarttime >=SYSDATE-&&days_ago
  --AND t.flowchart_name LIKE 'PROD\_PERIOD\_IVR\_%' ESCAPE '\'
  AND t.flowchart_name='PROD_PERIOD_IVR_��� - call_ppd'
ORDER BY 1 asc,2 asc
;

CREATE TABLE SYSTEM.flowcharts_sql_stat as
SELECT *
FROM sys.wrh$_sqlstat t
WHERE t.dbid=&&v_dbid
  AND t.sql_id IN ('656fqdyct39r3','2yq28p4s3k4b4','bw72j8y74551r','drqy7ap5brzcs','c35m9jfaztnb2','43mtq0thymkf3','6vwcyy7j5nujs','fhwrbknmt893x','8k8xht7w0ja43','27qrgxfaz5cdz','b1b7464mb7jdr','fgcvncf0ab9dh','7uzfwj6uc2j97','3a3s0wdqnujv0','fhcvq1zghrjq0','9dh9fsyxknbvm','2scr10p51nz9n','5852kn7wdaa2j','6hy7za2pbp0wk','c86cfyn3ydruv','113745qskh2ua','gp8yvuqyu1gbn','a2rfzw09fdy05','7qd16a5dxt4cr','64p0g4mq5rcbs','acfw93w0n160u','0hk4fg4fm1d3c','4vk38fgqhyrnd','7mkmy5havp8t9','b5tt13nkf60px','4pqvhdnfs7yws','6vd8y03u444mq','dazqfjt3p0nzg','00zqy3yd0r3p3','c1ycuvs4bg6qa','7kk80abxyk2vq','3pgu5vtddncq6','c19f54t1a2buy','4wshzn3wp3qcm','9z35wpda1p9q3','612924apk98bn','72vzxh5x7pgus','aahsjvcnr3swn','67qgp8kuu764d','csdtqq6wxu6q0','2jrs0mazckk0f','byw7aw38sa1ux','1hb7cbjtd6wv5','fwrr2zhs6aj22','0k7rnrgq2z8kz','1tuz57ppa0vaa','9gvcprvsdc3s1','bjp9byv9sx5ay','8s17djwfwhy5w','1ubvrs3kxmbvm','gv9zxn1f3qu2u','0a44h7h72p7d7','bw5us2rbcx8bp','c93f4gnb8fx90','8tjcaajuukrgu','7u2zy9hg93wya','cjxq7srjwvvqd','3v8ggn0jttz37','bpxypua3w2n18','2vrs15f8dwym8','6hvzqw3vvnm8v','a30jk9uq8dgua','a8dnkzmb5yckf','46ag192c8wq35','37ausfzgad64x','2au9wxjddmz2p','5h78yxatq67u2','6kuqum8drtmr0','famucpfssuh19','3cp73faszdmj6','4vfdj1453tgzh','339xbasub1p2z','f8bkmrr8udwvx','7m1dzjrzmzy3g','6xrjjh953y3sp','70rv5016juwyq','gxtg877ta1dfg','4ngb0bzdw25w7','2nkcg30db6xt8','gscsgrrcwt98w','3kyxsrwpnpnbf','5y513mxkn2xfb','4g1pm9p676dqp','94axxg96346d3','0jd2zrgjvxr7j','3zt6bcgcg1bdq','3sdqvb48xt2sm','9ba5b3yv84bbg','2apv86388dkpr','3jt4bnvu7m688','0fry86zcvacnx','1hyqarasjdv0k','25p5tmv83wqxd','4us38yukts2ca','a26r7vdpbx1a5','0t297btux2r7b','ar7ykp3xc9dgg','b7xa5p0jjwmgn','3scc8dp68bkcm','4h2w2mrw59dx3','83aym2n09b60w','bqdgkk0ndbdqg','brawsrdwdwbuu','96fv8fcbku5uw','dxtfqm1wgy42c','9tanpg34rfcu0','4p63635ucszmh','4wd92rwwr1x9x','9214n1dxw8b0r','0538ar46v2xgs','0dz68u6cg42vh','bvha5bf5unn53','c0pcqfy2wzw5y','c4w7h2xacp7m5','10b7dw24g1zh8','80978vv3mtnfq','81yw1ug00wtp7','8pa4urth1p4b7','60a5q66w9yz06','bnruq7qdg7u0k','94mynuy7cbuub','1z9fjqyt515xh','98r4f80n7z92r','arndbzpp5f151','7647pdjvbcjpt','fqhc3z2pvjqsg','1bmnkzwjp0943','66dkn3rzhudd4','0rj55k77wu1mj','bzy3d7sdb4zqa','8jghdtm1dprgt','a4553xnd2xvb7','cd97hzry8rd6u','07rm5p65sc48u','cg7rxmzv321nr','5v2d4qvask2h7','3930mytvg0048','ba1w7z6gbssf2','2qtshb3xqc475','gvpj2s1yz3z7n','gggg54n5s2pmx','g6xzy6uhjj3nn','992umf9xz7ym6','fnjgwjwc1msa8','cc5tm35dghqc8','4ksuy1kkj0jcu','2g5c2hb73jsy8','3xydvatjfuzgg','19j1k794vfgza','3qr557j101nuz','0tq7w0p5mymp4','792w80j3x5ssy','74fbndmk12891','5u2brk3890zg4','8q5u2d8g4ud1n','4k32u9420xhur','3f59pyxrwbwf1','d5c9m1hzjkbbk','2mbub2r3c7z6h','a46zc7w4gujum','6nawbwpw00aj4','62yccf3u2t9u4','bn21yv6m94167','fr2fhq1944928','dj9b44spcry31','8z5rk7mupzh8w','bf04d10kbqxsu','6tbgnr7fv5svx','fj2dzqxubptzx','180425y961w4v','1g1q0bfvpspta','5wwpk8rzappu0','9btydsr1h680s','33aa85dy4cfwg','d9pf0au1jc0cv','duqkuzrq5qx13','cbra902jfmpjf','8rhw8vb11jtv1','193mk8dngaj16','cx50zayp2r46w','fh0w7q0p5468s','6q6zjnswzc8tv','5syrxc5cfs9dw','fjycfajgg8by3','fznj7t786y9r0','1jf637rpx05jf','45nj8r4qsp3uc','44yksnata3j5v','9cvcx774j3tbx','6nb6mub6mmqmt')
;

ALTER TABLE SYSTEM.flowcharts_sql_stat ADD (flowchart_name VARCHAR2(128));
UPDATE SYSTEM.flowcharts_sql_stat SET flowchart_name='PROD_PERIOD_IVR_��� - call_ppd';
COMMIT;

CREATE table SYSTEM.flowcharts2_sql_stat as
SELECT 'PROD_PERIOD_IVR_������� - call_rozn_new' AS chart_name, t.*
FROM sys.wrh$_sqlstat t
WHERE t.dbid=&&v_dbid
  AND t.sql_id IN ('1jcrhpry20v0r','6g8c835vhqn0u','1b43udwxq434p','3cd2hy7yx0u2k','3ruvpwky92pd8','6t3fmwk9xdf4u','2pt38jn1h53wt','1faxzybvz1jas','cbtk668za0wh9','0rutg8smdvwn6','1huqcwcjzgzka','cyaz174ky8ph4','4buf6yv1870ms','gaf163u6nujrj','avmb3tyubwpw9','fgcvncf0ab9dh','du6963xqhqrdn','2zt8jvq1pn4up','1kyvsd2g3w0qh','8u0apr41jasq2','13vnauhpzwbav','f1gnf5ryv3gpr','g420bdgug37dt','fw156gw3rghtr','bq3bw23d4dm2v','32k27dnkrhyak','auzb3w4j7gtkh','74rct4xjmb8h4','byn2n9dyh8bnk','akks467wjj6hz','ah9cqgzsq50z4','gq0jbrtpz2h3x','g6t0d2qq2m516','86mc905vsw75n','1f41gryu6ky8z','bjbaqyjk5gb98','36rb604mcgsmv','bfyjhjz4ghd3f','9w9wundpxg4cv','bv3kphbj46532','6yqvwz7x1qytj','1576jc0hg2rpd','8rc519umrtkxu','afzqbp81kwxh2','71m98hcx881rm','774rnbujz0x3n','7a6ank33au3fc','a0wbc26k0dqdr','7hpzrf34uxns9','13jrz1wvutdsz','5utc32d3n9sba','grk04zxprbxs5','ay78raj034nu4','bb8dp6wyabhd9','7yh47kspz0g6j','8fvbt5tgny0jw','48hhz2z1tm10k','2m74w82nfbmzp','73rur1gg83v52','dbtj5tbp8w7cg','5gc05v0x4a7zj','adtrkdhp15j03','4mzdy4kbr0dqw','b3vfjs6nbnrxv','58y4rxzr03xqw','1xw1uxqw9bht8','f30m30xcdp7yg','9d2sv3hufayz2','duunn58a7q2yt','8anqfs7q214ah','8c8fgjv5ggm08','3ffcu3m5vjh0v','fahkagnnkth0y','4gzgmjvgzmj3t','00zqy3yd0r3p3','88y31m9ck5asv','141y67hfdk04r','81cmy5acbpp0r','9sq4sh4ft10w6','ax3kpgms9z9yt','bmjf3u748xc33','1rzj30j03rp0m','322nc85q0zn8w','4q48j4vq6pt6f','54uwm1a7n26zj','8rzh4druzwq7k','0gsu967hwkzzh','2hanh13drw9ww','8m0gd43yvwcch','4fvsq6dv4qh0p','1gj3s3fhb1tdm','cn88tukrfaf42','208ucw0jw1cyp','bjghcybuqjqnc','335n76hq05s78','2afx9m5t2nz29','1d1q4hkh0cgf1','8w0c9am0kv2qa','9cw27t4p9q93r','3cu870uvfjd84','706d3z8j8s18m','7b1u7931vqsyg','8a7s0dhyyvcxu','12bk8az01ht8p','9kga8gtkt6wzb','8zdhmqfwjar7c','5b18pqvx262q9','dvv6vf1rjt59u','81qk0t78z1cvc','fjdkacajmp7x0','42sw2hqgy4k8d','dwu52bx8usk45','9xk97d9q41py9','4psj926fvqdfk','9fhgxrv07850j','41f1prtqwb7zd','b0up49mpqw9js','bjp9byv9sx5ay','7j89tk67gtquw','7t3dvhnvv116m','3nf86gxza1g2x','75psnc3cn7u1b','7uh17tc3skpw1','14k01f9m0n65p','fm6yfhj4q8kbn','0766y8hug99bu','2br9tbrdsq2vz','b6uzqkgaxksq9','dcz6v7x6ucr53','66qnch6yzwf5m','00v99hjgb5x23','01d6b445sftvb','db5y84vp3kbnf','g5n20cac71jf9','c23x3bh6h1txv','32d2zrrbhkf37','5fjuhh0rkqw7r','8a5d0w4m9kw9x','anrj5rwr0j8sm','18jsp1wy0s75m','ctum8vb62mhz2','0wxjnz89j2787','00ajuu5902429','c3mpz0tn9z7z0','4bxcpr1vt911k','4d2t5y0a2w83h','fad97b74nn7jp','dbdsuxsascc3n','72wv7pfwa2bxw','cz21bunnucs7n','60sxdh4r3ungk','340fp6qasqpmm','8gqz9rksmb4v1','dmq3sukxnvu7h','63a6utpfqts0k','0w7z85dn9safx','bjgbzzv35p13j','9gxcrduxca3z8','79p1d0fqr95kb','0wpfxxw3stxrw','38ntns3cht8k1','2wagqhxxbw0hx','3h9qsnj87nr3d','btxmzzpk8xpxb','9zbwpa0h579v7','a98rqtkx0k5af','39np0ddv1xxjs','dr1wbn40y1yq5','8ns2s90baza5n','d4cmr5acyh2jt','cp73wp7kkjwpp','a7apshdnznca8','8auhv9w189qj3','7v0dc19051k5p','gfh8h1mh1s4b2','g2pyfyg3aa55g','bxja4kp0zfhbx','7j42k0n15nuv4','cp4kf164acnzn','9gq1887jtzv0v','anm0p1bfx3sn2','f95hvr4cq3zvz','648gdx2hx1zk3','3ks9mu5krmvvv','6ywys86kmh6tr','cp4r71qsq1t5t','4b67vx4bkj5zs','5ugavvdqcgma9','3whgyb41k6na4','cgfzzy6uzrr6t','1fvfp5aqzga3m','f18gtvhmagpwg','cv3395xzh9xrm','d1h49tfa4f0xk','7zx4sg3h05mx0','56yma41s8xs41','5tjthywsgbyqs','3qmaww2xr9ppw','f89apa7gpf43h','7dvr4ktdqk5zs','306hrdg0hsa3a','4h4p3kmzdp39u','5xn9r9dznmx2u','6844u0hh3n3av','34693h5jdc7w8','25aacx7v4zs2v','8fayzshd2vzhf','9s2a0bbkxhkm5','15cdgdpy8yh3x','9rdja5f45d3j5','0mvtdja02aqb2','5gn08pz0cfmq6','92s0tzv96v9am','d8yfz3vb70pkr','c9866f2wq4z5j','4m67fj1bd48yy','b5d60xsdac89v','0m5kbbmyz5s2g','2yam8h6cnwca7','1hn71n9wpmfat','4f27cx752nb8x','8gudwkm50rmyn','92k4yn3ry2c30','1cgs3hpgjgnjj','b425bb3bu11np','fjwqd186apq5a','08fcm2g1c51vr','7cd46n5r92vzu','5wtfwxkhnznr7','d77nuppqqa3dn','9zpkkabasbgzm','aud5b6q88u32g','b8f7kgcuxjy0s','38zrd1509hvvu','474yp7kyffstq','5q7kyb9b3p6ka','gqk4wjs2hhgpc','cd8mydvs0zcwq','6c0gwu98q6aqr','b9142v89rv687','f7ypnnhg4j4a9','82dj307qy7pqb','2rqk884cwfhd8','dpyw5puktahfn','6489qrb9vq1ny','4j9ws9ntk7xb4','32q4daabpcw23','1x24bnvpf1vqp','afyjf4pjyjqat','afy5nansqs446','3ss3t0nqtka7x','2hch5ac2y7s3r','89qtj74qrb65g','2zca1m74064ww','75v4jzjprfypm','atsy1zdxpyg25','99fhq10pdxkh8','bawh3a80ug4t2','0uyap9wkhm61b','3q5azyck2604h','c5pqr3w23jdby','2mg5hr5vpd9hq','bjju17w833svj','cvh5dxxk7yyjy','04rtvtzdmpvcv','34xk533376gat','c42su2str7987','a96mfxakvrm2v','f4n81qrtd55vu','dx2rugw8m846q','byv5rzbppwdmj','b1yhn5chpkrmk','9hw0v0b0vd50w','5zq78d4z2j7t8','ahp4w1c9vfpbs','cgymjj24gxxdj','2cfkjf1unt2gq','ah76rkf03mhyq','9z0jpgk8mmsrk','0zmubzrd76b65','0zdhsfpkbtfkf','9vysqgpvyad2u','68v5unqqrsmyf','41z3uyz67au54','b6f6qy8mxh5xz','0arwv4sr90ths','0gc59h6pq2s2x','70068uyt49crd','54zkdmwb878z4','6pvsm94rhynr3','0vuwgh594r2bv','6kka68md1zxcv','gb8m7ht2gg1qq','03kp01xdk34cj','1gswb4m3wcrg0','5cn62trkrkfaz','c4kmpu2bz63g5','9g1drpb1kqwvj','2qapj7muf7fwd','95nbkbswmt3wc','2jwcnw94bpmdd','by705v3hzy8p1','amj8n2pqd1nmz','fcm39t1a1xy6s','dnv5y0pum6r1w','7yk0ys4dtaxgu','5wr5s851ggyat','ftfgxmq1p3bbc','d66r801dtfy8u','c701dq6un1x1x','3bpypkrq3srwb','5crj311w9bbd7','528n3cfu0nfj7','dy1339nz8z5vm','bza2zjtua1vpy','6p845rbxuufp7','2uu9tuu0m0sc6','6vwk9fztbpn8f','6tmkg60gup2bh','ayn87rbmq4cbr','6kc4dnqjddcy4','4hdgz7jb4hnpn','0hsjmwhmng31c','0h59555t9by6v','4r6nd9a8x3a6p','7u2br51xsrggj','b2r0fnd01yjsw','97yrgn5wrxufq','d3kayuvdq62ws','3xy1t4b4vb2ac','1wrjkudjhqqqf','dvtxg9434j5zs','7dbyz6k24xhqk','33gdcxcaqz51q','9gpv02pfptcvp','1ztwyn5us59np','4zq69qcb98kku','2zdvaprj5h066','gjgu19wpwrh3a','bcgsm57tcsqy9','d24tn8j6339zd','9k87mxqsdc0r1','dt0cg1xdm53jp','3wff3udsav0h4','4nb8c81t8d17b','0hj3nc8095h82','649719yrtcjw4','1df59wywj7ynv','9sgx2n8q8ag8p','8vd653c03p01z','ddsxw124q4j88','5pm8zd1ukbchx','38h60nr5062qv','4zncb1fkwtmbp','2jzj7k4azqcr4','3btbcsbp2ph8t','1wgprspt8rrmg','gpa8c40mytgnq','anhymgsu54bjr','5r2m1gkkds06p','1g2uh66kjrga3','61uuzhw658zdp','gc07bsjd50vr3','5bjfc6v76hkyn','agnyfbv273ss8','9mbww7ucg0nn8','5bkh6abjbj1pw','7yjt1426wg7xg','fska227ba22ny','73jkrpjy0x851','3c8ax23s8cck7','7sx5p1ug5ag12','af28xbfcdrkbb','cby4jh94jzm0g','8jxgghp4qhzja','07csc3cn8csx9','9h1j0byq6z9t4','2k4ub9w7mg404','fk5n1jrz3xtz2','fz9c0ua5uw1xy','0jc24paxpfgva','99wj1u82u1qhc','ff8r0407t9k3r','atkrvmg1ghtv6','f0wmhx2y96bwr','dkc5y2zpnh15y','6ksqqc1zc05nq','8s02qb19su5n5','gk63kuujgsyb1','0jd187zb0d0yh','bpxx3dzf3fb9p','4u2tuamp4srb3','c9yx2twr7mx5u','6kwq3psh1xcj2','6ac5r46gdmft9','9kmd6mtxx6avt','7xqphfs94g4k5','bg0yv3pqd2xqs','dqsxbajujjw1t','gnwdhdqyvkqs3','b9b8jn99q4x6v','1729h7ytc7nd1','fkvnb8mazgyxr','9wkc8djs08ntt','2v8cyw764qrdg','5v10qnrh1nufp','3j2fw7ysauw4q','4h3kk1p9w7jm4','350z4j92n0qz9','31mu1zfvv1g52','2kcc3fkqrr6x2','bjkgp8d349c6a','2m8xb88ud7ast','5aw4ds50q7p5b','46624jv9nsqqk','2pct5spzqy3b1','8u7w3m9qt312p','1hf34smc92fgk','ddb6yw44dmxq5','6p1kdjqwgny0m','aypws92v22mjr','8700cy248cv7c','93xj5u2099hrh','bx4hqm7vvsahp','cnrmhhu44c08k','cuyt7wkb7mh2y','2mavahzcknk1d','8xnb55kx6r798','8xgs8ptmqpx6u','bw34mgqsckhs1','4w0guj6qtdst5','2an2q1b2qwust','gnuaq23hdkadb','7czv7xw525s09','6ugvn9j9cmyp5','a7b2k5uvzc4rk','322aqrx43tnqz','4u12u47pg8ukv','6dsaq02h89vyh','bm8yth6p3qrny','ah1k2um9k0r5k','3n5td9w9quczu','gk3m2ra7ubg2q','789uurhvunhym','5ydhag53wxvm7','gh6zq3m4t1mmg','avp574m053k9u','d8zjayym7ymbm','51y8a0rd4jc20','8ccc6qhndz77x','2g4x8k80vyd1u','5sz1b2d4b9bvu','1gv2zrub9r483','9b5hhx61ghw76','05tq7wnc0bsrq','8911vdfb3rkfm','dm8gvbh60why9','ah52txgq39pnw','9a58bmjaryq27','fv1g6nar5t1bn','38pvw330tj1tq','01uj2269uavbn','5gc9k3qhw9k86','fgaqrragnwyqx','3b7r6uksx7nd6','dm823t4pjy0rf','9n8qjtp8sgr7t','0bfp21vhpctf0','cwzj7mksd7x9k','a0z455cvats8r','7kn99m515hz7j','1bsfqzqm901p0','0uuf571w7m4a5','f9xbz91080wk5','a6jhzg6tk7hcb','gnn02dgrgy8r6','2v2ubnwftutay','d77gjrvsd9dw6','20ujr3pcq7bcz','5ga7u4s0kbxgb','cvsqufvnvmm6w','g7h2qr946z0j6','2zqu5b7pdhs1j','f45z7xmp3xb2z','a8jz2y4fxx808','1ccjgunvxnhmg','dqc21rzxc1mwy','b0ys8mg8gxu6t','b7hhcwnfuahwx')
;

PROD_PERIOD_IVR_������� - call_rozn_new


SELECT t.flowchart_name AS flowchart_name,
       Count(*) AS executions,
       Sum(60*extract(hour FROM t.runendtime-t.runstarttime) + extract(MINUTE FROM t.runendtime-t.runstarttime)) AS total_elatime
from CAMPAIGN.sys_monit_flowchart_delta_time t
WHERE 1=1
  AND t.runstarttime >=SYSDATE-&&days_ago
GROUP BY t.flowchart_name
;

