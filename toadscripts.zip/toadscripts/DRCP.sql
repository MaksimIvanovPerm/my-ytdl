EXEC DBMS_CONNECTION_POOL.STOP_POOL();
EXEC DBMS_CONNECTION_POOL.START_POOL();
BEGIN
DBMS_CONNECTION_POOL.CONFIGURE_POOL (pool_name=>'SYS_DEFAULT_CONNECTION_POOL',
minsize=>10,
maxsize=>100,
incrsize=>1,
session_cached_cursors=>64,
inactivity_timeout=>900,
max_think_time=>900,
max_use_session=>500000,
max_lifetime_session=>900);
END;
/

EXEC DBMS_CONNECTION_POOL.ALTER_PARAM(pool_name=>'SYS_DEFAULT_CONNECTION_POOL',param_name=>'num_cbrok',param_value=>'2');


SELECT * FROM sys.DBA_CPOOL_INFO t;
SELECT * FROM V$CPOOL_CONN_INFO t;
SELECT * FROM V$CPOOL_STATS t;
SELECT * FROM V$CPOOL_CC_STATS t;






