--TRUNCATE TABLE sys.temp_sql_stat REUSE STORAGE;
-- drop TABLE sys.temp_sql_stat
SELECT * FROM sys.temp_sql_stat t;
SELECT '>'||t.sql_id||'<' FROM sys.temp_sql_stat t;
SELECT '>'||regexp_replace(t.sql_id,' +$','')||'<' FROM sys.temp_sql_stat t;

SELECT *
FROM sys.temp_sql_stat t
WHERE regexp_replace(t.sql_id,' +$','') IN ('bxtc01u7dchr8')
;

SELECT *
FROM sys.wrh$_sqlstat t
WHERE t.sql_id IN (SELECT s.sql_id FROM sys.temp_sql_stat s)
;

SELECT *
FROM sys.wrh$_sqlstat t
WHERE t.sql_id IN ('1b5x5vbutnnxq')
  AND t.dbid=&&v_dbid AND t.snap_id between &&v_bsnap and &&v_esnap
ORDER BY t.snap_id
;

SELECT t.snap_id, Sum(t.disk_reads_delta) AS ph_reads
FROM sys.wrh$_sqlstat t
WHERE t.sql_id IN (SELECT REPLACE(t.sql_id,' ','') FROM sys.temp_sql_stat s)
  AND t.dbid=&&v_dbid
  AND t.snap_id between &&v_bsnap and &&v_esnap
  AND t.parsing_schema_name='EXCELLENT'
GROUP BY t.snap_id
ORDER BY t.snap_id
;

SELECT v2.snap_id, v1.*
FROM (SELECT t.snap_id AS snap_id,
       t.sql_id AS sql_id,
       t.disk_reads_delta AS stat_value
FROM sys.wrh$_sqlstat t
WHERE t.sql_id IN (SELECT REPLACE(t.sql_id,' ','') FROM sys.temp_sql_stat s)
  AND t.dbid=&&v_dbid AND t.snap_id between &&v_bsnap and &&v_esnap
) v1,
(SELECT * FROM sys.wrm$_snapshot snp WHERE snp.dbid=&&v_dbid AND snp.snap_id between &&v_bsnap and &&v_esnap ) v2
WHERE v1.snap_id(+)=v2.snap_id
ORDER BY v2.snap_id, v1.sql_id
;


SELECT t.sql_id AS sql_id,
       Sum(t.disk_reads_delta) AS volume,
       Count(*) AS fullness
FROM sys.wrh$_sqlstat t
WHERE t.sql_id IN (SELECT s.sql_id FROM sys.temp_sql_stat s)
  AND t.dbid=&&v_dbid AND t.snap_id between &&v_bsnap and &&v_esnap
  AND t.parsing_schema_name='EXCELLENT'
GROUP BY t.sql_id
ORDER BY t.sql_id
;

SELECT t.*
FROM sys.temp_sql_stat t,
     sys.wrh$_sqltext st
WHERE st.dbid=&&v_dbid
  AND st.sql_id=t.sql_id
  AND st.command_type!=47
ORDER BY t.metric desc
;