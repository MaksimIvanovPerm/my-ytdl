select *
from WRM$_DATABASE_INSTANCE t
where T.dbid=&&v_dbid
ORDER BY t.STARTUP_TIME DESC
;
-- ALTER SESSION SET nls_date_format='yyyy.mm.dd hh24:mi:ss';
SET define off
ALTER SESSION SET current_schema=AWR12C;
define awr_schema="AWR12C"

ALTER SESSION SET current_schema=SYS;
define awr_schema="SYS"
define awr_schema="awr_publisher"
set echo off verify off

SELECT *
--dbid
from sys.v_$database;

SELECT * FROM sys.v_$version;

SELECT sysdate, t.* FROM sys.v_$instance t;

SELECT * FROM sys.V_$CONTROLFILE_RECORD_SECTION;
define v_dbid=3220346047
define v_bsnap=32363
define v_esnap=32471
define v_insnum=1
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ', ';
ALTER SESSION SET nls_date_format='yyyy.mm.dd-hh24:mi:ss';


select cast(s.begin_interval_time AS TIMESTAMP(0)) AS snap_time,
       substr(extract(day from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')) * 24 * 60 * 60 +
       extract(hour from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')) * 60 * 60 +
       extract(minute from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')) * 60 +
       trunc(extract(second from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')),0),0,15) as snap_timestamp,
       s.snap_id
from SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
  AND s.snap_id between &&v_bsnap and &&v_esnap --AND s.instance_number=&&v_insnum
  --AND s.begin_interval_time>SYSDATE-15
order by s.snap_id asc;

select --Trunc(s.begin_interval_time,'HH24') AS snap_time, snap_id
       --To_Char(s.begin_interval_time,'yyyy-mm-dd_hh24:mi') AS DATETIME
       --s.begin_interval_time, s.begin_interval_time-3/24
       --Min(s.begin_interval_time)
       *
       --Min(s.snap_id), Max(s.snap_id)
       --s.snap_id, s.begin_interval_time, extract(minute from (s.begin_interval_time)) AS minutes
from SYS.WRM$_SNAPSHOT s
where 1=1
  AND s.instance_number=&&v_insnum
  AND s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
--and s.BEGIN_INTERVAL_TIME>=To_Date('01.06.2015 00:00:00','dd.mm.yyyy hh24:mi:ss')
  --AND s.flush_elapsed IS NOT NULL
  --AND s.snap_timezone IS NOT NULL
  --s.snap_id=356
  --AND extract(minute from (s.begin_interval_time)) > 10
order by s.snap_id asc;

select Min(s.snap_id) AS bsnap_id, Max(s.snap_id) AS esnap_id, extract(hour from (s.begin_interval_time)) AS hh24,
       'exec DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE('||Min(s.snap_id)||', '||Max(s.snap_id)||', &&v_dbid);' AS cmd
from SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
  AND extract(minute from (s.begin_interval_time)) > 10
GROUP BY extract (hour from (s.begin_interval_time))
--order by s.snap_id ASC
;

select --s.snap_id,
       'exec DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE('||s.snap_id||', '||s.snap_id||', &&v_dbid);' AS cmd
from SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
  AND extract(minute from (s.begin_interval_time)) > 10
order by s.snap_id ASC
;

SELECT *
FROM sys.wrm$_snap_error t
;

/*
exec DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE(&&v_bsnap,&&v_esnap,&&v_dbid);
commit;
EXECUTE DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS( interval  =>  10);
EXECUTE DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS( interval  =>  60, retention => (14*24*60));
EXECUTE DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS( interval  =>  10, retention => (7*24*60));
commit;
exec DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();
*/
--baselines --------------------------------------------------------------
EXEC DBMS_WORKLOAD_REPOSITORY.modify_baseline_window_size(window_size =>7);
SELECT * 
FROM DBA_HIST_BASELINE 
WHERE 1=1
  --and BASELINE_NAME='SYSTEM_MOVING_WINDOW'
;

exec DBMS_WORKLOAD_REPOSITORY.CREATE_BASELINE(start_snap_id=>32296, end_snap_id=>32339, baseline_name=>'baseline2', dbid=>&&v_dbid, expiration=>10);
select * from sys.dba_hist_baseline t order by t.baseline_id asc;
SELECT * FROM   TABLE(DBMS_WORKLOAD_REPOSITORY.select_baseline_details(1));

define first_baseline="baseline1"
define second_baseline="baseline2"
with data1 as (
               select metric_name,  minimum, round(average,2) as average, maximum
               from table( DBMS_WORKLOAD_REPOSITORY.SELECT_BASELINE_METRIC('&&first_baseline', &&v_dbid, &&v_insnum) )
              ),
     data2 as (
               select metric_name,  minimum, round(average,2) as average, maximum
               from table( DBMS_WORKLOAD_REPOSITORY.SELECT_BASELINE_METRIC('&&second_baseline', &&v_dbid, &&v_insnum) )
              )
select case when data1.metric_name is not null then data1.metric_name
            else data2.metric_name 
       end as metric_name, data1.average as bl1, data2.average as bl2,
       data2.average-data1.average as delta
from data1 full outer join data2 on data1.metric_name=data2.metric_name
order by 
        --metric_name asc
        delta asc
;


exec DBMS_WORKLOAD_REPOSITORY.DROP_BASELINE(baseline_name=>'baseline2', cascade=>true, dbid=>&&v_dbid);
---------------------------------------------------------------------------------------------------------
set pagesize 0 linesize 128
select OCCUPANT_NAME||' '||OCCUPANT_DESC||' '||SCHEMA_NAME||' '||MOVE_PROCEDURE||' '||MOVE_PROCEDURE_DESC||' '||SPACE_USAGE_KBYTES from V$SYSAUX_OCCUPANTS order by SPACE_USAGE_KBYTES;

SELECT --*
       t.snap_interval, t.retention
FROM sys.dba_hist_wr_control t
WHERE t.dbid=&&v_dbid
;

SELECT * FROM PRODUCT_COMPONENT_VERSION;

SELECT *
FROM V$SYSAUX_OCCUPANTS t
ORDER BY t.space_usage_kbytes desc
;

/*
-- Usage and Storage Management of SYSAUX tablespace occupants SM/AWR, SM/ADVISOR, SM/OPTSTAT and SM/OTHER (Doc ID 329984.1)
select dbms_stats.get_stats_history_retention from dual;
exec dbms_stats.alter_stats_history_retention(7);
exec dbms_stats.purge_stats(CURRENT_TIMESTAMP);
*/

--@?/rdbms/admin/awrinfo.sql

-- truncate table WRH$_SYSMETRIC_SUMMARY drop storage;
-- truncate table WRH$_WAITCLASSMETRIC_HISTORY drop storage;
-- truncate table WRH$_SYSMETRIC_HISTORY drop storage;
-- truncate table WRH$_STREAMS_POOL_ADVICE drop storage;
-- truncate table WRH$_SGA_TARGET_ADVICE drop storage;
-- truncate table WRH$_JAVA_POOL_ADVICE drop storage;
-- truncate table WRH$_PGA_TARGET_ADVICE drop storage;
-- truncate table WRH$_RSRC_CONSUMER_GROUP drop storage;
-- eqmmon only
-- truncate table SYS.WRH$_SQL_PLAN drop storage;
-- truncate table SYS.WRH$_LATCH drop storage;

select *
from WRM$_DATABASE_INSTANCE t
--where T.dbid=&&v_dbid
--ORDER BY t.STARTUP_TIME DESC
;


SELECT --t.retention||' '||t.snap_interval AS col
       t.*
FROM sys.DBA_HIST_WR_CONTROL t
WHERE t.dbid=(SELECT dbid FROM v$database)
;

SELECT DISTINCT st.snap_id
       ,Lag(st.snap_id,1,null) OVER( ORDER BY st.snap_id asc ) AS prev_snap_id
FROM sys.WRH$_SYS_TIME_MODEL st
WHERE st.dbid=&&v_dbid AND st.snap_id between &&v_bsnap and &&v_esnap
ORDER BY st.snap_id asc
;

SELECT st.snap_id, st.stat_id, st.Value AS stat_value, tmn.stat_name AS stat_name
       ,(SELECT Max(s.snap_id) FROM sys.wrm$_snapshot s WHERE s.dbid=&&v_dbid AND s.snap_id between &&v_bsnap and &&v_esnap AND s.snap_id < st.snap_id) AS prev_snap_id
FROM sys.WRH$_SYS_TIME_MODEL st, sys.WRH$_STAT_NAME tmn
WHERE st.dbid=&&v_dbid AND st.snap_id between &&v_bsnap and &&v_esnap
  AND ST.STAT_ID=TMN.STAT_ID
  AND tmn.dbid=&&v_dbid
ORDER BY st.snap_id asc, st.stat_id ASC
;

select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, TMN.STAT_NAME as stat_name, ST.VALUE as stat_value
from sys.wrm$_snapshot s, sys.WRH$_SYS_TIME_MODEL st,
     sys.WRH$_STAT_NAME tmn, sys.WRM$_DATABASE_INSTANCE d
where S.SNAP_ID=ST.SNAP_ID and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and ST.STAT_ID=TMN.STAT_ID
  and D.dbid=&&v_dbid and D.DBID=S.dbid and D.INSTANCE_NUMBER=S.INSTANCE_NUMBER
  and D.STARTUP_TIME=S.STARTUP_TIME
  and S.snap_id between &&v_bsnap and &&v_esnap
;


select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, TMN.STAT_NAME as stat_name, ST.VALUE as stat_value
from sys.wrm$_snapshot s, sys.WRH$_SYS_TIME_MODEL st,
     sys.WRH$_STAT_NAME tmn, sys.WRM$_DATABASE_INSTANCE d
where S.SNAP_ID=ST.SNAP_ID and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and ST.STAT_ID=TMN.STAT_ID
  and D.dbid=&&v_dbid AND d.INSTANCE_NUMBER=&&v_insnum
  AND D.DBID=S.dbid and D.INSTANCE_NUMBER=S.INSTANCE_NUMBER
  and D.STARTUP_TIME=S.STARTUP_TIME
  and S.snap_id between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select  to_char(e.snap_time,'dd.mm.yyyy hh24:mi') as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where 1=1
  AND e.snap_id=(b.snap_id + 1)
  --AND e.snap_id=b.prev_snap_id
  and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('DB time' as db_time,'DB CPU' as db_cpu,
      'background elapsed time' as bgrnd_el_tm,
      'background cpu time' AS bgrnd_cpu_tm,
      'sequence load elapsed time' as seq_load_el_tm,
      'parse time elapsed' as parse_el_tm,
      'hard parse elapsed time' as  hard_parse_el_tm,
      'sql execute elapsed time' as sql_exec_el_tm,
      'connection management call elapsed time' as conn_mgmnt_call_el_tm,
      'failed parse elapsed time' as failed_parse_el_tm,
      'failed parse (out of shared memory) elapsed time' AS fail_parse_outofshmem_el_tm,
      'hard parse (sharing criteria) elapsed time' as hrd_parse_sharing_crit_el_tm,
      'hard parse (bind mismatch) elapsed time' as hrd_prs_bing_mismtch_el_tm,
      'PL/SQL execution elapsed time' as plsql_exec_el_tm,
      'inbound PL/SQL rpc elapsed time' as inbnd_plsql_rpc_el_tm,
      'PL/SQL compilation elapsed time' as plsql_compile_el_tm,
      'Java execution elapsed time' as java_exec_el_tm,
      'repeated bind elapsed time' as repeat_bind_el_tm,
      'RMAN cpu time (backup/restore)' as rman_bcp_rstr_cpu_tm,
      'scheduler wait time' AS sched_wait_time
      )
)
where db_time is not null
order by snap_id;


SELECT *
FROM WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 --and S.SNAP_ID between &&v_bsnap and &&v_esnap
ORDER BY s.snap_id;

SELECT *
FROM WRH$_SYSTEM_EVENT s
WHERE s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
ORDER BY s.snap_id;

-- Wait time by wait cl�sses
select snap_time, snap_id, Concurrency, UserIO, SystemIO, Administrative, Other, Scheduler, Configuration, "Cluster", Application, Queueing, Network, Commit
from (
with    local_data as (select    S.BEGIN_INTERVAL_TIME as snap_time,
                        S.SNAP_ID as snap_id,
                        en.WAIT_CLASS as stat_name,
                        sum(SE.TIME_WAITED_MICRO) as stat_value
              from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
              where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
                    and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
                    and SE.EVENT_ID=EN.EVENT_ID and SE.DBID=EN.DBID
              group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.WAIT_CLASS
             ),
        b as ( select * from local_data ),
        e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'Concurrency' as Concurrency,
'User I/O' as UserIO,
'System I/O' as SystemIO,
'Administrative' as Administrative,
'Other' as Other,
'Scheduler' as Scheduler,
'Configuration' as Configuration,
'Cluster' as "Cluster",
'Application' as Application,
'Idle' as Idle,
'Queueing' as Queueing,
'Network' as Network,
'Commit' as Commit
)
    )
order by snap_id;

--
SELECT ''''||t.name||''' as '||regexp_REPLACE(t.name,'[ \/:\-\,\(\)]','')||',' AS col
FROM v$event_name t
WHERE t.wait_class='Concurrency'
;
--
-- Scheduler class ---
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='Scheduler'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'acknowledge over PGA limit' as acknowledgeoverPGAlimit,
'resmgr:cpu quantum' as resmgrcpuquantum,
'resmgr:large I/O queued' as resmgrlargeIOqueued,
'resmgr:small I/O queued' as resmgrsmallIOqueued,
'resmgr:become active' as resmgrbecomeactive,
'resmgr:pq queued' as resmgrpqqueued,
'enq: JX - SQL statement queue' as enqJX_SQLstatementqueue,
'enq: JX - cleanup of  queue' as enqJX_cleanupofqueue,
'PX Queuing: statement queue' as PXQueuingstatementqueue
)
    )
order by snap_id;
------------------------
-- Application class
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='Application'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'enq: PW - flush prewarm buffers' as enqPWflushprewarmbuffers,
'enq: RO - contention' as enqROcontention,
'enq: RO - fast object reuse' as enqROfastobjectreuse,
'enq: KO - fast object checkpoint' as enqKOfastobjectcheckpoint,
'enq: TM - contention' as enqTMcontention,
'enq: TX - row lock contention' as enqTXrowlockcontention,
'Wait for Table Lock' as WaitforTableLock,
'enq: RC - Result Cache: Contention' as enqRCResultCacheContention,
'Streams capture: filter callback waiting for ruleset' as StrmCaptrFiltrCallBckWtn4Rlst,
'Streams: apply reader waiting for DDL to apply' as e1,
'SQL*Net break/reset to client' as SQLNetbreakresettoclient,
'SQL*Net break/reset to dblink' as SQLNetbreakresettodblink,
'External Procedure initial connection' as e2,
'External Procedure call' as ExternalProcedurecall,
'enq: UL - contention' as enqULcontention,
'OLAP DML Sleep' as OLAPDMLSleep,
'WCR: replay lock order' as WCRreplaylockorder
)
    )
order by snap_id;

--------------------------------------------------------------------------------



-- Application class
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='Application'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'enq: PW - flush prewarm buffers' as enqPWflushprewarmbuffers,
'enq: RO - contention' as enqROcontention,
'enq: RO - fast object reuse' as enqROfastobjectreuse,
'enq: KO - fast object checkpoint' as enqKOfastobjectcheckpoint,
'enq: TM - contention' as enqTMcontention,
'enq: TX - row lock contention' as enqTXrowlockcontention,
'Wait for Table Lock' as WaitforTableLock,
'enq: RC - Result Cache: Contention' as enqRCResultCacheContention,
'REPL Capture: filter callback ruleset' as REPLCptrfiltercallbackruleset,
'REPL Apply: apply DDL' as REPLApplyapplyDDL,
'SQL*Net break/reset to client' as SQLNetbreakresettoclient,
'SQL*Net break/reset to dblink' as SQLNetbreakresettodblink,
'External Procedure initial connection' as ExtProcInitialConnection,
'External Procedure call' as ExternalProcedurecall,
'enq: UL - contention' as enqULcontention,
'OLAP DML Sleep' as OLAPDMLSleep,
'WCR: replay lock order' as WCRreplaylockorder
)
    )
order by snap_id;

--------------------------------------------------------------------------------

-- System IO
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='System I/O'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'Clonedb bitmap file write' as Clonedbbitmapfilewrite,
'Log archive I/O' as LogarchiveIO,
'RMAN backup & recovery I/O' as RMANbackupRecoveryIO,
'Standby redo I/O' as StandbyredoIO,
'Network file transfer' as Networkfiletransfer,
'io done' as iodone,
'RMAN Disk slave I/O' as RMANDiskslaveIO,
'RMAN Tape slave I/O' as RMANTapeslaveIO,
'DBWR slave I/O' as DBWRslaveIO,
'LGWR slave I/O' as LGWRslaveIO,
'Archiver slave I/O' as ArchiverslaveIO,
'control file sequential read' as controlfilesequentialread,
'control file single write' as controlfilesinglewrite,
'control file parallel write' as controlfileparallelwrite,
'recovery read' as recoveryread,
'RFS sequential i/o' as RFSsequentialio,
'RFS random i/o' as RFSrandomio,
'RFS write' as RFSwrite,
'log file sequential read' as logfilesequentialread,
'log file single write' as logfilesinglewrite,
'log file parallel write' as logfileparallelwrite,
'db file parallel write' as dbfileparallelwrite,
'db file async I/O submit' as dbfileasyncIOsubmit,
'flashback log file write' as flashbacklogfilewrite,
'flashback log file read' as flashbacklogfileread,
'cell smart incremental backup' as cellsmartincrementalbackup,
'cell smart restore from backup' as cellsmartrestorefrombackup,
'kfk: async disk IO' as kfkasyncdiskIO,
'cell manager opening cell' as cellmanageropeningcell,
'cell manager closing cell' as cellmanagerclosingcell,
'cell manager discovering disks' as cellmanagerdiscoveringdisks
)
    )
order by snap_id;

--------------------------------------------------------------------------------

-- Commit waits
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in (
  'remote log force - commit','log file sync','nologging standby txn commit','enq: BB - 2PC across RAC instances'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'remote log force - commit' AS rem_log_force_cmt,
'log file sync' AS log_file_sync,
'nologging standby txn commit' AS nologg_stb_txn_cmt,
'enq: BB - 2PC across RAC instances' AS enq_BB_2PC_acr
    )
     )
order by snap_id;

--------------------------------------------------------------------------------


-- Network class
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in (
  'remote db operation','remote db file read','remote db file write','ARCH wait for net re-connect','LGWR wait on ATTACH','ARCH wait on ATTACH','ARCH wait for netserver start','LNS wait on ATTACH','LNS wait on SENDREQ','LNS wait on DETACH','LGWR wait on SENDREQ','LGWR wait on DETACH','ARCH wait on SENDREQ','ARCH wait on DETACH','ARCH wait for netserver init 2','LNS wait on LGWR','LGWR wait on LNS','ARCH wait for flow-control','ARCH wait for netserver detach','TCP Socket (KGAS)','virtual circuit wait','dispatcher listen timer','dedicated server timer','SQL*Net message to client','SQL*Net message to dblink','SQL*Net more data to client','SQL*Net more data to dblink','SQL*Net more data from client','SQL*Net message from dblink','SQL*Net more data from dblink','SQL*Net vector data to client','SQL*Net vector data from client','SQL*Net vector data to dblink','SQL*Net vector data from dblink','TEXT: URL_DATASTORE network wait'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'remote db operation' as remote_db_operation,
'remote db file read' as remote_db_file_read,
'remote db file write' as remote_db_file_write,
'ARCH wait for net re-connect' as ARCH_wait_for_net_re_connect,
'LGWR wait on ATTACH' as LGWR_wait_on_ATTACH,
'ARCH wait on ATTACH' as ARCH_wait_on_ATTACH,
'ARCH wait for netserver start' as ARCH_wait_for_netserver_start,
'LNS wait on ATTACH' as LNS_wait_on_ATTACH,
'LNS wait on SENDREQ' as LNS_wait_on_SENDREQ,
'LNS wait on DETACH' as LNS_wait_on_DETACH,
'LGWR wait on SENDREQ' as LGWR_wait_on_SENDREQ,
'LGWR wait on DETACH' as LGWR_wait_on_DETACH,
'ARCH wait on SENDREQ' as ARCH_wait_on_SENDREQ,
'ARCH wait on DETACH' as ARCH_wait_on_DETACH,
'ARCH wait for netserver init 2' as ARCH_wait_for_netserver_init_2,
'LNS wait on LGWR' as LNS_wait_on_LGWR,
'LGWR wait on LNS' as LGWR_wait_on_LNS,
'ARCH wait for flow-control' as ARCH_wait_for_flow_control,
'ARCH wait for netserver detach' as ARCH_wait_for_netserver_detach,
'TCP Socket (KGAS)' as TCP_Socket__KGAS_,
'virtual circuit wait' as virtual_circuit_wait,
'dispatcher listen timer' as dispatcher_listen_timer,
'dedicated server timer' as dedicated_server_timer,
'SQL*Net message to client' as SQL_Net_message_to_client,
'SQL*Net message to dblink' as SQL_Net_message_to_dblink,
'SQL*Net more data to client' as SQL_Net_more_data_to_client,
'SQL*Net more data to dblink' as SQL_Net_more_data_to_dblink,
'SQL*Net more data from client' as SQL_Net_more_data_from_client,
'SQL*Net message from dblink' as SQL_Net_message_from_dblink,
'SQL*Net more data from dblink' as SQL_Net_more_data_from_dblink,
'SQL*Net vector data to client' as SQL_Net_vector_data_to_client,
'SQL*Net vector data from client' as SQLNet_vector_data_4fm_client,
'SQL*Net vector data to dblink' as SQL_Net_vector_data_to_dblink,
'SQL*Net vector data from dblink' as SQLNet_vector_data4rmdblink,
'TEXT: URL_DATASTORE network wait' as TEXT_URL_DATASTORE_ntwrk_wt
)
    )
order by snap_id;
--------------------------------------------------------------------------------
-- Administrative Class Wait Structure
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='Administrative'
  --and EN.EVENT_NAME in ( 'buffer busy waits','cursor: mutex S','cursor: mutex X','cursor: pin S','cursor: pin S wait on X','cursor: pin X','db flash cache invalidate wait','enq: HV - contention','enq: TX - index contention','enq: WG - lock fso','latch: cache buffers chains','latch: In memory undo latch','latch: MQL Tracking Latch','latch: row cache objects','latch: shared pool','latch: Undo Hint Latch','libcache interrupt action by LCK','library cache load lock','library cache lock','library cache: mutex S','library cache: mutex X','library cache pin','logout restrictor','os thread startup','pipe put','resmgr:internal state change','resmgr:sessions to exit','row cache lock','row cache read','securefile chain update','SecureFile mutex','Shared IO Pool Memory','Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'ASM COD rollback operation completion' as ASM_COD_rllbck_op_completion,
'ASM mount : wait for heartbeat' as ASM_mount_wait4heartbeat,
'Backup: MML command to channel' as Bcp_MML_command_to_channel,
'Backup: MML commit backup piece' as Bcp_MML_commit_backup_piece,
'Backup: MML create a backup piece' as Bcp_MML_create_a_backup_piece,
'Backup: MML data movement done?' as Bcp_MML_data_movement_done,
'Backup: MML datafile proxy backup?' as Bcp_MML_datafile_proxy_backup,
'Backup: MML datafile proxy restore?' as Bcp_MML_datafile_proxy_restore,
'Backup: MML delete backup piece' as Bcp_MML_delete_backup_piece,
'Backup: MML extended initialization' as Bcp_MML_extended_init,
'Backup: MML get base address' as Bcp_MML_get_base_address,
'Backup: MML initialization' as Bcp_MML_initialization,
'Backup: MML obtain a direct buffer' as Bcp_MML_obtain_a_direct_buffer,
'Backup: MML obtain textual error' as Bcp_MML_obtain_textual_error,
'Backup: MML proxy cancel' as Bcp_MML_proxy_cancel,
'Backup: MML proxy commit backup piece' as Bcp_MML_proxy_cmmit_bckp_pc,
'Backup: MML proxy initialize backup' as Bcp_MML_proxy_init_backup,
'Backup: MML proxy initialize restore' as Bcp_MML_proxy_init_restore,
'Backup: MML proxy prepare to start' as Bcp_MML_proxy_prepare2start,
'Backup: MML proxy session end' as Bcp_MML_proxy_session_end,
'Backup: MML proxy start data movement' as Bcp_MML_proxy_start_data_mvmnt,
'Backup: MML query backup piece' as Bcp_MML_query_backup_piece,
'Backup: MML query for direct buffers' as Bcp_MML_query4direct_buffers,
'Backup: MML read backup piece' as Bcp_MML_read_backup_piece,
'Backup: MML release a direct buffer' as Bcp_MML_rls_a_drct_bffr,
'Backup: MML restore backup piece' as Bcp_MML_restore_backup_piece,
'Backup: MML shutdown' as Bcp_MML_shutdown,
'Backup: MML v1 close backup piece' as Bcp_MML_v1_close_bcp_pc,
'Backup: MML v1 delete backup piece' as Bcp_MML_v1_delete_bcp_pc,
'Backup: MML v1 open backup piece' as Bcp_MML_v1_open_bcp_pc,
'Backup: MML v1 query backup piece' as Bcp_MML_v1_query_bcp_pc,
'Backup: MML v1 read backup piece' as Bcp_MML_v1_read_bcp_pc,
'Backup: MML v1 write backup piece' as Bcp_MML_v1_write_bcp_pc,
'Backup: MML write backup piece' as Bcp_MML_write_backup_piece,
'JS coord start wait' as JS_coord_start_wait,
'JS_kgl get object wait' as JS_kgl_get_object_wait,
'JS kill job wait' as JS_kill_job_wait,
'alter rbs offline' as alter_rbs_offline,
'alter_system set dispatcher' as alter_system_set_dispatcher,
'concurrent I/O completion' as concurrent_IO_completion,
'connection_pool wait' as connection_pool_wait,
'control_file backup creation' as control_file_backup_creation,
'datafile copy range completion' as datafile_copy_range_completion,
'db flash cache dynamic disabling wait' as db_flsh_cch_dnmc_dsblng_wt,
'enq: DB - contention' as enq_DB_contention,
'enq: MV - datafile move' as enq_MV_datafile_move,
'enq: TW - contention' as enq_TW_contention,
'enq: ZG - contention' as enq_ZG_contention,
'index (re)build online cleanup' as index_re_build_online_cleanup,
'index (re)build online merge' as index_re_build_online_merge,
'index (re)build online start' as index_re_build_online_start,
'multiple dbwriter suspend/resume for file offline' as mltpl_dbwr_sspndrsm4file_offln,
'switch logfile command' as switch_logfile_command,
'switch_undo - offline' as switch_undo_offline,
'wait for possible quiesce finish' as wait4possible_quiesce_finish
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Concurrency Class Wait Structure
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='Concurrency'
  --and EN.EVENT_NAME in ( 'buffer busy waits','cursor: mutex S','cursor: mutex X','cursor: pin S','cursor: pin S wait on X','cursor: pin X','db flash cache invalidate wait','enq: HV - contention','enq: TX - index contention','enq: WG - lock fso','latch: cache buffers chains','latch: In memory undo latch','latch: MQL Tracking Latch','latch: row cache objects','latch: shared pool','latch: Undo Hint Latch','libcache interrupt action by LCK','library cache load lock','library cache lock','library cache: mutex S','library cache: mutex X','library cache pin','logout restrictor','os thread startup','pipe put','resmgr:internal state change','resmgr:sessions to exit','row cache lock','row cache read','securefile chain update','SecureFile mutex','Shared IO Pool Memory','Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'logout restrictor' as logoutrestrictor,
'Shared IO Pool Memory' as SharedIOPoolMemory,
'latch: cache buffers chains' as latchcachebufferschains,
'buffer busy waits' as bufferbusywaits,
'db flash cache invalidate wait' as dbflashcacheinvalidatewait,
'log file sync: SCN ordering' as logfilesyncSCNordering,
'enq: TX - index contention' as enqTXindexcontention,
'latch: Undo Hint Latch' as latchUndoHintLatch,
'latch: In memory undo latch' as latchInmemoryundolatch,
'latch: MQL Tracking Latch' as latchMQLTrackingLatch,
'IM buffer busy' as IMbufferbusy,
'securefile chain update' as securefilechainupdate,
'enq: HV - contention' as enqHVcontention,
'SecureFile mutex' as SecureFilemutex,
'enq: WG - lock fso' as enqWGlockfso,
'Inmemory Populate: get loadscn' as InmemoryPopulategetloadscn,
'latch: row cache objects' as latchrowcacheobjects,
'row cache lock' as rowcachelock,
'row cache read' as rowcacheread,
'libcache interrupt action by LCK' as libcacheinterruptactionbyLCK,
'cursor: mutex X' as cursormutexX,
'cursor: mutex S' as cursormutexS,
'cursor: pin X' as cursorpinX,
'cursor: pin S' as cursorpinS,
'cursor: pin S wait on X' as cursorpinSwaitonX,
'enq: CB - role operation' as enqCBroleoperation,
'latch: shared pool' as latchsharedpool,
'LCK0 row cache object free' as LCK0rowcacheobjectfree,
'library cache pin' as librarycachepin,
'library cache lock' as librarycachelock,
'library cache load lock' as librarycacheloadlock,
'library cache: mutex X' as librarycachemutexX,
'library cache: mutex S' as librarycachemutexS,
'resmgr:internal state change' as resmgrinternalstatechange,
'resmgr:sessions to exit' as resmgrsessionstoexit,
'pipe put' as pipeput,
'REPL Apply: dependency' as REPLApplydependency,
'Cube Build Master Wait for Jobs' as CubeBuildMasterWaitforJobs
)
    )
order by snap_id;
------------------------------------------------------------------------------

-- UserIO Wait time structure
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'Parameter File I/O','Disk file operations I/O','Disk file I/O Calibration','Disk file Mirror Read','Disk file Mirror/Media Repair Write','direct path sync','Datapump dump file I/O','dbms_file_transfer I/O','DG Broker configuration file I/O','Data file init write','Log file init write','Pluggable Database file copy','File Copy','Shared IO Pool IO Completion','local write wait','buffer read retry','read by other session','db flash cache single block physical read','db flash cache multiblock physical read','db flash cache write','db file sequential read','db file scattered read','db file single write','db file parallel read','direct path read','direct path read temp','direct path write','direct path write temp','flashback log file sync','cell smart table scan','cell smart index scan','cell external table smart scan','cell statistics gather','cell smart file creation','Archive Manager file transfer I/O','securefile direct-read completion','securefile direct-write completion','BFILE read','utl_file I/O','external table read','external table write','external table open','external table seek','external table misc IO','dbverify reads','TEXT: File System I/O','ASM sync cache disk read','ASM Fixed Package I/O','ASM Staleness File I/O','cell single block physical read','cell multiblock physical read','cell list of blocks physical read','cell physical read no I/O','cell single block read request','cell multiblock read request','cell list of blocks read request' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'Parameter File I/O' as ParameterFileIO,
'Disk file operations I/O' as DiskfileoperationsIO,
'Disk file I/O Calibration' as DiskfileIOCalibration,
'Disk file Mirror Read' as DiskfileMirrorRead,
'Disk file Mirror/Media Repair Write' as DiskfileMirrorMediaRepairWrite,
'direct path sync' as directpathsync,
'Datapump dump file I/O' as DatapumpdumpfileIO,
'dbms_file_transfer I/O' as dbms_file_transferIO,
'DG Broker configuration file I/O' as DGBrokerconfigurationfileIO,
'Data file init write' as Datafileinitwrite,
'Log file init write' as Logfileinitwrite,
'Pluggable Database file copy' as PluggableDatabasefilecopy,
'File Copy' as FileCopy,
'Shared IO Pool IO Completion' as SharedIOPoolIOCompletion,
'local write wait' as localwritewait,
'buffer read retry' as bufferreadretry,
'read by other session' as readbyothersession,
'db flash cache single block physical read' as dbflashcacheSblckphysread,
'db flash cache multiblock physical read' as dbflashcacheMblckphysread,
'db flash cache write' as dbflashcachewrite,
'db file sequential read' as dbfilesequentialread,
'db file scattered read' as dbfilescatteredread,
'db file single write' as dbfilesinglewrite,
'db file parallel read' as dbfileparallelread,
'direct path read' as directpathread,
'direct path read temp' as directpathreadtemp,
'direct path write' as directpathwrite,
'direct path write temp' as directpathwritetemp,
'flashback log file sync' as flashbacklogfilesync,
'cell smart table scan' as cellsmarttablescan,
'cell smart index scan' as cellsmartindexscan,
'cell external table smart scan' as cellexternaltablesmartscan,
'cell statistics gather' as cellstatisticWRH_%ther,
'cell smart file creation' as cellsmartfilecreation,
'Archive Manager file transfer I/O' as ArchiveManagerfiletransferIO,
'securefile direct-read completion' as ScrfileDrct_rdcompletion,
'securefile direct-write completion' as ScrfileDrct_wrcompletion,
'BFILE read' as BFILEread,
'utl_file I/O' as utl_fileIO,
'external table read' as externaltableread,
'external table write' as externaltablewrite,
'external table open' as externaltableopen,
'external table seek' as externaltableseek,
'external table misc IO' as externaltablemiscIO,
'dbverify reads' as dbverifyreads,
'TEXT: File System I/O' as TEXT_FileSystemIO,
'ASM sync cache disk read' as ASMsynccachediskread,
'ASM Fixed Package I/O' as ASMFixedPackageIO,
'ASM Staleness File I/O' as ASMStalenessFileIO,
'cell single block physical read' as cellsingleblockphysicalread,
'cell multiblock physical read' as cellmultiblockphysicalread,
'cell list of blocks physical read' as celllistofblocksphysicalread,
'cell physical read no I/O' as cellphysicalreadnoIO,
'cell single block read request' as cellsingleblockreadrequest,
'cell multiblock read request' as cellmultiblockreadrequest,
'cell list of blocks read request' as celllistofblocksreadrequest
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Configuration Wait time structure
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','nologging range consumption list','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','SecureFile log buffer','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','REPL Apply: commit','wait for EMON to process ntfns' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'free buffer waits' as freebufferwaits,
'checkpoint completed' as checkpointcompleted,
'write complete waits' as writecompletewaits,
'write complete waits: flash cache' as writecompletewaitsflashcache,
'latch: redo writing' as latchredowriting,
'latch: redo copy' as latchredocopy,
'log buffer space' as logbufferspace,
'log file switch (checkpoint incomplete)' as lgflSwtchChckpIntinComplete,
'log file switch (private strand flush incomplete)' as lgflSwtchPrvtStrndflshIncmplt,
'log file switch (archiving needed)' as logfileswitchArchivingneeded,
'log file switch completion' as logfileswitchcompletion,
'flashback buf free by RVWR' as flashbackbuffreebyRVWR,
'nologging range consumption list' as nologgingrangeconsumptionlist,
'enq: ST - contention' as enqSTcontention,
'undo segment extension' as undosegmentextension,
'undo segment tx slot' as undosegmenttxslot,
'enq: TX - allocate ITL entry' as enqTXallocateITLentry,
'statement suspended, wait error to be cleared' as StmtSuspendedWaitErrToBeClrd,
'SecureFile log buffer' as SecureFilelogbuffer,
'enq: HW - contention' as enqHWcontention,
'enq: SS - contention' as enqSScontention,
'sort segment request' as sortsegmentrequest,
'enq: SQ - contention' as enqSQcontention,
'Global transaction acquire instance locks' as GlblTxAcquireinstancelocks,
'REPL Apply: commit' as REPLApplycommit,
'wait for EMON to process ntfns' as waitforEMONtoprocessntfns
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Others
-- See R-script AnalyzeOthersWaitClass.r and do
-- cat ./class_events.txt | grep -f ./filter.txt at dwh
-- cat temp.txt | grep -f filter.txt
SELECT *
FROM v$event_name t
WHERE t.event_id=906644781
;

SELECT *
FROM (
SELECT ''''||t.name||''' as e'||ROWNUM||',' AS col,
       ROWNUM AS col2
FROM v$event_name t
WHERE t.wait_class='Other' )
WHERE col2 IN (4,11,16,17,20,41,43,44,48,56,84,214,221,223,224,227,238,240,311,312,320,369,465,474,743,808,809,810,814,816,1154,1167)
;

SELECT --*
SNAP_ID,E4,E11,E16,E17,E20,E41,E43,E44,E48,E56,E84,E214,E221,E223,E224,E227,E238,E240,E302,E311,E312,E320,E369,E465,E474,E520,E743,E808,E809,E810,E814,E816,E1167
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, sys.DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  --and SE.EVENT_NAME in ( 'null event','events in waitclass Other','enq: WM - WLM Plan activation','latch free','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','unspecified wait event','latch activity','wait list latch activity','wait list latch free','global enqueue expand wait','free process state object','inactive session','process terminate','latch: call allocation','latch: session allocation','check CPU wait times','enq: CI - contention','enq: PR - contention','enq: AK -  contention','enq: XK -  contention','enq: DI -  contention','enq: RM -  contention','enq: BO -  contention','ges resource enqueue open retry sleep','ksim generic wait event','debugger command','ksdxexeother','ksdxexeotherwait','latch: ksm sga alloc latch','defer SGA allocation slave','SGA Allocator termination','enq: PE - contention','enq: PG - contention','ksbsrv','ksbcic','process startup','process shutdown','prior spawner clean up','latch: messages','rdbms ipc message block','rdbms ipc reply','latch: enqueue hash chains','enq: FP - global fob contention','enq: RE - block repair contention','enq: BM - clonedb bitmap file write','asynch descriptor resize','enq: FO - file system operation contention','imm op','slave exit','enq: KM - contention','enq: KT - contention','enq: CA - contention','enq: KD - determine DBRM master','reliable message','broadcast mesg queue transition','broadcast mesg recovery queue transition','KSV master wait','master exit','ksv slave avail wait','enq: PV - syncstart','enq: PV - syncshut','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SX - contention 5','enq: SX - contention 6','first spare wait event','second spare wait event','IPC send completion sync','OSD IPC library','IPC wait for name service busy','IPC busy async request','IPC waiting for OSD resources','ksxr poll remote instances','ksxr wait for mount shared','DBMS_LDAP: LDAP operation ','wait for FMON to come up','enq: FM - contention','enq: XY - contention','set director factor wait','latch: active service list','enq: AS - service activation','enq: PD - contention','oracle thread bootstrap','os thread creation','cleanup of aborted process','enq: XM -  contention','enq: RU - contention','enq: RU - waiting','rolling migration: cluster quiesce','LMON global data update','process diagnostic dump','enq: MX - sync storage server info','master diskmon startup','master diskmon read','DSKM to complete cell health check','pmon dblkr tst event','pmon cleanup on exit','latch: ksolt alloc','lightweight thread operation','enq: ZX - repopulation file write','DIAG lock acquisition','latch: ges resource hash list','DFS lock handle','ges LMD to shutdown','ges client process to exit','ges global resource directory to be frozen','ges resource directory to be unfrozen','gcs resource directory to be unfrozen','ges LMD to inherit communication channels','ges lmd sync during reconfig','ges wait for lmon to be ready','ges cgs registration','wait for master scn','ges yield cpu in reconfig','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges lms sync during dynamic remastering and reconfig','ges LMON to join CGS group','ges pmon to exit','ges lmd and pmon to attach','gcs drm freeze begin','gcs retry nowait latch get','gcs remastering wait for read latch','ges cached resource cleanup','ges generic event','ges retry query node','ges process with outstanding i/o','ges user error','ges enter server mode','gcs enter server mode','gcs drm freeze in enter server mode','gcs ddet enter server mode','ges cancel','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges master to get established for SCN op','ges LMON to get to FTDONE ','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges inquiry response','ges reusing os pid','ges LMON for send queues','ges LMD suspend for testing event','ges performance test completion','kjbopen wait for recovery domain attach','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','ges RMS0 retry add redo log','readable standby redo apply remastering','ges DFS hang analysis phase 2 acks','ges/gcs diag dump','global plug and play automatic resource creation','gcs lmon dirtydetach step completion','recovery instance recovery completion','ack for a broadcasted res from a remote instance','latch: kjci process context latch','latch: kjci request sequence latch','DLM cross inst call completion','DLM: shared instance mode init','enq: KI - contention','latch: kjoeq omni enqueue hash bucket latch','DLM enqueue copy completion','latch: kjoer owner hash bucket','DLM Omni Enq Owner replication','KJC: Wait for msg sends to complete','ges message buffer allocation','kjctssqmg: quick message send wait','kjctcisnd: Queue/Send client message','gcs domain validation','latch: gcs resource hash','affinity expansion in replay','wait for sync ack','wait for verification ack','wait for assert messages to be sent','wait for scn ack','lms flush message acks','name-service call wait','CGS wait for IPC msg','kjxgrtest','IMR mount phase II completion','IMR disk votes','IMR rr lock release','IMR net-check message ack','IMR rr update','IMR membership resolution','IMR CSS join retry','CGS skgxn join retry','gcs to be enabled','gcs log flush sync','enq: PP -  contention','enq: HM -  contention','GCR ctx lock acquisition','GCR CSS group lock','GCR CSS group join','GCR CSS group leave','GCR CSS group update','GCR CSS group query','enq: AC - acquiring partition id','SGA: allocation forcing component growth','SGA: sga_target resize','enq: SC -  contention','control file heartbeat','control file diagnostic dump','enq: CF - contention','enq: SW - contention','enq: DS - contention','enq: TC - contention','enq: TC - contention2','buffer exterminate','buffer resize','latch: cache buffers lru chain','enq: PW - perwarm status in dbw0','latch: checkpoint queue latch','latch: cache buffer handles','kcbzps','DBWR range invalidation sync','buffer deadlock','buffer latch','cr request retry','writes stopped by instance recovery or database suspension','lock escalate retry','lock deadlock retry','prefetch warmup block being transferred','recovery buffer pinned','TSE master key rekey','TSE SSO wallet reopen','force-cr-override flush','enq: CR - block range reuse ckpt','wait for MTTR advisory state object','latch: object queue header operation','retry cftxn during close','get branch/thread/sequence enqueue','enq: WL - Test access/locking','Data Guard server operation completion','FAL archive wait 1 sec for REOPEN minimum','TEST: action sync','TEST: action hang','RSGA: RAC reconfiguration','enq: WL - RAC-wide SGA initialize','enq: WL - RAC-wide SGA write','enq: WL - RAC-wide SGA dump','LGWR ORL/NoExp FAL archival','enq: WS -  contention','MRP wait on process start','MRP wait on process restart','MRP wait on startup clear','MRP inactivation','MRP termination','MRP state inspection','MRP wait on archivelog arrival','MRP wait on archivelog archival','enq: WL - Far Sync Fail Over','Monitor testing','enq: WL - redo_db table update','enq: WL - redo_db table query','enq: WL - redo_log table update','enq: WL - redo_log table query','enq: PY - AVM RTA access instance','enq: PY - AVM RTA access database','enq: PY - AVM RTA access database 2','log switch/archive','enq: WL - Switchover To Primary','ARCH wait on c/f tx acquire 1','RFS attach','RFS create','RFS close','RFS announce','RFS register','RFS detach','RFS ping','RFS dispatch','enq: WL - RFS global state contention','LGWR simulation latency wait','LNS simulation latency wait','ASYNC Remote Write','SYNC Remote Write','ARCH Remote Write','Redo Transport Attach','Redo Transport Detach','Redo Transport Open','Redo Transport Close','Redo Transport Ping','Remote SYNC Ping','Redo Transport Slave Startup','Redo Transport Slave Shutdown','Redo Writer Remote Sync Notify','Redo Writer Remote Sync Complete','Redo Transport MISC','Data Guard: RFS disk I/O','ARCH wait for process start 1','ARCH wait for process death 1','ARCH wait for process start 3','Data Guard: process exit','Data Guard: process clean up','LGWR-LNS wait on channel','enq: WR - contention','Redo transport testing','enq: RZ - add element','enq: RZ - remove element','Image redo gen delay','LGWR wait for redo copy','latch: redo allocation','log file switch (clearing log file)','target log write size','LGWR any worker group','LGWR all worker groups','LGWR worker group ordering','LGWR intra group sync','LGWR intra group IO completion','enq: WL - contention','enq: RN - contention','DFS db file lock','enq: DF - contention','enq: IS - contention','enq: IP - open/close PDB','enq: FS - contention','enq: FS - online log operation','enq: DM - contention','enq: RP - contention','latch: gc element','enq: RT - contention','enq: RT - thread internal enable/disable','enq: IR - contention','enq: IR - contention2','enq: IR - global serialization','enq: IR - local serialization','enq: IR - arbitrate instance recovery','enq: MR - contention','enq: MR - standby role transition','enq: MR - multi instance redo apply','enq: MR - any role transition','enq: MR - PDB open','enq: MR - datafile online','enq: MR - adg instance recovery','shutdown after switchover to standby','cancel media recovery on switchover','parallel recovery coord wait for reply','parallel recovery coord send blocked','parallel recovery slave wait for change','enq: BR - file shrink','enq: BR - proxy-copy','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - space info datafile hdr update','enq: BR - request autobackup','enq: BR - perform autobackup','enq: BR - BA lock db','enq: BR - BA lock storage loc','enq: BR - BA lock timer queue','enq: BR - BA lock scheduler','enq: BR - BA lock API','enq: BR - BA quiesce storage ','enq: BR - BA check quiescence','enq: BR - BA run scheduler','enq: BR - BA purge storage loc','enq: BR - BA invalidate plans','enq: BR - BA protect plans','enq: ID - contention','Backup Restore Throttle sleep','Backup Restore Switch Bitmap sleep','Backup Restore Event 19778 sleep','enq: BS - Backup spare1','enq: BS - Backup spare2','enq: BS - Backup spare3','enq: BS - Backup spare4','enq: BS - Backup spare5','enq: BS - Backup spare6','enq: BS - Backup spare7','enq: BS - Backup spare8','enq: BS - Backup spare9','enq: BS - Backup spare0','enq: AB - ABMR process start/stop','enq: AB - ABMR process initialized','Auto BMR completion','Auto BMR RPC standby catchup','enq: BC - drop container group','enq: BC - create container','enq: BC - group - create container','enq: BC - drop container','enq: BC - group - create file','enq: BI - create file','enq: BI - identify file','enq: BI - delete file','enq: BZ - resize file','enq: BV - rebuild/validate group','Backup Appliance container synchronous read','Backup Appliance container synchronous write','Backup Appliance container I/O','enq: MN - contention','enq: PL - contention','enq: CP - Pluggable database resetlogs','enq: SB - logical standby metadata','enq: SB - table instantiation','Logical Standby Apply shutdown','Logical Standby pin transaction','Logical Standby dictionary build','Logical Standby Terminal Apply','Logical Standby Debug','Resolution of in-doubt txns','enq: XR - quiesce database','enq: XR - database force logging','standby query scn advance','change tracking file synchronous read','change tracking file synchronous write','change tracking file parallel write','block change tracking buffer space','CTWR media recovery checkpoint request','enq: CT - global space management','enq: CT - local space management','enq: CT - change stream ownership','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CT - CTWR process start/stop','enq: CT - reading','recovery area: computing dropped files','recovery area: computing obsolete files','recovery area: computing backed up files','recovery area: computing applied logs','enq: RS - file delete','enq: RS - record reuse','enq: RS - prevent file delete','enq: RS - prevent aging list update','enq: RS - persist alert level','enq: RS - read alert level','enq: RS - write alert level','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FD - Marker generation','enq: FD - Tablespace flashback on/off','enq: FD - Flashback coordinator','enq: FD - Flashback on/off','enq: FD - Restore point create/drop','enq: FD - Flashback logical operations','flashback free VI log','flashback log switch','enq: FW -  contention','RVWR wait for flashback copy','parallel recovery read buffer free','parallel recovery redo cache buffer free','parallel recovery change buffer free','cell smart flash unkeep','parallel recovery coord: all replies','datafile move cleanup during resize','recovery receive buffer free','recovery send buffer free','DBMS_ROLLING instruction completion','blocking txn id for DDL','transaction','inactive transaction branch','txn to complete','PMON to cleanup pseudo-branches at svc stop time','PMON to cleanup detached branches at shutdown','test long ops','latch: undo global data','undo segment recovery','unbound tx','wait for change','wait for another txn - undo rcv abort','wait for another txn - txn abort','wait for another txn - rollback to savepoint','undo_retention publish retry','enq: TA - contention','enq: TX - contention','enq: US - contention','wait for stopper event to be increased','wait for a undo record','wait for a paralle reco to abort','enq: IM - contention for blr','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: CN - race with txn','enq: CN - race with reg','enq: CN - race with init','latch: Change Notification Hash table latch','enq: CO - master slave det','enq: FE - contention','latch: change notification client cache latch','latch: SGA Logging Log Latch','latch: SGA Logging Bkt Latch','enq: MC - Securefile log','enq: MF - flush bkgnd periodic','enq: MF - creating swap in instance','enq: MF - flush space','enq: MF - flush client','enq: MF - flush prior error','enq: MF - flush destroy','latch: ILM activity tracking latch','latch: ILM access tracking extent','IM CU busy','enq: TF - contention','latch: lob segment hash table latch','latch: lob segment query latch','latch: lob segment dispenser latch','Wait for shrink lock2','Wait for shrink lock','L1 validation','Wait for TT enqueue','kttm2d','ktsambl','ktfbtgex','enq: DT - contention','enq: TS - contention','enq: FB - contention','enq: SK - contention','enq: DW - contention','enq: SU - contention','enq: TT - contention','ktm: instance recovery','instance state change','enq: SM -  contention','enq: SJ - Slave Task Cancel','Space Manager: slave messages','enq: FH - contention','latch: IM area scb latch','latch: IM area sb latch','enq: TZ - contention','enq: IN - contention','enq: ZB - contention','latch: IM seg hdr latch','latch: IM emb latch','enq: SV -  contention','index block split','kdblil wait before retrying ORA-54','dupl. cluster key','kdic_do_merge','enq: DL - contention','enq: HQ - contention','enq: HP - contention','enq: KL -  contention','enq: WG - delete fso','enq: SL - get lock','enq: SL - escalate lock','enq: SL - get lock for undo','enq: ZH - compression analysis','Compression analysis','enq: SZ - contention','enq: ZC - FS Seg contention','enq: ZD - FS CU mod','enq: SY - IM populate by other session','IM populate completion','In-Memory populate: over pga limit','row cache cleanup','row cache process','enq: QA -  contention','enq: QB -  contention','enq: QC -  contention','enq: QD -  contention','enq: QE -  contention','enq: QF -  contention','enq: QG -  contention','enq: QH -  contention','enq: QI -  contention','enq: QJ -  contention','enq: QK -  contention','enq: QL -  contention','enq: QM -  contention','enq: QN -  contention','enq: QO -  contention','enq: QP -  contention','enq: QQ -  contention','enq: QR -  contention','enq: QS -  contention','enq: QT -  contention','enq: QU -  contention','enq: QV -  contention','enq: QX -  contention','enq: QY -  contention','enq: QZ -  contention','enq: DV - contention','enq: SO - contention','enq: VA -  contention','enq: VB -  contention','enq: VC -  contention','enq: VD -  contention','enq: VE -  contention','enq: VF -  contention','enq: VG -  contention','enq: VH -  contention','enq: VI -  contention','enq: VJ -  contention','enq: VK -  contention','enq: VL -  contention','enq: VM -  contention','enq: VN -  contention','enq: VO -  contention','enq: VP -  contention','enq: VQ -  contention','enq: VR -  contention','enq: VS -  contention','enq: VT -  contention','enq: VU -  contention','enq: VV -  contention','enq: VX -  contention','enq: VY -  contention','enq: VZ -  contention','enq: EA -  contention','enq: EB -  contention','enq: EC -  contention','enq: ED -  contention','enq: EE -  contention','enq: EF -  contention','enq: EG -  contention','enq: EH -  contention','enq: EI -  contention','enq: EJ -  contention','enq: EK -  contention','enq: EL -  contention','enq: EM -  contention','enq: EN -  contention','enq: EO -  contention','enq: EP -  contention','enq: EQ -  contention','enq: ER -  contention','enq: ES -  contention','enq: ET -  contention','enq: EU -  contention','enq: EV -  contention','enq: EX -  contention','enq: EY -  contention','enq: EZ -  contention','enq: LA -  contention','enq: LB -  contention','enq: LC -  contention','enq: LD -  contention','enq: LE -  contention','enq: LF -  contention','enq: LG -  contention','enq: LH -  contention','enq: LI -  contention','enq: LJ -  contention','enq: LK -  contention','enq: LL -  contention','enq: LM -  contention','enq: LN -  contention','enq: LO -  contention','enq: LP -  contention','enq: LQ -  contention','enq: LR -  contention','enq: LS -  contention','enq: LT -  contention','enq: LU -  contention','enq: LV -  contention','enq: LX -  contention','enq: LY -  contention','enq: LZ -  contention','enq: YA -  contention','enq: YB -  contention','enq: YC -  contention','enq: YD -  contention','enq: YE -  contention','enq: YF -  contention','enq: YG -  contention','enq: YH -  contention','enq: YI -  contention','enq: YJ -  contention','enq: YK -  contention','enq: YL -  contention','enq: YM -  contention','enq: YN -  contention','enq: YO -  contention','enq: YP -  contention','enq: YQ -  contention','enq: YR -  contention','enq: YS -  contention','enq: YT -  contention','enq: YU -  contention','enq: YV -  contention','enq: YX -  contention','enq: YY -  contention','enq: YZ -  contention','enq: GA -  contention','enq: GB -  contention','enq: GC -  contention','enq: GD -  contention','enq: GE -  contention','enq: GF -  contention','enq: GG -  contention','enq: GH -  contention','enq: GI -  contention','enq: GJ -  contention','enq: GK -  contention','enq: GL -  contention','enq: GM -  contention','enq: GN -  contention','enq: GO -  contention','enq: GP -  contention','enq: GQ -  contention','enq: GR -  contention','enq: GS -  contention','enq: GT -  contention','enq: GU -  contention','enq: GV -  contention','enq: GX -  contention','enq: GY -  contention','enq: GZ -  contention','enq: NA -  contention','enq: NB -  contention','enq: NC -  contention','enq: ND -  contention','enq: NE -  contention','enq: NF -  contention','enq: NG -  contention','enq: NH -  contention','enq: NI -  contention','enq: NJ -  contention','enq: NK -  contention','enq: NL -  contention','enq: NM -  contention','enq: NN -  contention','enq: NO -  contention','enq: NP -  contention','enq: NQ -  contention','enq: NR -  contention','enq: NS -  contention','enq: NT -  contention','enq: NU -  contention','enq: NV -  contention','enq: NX -  contention','enq: NY -  contention','enq: NZ -  contention','enq: IV -  contention','enq: TP - contention','enq: RW - MV metadata contention','enq: OC - contention','enq: OL - contention','kkdlgon','kkdlsipon','kkdlhpon','kgltwait','kksfbc research','kksscl hash split','kksfbc child completion','enq: CU - contention','enq: AE - lock','enq: PF - contention','enq: IL - contention','enq: CL - drop label','enq: CL - compare labels','enq: SG - OLS Add Group','enq: SG - OLS Create Group','enq: SG - OLS Drop Group','enq: SG - OLS Alter Group Parent','enq: OP - OLS Store user entries','enq: OP - OLS Cleanup unused profiles','enq: CC - decryption','enq: MK - contention','enq: OW - initialization','enq: OW - termination','enq: RK - set key','enq: HC - HSM cache write','enq: HC - HSM cache read','enq: RL - RAC wallet lock','enq: ZZ - update hash tables','Failed Logon Delay','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZS - excl access to spill audit file','enq: PA - modify a privilege capture','enq: PA - read a privilege capture','enq: PC - update privilege capture info','enq: PC - read privilege capture info','enq: KZ -  contention','enq: DX - contention','enq: DR - contention','pending global transaction(s)','free global transaction table entry','library cache revalidation','library cache shutdown','BFILE closure','BFILE check if exists','BFILE check if open','BFILE get length','BFILE get name object','BFILE get path object','BFILE open','BFILE internal seek','waiting to get CAS latch','waiting to get RM CAS latch','resmgr:internal state cleanup','xdb schema cache initialization','ASM cluster file access','CSS initialization','CSS group registration','CSS group membership query','CSS operation: data query','CSS operation: data update','CSS Xgrp shared operation','CSS operation: query','CSS operation: action','CSS operation: diagnostic','GIPC operation: dump','GPnP Initialization','GPnP Termination','GPnP Get Item','GPnP Set Item','GPnP Get Error','ADR file lock','ADR block file read','ADR block file write','CRS call completion','dispatcher shutdown','listener registration dump','latch: virtual circuit queues','listen endpoint status','OJVM: Generic','select wait','jobq slave shutdown wait','jobq slave TJ process wait','job scheduler coordinator slave wait','enq: JD - contention','enq: JQ - contention','enq: OD - Serializing DDLs','RAC referential constraint parent lock','RAC: constraint DDL lock','kkshgnc reloop','optimizer stats update retry','wait active processes','SUPLOG PL wait for inflight pragma-d PL/SQL','enq: MD - contention','enq: MS - contention','wait for kkpo ref-partitioning *TEST EVENT*','enq: AP - contention','PX slave connection','PX slave release','PX Send Wait','PX qref latch','PX server shutdown','PX create server','PX signal server','PX Deq Credit: free buffer','PX Deq: Test for msg','PX Deq: Test for credit','PX Deq: Signal ACK RSG','PX Deq: Signal ACK EXT','PX Deq: reap credit','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX Deq Credit: Session Stats','PX Deq: Slave Session Stats','PX Deq: Slave Join Frag','enq: PI - contention','enq: PS - contention','latch: parallel query alloc buffer','kxfxse','kxfxsp','PX Deq: Table Q qref','PX Deq: Table Q Get Keys','PX Deq: Table Q Close','GV$: slave acquisition retry wait time','PX hash elem being inserted','latch: PX hash array latch','enq: AY - contention','enq: TO - contention','enq: IT - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: RD - RAC load','enq: KV - key vector creation coordination','timer in sksawat','scginq AST call','kupp process wait','Kupp process shutdown','Data Pump slave startup','Data Pump slave init','enq: KP - contention','Replication Dequeue ','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','enq: SR - contention','REPL Capture/Apply: database startup','REPL Capture/Apply: miscellaneous','enq: SI - contention','REPL Capture/Apply: RAC inter-instance ack','enq: IA - contention','enq: JI - contention','qerex_gdml','enq: AT - contention','opishd','kpodplck wait before retrying ORA-54','enq: CQ - contention','wait for EMON to spawn','EMON termination','Emon coordinator startup','enq: SE - contention','tsm with timeout','Streams AQ: waiting for busy instance for instance_name','enq: TQ - TM contention','enq: TQ - DDL contention','enq: TQ - INI contention','enq: TQ - DDL-INI contention','enq: TQ - INI sq contention','enq: TQ - MC free sync at cross job start','enq: TQ - MC free sync at cross job stop','enq: TQ - MC free sync at cross job end','enq: TQ - MC free sync at export subshard','enq: TQ -  sq TM contention','AQ reload SO release','enq: RQ - Enqueue commit uncached','enq: RQ - Enqueue commit cached','enq: RQ - Dequeue update scn','enq: RQ - Parallel cross update scn','enq: RQ - Cross update scn','enq: RQ - Trucate subshard','enq: RQ - Cross export subshard','enq: RQ - Cross import subshard','enq: RQ - Free shadow shard','enq: RQ - AQ indexed cached commit','enq: RQ - AQ uncached commit WM update','enq: RQ - AQ uncached dequeue','enq: RQ - AQ Eq Ptn Mapping','enq: RQ - AQ Dq Ptn Mapping','enq: RQ - AQ Trnc mem free','enq: RQ - AQ Trnc mem free remote','enq: RQ - AQ Trnc mem free by LB','enq: RQ - AQ Trnc mem free by CP','enq: RQ - AQ Enq commit incarnation wrap','enq: RQ - AQ Rule evaluation segment load','AQ propagation connection','enq: DP - contention','enq: MH - contention','enq: ML - contention','enq: PH - contention','enq: SF - contention','enq: XH - contention','enq: WA - contention','Streams AQ: QueueTable kgl locks','AQ spill debug idle','AQ master shutdown','AQPC: new master','AQ Background Master: slave start','enq: AQ - QPT fg map dqpt','enq: AQ - QPT fg map qpt','enq: PQ - QPT add qpt','enq: PQ - QPT drop qpt','enq: PQ - QPT add dqpt','enq: PQ - QPT drop dqpt','enq: PQ - QPT add qpt fg','enq: PQ - QPT add dqpt fg','enq: PQ - QPT Trunc','enq: PQ - QPT LB Trunc sync','enq: PQ - QPT XSTART Trunc sync','AQ master: time mgmt/task cleanup','AQ slave: time mgmt/task cleanup','enq: BA - SUBBMAP contention','AQ:non durable subscriber add or drop','enq: CX - TEXT: Index Specific Lock','enq: OT - TEXT: Generic Lock','XDB SGA initialization','enq: XC - XDB Configuration','NFS read delegation outstanding','Data Guard Broker Wait','enq: RF - synch: DG Broker metadata','enq: RF - atomicity','enq: RF - synchronization: aifo master','enq: RF - new AI','enq: RF - synchronization: critical ai','enq: RF - RF - Database Automatic Disable','enq: RF - FSFO Observer Heartbeat','enq: RF - DG Broker Current File ID','enq: RF - FSFO Primary Shutdown suspended','enq: RF - Broker State Lock','enq: RF - FSFO string buffer','PX Deq: OLAP Update Reply','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Close','OLAP Parallel Type Deq','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Temp Grew','OLAP Null PQ Reason','OLAP Aggregate Master Enq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Client Deq','enq: AW - AW$ table lock','enq: AW - AW state lock','enq: AW - user access for AW','enq: AW - AW generation lock','enq: AG - contention','enq: AO - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhiClose','enq: OQ - xsoqhistrecb','enq: IZ -  contention','enq: AM - client registration','enq: AM - shutdown','enq: AM - rollback COD reservation','enq: AM - background COD reservation','enq: AM - ASM cache freeze','enq: AM - ASM ACD Relocation','enq: AM - group use','enq: AM - group block','enq: AM - ASM File Destroy','enq: AM - ASM User','enq: AM - ASM Password File Update','enq: AM - ASM Amdu Dump','enq: AM - disk offline','enq: AM - ASM reserved','enq: AM - block repair','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM file relocation','enq: AM - ASM SR relocation','enq: AM - ASM Grow ACD','enq: AM - ASM DD update SrRloc','enq: AM - ASM file chown','enq: AM - Register with IOServer','enq: AM - ASM metadata replication','enq: AM - SR slice Clear/Mark','enq: AM - Enable Remote ASM','enq: AM - Disable Remote ASM','enq: AM - Credential creation','enq: AM - Credential deletion','enq: AM - ASM file access req','enq: AM - ASM client operation','enq: AM - ASM client check','enq: AM - ASM ATB COD creation','enq: AM - Create default DG key in OCR','enq: AM - ASM Audit file Delete','enq: AM - ASM Audit file Cleanup','enq: AM - ASM VAT migration','enq: AM - Update SR nomark flag','enq: AM - ASM VAL cache','enq: AM - ASM SR Segment Reuse','ASM internal hang test','ASM Instance startup','buffer busy','buffer freelistbusy','buffer rememberlist busy','buffer writeList full','no free buffers','buffer write wait','buffer invalidation wait','buffer dirty disabled','ASM metadata cache frozen','enq: FZ -  contention','enq: CM - gate','enq: CM - instance','enq: CM - diskgroup dismount','enq: XQ - recovery','enq: XQ - relocation','enq: XQ - purification','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: DO - disk online','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','extent map load/unlock','enq: XL - fault extent map','Sync ASM rebalance','Sync ASM discovery','enq: DG - contention','enq: DD - contention','enq: HD - contention','enq: DQ -  contention','enq: DN - contention','Cluster stabilization wait','Cluster Suspension wait','ASM background starting','ASM db client exists','ASM file metadata operation','ASM network foreground exits','enq: XB -  contention','enq: FA - access file','enq: RX - relocate extent','enq: RX - unlock extent','enq: AR -  contention','enq: AH -  contention','log write(odd)','log write(even)','checkpoint advanced','enq: FR - contention','enq: FR - use the thread','enq: FR - recover the thread','enq: FG - serialize ACD relocate','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FX - issue ACD Xtnt Relocation CIC','rollback operations block full','rollback operations active','enq: RB - contention','ASM: MARK subscribe to msg channel','ASM: Send msg to MARK','call','enq: IC - IOServer clientID','enq: IF - file open','enq: IF - file close','enq: PT - contention','enq: PT - ASM Storage May Split','enq: PM -  contention','ASM PST operation','global cache busy','lock release pending','dma prepare busy','GCS lock cancel','GCS lock open S','GCS lock open X','GCS lock open','GCS lock cvt S','GCS lock cvt X','GCS lock esc X','GCS lock esc','GCS recovery lock open','GCS recovery lock convert','kfcl: instance recovery','no free locks','lock close','enq: KE -  contention','enq: KQ - access ASM attribute','ASM Volume Background','ASM volume directive send','ASM Volume Resource Action','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AV - AVD client registration','enq: AV - add/enable first volume in DG','ASM: OFS Cluster membership update','ASM Scrubbing I/O','enq: WF - contention','enq: WT - contention','enq: WP - contention','enq: FU - contention','enq: MW - contention','AWR Flush','AWR Metric Capture','enq: TB - SQL Tuning Base Cache Update','enq: TB - SQL Tuning Base Cache Load','enq: SH - contention','enq: AF - task serialization','MMON slave messages','MMON (Lite) shutdown','enq: MO - contention','enq: TL - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: RR - contention','WCR: RAC message context busy','WCR: capture file IO write','WCR: Sync context busy','latch: WCR: sync','latch: WCR: processes HT','enq: RA - RT ADDM flood control','enq: JS - contention','enq: JS - job run lock - synchronize','enq: JS - job recov lock','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - q mem clnup lck','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - wdw op','enq: JS - evt notify','enq: JS - aq sync','enq: XD - ASM disk drop/add','enq: XD - ASM disk ONLINE','enq: XD - ASM disk OFFLINE','cell worker online completion','cell worker retry ','cell manager cancel work request','opening cell offload device','ioctl to cell offload device','reap block level offload operations','CDB: Per Instance Query for PDB Info','enq: PB - PDB Lock','secondary event' )
  AND se.wait_class='Other'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'latch free' as e4,
'wait list latch free' as e11,
'latch: call allocation' as e16,
'latch: session allocation' as e17,
'enq: PR - contention' as e20,
'latch: messages' as e41,
'rdbms ipc reply' as e43,
'latch: enqueue hash chains' as e44,
'asynch descriptor resize' as e48,
'reliable message' as e56,
'latch: active service list' as e84,
'enq: CF - contention' as e214,
'latch: cache buffers lru chain' as e221,
'latch: checkpoint queue latch' as e223,
'latch: cache buffer handles' as e224,
'buffer deadlock' as e227,
'enq: CR - block range reuse ckpt' as e238,
'latch: object queue header operation' as e240,
'ARCH wait for process start 3' as e302,
'LGWR wait for redo copy' as e311,
'latch: redo allocation' as e312,
'enq: WL - contention' as e320,
'Backup Restore Throttle sleep' as e369,
'latch: undo global data' as e465,
'enq: TX - contention' as e474,
'instance state change' as e520,
'kksfbc child completion' as e743,
'ADR file lock' as e808,
'ADR block file read' as e809,
'ADR block file write' as e810,
'latch: virtual circuit queues' as e814,
'OJVM: Generic' as e816,
'enq: JS - queue lock' as e1167
 )
  )
order by snap_id
;



SELECT *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, sys.DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  --and SE.EVENT_NAME in ( 'null event','events in waitclass Other','enq: WM - WLM Plan activation','latch free','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','unspecified wait event','latch activity','wait list latch activity','wait list latch free','global enqueue expand wait','free process state object','inactive session','process terminate','latch: call allocation','latch: session allocation','check CPU wait times','enq: CI - contention','enq: PR - contention','enq: AK -  contention','enq: XK -  contention','enq: DI -  contention','enq: RM -  contention','enq: BO -  contention','ges resource enqueue open retry sleep','ksim generic wait event','debugger command','ksdxexeother','ksdxexeotherwait','latch: ksm sga alloc latch','defer SGA allocation slave','SGA Allocator termination','enq: PE - contention','enq: PG - contention','ksbsrv','ksbcic','process startup','process shutdown','prior spawner clean up','latch: messages','rdbms ipc message block','rdbms ipc reply','latch: enqueue hash chains','enq: FP - global fob contention','enq: RE - block repair contention','enq: BM - clonedb bitmap file write','asynch descriptor resize','enq: FO - file system operation contention','imm op','slave exit','enq: KM - contention','enq: KT - contention','enq: CA - contention','enq: KD - determine DBRM master','reliable message','broadcast mesg queue transition','broadcast mesg recovery queue transition','KSV master wait','master exit','ksv slave avail wait','enq: PV - syncstart','enq: PV - syncshut','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SX - contention 5','enq: SX - contention 6','first spare wait event','second spare wait event','IPC send completion sync','OSD IPC library','IPC wait for name service busy','IPC busy async request','IPC waiting for OSD resources','ksxr poll remote instances','ksxr wait for mount shared','DBMS_LDAP: LDAP operation ','wait for FMON to come up','enq: FM - contention','enq: XY - contention','set director factor wait','latch: active service list','enq: AS - service activation','enq: PD - contention','oracle thread bootstrap','os thread creation','cleanup of aborted process','enq: XM -  contention','enq: RU - contention','enq: RU - waiting','rolling migration: cluster quiesce','LMON global data update','process diagnostic dump','enq: MX - sync storage server info','master diskmon startup','master diskmon read','DSKM to complete cell health check','pmon dblkr tst event','pmon cleanup on exit','latch: ksolt alloc','lightweight thread operation','enq: ZX - repopulation file write','DIAG lock acquisition','latch: ges resource hash list','DFS lock handle','ges LMD to shutdown','ges client process to exit','ges global resource directory to be frozen','ges resource directory to be unfrozen','gcs resource directory to be unfrozen','ges LMD to inherit communication channels','ges lmd sync during reconfig','ges wait for lmon to be ready','ges cgs registration','wait for master scn','ges yield cpu in reconfig','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges lms sync during dynamic remastering and reconfig','ges LMON to join CGS group','ges pmon to exit','ges lmd and pmon to attach','gcs drm freeze begin','gcs retry nowait latch get','gcs remastering wait for read latch','ges cached resource cleanup','ges generic event','ges retry query node','ges process with outstanding i/o','ges user error','ges enter server mode','gcs enter server mode','gcs drm freeze in enter server mode','gcs ddet enter server mode','ges cancel','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges master to get established for SCN op','ges LMON to get to FTDONE ','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges inquiry response','ges reusing os pid','ges LMON for send queues','ges LMD suspend for testing event','ges performance test completion','kjbopen wait for recovery domain attach','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','ges RMS0 retry add redo log','readable standby redo apply remastering','ges DFS hang analysis phase 2 acks','ges/gcs diag dump','global plug and play automatic resource creation','gcs lmon dirtydetach step completion','recovery instance recovery completion','ack for a broadcasted res from a remote instance','latch: kjci process context latch','latch: kjci request sequence latch','DLM cross inst call completion','DLM: shared instance mode init','enq: KI - contention','latch: kjoeq omni enqueue hash bucket latch','DLM enqueue copy completion','latch: kjoer owner hash bucket','DLM Omni Enq Owner replication','KJC: Wait for msg sends to complete','ges message buffer allocation','kjctssqmg: quick message send wait','kjctcisnd: Queue/Send client message','gcs domain validation','latch: gcs resource hash','affinity expansion in replay','wait for sync ack','wait for verification ack','wait for assert messages to be sent','wait for scn ack','lms flush message acks','name-service call wait','CGS wait for IPC msg','kjxgrtest','IMR mount phase II completion','IMR disk votes','IMR rr lock release','IMR net-check message ack','IMR rr update','IMR membership resolution','IMR CSS join retry','CGS skgxn join retry','gcs to be enabled','gcs log flush sync','enq: PP -  contention','enq: HM -  contention','GCR ctx lock acquisition','GCR CSS group lock','GCR CSS group join','GCR CSS group leave','GCR CSS group update','GCR CSS group query','enq: AC - acquiring partition id','SGA: allocation forcing component growth','SGA: sga_target resize','enq: SC -  contention','control file heartbeat','control file diagnostic dump','enq: CF - contention','enq: SW - contention','enq: DS - contention','enq: TC - contention','enq: TC - contention2','buffer exterminate','buffer resize','latch: cache buffers lru chain','enq: PW - perwarm status in dbw0','latch: checkpoint queue latch','latch: cache buffer handles','kcbzps','DBWR range invalidation sync','buffer deadlock','buffer latch','cr request retry','writes stopped by instance recovery or database suspension','lock escalate retry','lock deadlock retry','prefetch warmup block being transferred','recovery buffer pinned','TSE master key rekey','TSE SSO wallet reopen','force-cr-override flush','enq: CR - block range reuse ckpt','wait for MTTR advisory state object','latch: object queue header operation','retry cftxn during close','get branch/thread/sequence enqueue','enq: WL - Test access/locking','Data Guard server operation completion','FAL archive wait 1 sec for REOPEN minimum','TEST: action sync','TEST: action hang','RSGA: RAC reconfiguration','enq: WL - RAC-wide SGA initialize','enq: WL - RAC-wide SGA write','enq: WL - RAC-wide SGA dump','LGWR ORL/NoExp FAL archival','enq: WS -  contention','MRP wait on process start','MRP wait on process restart','MRP wait on startup clear','MRP inactivation','MRP termination','MRP state inspection','MRP wait on archivelog arrival','MRP wait on archivelog archival','enq: WL - Far Sync Fail Over','Monitor testing','enq: WL - redo_db table update','enq: WL - redo_db table query','enq: WL - redo_log table update','enq: WL - redo_log table query','enq: PY - AVM RTA access instance','enq: PY - AVM RTA access database','enq: PY - AVM RTA access database 2','log switch/archive','enq: WL - Switchover To Primary','ARCH wait on c/f tx acquire 1','RFS attach','RFS create','RFS close','RFS announce','RFS register','RFS detach','RFS ping','RFS dispatch','enq: WL - RFS global state contention','LGWR simulation latency wait','LNS simulation latency wait','ASYNC Remote Write','SYNC Remote Write','ARCH Remote Write','Redo Transport Attach','Redo Transport Detach','Redo Transport Open','Redo Transport Close','Redo Transport Ping','Remote SYNC Ping','Redo Transport Slave Startup','Redo Transport Slave Shutdown','Redo Writer Remote Sync Notify','Redo Writer Remote Sync Complete','Redo Transport MISC','Data Guard: RFS disk I/O','ARCH wait for process start 1','ARCH wait for process death 1','ARCH wait for process start 3','Data Guard: process exit','Data Guard: process clean up','LGWR-LNS wait on channel','enq: WR - contention','Redo transport testing','enq: RZ - add element','enq: RZ - remove element','Image redo gen delay','LGWR wait for redo copy','latch: redo allocation','log file switch (clearing log file)','target log write size','LGWR any worker group','LGWR all worker groups','LGWR worker group ordering','LGWR intra group sync','LGWR intra group IO completion','enq: WL - contention','enq: RN - contention','DFS db file lock','enq: DF - contention','enq: IS - contention','enq: IP - open/close PDB','enq: FS - contention','enq: FS - online log operation','enq: DM - contention','enq: RP - contention','latch: gc element','enq: RT - contention','enq: RT - thread internal enable/disable','enq: IR - contention','enq: IR - contention2','enq: IR - global serialization','enq: IR - local serialization','enq: IR - arbitrate instance recovery','enq: MR - contention','enq: MR - standby role transition','enq: MR - multi instance redo apply','enq: MR - any role transition','enq: MR - PDB open','enq: MR - datafile online','enq: MR - adg instance recovery','shutdown after switchover to standby','cancel media recovery on switchover','parallel recovery coord wait for reply','parallel recovery coord send blocked','parallel recovery slave wait for change','enq: BR - file shrink','enq: BR - proxy-copy','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - space info datafile hdr update','enq: BR - request autobackup','enq: BR - perform autobackup','enq: BR - BA lock db','enq: BR - BA lock storage loc','enq: BR - BA lock timer queue','enq: BR - BA lock scheduler','enq: BR - BA lock API','enq: BR - BA quiesce storage ','enq: BR - BA check quiescence','enq: BR - BA run scheduler','enq: BR - BA purge storage loc','enq: BR - BA invalidate plans','enq: BR - BA protect plans','enq: ID - contention','Backup Restore Throttle sleep','Backup Restore Switch Bitmap sleep','Backup Restore Event 19778 sleep','enq: BS - Backup spare1','enq: BS - Backup spare2','enq: BS - Backup spare3','enq: BS - Backup spare4','enq: BS - Backup spare5','enq: BS - Backup spare6','enq: BS - Backup spare7','enq: BS - Backup spare8','enq: BS - Backup spare9','enq: BS - Backup spare0','enq: AB - ABMR process start/stop','enq: AB - ABMR process initialized','Auto BMR completion','Auto BMR RPC standby catchup','enq: BC - drop container group','enq: BC - create container','enq: BC - group - create container','enq: BC - drop container','enq: BC - group - create file','enq: BI - create file','enq: BI - identify file','enq: BI - delete file','enq: BZ - resize file','enq: BV - rebuild/validate group','Backup Appliance container synchronous read','Backup Appliance container synchronous write','Backup Appliance container I/O','enq: MN - contention','enq: PL - contention','enq: CP - Pluggable database resetlogs','enq: SB - logical standby metadata','enq: SB - table instantiation','Logical Standby Apply shutdown','Logical Standby pin transaction','Logical Standby dictionary build','Logical Standby Terminal Apply','Logical Standby Debug','Resolution of in-doubt txns','enq: XR - quiesce database','enq: XR - database force logging','standby query scn advance','change tracking file synchronous read','change tracking file synchronous write','change tracking file parallel write','block change tracking buffer space','CTWR media recovery checkpoint request','enq: CT - global space management','enq: CT - local space management','enq: CT - change stream ownership','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CT - CTWR process start/stop','enq: CT - reading','recovery area: computing dropped files','recovery area: computing obsolete files','recovery area: computing backed up files','recovery area: computing applied logs','enq: RS - file delete','enq: RS - record reuse','enq: RS - prevent file delete','enq: RS - prevent aging list update','enq: RS - persist alert level','enq: RS - read alert level','enq: RS - write alert level','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FD - Marker generation','enq: FD - Tablespace flashback on/off','enq: FD - Flashback coordinator','enq: FD - Flashback on/off','enq: FD - Restore point create/drop','enq: FD - Flashback logical operations','flashback free VI log','flashback log switch','enq: FW -  contention','RVWR wait for flashback copy','parallel recovery read buffer free','parallel recovery redo cache buffer free','parallel recovery change buffer free','cell smart flash unkeep','parallel recovery coord: all replies','datafile move cleanup during resize','recovery receive buffer free','recovery send buffer free','DBMS_ROLLING instruction completion','blocking txn id for DDL','transaction','inactive transaction branch','txn to complete','PMON to cleanup pseudo-branches at svc stop time','PMON to cleanup detached branches at shutdown','test long ops','latch: undo global data','undo segment recovery','unbound tx','wait for change','wait for another txn - undo rcv abort','wait for another txn - txn abort','wait for another txn - rollback to savepoint','undo_retention publish retry','enq: TA - contention','enq: TX - contention','enq: US - contention','wait for stopper event to be increased','wait for a undo record','wait for a paralle reco to abort','enq: IM - contention for blr','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: CN - race with txn','enq: CN - race with reg','enq: CN - race with init','latch: Change Notification Hash table latch','enq: CO - master slave det','enq: FE - contention','latch: change notification client cache latch','latch: SGA Logging Log Latch','latch: SGA Logging Bkt Latch','enq: MC - Securefile log','enq: MF - flush bkgnd periodic','enq: MF - creating swap in instance','enq: MF - flush space','enq: MF - flush client','enq: MF - flush prior error','enq: MF - flush destroy','latch: ILM activity tracking latch','latch: ILM access tracking extent','IM CU busy','enq: TF - contention','latch: lob segment hash table latch','latch: lob segment query latch','latch: lob segment dispenser latch','Wait for shrink lock2','Wait for shrink lock','L1 validation','Wait for TT enqueue','kttm2d','ktsambl','ktfbtgex','enq: DT - contention','enq: TS - contention','enq: FB - contention','enq: SK - contention','enq: DW - contention','enq: SU - contention','enq: TT - contention','ktm: instance recovery','instance state change','enq: SM -  contention','enq: SJ - Slave Task Cancel','Space Manager: slave messages','enq: FH - contention','latch: IM area scb latch','latch: IM area sb latch','enq: TZ - contention','enq: IN - contention','enq: ZB - contention','latch: IM seg hdr latch','latch: IM emb latch','enq: SV -  contention','index block split','kdblil wait before retrying ORA-54','dupl. cluster key','kdic_do_merge','enq: DL - contention','enq: HQ - contention','enq: HP - contention','enq: KL -  contention','enq: WG - delete fso','enq: SL - get lock','enq: SL - escalate lock','enq: SL - get lock for undo','enq: ZH - compression analysis','Compression analysis','enq: SZ - contention','enq: ZC - FS Seg contention','enq: ZD - FS CU mod','enq: SY - IM populate by other session','IM populate completion','In-Memory populate: over pga limit','row cache cleanup','row cache process','enq: QA -  contention','enq: QB -  contention','enq: QC -  contention','enq: QD -  contention','enq: QE -  contention','enq: QF -  contention','enq: QG -  contention','enq: QH -  contention','enq: QI -  contention','enq: QJ -  contention','enq: QK -  contention','enq: QL -  contention','enq: QM -  contention','enq: QN -  contention','enq: QO -  contention','enq: QP -  contention','enq: QQ -  contention','enq: QR -  contention','enq: QS -  contention','enq: QT -  contention','enq: QU -  contention','enq: QV -  contention','enq: QX -  contention','enq: QY -  contention','enq: QZ -  contention','enq: DV - contention','enq: SO - contention','enq: VA -  contention','enq: VB -  contention','enq: VC -  contention','enq: VD -  contention','enq: VE -  contention','enq: VF -  contention','enq: VG -  contention','enq: VH -  contention','enq: VI -  contention','enq: VJ -  contention','enq: VK -  contention','enq: VL -  contention','enq: VM -  contention','enq: VN -  contention','enq: VO -  contention','enq: VP -  contention','enq: VQ -  contention','enq: VR -  contention','enq: VS -  contention','enq: VT -  contention','enq: VU -  contention','enq: VV -  contention','enq: VX -  contention','enq: VY -  contention','enq: VZ -  contention','enq: EA -  contention','enq: EB -  contention','enq: EC -  contention','enq: ED -  contention','enq: EE -  contention','enq: EF -  contention','enq: EG -  contention','enq: EH -  contention','enq: EI -  contention','enq: EJ -  contention','enq: EK -  contention','enq: EL -  contention','enq: EM -  contention','enq: EN -  contention','enq: EO -  contention','enq: EP -  contention','enq: EQ -  contention','enq: ER -  contention','enq: ES -  contention','enq: ET -  contention','enq: EU -  contention','enq: EV -  contention','enq: EX -  contention','enq: EY -  contention','enq: EZ -  contention','enq: LA -  contention','enq: LB -  contention','enq: LC -  contention','enq: LD -  contention','enq: LE -  contention','enq: LF -  contention','enq: LG -  contention','enq: LH -  contention','enq: LI -  contention','enq: LJ -  contention','enq: LK -  contention','enq: LL -  contention','enq: LM -  contention','enq: LN -  contention','enq: LO -  contention','enq: LP -  contention','enq: LQ -  contention','enq: LR -  contention','enq: LS -  contention','enq: LT -  contention','enq: LU -  contention','enq: LV -  contention','enq: LX -  contention','enq: LY -  contention','enq: LZ -  contention','enq: YA -  contention','enq: YB -  contention','enq: YC -  contention','enq: YD -  contention','enq: YE -  contention','enq: YF -  contention','enq: YG -  contention','enq: YH -  contention','enq: YI -  contention','enq: YJ -  contention','enq: YK -  contention','enq: YL -  contention','enq: YM -  contention','enq: YN -  contention','enq: YO -  contention','enq: YP -  contention','enq: YQ -  contention','enq: YR -  contention','enq: YS -  contention','enq: YT -  contention','enq: YU -  contention','enq: YV -  contention','enq: YX -  contention','enq: YY -  contention','enq: YZ -  contention','enq: GA -  contention','enq: GB -  contention','enq: GC -  contention','enq: GD -  contention','enq: GE -  contention','enq: GF -  contention','enq: GG -  contention','enq: GH -  contention','enq: GI -  contention','enq: GJ -  contention','enq: GK -  contention','enq: GL -  contention','enq: GM -  contention','enq: GN -  contention','enq: GO -  contention','enq: GP -  contention','enq: GQ -  contention','enq: GR -  contention','enq: GS -  contention','enq: GT -  contention','enq: GU -  contention','enq: GV -  contention','enq: GX -  contention','enq: GY -  contention','enq: GZ -  contention','enq: NA -  contention','enq: NB -  contention','enq: NC -  contention','enq: ND -  contention','enq: NE -  contention','enq: NF -  contention','enq: NG -  contention','enq: NH -  contention','enq: NI -  contention','enq: NJ -  contention','enq: NK -  contention','enq: NL -  contention','enq: NM -  contention','enq: NN -  contention','enq: NO -  contention','enq: NP -  contention','enq: NQ -  contention','enq: NR -  contention','enq: NS -  contention','enq: NT -  contention','enq: NU -  contention','enq: NV -  contention','enq: NX -  contention','enq: NY -  contention','enq: NZ -  contention','enq: IV -  contention','enq: TP - contention','enq: RW - MV metadata contention','enq: OC - contention','enq: OL - contention','kkdlgon','kkdlsipon','kkdlhpon','kgltwait','kksfbc research','kksscl hash split','kksfbc child completion','enq: CU - contention','enq: AE - lock','enq: PF - contention','enq: IL - contention','enq: CL - drop label','enq: CL - compare labels','enq: SG - OLS Add Group','enq: SG - OLS Create Group','enq: SG - OLS Drop Group','enq: SG - OLS Alter Group Parent','enq: OP - OLS Store user entries','enq: OP - OLS Cleanup unused profiles','enq: CC - decryption','enq: MK - contention','enq: OW - initialization','enq: OW - termination','enq: RK - set key','enq: HC - HSM cache write','enq: HC - HSM cache read','enq: RL - RAC wallet lock','enq: ZZ - update hash tables','Failed Logon Delay','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZS - excl access to spill audit file','enq: PA - modify a privilege capture','enq: PA - read a privilege capture','enq: PC - update privilege capture info','enq: PC - read privilege capture info','enq: KZ -  contention','enq: DX - contention','enq: DR - contention','pending global transaction(s)','free global transaction table entry','library cache revalidation','library cache shutdown','BFILE closure','BFILE check if exists','BFILE check if open','BFILE get length','BFILE get name object','BFILE get path object','BFILE open','BFILE internal seek','waiting to get CAS latch','waiting to get RM CAS latch','resmgr:internal state cleanup','xdb schema cache initialization','ASM cluster file access','CSS initialization','CSS group registration','CSS group membership query','CSS operation: data query','CSS operation: data update','CSS Xgrp shared operation','CSS operation: query','CSS operation: action','CSS operation: diagnostic','GIPC operation: dump','GPnP Initialization','GPnP Termination','GPnP Get Item','GPnP Set Item','GPnP Get Error','ADR file lock','ADR block file read','ADR block file write','CRS call completion','dispatcher shutdown','listener registration dump','latch: virtual circuit queues','listen endpoint status','OJVM: Generic','select wait','jobq slave shutdown wait','jobq slave TJ process wait','job scheduler coordinator slave wait','enq: JD - contention','enq: JQ - contention','enq: OD - Serializing DDLs','RAC referential constraint parent lock','RAC: constraint DDL lock','kkshgnc reloop','optimizer stats update retry','wait active processes','SUPLOG PL wait for inflight pragma-d PL/SQL','enq: MD - contention','enq: MS - contention','wait for kkpo ref-partitioning *TEST EVENT*','enq: AP - contention','PX slave connection','PX slave release','PX Send Wait','PX qref latch','PX server shutdown','PX create server','PX signal server','PX Deq Credit: free buffer','PX Deq: Test for msg','PX Deq: Test for credit','PX Deq: Signal ACK RSG','PX Deq: Signal ACK EXT','PX Deq: reap credit','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX Deq Credit: Session Stats','PX Deq: Slave Session Stats','PX Deq: Slave Join Frag','enq: PI - contention','enq: PS - contention','latch: parallel query alloc buffer','kxfxse','kxfxsp','PX Deq: Table Q qref','PX Deq: Table Q Get Keys','PX Deq: Table Q Close','GV$: slave acquisition retry wait time','PX hash elem being inserted','latch: PX hash array latch','enq: AY - contention','enq: TO - contention','enq: IT - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: RD - RAC load','enq: KV - key vector creation coordination','timer in sksawat','scginq AST call','kupp process wait','Kupp process shutdown','Data Pump slave startup','Data Pump slave init','enq: KP - contention','Replication Dequeue ','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','enq: SR - contention','REPL Capture/Apply: database startup','REPL Capture/Apply: miscellaneous','enq: SI - contention','REPL Capture/Apply: RAC inter-instance ack','enq: IA - contention','enq: JI - contention','qerex_gdml','enq: AT - contention','opishd','kpodplck wait before retrying ORA-54','enq: CQ - contention','wait for EMON to spawn','EMON termination','Emon coordinator startup','enq: SE - contention','tsm with timeout','Streams AQ: waiting for busy instance for instance_name','enq: TQ - TM contention','enq: TQ - DDL contention','enq: TQ - INI contention','enq: TQ - DDL-INI contention','enq: TQ - INI sq contention','enq: TQ - MC free sync at cross job start','enq: TQ - MC free sync at cross job stop','enq: TQ - MC free sync at cross job end','enq: TQ - MC free sync at export subshard','enq: TQ -  sq TM contention','AQ reload SO release','enq: RQ - Enqueue commit uncached','enq: RQ - Enqueue commit cached','enq: RQ - Dequeue update scn','enq: RQ - Parallel cross update scn','enq: RQ - Cross update scn','enq: RQ - Trucate subshard','enq: RQ - Cross export subshard','enq: RQ - Cross import subshard','enq: RQ - Free shadow shard','enq: RQ - AQ indexed cached commit','enq: RQ - AQ uncached commit WM update','enq: RQ - AQ uncached dequeue','enq: RQ - AQ Eq Ptn Mapping','enq: RQ - AQ Dq Ptn Mapping','enq: RQ - AQ Trnc mem free','enq: RQ - AQ Trnc mem free remote','enq: RQ - AQ Trnc mem free by LB','enq: RQ - AQ Trnc mem free by CP','enq: RQ - AQ Enq commit incarnation wrap','enq: RQ - AQ Rule evaluation segment load','AQ propagation connection','enq: DP - contention','enq: MH - contention','enq: ML - contention','enq: PH - contention','enq: SF - contention','enq: XH - contention','enq: WA - contention','Streams AQ: QueueTable kgl locks','AQ spill debug idle','AQ master shutdown','AQPC: new master','AQ Background Master: slave start','enq: AQ - QPT fg map dqpt','enq: AQ - QPT fg map qpt','enq: PQ - QPT add qpt','enq: PQ - QPT drop qpt','enq: PQ - QPT add dqpt','enq: PQ - QPT drop dqpt','enq: PQ - QPT add qpt fg','enq: PQ - QPT add dqpt fg','enq: PQ - QPT Trunc','enq: PQ - QPT LB Trunc sync','enq: PQ - QPT XSTART Trunc sync','AQ master: time mgmt/task cleanup','AQ slave: time mgmt/task cleanup','enq: BA - SUBBMAP contention','AQ:non durable subscriber add or drop','enq: CX - TEXT: Index Specific Lock','enq: OT - TEXT: Generic Lock','XDB SGA initialization','enq: XC - XDB Configuration','NFS read delegation outstanding','Data Guard Broker Wait','enq: RF - synch: DG Broker metadata','enq: RF - atomicity','enq: RF - synchronization: aifo master','enq: RF - new AI','enq: RF - synchronization: critical ai','enq: RF - RF - Database Automatic Disable','enq: RF - FSFO Observer Heartbeat','enq: RF - DG Broker Current File ID','enq: RF - FSFO Primary Shutdown suspended','enq: RF - Broker State Lock','enq: RF - FSFO string buffer','PX Deq: OLAP Update Reply','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Close','OLAP Parallel Type Deq','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Temp Grew','OLAP Null PQ Reason','OLAP Aggregate Master Enq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Client Deq','enq: AW - AW$ table lock','enq: AW - AW state lock','enq: AW - user access for AW','enq: AW - AW generation lock','enq: AG - contention','enq: AO - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhiClose','enq: OQ - xsoqhistrecb','enq: IZ -  contention','enq: AM - client registration','enq: AM - shutdown','enq: AM - rollback COD reservation','enq: AM - background COD reservation','enq: AM - ASM cache freeze','enq: AM - ASM ACD Relocation','enq: AM - group use','enq: AM - group block','enq: AM - ASM File Destroy','enq: AM - ASM User','enq: AM - ASM Password File Update','enq: AM - ASM Amdu Dump','enq: AM - disk offline','enq: AM - ASM reserved','enq: AM - block repair','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM file relocation','enq: AM - ASM SR relocation','enq: AM - ASM Grow ACD','enq: AM - ASM DD update SrRloc','enq: AM - ASM file chown','enq: AM - Register with IOServer','enq: AM - ASM metadata replication','enq: AM - SR slice Clear/Mark','enq: AM - Enable Remote ASM','enq: AM - Disable Remote ASM','enq: AM - Credential creation','enq: AM - Credential deletion','enq: AM - ASM file access req','enq: AM - ASM client operation','enq: AM - ASM client check','enq: AM - ASM ATB COD creation','enq: AM - Create default DG key in OCR','enq: AM - ASM Audit file Delete','enq: AM - ASM Audit file Cleanup','enq: AM - ASM VAT migration','enq: AM - Update SR nomark flag','enq: AM - ASM VAL cache','enq: AM - ASM SR Segment Reuse','ASM internal hang test','ASM Instance startup','buffer busy','buffer freelistbusy','buffer rememberlist busy','buffer writeList full','no free buffers','buffer write wait','buffer invalidation wait','buffer dirty disabled','ASM metadata cache frozen','enq: FZ -  contention','enq: CM - gate','enq: CM - instance','enq: CM - diskgroup dismount','enq: XQ - recovery','enq: XQ - relocation','enq: XQ - purification','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: DO - disk online','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','extent map load/unlock','enq: XL - fault extent map','Sync ASM rebalance','Sync ASM discovery','enq: DG - contention','enq: DD - contention','enq: HD - contention','enq: DQ -  contention','enq: DN - contention','Cluster stabilization wait','Cluster Suspension wait','ASM background starting','ASM db client exists','ASM file metadata operation','ASM network foreground exits','enq: XB -  contention','enq: FA - access file','enq: RX - relocate extent','enq: RX - unlock extent','enq: AR -  contention','enq: AH -  contention','log write(odd)','log write(even)','checkpoint advanced','enq: FR - contention','enq: FR - use the thread','enq: FR - recover the thread','enq: FG - serialize ACD relocate','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FX - issue ACD Xtnt Relocation CIC','rollback operations block full','rollback operations active','enq: RB - contention','ASM: MARK subscribe to msg channel','ASM: Send msg to MARK','call','enq: IC - IOServer clientID','enq: IF - file open','enq: IF - file close','enq: PT - contention','enq: PT - ASM Storage May Split','enq: PM -  contention','ASM PST operation','global cache busy','lock release pending','dma prepare busy','GCS lock cancel','GCS lock open S','GCS lock open X','GCS lock open','GCS lock cvt S','GCS lock cvt X','GCS lock esc X','GCS lock esc','GCS recovery lock open','GCS recovery lock convert','kfcl: instance recovery','no free locks','lock close','enq: KE -  contention','enq: KQ - access ASM attribute','ASM Volume Background','ASM volume directive send','ASM Volume Resource Action','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AV - AVD client registration','enq: AV - add/enable first volume in DG','ASM: OFS Cluster membership update','ASM Scrubbing I/O','enq: WF - contention','enq: WT - contention','enq: WP - contention','enq: FU - contention','enq: MW - contention','AWR Flush','AWR Metric Capture','enq: TB - SQL Tuning Base Cache Update','enq: TB - SQL Tuning Base Cache Load','enq: SH - contention','enq: AF - task serialization','MMON slave messages','MMON (Lite) shutdown','enq: MO - contention','enq: TL - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: RR - contention','WCR: RAC message context busy','WCR: capture file IO write','WCR: Sync context busy','latch: WCR: sync','latch: WCR: processes HT','enq: RA - RT ADDM flood control','enq: JS - contention','enq: JS - job run lock - synchronize','enq: JS - job recov lock','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - q mem clnup lck','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - wdw op','enq: JS - evt notify','enq: JS - aq sync','enq: XD - ASM disk drop/add','enq: XD - ASM disk ONLINE','enq: XD - ASM disk OFFLINE','cell worker online completion','cell worker retry ','cell manager cancel work request','opening cell offload device','ioctl to cell offload device','reap block level offload operations','CDB: Per Instance Query for PDB Info','enq: PB - PDB Lock','secondary event' )
  AND se.wait_class='Other'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
/*'null event' as e1,
'events in waitclass Other' as e2,
'enq: WM - WLM Plan activation' as e3,
'latch free' as e4,
'kslwait unit test event 1' as e5,
'kslwait unit test event 2' as e6,
'kslwait unit test event 3' as e7,
'unspecified wait event' as e8,
'latch activity' as e9,
'wait list latch activity' as e10,
'wait list latch free' as e11,
'global enqueue expand wait' as e12,
'free process state object' as e13,
'inactive session' as e14,
'process terminate' as e15,
'latch: call allocation' as e16,
'latch: session allocation' as e17,
'check CPU wait times' as e18,
'enq: CI - contention' as e19,
'enq: PR - contention' as e20,
'enq: AK -  contention' as e21,
'enq: XK -  contention' as e22,
'enq: DI -  contention' as e23,
'enq: RM -  contention' as e24,
'enq: BO -  contention' as e25,
'ges resource enqueue open retry sleep' as e26,
'ksim generic wait event' as e27,
'debugger command' as e28,
'ksdxexeother' as e29,
'ksdxexeotherwait' as e30,
'latch: ksm sga alloc latch' as e31,
'defer SGA allocation slave' as e32,
'SGA Allocator termination' as e33,
'enq: PE - contention' as e34,
'enq: PG - contention' as e35,
'ksbsrv' as e36,
'ksbcic' as e37,
'process startup' as e38,
'process shutdown' as e39,
'prior spawner clean up' as e40,
'latch: messages' as e41,
'rdbms ipc message block' as e42,
'rdbms ipc reply' as e43,
'latch: enqueue hash chains' as e44,
'enq: FP - global fob contention' as e45,
'enq: RE - block repair contention' as e46,
'enq: BM - clonedb bitmap file write' as e47,
'asynch descriptor resize' as e48,
'enq: FO - file system operation contention' as e49,
'imm op' as e50,
'slave exit' as e51,
'enq: KM - contention' as e52,
'enq: KT - contention' as e53,
'enq: CA - contention' as e54,
'enq: KD - determine DBRM master' as e55,
'reliable message' as e56,
'broadcast mesg queue transition' as e57,
'broadcast mesg recovery queue transition' as e58,
'KSV master wait' as e59,
'master exit' as e60,
'ksv slave avail wait' as e61,
'enq: PV - syncstart' as e62,
'enq: PV - syncshut' as e63,
'enq: SP - contention 1' as e64,
'enq: SP - contention 2' as e65,
'enq: SP - contention 3' as e66,
'enq: SP - contention 4' as e67,
'enq: SX - contention 5' as e68,
'enq: SX - contention 6' as e69,
'first spare wait event' as e70,
'second spare wait event' as e71,
'IPC send completion sync' as e72,
'OSD IPC library' as e73,
'IPC wait for name service busy' as e74,
'IPC busy async request' as e75,
'IPC waiting for OSD resources' as e76,
'ksxr poll remote instances' as e77,
'ksxr wait for mount shared' as e78,
'DBMS_LDAP: LDAP operation ' as e79,
'wait for FMON to come up' as e80,
'enq: FM - contention' as e81,
'enq: XY - contention' as e82,
'set director factor wait' as e83,
'latch: active service list' as e84,
'enq: AS - service activation' as e85,
'enq: PD - contention' as e86,
'oracle thread bootstrap' as e87,
'os thread creation' as e88,
'cleanup of aborted process' as e89,
'enq: XM -  contention' as e90,
'enq: RU - contention' as e91,
'enq: RU - waiting' as e92,
'rolling migration: cluster quiesce' as e93,
'LMON global data update' as e94,
'process diagnostic dump' as e95,
'enq: MX - sync storage server info' as e96,
'master diskmon startup' as e97,
'master diskmon read' as e98,
'DSKM to complete cell health check' as e99,
'pmon dblkr tst event' as e100,
'pmon cleanup on exit' as e101,
'latch: ksolt alloc' as e102,
'lightweight thread operation' as e103,
'enq: ZX - repopulation file write' as e104,
'DIAG lock acquisition' as e105,
'latch: ges resource hash list' as e106,
'DFS lock handle' as e107,
'ges LMD to shutdown' as e108,
'ges client process to exit' as e109,
'ges global resource directory to be frozen' as e110,
'ges resource directory to be unfrozen' as e111,
'gcs resource directory to be unfrozen' as e112,
'ges LMD to inherit communication channels' as e113,
'ges lmd sync during reconfig' as e114,
'ges wait for lmon to be ready' as e115,
'ges cgs registration' as e116,
'wait for master scn' as e117,
'ges yield cpu in reconfig' as e118,
'ges2 proc latch in rm latch get 1' as e119,
'ges2 proc latch in rm latch get 2' as e120,
'ges lmd/lmses to freeze in rcfg' as e121,
'ges lmd/lmses to unfreeze in rcfg' as e122,
'ges lms sync during dynamic remastering and reconfig' as e123,
'ges LMON to join CGS group' as e124,
'ges pmon to exit' as e125,
'ges lmd and pmon to attach' as e126,
'gcs drm freeze begin' as e127,
'gcs retry nowait latch get' as e128,
'gcs remastering wait for read latch' as e129,
'ges cached resource cleanup' as e130,
'ges generic event' as e131,
'ges retry query node' as e132,
'ges process with outstanding i/o' as e133,
'ges user error' as e134,
'ges enter server mode' as e135,
'gcs enter server mode' as e136,
'gcs drm freeze in enter server mode' as e137,
'gcs ddet enter server mode' as e138,
'ges cancel' as e139,
'ges resource cleanout during enqueue open' as e140,
'ges resource cleanout during enqueue open-cvt' as e141,
'ges master to get established for SCN op' as e142,
'ges LMON to get to FTDONE ' as e143,
'ges1 LMON to wake up LMD - mrcvr' as e144,
'ges2 LMON to wake up LMD - mrcvr' as e145,
'ges2 LMON to wake up lms - mrcvr 2' as e146,
'ges2 LMON to wake up lms - mrcvr 3' as e147,
'ges inquiry response' as e148,
'ges reusing os pid' as e149,
'ges LMON for send queues' as e150,
'ges LMD suspend for testing event' as e151,
'ges performance test completion' as e152,
'kjbopen wait for recovery domain attach' as e153,
'kjudomatt wait for recovery domain attach' as e154,
'kjudomdet wait for recovery domain detach' as e155,
'kjbdomalc allocate recovery domain - retry' as e156,
'kjbdrmcvtq lmon drm quiesce: ping completion' as e157,
'ges RMS0 retry add redo log' as e158,
'readable standby redo apply remastering' as e159,
'ges DFS hang analysis phase 2 acks' as e160,
'ges/gcs diag dump' as e161,
'global plug and play automatic resource creation' as e162,
'gcs lmon dirtydetach step completion' as e163,
'recovery instance recovery completion' as e164,
'ack for a broadcasted res from a remote instance' as e165,
'latch: kjci process context latch' as e166,
'latch: kjci request sequence latch' as e167,
'DLM cross inst call completion' as e168,
'DLM: shared instance mode init' as e169,
'enq: KI - contention' as e170,
'latch: kjoeq omni enqueue hash bucket latch' as e171,
'DLM enqueue copy completion' as e172,
'latch: kjoer owner hash bucket' as e173,
'DLM Omni Enq Owner replication' as e174,
'KJC: Wait for msg sends to complete' as e175,
'ges message buffer allocation' as e176,
'kjctssqmg: quick message send wait' as e177,
'kjctcisnd: Queue/Send client message' as e178,
'gcs domain validation' as e179,
'latch: gcs resource hash' as e180,
'affinity expansion in replay' as e181,
'wait for sync ack' as e182,
'wait for verification ack' as e183,
'wait for assert messages to be sent' as e184,
'wait for scn ack' as e185,
'lms flush message acks' as e186,
'name-service call wait' as e187,
'CGS wait for IPC msg' as e188,
'kjxgrtest' as e189,
'IMR mount phase II completion' as e190,
'IMR disk votes' as e191,
'IMR rr lock release' as e192,
'IMR net-check message ack' as e193,
'IMR rr update' as e194,
'IMR membership resolution' as e195,
'IMR CSS join retry' as e196,
'CGS skgxn join retry' as e197,
'gcs to be enabled' as e198,
'gcs log flush sync' as e199,
'enq: PP -  contention' as e200,
'enq: HM -  contention' as e201,
'GCR ctx lock acquisition' as e202,
'GCR CSS group lock' as e203,
'GCR CSS group join' as e204,
'GCR CSS group leave' as e205,
'GCR CSS group update' as e206,
'GCR CSS group query' as e207,
'enq: AC - acquiring partition id' as e208,
'SGA: allocation forcing component growth' as e209,
'SGA: sga_target resize' as e210,
'enq: SC -  contention' as e211,
'control file heartbeat' as e212,
'control file diagnostic dump' as e213,
'enq: CF - contention' as e214,
'enq: SW - contention' as e215,
'enq: DS - contention' as e216,
'enq: TC - contention' as e217,
'enq: TC - contention2' as e218,
'buffer exterminate' as e219,
'buffer resize' as e220,
'latch: cache buffers lru chain' as e221,
'enq: PW - perwarm status in dbw0' as e222,
'latch: checkpoint queue latch' as e223,
'latch: cache buffer handles' as e224,
'kcbzps' as e225,
'DBWR range invalidation sync' as e226,
'buffer deadlock' as e227,
'buffer latch' as e228,
'cr request retry' as e229,
'writes stopped by instance recovery or database suspension' as e230,
'lock escalate retry' as e231,
'lock deadlock retry' as e232,
'prefetch warmup block being transferred' as e233,
'recovery buffer pinned' as e234,
'TSE master key rekey' as e235,
'TSE SSO wallet reopen' as e236,
'force-cr-override flush' as e237,
'enq: CR - block range reuse ckpt' as e238,
'wait for MTTR advisory state object' as e239,
'latch: object queue header operation' as e240,
'retry cftxn during close' as e241,
'get branch/thread/sequence enqueue' as e242,
'enq: WL - Test access/locking' as e243,
'Data Guard server operation completion' as e244,
'FAL archive wait 1 sec for REOPEN minimum' as e245,
'TEST: action sync' as e246,
'TEST: action hang' as e247,
'RSGA: RAC reconfiguration' as e248,
'enq: WL - RAC-wide SGA initialize' as e249,
'enq: WL - RAC-wide SGA write' as e250,
'enq: WL - RAC-wide SGA dump' as e251,
'LGWR ORL/NoExp FAL archival' as e252,
'enq: WS -  contention' as e253,
'MRP wait on process start' as e254,
'MRP wait on process restart' as e255,
'MRP wait on startup clear' as e256,
'MRP inactivation' as e257,
'MRP termination' as e258,
'MRP state inspection' as e259,
'MRP wait on archivelog arrival' as e260,
'MRP wait on archivelog archival' as e261,
'enq: WL - Far Sync Fail Over' as e262,
'Monitor testing' as e263,
'enq: WL - redo_db table update' as e264,
'enq: WL - redo_db table query' as e265,
'enq: WL - redo_log table update' as e266,
'enq: WL - redo_log table query' as e267,
'enq: PY - AVM RTA access instance' as e268,
'enq: PY - AVM RTA access database' as e269,
'enq: PY - AVM RTA access database 2' as e270,
'log switch/archive' as e271,
'enq: WL - Switchover To Primary' as e272,
'ARCH wait on c/f tx acquire 1' as e273,
'RFS attach' as e274,
'RFS create' as e275,
'RFS close' as e276,
'RFS announce' as e277,
'RFS register' as e278,
'RFS detach' as e279,
'RFS ping' as e280,
'RFS dispatch' as e281,
'enq: WL - RFS global state contention' as e282,
'LGWR simulation latency wait' as e283,
'LNS simulation latency wait' as e284,
'ASYNC Remote Write' as e285,
'SYNC Remote Write' as e286,
'ARCH Remote Write' as e287,
'Redo Transport Attach' as e288,
'Redo Transport Detach' as e289,
'Redo Transport Open' as e290,
'Redo Transport Close' as e291,
'Redo Transport Ping' as e292,
'Remote SYNC Ping' as e293,
'Redo Transport Slave Startup' as e294,
'Redo Transport Slave Shutdown' as e295,
'Redo Writer Remote Sync Notify' as e296,
'Redo Writer Remote Sync Complete' as e297,
'Redo Transport MISC' as e298,
'Data Guard: RFS disk I/O' as e299,
'ARCH wait for process start 1' as e300,
'ARCH wait for process death 1' as e301,
'ARCH wait for process start 3' as e302,
'Data Guard: process exit' as e303,
'Data Guard: process clean up' as e304,
'LGWR-LNS wait on channel' as e305,
'enq: WR - contention' as e306,
'Redo transport testing' as e307,
'enq: RZ - add element' as e308,
'enq: RZ - remove element' as e309,
'Image redo gen delay' as e310,
'LGWR wait for redo copy' as e311,
'latch: redo allocation' as e312,
'log file switch (clearing log file)' as e313,
'target log write size' as e314,
'LGWR any worker group' as e315,
'LGWR all worker groups' as e316,
'LGWR worker group ordering' as e317,
'LGWR intra group sync' as e318,
'LGWR intra group IO completion' as e319,
'enq: WL - contention' as e320,
'enq: RN - contention' as e321,
'DFS db file lock' as e322,
'enq: DF - contention' as e323,
'enq: IS - contention' as e324,
'enq: IP - open/close PDB' as e325,
'enq: FS - contention' as e326,
'enq: FS - online log operation' as e327,
'enq: DM - contention' as e328,
'enq: RP - contention' as e329,
'latch: gc element' as e330,
'enq: RT - contention' as e331,
'enq: RT - thread internal enable/disable' as e332,
'enq: IR - contention' as e333,
'enq: IR - contention2' as e334,
'enq: IR - global serialization' as e335,
'enq: IR - local serialization' as e336,
'enq: IR - arbitrate instance recovery' as e337,
'enq: MR - contention' as e338,
'enq: MR - standby role transition' as e339,
'enq: MR - multi instance redo apply' as e340,
'enq: MR - any role transition' as e341,
'enq: MR - PDB open' as e342,
'enq: MR - datafile online' as e343,
'enq: MR - adg instance recovery' as e344,
'shutdown after switchover to standby' as e345,
'cancel media recovery on switchover' as e346,
'parallel recovery coord wait for reply' as e347,
'parallel recovery coord send blocked' as e348,
'parallel recovery slave wait for change' as e349,
'enq: BR - file shrink' as e350,
'enq: BR - proxy-copy' as e351,
'enq: BR - multi-section restore header' as e352,
'enq: BR - multi-section restore section' as e353,
'enq: BR - space info datafile hdr update' as e354,
'enq: BR - request autobackup' as e355,
'enq: BR - perform autobackup' as e356,
'enq: BR - BA lock db' as e357,
'enq: BR - BA lock storage loc' as e358,
'enq: BR - BA lock timer queue' as e359,
'enq: BR - BA lock scheduler' as e360,
'enq: BR - BA lock API' as e361,
'enq: BR - BA quiesce storage ' as e362,
'enq: BR - BA check quiescence' as e363,
'enq: BR - BA run scheduler' as e364,
'enq: BR - BA purge storage loc' as e365,
'enq: BR - BA invalidate plans' as e366,
'enq: BR - BA protect plans' as e367,
'enq: ID - contention' as e368,
'Backup Restore Throttle sleep' as e369,
'Backup Restore Switch Bitmap sleep' as e370,
'Backup Restore Event 19778 sleep' as e371,
'enq: BS - Backup spare1' as e372,
'enq: BS - Backup spare2' as e373,
'enq: BS - Backup spare3' as e374,
'enq: BS - Backup spare4' as e375,
'enq: BS - Backup spare5' as e376,
'enq: BS - Backup spare6' as e377,
'enq: BS - Backup spare7' as e378,
'enq: BS - Backup spare8' as e379,
'enq: BS - Backup spare9' as e380,
'enq: BS - Backup spare0' as e381,
'enq: AB - ABMR process start/stop' as e382,
'enq: AB - ABMR process initialized' as e383,
'Auto BMR completion' as e384,
'Auto BMR RPC standby catchup' as e385,
'enq: BC - drop container group' as e386,
'enq: BC - create container' as e387,
'enq: BC - group - create container' as e388,
'enq: BC - drop container' as e389,
'enq: BC - group - create file' as e390,
'enq: BI - create file' as e391,
'enq: BI - identify file' as e392,
'enq: BI - delete file' as e393,
'enq: BZ - resize file' as e394,
'enq: BV - rebuild/validate group' as e395,
'Backup Appliance container synchronous read' as e396,
'Backup Appliance container synchronous write' as e397,
'Backup Appliance container I/O' as e398,
'enq: MN - contention' as e399,
'enq: PL - contention' as e400,
'enq: CP - Pluggable database resetlogs' as e401,
'enq: SB - logical standby metadata' as e402,
'enq: SB - table instantiation' as e403,
'Logical Standby Apply shutdown' as e404,
'Logical Standby pin transaction' as e405,
'Logical Standby dictionary build' as e406,
'Logical Standby Terminal Apply' as e407,
'Logical Standby Debug' as e408,
'Resolution of in-doubt txns' as e409,
'enq: XR - quiesce database' as e410,
'enq: XR - database force logging' as e411,
'standby query scn advance' as e412,
'change tracking file synchronous read' as e413,
'change tracking file synchronous write' as e414,
'change tracking file parallel write' as e415,
'block change tracking buffer space' as e416,
'CTWR media recovery checkpoint request' as e417,
'enq: CT - global space management' as e418,
'enq: CT - local space management' as e419,
'enq: CT - change stream ownership' as e420,
'enq: CT - state' as e421,
'enq: CT - state change gate 1' as e422,
'enq: CT - state change gate 2' as e423,
'enq: CT - CTWR process start/stop' as e424,
'enq: CT - reading' as e425,
'recovery area: computing dropped files' as e426,
'recovery area: computing obsolete files' as e427,
'recovery area: computing backed up files' as e428,
'recovery area: computing applied logs' as e429,
'enq: RS - file delete' as e430,
'enq: RS - record reuse' as e431,
'enq: RS - prevent file delete' as e432,
'enq: RS - prevent aging list update' as e433,
'enq: RS - persist alert level' as e434,
'enq: RS - read alert level' as e435,
'enq: RS - write alert level' as e436,
'enq: FL - Flashback database log' as e437,
'enq: FL - Flashback db command' as e438,
'enq: FD - Marker generation' as e439,
'enq: FD - Tablespace flashback on/off' as e440,
'enq: FD - Flashback coordinator' as e441,
'enq: FD - Flashback on/off' as e442,
'enq: FD - Restore point create/drop' as e443,
'enq: FD - Flashback logical operations' as e444,
'flashback free VI log' as e445,
'flashback log switch' as e446,
'enq: FW -  contention' as e447,
'RVWR wait for flashback copy' as e448,
'parallel recovery read buffer free' as e449,
'parallel recovery redo cache buffer free' as e450,
'parallel recovery change buffer free' as e451,
'cell smart flash unkeep' as e452,
'parallel recovery coord: all replies' as e453,
'datafile move cleanup during resize' as e454,
'recovery receive buffer free' as e455,
'recovery send buffer free' as e456,
'DBMS_ROLLING instruction completion' as e457,
'blocking txn id for DDL' as e458,
'transaction' as e459,
'inactive transaction branch' as e460,
'txn to complete' as e461,
'PMON to cleanup pseudo-branches at svc stop time' as e462,
'PMON to cleanup detached branches at shutdown' as e463,
'test long ops' as e464,
'latch: undo global data' as e465,
'undo segment recovery' as e466,
'unbound tx' as e467,
'wait for change' as e468,
'wait for another txn - undo rcv abort' as e469,
'wait for another txn - txn abort' as e470,
'wait for another txn - rollback to savepoint' as e471,
'undo_retention publish retry' as e472,
'enq: TA - contention' as e473,
'enq: TX - contention' as e474,
'enq: US - contention' as e475,
'wait for stopper event to be increased' as e476,
'wait for a undo record' as e477,
'wait for a paralle reco to abort' as e478,
'enq: IM - contention for blr' as e479,
'enq: TD - KTF dump entries' as e480,
'enq: TE - KTF broadcast' as e481,
'enq: CN - race with txn' as e482,
'enq: CN - race with reg' as e483,
'enq: CN - race with init' as e484,
'latch: Change Notification Hash table latch' as e485,
'enq: CO - master slave det' as e486,
'enq: FE - contention' as e487,
'latch: change notification client cache latch' as e488,
'latch: SGA Logging Log Latch' as e489,
'latch: SGA Logging Bkt Latch' as e490,
'enq: MC - Securefile log' as e491,
'enq: MF - flush bkgnd periodic' as e492,
'enq: MF - creating swap in instance' as e493,
'enq: MF - flush space' as e494,
'enq: MF - flush client' as e495,
'enq: MF - flush prior error' as e496,
'enq: MF - flush destroy' as e497,
'latch: ILM activity tracking latch' as e498,
'latch: ILM access tracking extent' as e499,
'IM CU busy' as e500,
'enq: TF - contention' as e501,
'latch: lob segment hash table latch' as e502,
'latch: lob segment query latch' as e503,
'latch: lob segment dispenser latch' as e504,
'Wait for shrink lock2' as e505,
'Wait for shrink lock' as e506,
'L1 validation' as e507,
'Wait for TT enqueue' as e508,
'kttm2d' as e509,
'ktsambl' as e510,
'ktfbtgex' as e511,
'enq: DT - contention' as e512,
'enq: TS - contention' as e513,
'enq: FB - contention' as e514,
'enq: SK - contention' as e515,
'enq: DW - contention' as e516,
'enq: SU - contention' as e517,
'enq: TT - contention' as e518,
'ktm: instance recovery' as e519,
'instance state change' as e520,
'enq: SM -  contention' as e521,
'enq: SJ - Slave Task Cancel' as e522,
'Space Manager: slave messages' as e523,
'enq: FH - contention' as e524,
'latch: IM area scb latch' as e525,
'latch: IM area sb latch' as e526,
'enq: TZ - contention' as e527,
'enq: IN - contention' as e528,
'enq: ZB - contention' as e529,
'latch: IM seg hdr latch' as e530,
'latch: IM emb latch' as e531,
'enq: SV -  contention' as e532,
'index block split' as e533,
'kdblil wait before retrying ORA-54' as e534,
'dupl. cluster key' as e535,
'kdic_do_merge' as e536,
'enq: DL - contention' as e537,
'enq: HQ - contention' as e538,
'enq: HP - contention' as e539,
'enq: KL -  contention' as e540,
'enq: WG - delete fso' as e541,
'enq: SL - get lock' as e542,
'enq: SL - escalate lock' as e543,
'enq: SL - get lock for undo' as e544,
'enq: ZH - compression analysis' as e545,
'Compression analysis' as e546,
'enq: SZ - contention' as e547,
'enq: ZC - FS Seg contention' as e548,
'enq: ZD - FS CU mod' as e549,
'enq: SY - IM populate by other session' as e550,
'IM populate completion' as e551,
'In-Memory populate: over pga limit' as e552,
'row cache cleanup' as e553,
'row cache process' as e554,
'enq: QA -  contention' as e555,
'enq: QB -  contention' as e556,
'enq: QC -  contention' as e557,
'enq: QD -  contention' as e558,
'enq: QE -  contention' as e559,
'enq: QF -  contention' as e560,
'enq: QG -  contention' as e561,
'enq: QH -  contention' as e562,
'enq: QI -  contention' as e563,
'enq: QJ -  contention' as e564,
'enq: QK -  contention' as e565,
'enq: QL -  contention' as e566,
'enq: QM -  contention' as e567,
'enq: QN -  contention' as e568,
'enq: QO -  contention' as e569,
'enq: QP -  contention' as e570,
'enq: QQ -  contention' as e571,
'enq: QR -  contention' as e572,
'enq: QS -  contention' as e573,
'enq: QT -  contention' as e574,
'enq: QU -  contention' as e575,
'enq: QV -  contention' as e576,
'enq: QX -  contention' as e577,
'enq: QY -  contention' as e578,
'enq: QZ -  contention' as e579,
'enq: DV - contention' as e580,
'enq: SO - contention' as e581,
'enq: VA -  contention' as e582,
'enq: VB -  contention' as e583,
'enq: VC -  contention' as e584,
'enq: VD -  contention' as e585,
'enq: VE -  contention' as e586,
'enq: VF -  contention' as e587,
'enq: VG -  contention' as e588,
'enq: VH -  contention' as e589,
'enq: VI -  contention' as e590,
'enq: VJ -  contention' as e591,
'enq: VK -  contention' as e592,
'enq: VL -  contention' as e593,
'enq: VM -  contention' as e594,
'enq: VN -  contention' as e595,
'enq: VO -  contention' as e596,
'enq: VP -  contention' as e597,
'enq: VQ -  contention' as e598,
'enq: VR -  contention' as e599,
'enq: VS -  contention' as e600,
'enq: VT -  contention' as e601,
'enq: VU -  contention' as e602,
'enq: VV -  contention' as e603,
'enq: VX -  contention' as e604,
'enq: VY -  contention' as e605,
'enq: VZ -  contention' as e606,
'enq: EA -  contention' as e607,
'enq: EB -  contention' as e608,
'enq: EC -  contention' as e609,
'enq: ED -  contention' as e610,
'enq: EE -  contention' as e611,
'enq: EF -  contention' as e612,
'enq: EG -  contention' as e613,
'enq: EH -  contention' as e614,
'enq: EI -  contention' as e615,
'enq: EJ -  contention' as e616,
'enq: EK -  contention' as e617,
'enq: EL -  contention' as e618,
'enq: EM -  contention' as e619,
'enq: EN -  contention' as e620,
'enq: EO -  contention' as e621,
'enq: EP -  contention' as e622,
'enq: EQ -  contention' as e623,
'enq: ER -  contention' as e624,
'enq: ES -  contention' as e625,
'enq: ET -  contention' as e626,
'enq: EU -  contention' as e627,
'enq: EV -  contention' as e628,
'enq: EX -  contention' as e629,
'enq: EY -  contention' as e630,
'enq: EZ -  contention' as e631,
'enq: LA -  contention' as e632,
'enq: LB -  contention' as e633,
'enq: LC -  contention' as e634,
'enq: LD -  contention' as e635,
'enq: LE -  contention' as e636,
'enq: LF -  contention' as e637,
'enq: LG -  contention' as e638,
'enq: LH -  contention' as e639,
'enq: LI -  contention' as e640,
'enq: LJ -  contention' as e641,
'enq: LK -  contention' as e642,
'enq: LL -  contention' as e643,
'enq: LM -  contention' as e644,
'enq: LN -  contention' as e645,
'enq: LO -  contention' as e646,
'enq: LP -  contention' as e647,
'enq: LQ -  contention' as e648,
'enq: LR -  contention' as e649,
'enq: LS -  contention' as e650,
'enq: LT -  contention' as e651,
'enq: LU -  contention' as e652,
'enq: LV -  contention' as e653,
'enq: LX -  contention' as e654,
'enq: LY -  contention' as e655,
'enq: LZ -  contention' as e656,
'enq: YA -  contention' as e657,
'enq: YB -  contention' as e658,
'enq: YC -  contention' as e659,
'enq: YD -  contention' as e660,
'enq: YE -  contention' as e661,
'enq: YF -  contention' as e662,
'enq: YG -  contention' as e663,
'enq: YH -  contention' as e664,
'enq: YI -  contention' as e665,
'enq: YJ -  contention' as e666,
'enq: YK -  contention' as e667,
'enq: YL -  contention' as e668,
'enq: YM -  contention' as e669,
'enq: YN -  contention' as e670,
'enq: YO -  contention' as e671,
'enq: YP -  contention' as e672,
'enq: YQ -  contention' as e673,
'enq: YR -  contention' as e674,
'enq: YS -  contention' as e675,
'enq: YT -  contention' as e676,
'enq: YU -  contention' as e677,
'enq: YV -  contention' as e678,
'enq: YX -  contention' as e679,
'enq: YY -  contention' as e680,
'enq: YZ -  contention' as e681,
'enq: GA -  contention' as e682,
'enq: GB -  contention' as e683,
'enq: GC -  contention' as e684,
'enq: GD -  contention' as e685,
'enq: GE -  contention' as e686,
'enq: GF -  contention' as e687,
'enq: GG -  contention' as e688,
'enq: GH -  contention' as e689,
'enq: GI -  contention' as e690,
'enq: GJ -  contention' as e691,
'enq: GK -  contention' as e692,
'enq: GL -  contention' as e693,
'enq: GM -  contention' as e694,
'enq: GN -  contention' as e695,
'enq: GO -  contention' as e696,
'enq: GP -  contention' as e697,
'enq: GQ -  contention' as e698,
'enq: GR -  contention' as e699,
'enq: GS -  contention' as e700,
'enq: GT -  contention' as e701,
'enq: GU -  contention' as e702,
'enq: GV -  contention' as e703,
'enq: GX -  contention' as e704,
'enq: GY -  contention' as e705,
'enq: GZ -  contention' as e706,
'enq: NA -  contention' as e707,
'enq: NB -  contention' as e708,
'enq: NC -  contention' as e709,
'enq: ND -  contention' as e710,
'enq: NE -  contention' as e711,
'enq: NF -  contention' as e712,
'enq: NG -  contention' as e713,
'enq: NH -  contention' as e714,
'enq: NI -  contention' as e715,
'enq: NJ -  contention' as e716,
'enq: NK -  contention' as e717,
'enq: NL -  contention' as e718,
'enq: NM -  contention' as e719,
'enq: NN -  contention' as e720,
'enq: NO -  contention' as e721,
'enq: NP -  contention' as e722,
'enq: NQ -  contention' as e723,
'enq: NR -  contention' as e724,
'enq: NS -  contention' as e725,
'enq: NT -  contention' as e726,
'enq: NU -  contention' as e727,
'enq: NV -  contention' as e728,
'enq: NX -  contention' as e729,
'enq: NY -  contention' as e730,
'enq: NZ -  contention' as e731,
'enq: IV -  contention' as e732,
'enq: TP - contention' as e733,
'enq: RW - MV metadata contention' as e734,
'enq: OC - contention' as e735,
'enq: OL - contention' as e736,
'kkdlgon' as e737,
'kkdlsipon' as e738,
'kkdlhpon' as e739,
'kgltwait' as e740,
'kksfbc research' as e741,
'kksscl hash split' as e742,
'kksfbc child completion' as e743,
'enq: CU - contention' as e744,
'enq: AE - lock' as e745,
'enq: PF - contention' as e746,
'enq: IL - contention' as e747,
'enq: CL - drop label' as e748,
'enq: CL - compare labels' as e749,
'enq: SG - OLS Add Group' as e750,
'enq: SG - OLS Create Group' as e751,
'enq: SG - OLS Drop Group' as e752,
'enq: SG - OLS Alter Group Parent' as e753,
'enq: OP - OLS Store user entries' as e754,
'enq: OP - OLS Cleanup unused profiles' as e755,
'enq: CC - decryption' as e756,
'enq: MK - contention' as e757,
'enq: OW - initialization' as e758,
'enq: OW - termination' as e759,
'enq: RK - set key' as e760,
'enq: HC - HSM cache write' as e761,
'enq: HC - HSM cache read' as e762,
'enq: RL - RAC wallet lock' as e763,
'enq: ZZ - update hash tables' as e764,
'Failed Logon Delay' as e765,
'enq: ZA - add std audit table partition' as e766,
'enq: ZF - add fga audit table partition' as e767,
'enq: ZS - excl access to spill audit file' as e768,
'enq: PA - modify a privilege capture' as e769,
'enq: PA - read a privilege capture' as e770,
'enq: PC - update privilege capture info' as e771,
'enq: PC - read privilege capture info' as e772,
'enq: KZ -  contention' as e773,
'enq: DX - contention' as e774,
'enq: DR - contention' as e775,
'pending global transaction(s)' as e776,
'free global transaction table entry' as e777,
'library cache revalidation' as e778,
'library cache shutdown' as e779,
'BFILE closure' as e780,
'BFILE check if exists' as e781,
'BFILE check if open' as e782,
'BFILE get length' as e783,
'BFILE get name object' as e784,
'BFILE get path object' as e785,
'BFILE open' as e786,
'BFILE internal seek' as e787,
'waiting to get CAS latch' as e788,
'waiting to get RM CAS latch' as e789,
'resmgr:internal state cleanup' as e790,
'xdb schema cache initialization' as e791,
'ASM cluster file access' as e792,
'CSS initialization' as e793,
'CSS group registration' as e794,
'CSS group membership query' as e795,
'CSS operation: data query' as e796,
'CSS operation: data update' as e797,
'CSS Xgrp shared operation' as e798,
'CSS operation: query' as e799,
'CSS operation: action' as e800,
'CSS operation: diagnostic' as e801,
'GIPC operation: dump' as e802,
'GPnP Initialization' as e803,
'GPnP Termination' as e804,
'GPnP Get Item' as e805,
'GPnP Set Item' as e806,
'GPnP Get Error' as e807,
'ADR file lock' as e808,
'ADR block file read' as e809,
'ADR block file write' as e810,
'CRS call completion' as e811,
'dispatcher shutdown' as e812,
'listener registration dump' as e813,
'latch: virtual circuit queues' as e814,
'listen endpoint status' as e815,
'OJVM: Generic' as e816,
'select wait' as e817,
'jobq slave shutdown wait' as e818,
'jobq slave TJ process wait' as e819,
'job scheduler coordinator slave wait' as e820,
'enq: JD - contention' as e821,
'enq: JQ - contention' as e822,
'enq: OD - Serializing DDLs' as e823,
'RAC referential constraint parent lock' as e824,
'RAC: constraint DDL lock' as e825,
'kkshgnc reloop' as e826,
'optimizer stats update retry' as e827,
'wait active processes' as e828,
'SUPLOG PL wait for inflight pragma-d PL/SQL' as e829,
'enq: MD - contention' as e830,
'enq: MS - contention' as e831,
'wait for kkpo ref-partitioning *TEST EVENT*' as e832,
'enq: AP - contention' as e833,
'PX slave connection' as e834,
'PX slave release' as e835,
'PX Send Wait' as e836,
'PX qref latch' as e837,
'PX server shutdown' as e838,
'PX create server' as e839,
'PX signal server' as e840,
'PX Deq Credit: free buffer' as e841,
'PX Deq: Test for msg' as e842,
'PX Deq: Test for credit' as e843,
'PX Deq: Signal ACK RSG' as e844,
'PX Deq: Signal ACK EXT' as e845,
'PX Deq: reap credit' as e846,
'PX Nsq: PQ descriptor query' as e847,
'PX Nsq: PQ load info query' as e848,
'PX Deq Credit: Session Stats' as e849,
'PX Deq: Slave Session Stats' as e850,
'PX Deq: Slave Join Frag' as e851,
'enq: PI - contention' as e852,
'enq: PS - contention' as e853,
'latch: parallel query alloc buffer' as e854,
'kxfxse' as e855,
'kxfxsp' as e856,
'PX Deq: Table Q qref' as e857,
'PX Deq: Table Q Get Keys' as e858,
'PX Deq: Table Q Close' as e859,
'GV$: slave acquisition retry wait time' as e860,
'PX hash elem being inserted' as e861,
'latch: PX hash array latch' as e862,
'enq: AY - contention' as e863,
'enq: TO - contention' as e864,
'enq: IT - contention' as e865,
'enq: BF - allocation contention' as e866,
'enq: BF - PMON Join Filter cleanup' as e867,
'enq: RD - RAC load' as e868,
'enq: KV - key vector creation coordination' as e869,
'timer in sksawat' as e870,
'scginq AST call' as e871,
'kupp process wait' as e872,
'Kupp process shutdown' as e873,
'Data Pump slave startup' as e874,
'Data Pump slave init' as e875,
'enq: KP - contention' as e876,
'Replication Dequeue ' as e877,
'knpc_acwm_AwaitChangedWaterMark' as e878,
'knpc_anq_AwaitNonemptyQueue' as e879,
'knpsmai' as e880,
'enq: SR - contention' as e881,
'REPL Capture/Apply: database startup' as e882,
'REPL Capture/Apply: miscellaneous' as e883,
'enq: SI - contention' as e884,
'REPL Capture/Apply: RAC inter-instance ack' as e885,
'enq: IA - contention' as e886,
'enq: JI - contention' as e887,
'qerex_gdml' as e888,
'enq: AT - contention' as e889,
'opishd' as e890,
'kpodplck wait before retrying ORA-54' as e891,
'enq: CQ - contention' as e892,
'wait for EMON to spawn' as e893,
'EMON termination' as e894,
'Emon coordinator startup' as e895,
'enq: SE - contention' as e896,
'tsm with timeout' as e897,
'Streams AQ: waiting for busy instance for instance_name' as e898,
'enq: TQ - TM contention' as e899,
'enq: TQ - DDL contention' as e900,
'enq: TQ - INI contention' as e901,
'enq: TQ - DDL-INI contention' as e902,
'enq: TQ - INI sq contention' as e903,
'enq: TQ - MC free sync at cross job start' as e904,
'enq: TQ - MC free sync at cross job stop' as e905,
'enq: TQ - MC free sync at cross job end' as e906,
'enq: TQ - MC free sync at export subshard' as e907,
'enq: TQ -  sq TM contention' as e908,
'AQ reload SO release' as e909,
'enq: RQ - Enqueue commit uncached' as e910,
'enq: RQ - Enqueue commit cached' as e911,
'enq: RQ - Dequeue update scn' as e912,
'enq: RQ - Parallel cross update scn' as e913,
'enq: RQ - Cross update scn' as e914,
'enq: RQ - Trucate subshard' as e915,
'enq: RQ - Cross export subshard' as e916,
'enq: RQ - Cross import subshard' as e917,
'enq: RQ - Free shadow shard' as e918,
'enq: RQ - AQ indexed cached commit' as e919,
'enq: RQ - AQ uncached commit WM update' as e920,
'enq: RQ - AQ uncached dequeue' as e921,
'enq: RQ - AQ Eq Ptn Mapping' as e922,
'enq: RQ - AQ Dq Ptn Mapping' as e923,
'enq: RQ - AQ Trnc mem free' as e924,
'enq: RQ - AQ Trnc mem free remote' as e925,
'enq: RQ - AQ Trnc mem free by LB' as e926,
'enq: RQ - AQ Trnc mem free by CP' as e927,
'enq: RQ - AQ Enq commit incarnation wrap' as e928,
'enq: RQ - AQ Rule evaluation segment load' as e929,
'AQ propagation connection' as e930,
'enq: DP - contention' as e931,
'enq: MH - contention' as e932,
'enq: ML - contention' as e933,
'enq: PH - contention' as e934,
'enq: SF - contention' as e935,
'enq: XH - contention' as e936,
'enq: WA - contention' as e937,
'Streams AQ: QueueTable kgl locks' as e938,
'AQ spill debug idle' as e939,
'AQ master shutdown' as e940,
'AQPC: new master' as e941,
'AQ Background Master: slave start' as e942,
'enq: AQ - QPT fg map dqpt' as e943,
'enq: AQ - QPT fg map qpt' as e944,
'enq: PQ - QPT add qpt' as e945,
'enq: PQ - QPT drop qpt' as e946,
'enq: PQ - QPT add dqpt' as e947,
'enq: PQ - QPT drop dqpt' as e948,
'enq: PQ - QPT add qpt fg' as e949,
'enq: PQ - QPT add dqpt fg' as e950,
'enq: PQ - QPT Trunc' as e951,
'enq: PQ - QPT LB Trunc sync' as e952,
'enq: PQ - QPT XSTART Trunc sync' as e953,
'AQ master: time mgmt/task cleanup' as e954,
'AQ slave: time mgmt/task cleanup' as e955,
'enq: BA - SUBBMAP contention' as e956,
'AQ:non durable subscriber add or drop' as e957,
'enq: CX - TEXT: Index Specific Lock' as e958,
'enq: OT - TEXT: Generic Lock' as e959,
'XDB SGA initialization' as e960,
'enq: XC - XDB Configuration' as e961,
'NFS read delegation outstanding' as e962,
'Data Guard Broker Wait' as e963,
'enq: RF - synch: DG Broker metadata' as e964,
'enq: RF - atomicity' as e965,
'enq: RF - synchronization: aifo master' as e966,
'enq: RF - new AI' as e967,
'enq: RF - synchronization: critical ai' as e968,
'enq: RF - RF - Database Automatic Disable' as e969,
'enq: RF - FSFO Observer Heartbeat' as e970,
'enq: RF - DG Broker Current File ID' as e971,
'enq: RF - FSFO Primary Shutdown suspended' as e972,
'enq: RF - Broker State Lock' as e973,
'enq: RF - FSFO string buffer' as e974,
'PX Deq: OLAP Update Reply' as e975,
'PX Deq: OLAP Update Execute' as e976,
'PX Deq: OLAP Update Close' as e977,
'OLAP Parallel Type Deq' as e978,
'OLAP Parallel Temp Grow Request' as e979,
'OLAP Parallel Temp Grow Wait' as e980,
'OLAP Parallel Temp Grew' as e981,
'OLAP Null PQ Reason' as e982,
'OLAP Aggregate Master Enq' as e983,
'OLAP Aggregate Client Enq' as e984,
'OLAP Aggregate Master Deq' as e985,
'OLAP Aggregate Client Deq' as e986,
'enq: AW - AW$ table lock' as e987,*/
'enq: AW - AW state lock' as e988,
'enq: AW - user access for AW' as e989,
'enq: AW - AW generation lock' as e990,
'enq: AG - contention' as e991,
'enq: AO - contention' as e992,
'enq: OQ - xsoqhiAlloc' as e993,
'enq: OQ - xsoqhiFlush' as e994,
'enq: OQ - xsoq*histrecb' as e995,
'enq: OQ - xsoqhiClose' as e996,
'enq: OQ - xsoqhistrecb' as e997,
'enq: IZ -  contention' as e998,
'enq: AM - client registration' as e999,
'enq: AM - shutdown' as e1000,
'enq: AM - rollback COD reservation' as e1001,
'enq: AM - background COD reservation' as e1002,
'enq: AM - ASM cache freeze' as e1003,
'enq: AM - ASM ACD Relocation' as e1004,
'enq: AM - group use' as e1005,
'enq: AM - group block' as e1006,
'enq: AM - ASM File Destroy' as e1007,
'enq: AM - ASM User' as e1008,
'enq: AM - ASM Password File Update' as e1009,
'enq: AM - ASM Amdu Dump' as e1010,
'enq: AM - disk offline' as e1011,
'enq: AM - ASM reserved' as e1012,
'enq: AM - block repair' as e1013,
'enq: AM - ASM disk based alloc/dealloc' as e1014,
'enq: AM - ASM file descriptor' as e1015,
'enq: AM - ASM file relocation' as e1016,
'enq: AM - ASM SR relocation' as e1017,
'enq: AM - ASM Grow ACD' as e1018,
'enq: AM - ASM DD update SrRloc' as e1019,
'enq: AM - ASM file chown' as e1020,
'enq: AM - Register with IOServer' as e1021,
'enq: AM - ASM metadata replication' as e1022,
'enq: AM - SR slice Clear/Mark' as e1023,
'enq: AM - Enable Remote ASM' as e1024,
'enq: AM - Disable Remote ASM' as e1025,
'enq: AM - Credential creation' as e1026,
'enq: AM - Credential deletion' as e1027,
'enq: AM - ASM file access req' as e1028,
'enq: AM - ASM client operation' as e1029,
'enq: AM - ASM client check' as e1030,
'enq: AM - ASM ATB COD creation' as e1031,
'enq: AM - Create default DG key in OCR' as e1032,
'enq: AM - ASM Audit file Delete' as e1033,
'enq: AM - ASM Audit file Cleanup' as e1034,
'enq: AM - ASM VAT migration' as e1035,
'enq: AM - Update SR nomark flag' as e1036,
'enq: AM - ASM VAL cache' as e1037,
'enq: AM - ASM SR Segment Reuse' as e1038,
'ASM internal hang test' as e1039,
'ASM Instance startup' as e1040,
'buffer busy' as e1041,
'buffer freelistbusy' as e1042,
'buffer rememberlist busy' as e1043,
'buffer writeList full' as e1044,
'no free buffers' as e1045,
'buffer write wait' as e1046,
'buffer invalidation wait' as e1047,
'buffer dirty disabled' as e1048,
'ASM metadata cache frozen' as e1049,
'enq: FZ -  contention' as e1050,
'enq: CM - gate' as e1051,
'enq: CM - instance' as e1052,
'enq: CM - diskgroup dismount' as e1053,
'enq: XQ - recovery' as e1054,
'enq: XQ - relocation' as e1055,
'enq: XQ - purification' as e1056,
'enq: AD - allocate AU' as e1057,
'enq: AD - deallocate AU' as e1058,
'enq: AD - relocate AU' as e1059,
'enq: DO - disk online' as e1060,
'enq: DO - disk online recovery' as e1061,
'enq: DO - Staleness Registry create' as e1062,
'enq: DO - startup of MARK process' as e1063,
'extent map load/unlock' as e1064,
'enq: XL - fault extent map' as e1065,
'Sync ASM rebalance' as e1066,
'Sync ASM discovery' as e1067,
'enq: DG - contention' as e1068,
'enq: DD - contention' as e1069,
'enq: HD - contention' as e1070,
'enq: DQ -  contention' as e1071,
'enq: DN - contention' as e1072,
'Cluster stabilization wait' as e1073,
'Cluster Suspension wait' as e1074,
'ASM background starting' as e1075,
'ASM db client exists' as e1076,
'ASM file metadata operation' as e1077,
'ASM network foreground exits' as e1078,
'enq: XB -  contention' as e1079,
'enq: FA - access file' as e1080,
'enq: RX - relocate extent' as e1081,
'enq: RX - unlock extent' as e1082,
'enq: AR -  contention' as e1083,
'enq: AH -  contention' as e1084,
'log write(odd)' as e1085,
'log write(even)' as e1086,
'checkpoint advanced' as e1087,
'enq: FR - contention' as e1088,
'enq: FR - use the thread' as e1089,
'enq: FR - recover the thread' as e1090,
'enq: FG - serialize ACD relocate' as e1091,
'enq: FG - FG redo generation enq race' as e1092,
'enq: FG - LGWR redo generation enq race' as e1093,
'enq: FT - allow LGWR writes' as e1094,
'enq: FT - disable LGWR writes' as e1095,
'enq: FC - open an ACD thread' as e1096,
'enq: FC - recover an ACD thread' as e1097,
'enq: FX - issue ACD Xtnt Relocation CIC' as e1098,
'rollback operations block full' as e1099,
'rollback operations active' as e1100,
'enq: RB - contention' as e1101,
'ASM: MARK subscribe to msg channel' as e1102,
'ASM: Send msg to MARK' as e1103,
'call' as e1104,
'enq: IC - IOServer clientID' as e1105,
'enq: IF - file open' as e1106,
'enq: IF - file close' as e1107,
'enq: PT - contention' as e1108,
'enq: PT - ASM Storage May Split' as e1109,
'enq: PM -  contention' as e1110,
'ASM PST operation' as e1111,
'global cache busy' as e1112,
'lock release pending' as e1113,
'dma prepare busy' as e1114,
'GCS lock cancel' as e1115,
'GCS lock open S' as e1116,
'GCS lock open X' as e1117,
'GCS lock open' as e1118,
'GCS lock cvt S' as e1119,
'GCS lock cvt X' as e1120,
'GCS lock esc X' as e1121,
'GCS lock esc' as e1122,
'GCS recovery lock open' as e1123,
'GCS recovery lock convert' as e1124,
'kfcl: instance recovery' as e1125,
'no free locks' as e1126,
'lock close' as e1127,
'enq: KE -  contention' as e1128,
'enq: KQ - access ASM attribute' as e1129,
'ASM Volume Background' as e1130,
'ASM volume directive send' as e1131,
'ASM Volume Resource Action' as e1132,
'enq: AV - persistent DG number' as e1133,
'enq: AV - volume relocate' as e1134,
'enq: AV - AVD client registration' as e1135,
'enq: AV - add/enable first volume in DG' as e1136,
'ASM: OFS Cluster membership update' as e1137,
'ASM Scrubbing I/O' as e1138,
'enq: WF - contention' as e1139,
'enq: WT - contention' as e1140,
'enq: WP - contention' as e1141,
'enq: FU - contention' as e1142,
'enq: MW - contention' as e1143,
'AWR Flush' as e1144,
'AWR Metric Capture' as e1145,
'enq: TB - SQL Tuning Base Cache Update' as e1146,
'enq: TB - SQL Tuning Base Cache Load' as e1147,
'enq: SH - contention' as e1148,
'enq: AF - task serialization' as e1149,
'MMON slave messages' as e1150,
'MMON (Lite) shutdown' as e1151,
'enq: MO - contention' as e1152,
'enq: TL - contention' as e1153,
'enq: TH - metric threshold evaluation' as e1154,
'enq: TK - Auto Task Serialization' as e1155,
'enq: TK - Auto Task Slave Lockout' as e1156,
'enq: RR - contention' as e1157,
'WCR: RAC message context busy' as e1158,
'WCR: capture file IO write' as e1159,
'WCR: Sync context busy' as e1160,
'latch: WCR: sync' as e1161,
'latch: WCR: processes HT' as e1162,
'enq: RA - RT ADDM flood control' as e1163,
'enq: JS - contention' as e1164,
'enq: JS - job run lock - synchronize' as e1165,
'enq: JS - job recov lock' as e1166,
'enq: JS - queue lock' as e1167,
'enq: JS - sch locl enqs' as e1168,
'enq: JS - q mem clnup lck' as e1169,
'enq: JS - evtsub add' as e1170,
'enq: JS - evtsub drop' as e1171,
'enq: JS - wdw op' as e1172,
'enq: JS - evt notify' as e1173,
'enq: JS - aq sync' as e1174,
'enq: XD - ASM disk drop/add' as e1175,
'enq: XD - ASM disk ONLINE' as e1176,
'enq: XD - ASM disk OFFLINE' as e1177,
'cell worker online completion' as e1178,
'cell worker retry ' as e1179,
'cell manager cancel work request' as e1180,
'opening cell offload device' as e1181,
'ioctl to cell offload device' as e1182,
'reap block level offload operations' as e1183,
'CDB: Per Instance Query for PDB Info' as e1184,
'enq: PB - PDB Lock' as e1185,
'secondary event' as e1186
 )
  )
order by snap_id;
-------------------------------------------------------------
-- service stat
--service_names
SELECT * FROM sys.WRH$_STAT_NAME sn
WHERE sn.dbid=&&v_dbid
  AND sn.stat_id IN (SELECT DISTINCT sst.stat_id FROM sys.wrh$_service_stat sst WHERE sst.dbid=&&v_dbid AND sst.snap_id BETWEEN &&v_bsnap and &&v_esnap)
ORDER BY stat_name

;
define v_statname='DB CPU'
SELECT * FROM sys.wrh$_service_name sn WHERE sn.dbid=&&v_dbid ORDER BY service_name;
SELECT ''''||sn.service_name_hash||''' as '||SubStr( regexp_replace(sn.service_name,'[-\.]','_'), 1, 30)||',' AS col FROM sys.wrh$_service_name sn WHERE sn.dbid=&&v_dbid;

SELECT *
FROM (
WITH b AS (SELECT sst.snap_id, sst.service_name_hash, sst.value AS stat_value
FROM sys.wrh$_service_stat sst
WHERE sst.dbid=&&v_dbid
  AND sst.snap_id between &&v_bsnap and &&v_esnap
  AND sst.stat_id=(SELECT sn.stat_id FROM sys.WRH$_STAT_NAME sn WHERE sn.dbid=&&v_dbid AND sn.stat_name='&&v_statname') ),
     e AS (SELECT sst.snap_id, sst.service_name_hash, sst.Value AS stat_value
FROM sys.wrh$_service_stat sst
WHERE sst.dbid=&&v_dbid
  AND sst.snap_id between &&v_bsnap and &&v_esnap
  AND sst.stat_id=(SELECT sn.stat_id FROM sys.WRH$_STAT_NAME sn WHERE sn.dbid=&&v_dbid AND sn.stat_name='&&v_statname')
)
select e.snap_id as snap_id, e.service_name_hash as service_name_hash,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as stat_value
from b, e
where e.snap_id=(b.snap_id + 1) and e.service_name_hash=b.service_name_hash )
pivot (
Max(stat_value)
FOR service_name_hash IN (
'68180435' as fr_int_acct_spb_ertelecom_ru,
'85982699' as private_web_credolink_erteleco,
'164634665' as fr_wifi_acct_ic_ertelecom_ru,
'165959219' as SYS$BACKGROUND,
'207962200' as public_web_ic_ertelecom_ru,
'311744581' as cron_wc_spb_ertelecom_ru,
'518033491' as public_web_akado_spb_ertelecom,
'568750091' as cron_akado_spb_ertelecom_ru,
'584532797' as public_web_credolink_ertelecom,
'658945016' as arm_wc_spb_ertelecom_ru,
'726937858' as cron_spb_ertelecom_ru,
'856732863' as arm_credolink_ertelecom_ru,
'1008357184' as fr_wifi_auth_spb_ertelecom_ru,
'1026092995' as arm_ic_ertelecom_ru,
'1030262783' as billing_cron_spb_ertelecom_ru,
'1046062779' as ggreplicat_iz_ertelecom_ru,
'1110717807' as billing_ic_ertelecom_ru,
'1362571512' as arm_spb_ertelecom_ru,
'1438152112' as fr_wifi_acct_spb_ertelecom_ru,
'1443700763' as cron_iz_ertelecom_ru,
'1569327234' as billing_wc_spb_ertelecom_ru,
'1717231868' as billing_private_web_iz_ertelec,
'1724533213' as ggextract_iz_ertelecom_ru,
'1750558201' as billing_public_web_iz_erteleco,
'1844991858' as odi,
'1917491167' as billing_iz_ertelecom_ru,
'1936879931' as arm_akado_spb_ertelecom_ru,
'2045746603' as private_web_wc_spb_ertelecom_r,
'2079144500' as fr_gsv_acct_ic_ertelecom_ru,
'2083852886' as fr_int_auth_spb_ertelecom_ru,
'2167009997' as fr_wifi_auth_ic_ertelecom_ru,
'2193854716' as cron_ic_ertelecom_ru,
'2300734854' as public_web_iz_ertelecom_ru,
'2427670609' as billing_credolink_ertelecom_ru,
'2467829346' as billing_spb_ertelecom_ru,
'2568097075' as billing_stpetersburg_ertelecom,
'2614086244' as ggreplicat_spb_ertelecom_ru,
'2636077173' as fr_gsv_acct_spb_ertelecom_ru,
'2657905305' as billing_private_web_stpetersbu,
'2749790878' as cron_credolink_ertelecom_ru,
'2886338973' as billing_cron_iz_ertelecom_ru,
'2920096194' as private_web_akado_spb_erteleco,
'3205768157' as ggextract_spb_ertelecom_ru,
'3235973120' as fr_int_auth_ic_ertelecom_ru,
'3260762177' as billing_cron_stpetersburg_erte,
'3331913516' as fr_gsv_auth_ic_ertelecom_ru,
'3363528448' as billing_akado_spb_ertelecom_ru,
'3399492279' as arm_iz_ertelecom_ru,
'3427055676' as SYS$USERS,
'3461544094' as fr_gsv_auth_spb_ertelecom_ru,
'3632043770' as private_web_ic_ertelecom_ru,
'3633793097' as fr_int_acct_ic_ertelecom_ru,
'3724175039' as public_web_wc_spb_ertelecom_ru,
'3978870396' as public_web_spb_ertelecom_ru,
'4203987507' as private_web_iz_ertelecom_ru,
'4238820648' as private_web_spb_ertelecom_ru,
'4294464263' as billing_public_web_stpetersbur
 )
)
ORDER BY snap_id asc
;

SELECT ''''||sn.service_name_hash||''' as '||SubStr( regexp_replace(sn.service_name,'[-\.]','_'), 1, 30)||',' AS col FROM sys.wrh$_service_name sn WHERE sn.dbid=&&v_dbid;

SELECT *
FROM (
SELECT Trunc(t.sample_time,'hh24') AS datetime, t.service_hash AS service_hash, 
       --Sum(Round(t.pga_allocated/1024/1024,2)) AS stat_value
       Count(DISTINCT t.session_id||'.'||t.session_serial# ) AS stat_value
FROM sys.dba_hist_active_sess_history t
             WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
             GROUP BY Trunc(t.sample_time,'hh24'), t.service_hash
)
pivot (
Max(stat_value)
FOR service_hash IN (
'68180435' as fr_int_acct_spb_ertelecom_ru,
'85982699' as private_web_credolink_erteleco,
'164634665' as fr_wifi_acct_ic_ertelecom_ru,
'165959219' as SYS$BACKGROUND,
'207962200' as public_web_ic_ertelecom_ru,
'311744581' as cron_wc_spb_ertelecom_ru,
'518033491' as public_web_akado_spb_ertelecom,
'568750091' as cron_akado_spb_ertelecom_ru,
'584532797' as public_web_credolink_ertelecom,
'658945016' as arm_wc_spb_ertelecom_ru,
'726937858' as cron_spb_ertelecom_ru,
'856732863' as arm_credolink_ertelecom_ru,
'1008357184' as fr_wifi_auth_spb_ertelecom_ru,
'1026092995' as arm_ic_ertelecom_ru,
'1030262783' as billing_cron_spb_ertelecom_ru,
'1046062779' as ggreplicat_iz_ertelecom_ru,
'1110717807' as billing_ic_ertelecom_ru,
'1362571512' as arm_spb_ertelecom_ru,
'1438152112' as fr_wifi_acct_spb_ertelecom_ru,
'1443700763' as cron_iz_ertelecom_ru,
'1569327234' as billing_wc_spb_ertelecom_ru,
'1717231868' as billing_private_web_iz_ertelec,
'1724533213' as ggextract_iz_ertelecom_ru,
'1750558201' as billing_public_web_iz_erteleco,
'1844991858' as odi,
'1917491167' as billing_iz_ertelecom_ru,
'1936879931' as arm_akado_spb_ertelecom_ru,
'2045746603' as private_web_wc_spb_ertelecom_r,
'2079144500' as fr_gsv_acct_ic_ertelecom_ru,
'2083852886' as fr_int_auth_spb_ertelecom_ru,
'2167009997' as fr_wifi_auth_ic_ertelecom_ru,
'2193854716' as cron_ic_ertelecom_ru,
'2300734854' as public_web_iz_ertelecom_ru,
'2427670609' as billing_credolink_ertelecom_ru,
'2467829346' as billing_spb_ertelecom_ru,
'2568097075' as billing_stpetersburg_ertelecom,
'2614086244' as ggreplicat_spb_ertelecom_ru,
'2636077173' as fr_gsv_acct_spb_ertelecom_ru,
'2657905305' as billing_private_web_stpetersbu,
'2749790878' as cron_credolink_ertelecom_ru,
'2886338973' as billing_cron_iz_ertelecom_ru,
'2920096194' as private_web_akado_spb_erteleco,
'3205768157' as ggextract_spb_ertelecom_ru,
'3235973120' as fr_int_auth_ic_ertelecom_ru,
'3260762177' as billing_cron_stpetersburg_erte,
'3331913516' as fr_gsv_auth_ic_ertelecom_ru,
'3363528448' as billing_akado_spb_ertelecom_ru,
'3399492279' as arm_iz_ertelecom_ru,
'3427055676' as SYS$USERS,
'3461544094' as fr_gsv_auth_spb_ertelecom_ru,
'3632043770' as private_web_ic_ertelecom_ru,
'3633793097' as fr_int_acct_ic_ertelecom_ru,
'3724175039' as public_web_wc_spb_ertelecom_ru,
'3978870396' as public_web_spb_ertelecom_ru,
'4203987507' as private_web_iz_ertelecom_ru,
'4238820648' as private_web_spb_ertelecom_ru,
'4294464263' as billing_public_web_stpetersbur
 )
)
ORDER BY datetime asc
;


--define v_sname="billing_private_web.nnovgorod.ertelecom.ru"
--define v_sname="billing_private_web.rostov.ertelecom.ru"
--define v_sname="billing_public_web.nnovgorod.ertelecom.ru"
--define v_sname="billing_public_web.rostov.ertelecom.ru"
--define v_sname="private_web.nn.ertelecom.ru"
define v_sname="private_web.rostov.ertelecom.ru"
--define v_sname="public_web.nn.ertelecom.ru"
--define v_sname="public_web.rostov.ertelecom.ru"

SELECT *
FROM (
WITH  b AS (SELECT  sst.snap_id AS snap_id, sn.stat_name AS stat_name, sst.Value AS stat_value
FROM sys.wrh$_service_stat sst, sys.WRH$_STAT_NAME sn
WHERE sst.dbid=&&v_dbid
  AND sst.snap_id between &&v_bsnap and &&v_esnap
  --AND sst.snap_id=28889
  AND sst.service_name_hash = (SELECT sn.service_name_hash FROM sys.wrh$_service_name sn WHERE sn.dbid=&&v_dbid AND sn.service_name='&&v_sname')
  AND sst.dbid=sn.dbid AND sst.stat_id=sn.stat_id),
      e AS (SELECT  sst.snap_id AS snap_id, sn.stat_name AS stat_name, sst.Value AS stat_value
FROM sys.wrh$_service_stat sst, sys.WRH$_STAT_NAME sn
WHERE sst.dbid=&&v_dbid
  AND sst.snap_id between &&v_bsnap and &&v_esnap
  --AND sst.snap_id=28889
  AND sst.service_name_hash = (SELECT sn.service_name_hash FROM sys.wrh$_service_name sn WHERE sn.dbid=&&v_dbid AND sn.service_name='&&v_sname')
  AND sst.dbid=sn.dbid AND sst.stat_id=sn.stat_id)
select e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as stat_value
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
  )
pivot (
Max(stat_value)
FOR stat_name IN (
'application wait time' as application_wait_time,
'cluster wait time' as cluster_wait_time,
'concurrency wait time' as concurrency_wait_time,
'db block changes' as db_block_changes,
'DB CPU' as DB_CPU,
'DB time' as DB_time,
'execute count' as execute_count,
'gc cr block receive time' as gc_cr_block_receive_time,
'gc cr blocks received' as gc_cr_blocks_received,
'gc current block receive time' as gc_current_block_receive_time,
'gc current blocks received' as gc_current_blocks_received,
'logons cumulative' as logons_cumulative,
'opened cursors cumulative' as opened_cursors_cumulative,
'parse count (total)' as parse_count_total,
'parse time elapsed' as parse_time_elapsed,
'physical reads' as physical_reads,
'physical writes' as physical_writes,
'redo size' as redo_size,
'session cursor cache hits' as session_cursor_cache_hits,
'session logical reads' as session_logical_reads,
'sql execute elapsed time' as sql_execute_elapsed_time,
'user calls' as user_calls,
'user commits' as user_commits,
'user I/O wait time' as user_IO_wtime,
'user rollbacks' as user_rollbacks,
'workarea executions - multipass' as wa_multipass,
'workarea executions - onepass' as wa_onepass,
'workarea executions - optimal' as wa_optimal
 )
)
ORDER BY snap_id asc
;

SELECT * FROM  WRH$_SYSSTAT st
;
SELECT * from WRH$_STAT_NAME sn
WHERE sn.stat_id IN (63887964,85052502,326482564,582481098,798730793,916801489,1099569955,1190468109,1236385760,1388758753,1431595225,1759426133,2263124246,2432034337,2453370665,2666645286,2748282437,2821698184,2877738702,2882015696,3143187968,3211650785,3332107451,3649082374,3671147913,3678609077,3804491469,3868577743
)
ORDER BY sn.stat_name;


SELECT *
FROM sys.wrh$_service_name sn
WHERE sn.dbid=&&v_dbid AND sn.service_name IN ('billing_private_web.nnovgorod.ertelecom.ru','billing_private_web.rostov.ertelecom.ru','billing_public_web.nnovgorod.ertelecom.ru','billing_public_web.rostov.ertelecom.ru','private_web.nn.ertelecom.ru','private_web.rostov.ertelecom.ru','public_web.nn.ertelecom.ru','public_web.rostov.ertelecom.ru')
;
-------------------------------------------------------------
select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'buffer busy waits', 'cursor: mutex S', 'cursor: mutex X', 'cursor: pin S', 'cursor: pin S wait on X', 'cursor: pin X', 'db flash cache invalidate wait', 'enq: HV - contention', 'enq: TX - index contention', 'enq: WG - lock fso', 'latch: cache buffers chains', 'latch: In memory undo latch', 'latch: MQL Tracking Latch', 'latch: row cache objects', 'latch: shared pool', 'latch: Undo Hint Latch', 'libcache interrupt action by LCK', 'library cache load lock', 'library cache lock', 'library cache: mutex S', 'library cache: mutex X', 'library cache pin', 'logout restrictor', 'os thread startup', 'pipe put', 'resmgr:internal state change', 'resmgr:sessions to exit', 'row cache lock', 'row cache read', 'securefile chain update', 'SecureFile mutex', 'Shared IO Pool Memory', 'Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'buffer busy waits', 'cursor: mutex S', 'cursor: mutex X', 'cursor: pin S', 'cursor: pin S wait on X', 'cursor: pin X', 'db flash cache invalidate wait', 'enq: HV - contention', 'enq: TX - index contention', 'enq: WG - lock fso', 'latch: cache buffers chains', 'latch: In memory undo latch', 'latch: MQL Tracking Latch', 'latch: row cache objects', 'latch: shared pool', 'latch: Undo Hint Latch', 'libcache interrupt action by LCK', 'library cache load lock', 'library cache lock', 'library cache: mutex S', 'library cache: mutex X', 'library cache pin', 'logout restrictor', 'os thread startup', 'pipe put', 'resmgr:internal state change', 'resmgr:sessions to exit', 'row cache lock', 'row cache read', 'securefile chain update', 'SecureFile mutex', 'Shared IO Pool Memory', 'Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'buffer busy waits' as buffer_busy_waits,
'cursor: mutex S' as cursor__mutex_S,
'cursor: mutex X' as cursor__mutex_X,
'cursor: pin S' as cursor__pin_S,
'cursor: pin S wait on X' as cursor__pin_S_wait_on_X,
'cursor: pin X' as cursor__pin_X,
'db flash cache invalidate wait' as db_flash_cache_invalidate_wait,
'enq: HV - contention' as eqnHV___contention,
'enq: TX - index contention' as eqnTX___index_contention,
'enq: WG - lock fso' as eqnWG___lock_fso,
'latch: cache buffers chains' as latch__cache_buffers_chains,
'latch: In memory undo latch' as latch__In_memory_undo_latch,
'latch: MQL Tracking Latch' as latch__MQL_Tracking_Latch,
'latch: row cache objects' as latch__row_cache_objects,
'latch: shared pool' as latch__shared_pool,
'latch: Undo Hint Latch' as latch__Undo_Hint_Latch,
'libcache interrupt action by LCK' as libcacheIntrrptActionByLCK,
'library cache load lock' as library_cache_load_lock,
'library cache lock' as library_cache_lock,
'library cache: mutex S' as library_cache__mutex_S,
'library cache: mutex X' as library_cache__mutex_X,
'library cache pin' as library_cache_pin,
'logout restrictor' as logout_restrictor,
'os thread startup' as os_thread_startup,
'pipe put' as pipe_put,
'resmgr:internal state change' as resmgr_internal_state_change,
'resmgr:sessions to exit' as resmgr_sessions_to_exit,
'row cache lock' as row_cache_lock,
'row cache read' as row_cache_read,
'securefile chain update' as securefile_chain_update,
'SecureFile mutex' as SecureFile_mutex,
'Shared IO Pool Memory' as Shared_IO_Pool_Memory,
'Streams apply: waiting for dependency' as StrmsApplyWaiting4dependency
)
    )
order by snap_id;


-- resource usage
select  S.BEGIN_INTERVAL_TIME as snap_time,
        s.snap_id,
        T.RESOURCE_NAME,
        T.CURRENT_UTILIZATION,
        T.INITIAL_ALLOCATION,
        T.MAX_UTILIZATION,
        T.LIMIT_VALUE
from WRH$_RESOURCE_LIMIT t, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and t.DBID=S.DBID and t.INSTANCE_NUMBER=S.INSTANCE_NUMBER and t.SNAP_ID=S.SNAP_ID
  and T.RESOURCE_NAME='processes'
order by s.SNAP_ID;

select *
from (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        s.snap_id as snap_id,
        T.RESOURCE_NAME as res_name,
        T.LIMIT_VALUE-T.CURRENT_UTILIZATION as free_resource
from WRH$_RESOURCE_LIMIT t, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and t.DBID=S.DBID and t.INSTANCE_NUMBER=S.INSTANCE_NUMBER and t.SNAP_ID=S.SNAP_ID
  and T.RESOURCE_NAME IN ('sessions','processes','max_shared_servers')
  )
pivot (
max(free_resource)
for res_name in (
'max_shared_servers' as max_sh_srvrs,
'processes' as prcss,
'sessions' as sssns
 )
  )
order by SNAP_ID;


--connection dispatchers
SELECT *
FROM (
SELECT snap_time, snap_id, name, --snap_delta, ns_delta,
       CASE WHEN ns_delta>0 THEN Round(snap_delta/ns_delta,0) ELSE 0 END AS connections
FROM (
WITH local_data AS (SELECT BEGIN_INTERVAL_TIME as snap_time, s.snap_id, sss.num_samples, t.sampled_total_conn, t.name
FROM sys.wrh$_SHARED_SERVER_SUMMARY sss, sys.wrh$_dispatcher t, sys.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and t.DBID=S.DBID and t.INSTANCE_NUMBER=S.INSTANCE_NUMBER and t.SNAP_ID=S.SNAP_ID
  AND sss.dbid=s.dbid AND sss.INSTANCE_NUMBER=S.INSTANCE_NUMBER and sss.SNAP_ID=S.SNAP_ID
--ORDER BY s.snap_id ASC, t.name asc
),
b as ( select * from local_data ),
e as ( select * from local_data )
SELECT e.snap_time, e.snap_id, e.num_samples AS ens, b.num_samples AS bns, e.sampled_total_conn, e.name,
       case when (e.sampled_total_conn - b.sampled_total_conn) < 0 then null else (e.sampled_total_conn - b.sampled_total_conn) end as snap_delta,
       case when (e.num_samples - b.num_samples) < 0 then null else (e.num_samples - b.num_samples) end as ns_delta
FROM b, e
WHERE e.snap_id=(b.snap_id+1) AND e.name=b.name
ORDER BY e.snap_id ASC, e.name asc
 )
  )

pivot(
max(connections)
for name in (
 'D000' AS D000,
 'D001' AS D001,
 'D002' AS D002,
 'D003' AS D003,
 'D004' AS D004,
 'D005' AS D005
)
)
ORDER BY snap_id asc
;

select *
from (
with
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        RL.RESOURCE_NAME as stat_name,
        RL.CURRENT_UTILIZATION as stat_value
from WRH$_RESOURCE_LIMIT rl, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and RL.DBID=S.DBID and RL.INSTANCE_NUMBER=S.INSTANCE_NUMBER and RL.SNAP_ID=S.SNAP_ID
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 )
pivot (
max(value_diff)
for stat_name in (
'enqueue_locks' as eqn_locks,
'max_rollback_segments' as max_rllbck_sgmnts,
'max_shared_servers' as max_sh_srvrs,
'processes' as prcss,
'sessions' as sssns
)
 )
order by snap_id;
--------------------------------------------------------------------------------

-- Dispatcher stats
SELECT *
FROM (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       d.name AS dispatcher,
       --d.totalq AS stat_value
       Round( d.busy/(d.busy+d.idle) , 4) AS stat_value
       --d.sampled_total_conn AS sampled_total_conn,
       --sh_stat.num_samples AS num_samples
       --Round(d.sampled_total_conn/sh_stat.num_samples,2) AS stat_value
from WRM$_SNAPSHOT s, sys.wrh$_dispatcher d, wrh$_shared_server_summary  sh_stat
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and d.DBID=s.dbid and d.INSTANCE_NUMBER=S.INSTANCE_NUMBER and d.snap_id=s.snap_id
  and s.dbid=sh_stat.dbid and S.snap_id=sh_stat.snap_id and s.INSTANCE_NUMBER=sh_stat.INSTANCE_NUMBER
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.dispatcher AS dispatcher,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as stat_value
from b, e
where e.snap_id=(b.snap_id+1) and e.dispatcher=b.dispatcher
 )
pivot (
Max(stat_value)
FOR dispatcher IN (
  'D000' AS D000,
  'D001' AS D001,
  'D002' AS D002,
  'D003' AS D003,
  'D004' AS D004
 )
)
ORDER BY snap_id;


SELECT *
FROM sys.wrh$_dispatcher t
WHERE t.dbid=&&v_dbid and t.SNAP_ID between &&v_bsnap and &&v_esnap
ORDER BY t.snap_id, t.name
;
--------------------------------------------------------------------------------
-- shared_server stat
SELECT *
FROM sys.dba_hist_shared_server_summary t
ORDER BY t.snap_id
;
--------------------------------------------------------------------------------

-- DataGuard events
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO)/1000000 as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and se.event_id=EN.EVENT_ID and se.dbid=en.dbid
  and EN.EVENT_NAME in (
  'LGWR wait on ATTACH','LGWR wait on DETACH','LGWR wait on LNS','LGWR wait on SENDREQ','LNS ASYNC archive log','LNS ASYNC dest activation','LNS ASYNC end of log','LNS simulation latency wait','LNS wait on ATTACH','LNS wait on DETACH','LNS wait on LGWR','LNS wait on SENDREQ'
  )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'LGWR wait on ATTACH' as LGWR_wait_on_ATTACH,
'LGWR wait on DETACH' as LGWR_wait_on_DETACH,
'LGWR wait on LNS' as LGWR_wait_on_LNS,
'LGWR wait on SENDREQ' as LGWR_wait_on_SENDREQ,
'LNS ASYNC archive log' as LNS_ASYNC_archive_log,
'LNS ASYNC dest activation' as LNS_ASYNC_dest_activation,
'LNS ASYNC end of log' as LNS_ASYNC_end_of_log,
'LNS simulation latency wait' as LNS_simulation_latency_wait,
'LNS wait on ATTACH' as LNS_wait_on_ATTACH,
'LNS wait on DETACH' as LNS_wait_on_DETACH,
'LNS wait on LGWR' as LNS_wait_on_LGWR,
'LNS wait on SENDREQ' as LNS_wait_on_SENDREQ
)
  )
order by snap_id;
------------------------


-- Commit stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'commit batch performed','commit batch requested','commit batch/immediate performed','commit batch/immediate requested','commit immediate performed','commit immediate requested','commit nowait performed','commit nowait requested','commit wait performed','commit wait requested','commit wait/nowait performed','commit wait/nowait requested','user commits'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as (select * from local_data),
e as (select * from local_data)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'commit batch performed' as cbatch_performed,
'commit batch requested' as cbatch_requested,
'commit batch/immediate performed' as cbatch_immediate_performed,
'commit batch/immediate requested' as cbatch_immediate_requested,
'commit immediate performed' as cimmediate_performed,
'commit immediate requested' as cimmediate_requested,
'commit nowait performed' as cnowait_performed,
'commit nowait requested' as cnowait_requested,
'commit wait performed' as ct_wait_performed,
'commit wait requested' as cwait_requested,
'commit wait/nowait performed' as cwait_nowait_performed,
'commit wait/nowait requested' as cwait_nowait_requested,
'user commits' as user_commits
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- Physical Reads stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical read total IO requests','physical read total multi block requests','physical reads','physical reads cache','physical read flash cache hits','physical reads direct','physical reads direct temporary tablespace','physical reads cache prefetch','physical reads prefetch warmup','physical reads retry corrupt','physical reads direct (lob)'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read total IO requests' as total_IO_read_rqsts,
'physical read total multi block requests' as total_mblckIO_read_rqsts,
'physical reads' as phr,
'physical reads cache' as phr_cache,
'physical read flash cache hits' as phr_flash_cache_hits,
'physical reads direct' as phr_direct,
'physical reads direct temporary tablespace' as phr_direct_tmp_tblspc,
'physical reads cache prefetch' as phr_cache_prefetch,
'physical reads prefetch warmup' as phr_prefetch_warmup,
'physical reads retry corrupt' as phr_retry_corrupt,
'physical reads direct (lob)' as phr_direct_lob
)
 )
order by snap_time;
--------------------------------------------------------------------------------
-- Physical Write stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical write total IO requests','physical write total multi block requests','physical writes','physical writes direct','physical writes from cache','physical write IO requests','physical writes direct temporary tablespace','physical writes non checkpoint','physical writes direct (lob)'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical write total IO requests' AS total_write_IO,
'physical write total multi block requests' as total_mblck_wrire_IO_rqsts,
'physical writes'  as phw,
'physical writes direct' AS direct_wrts,
'physical writes from cache' AS wrts_from_cache,
'physical write IO requests' AS wrte_IO_reqsts,
'physical writes direct temporary tablespace' wrt_direct_temp_tbs,
'physical writes non checkpoint' wrts_non_chkpt,
'physical writes direct (lob)' wrts_direct_lob
)
 )
order by snap_time;


-- Physical IO stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical read IO requests','physical read total IO requests','physical read total multi block requests','physical write IO requests','physical write total IO requests','physical write total multi block requests'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read IO requests' as pr_IO_rqsts,
--'physical read requests optimized' as pr_rqsts_optimized,
'physical read total IO requests' as pr_ttl_IO_rqsts,
'physical read total multi block requests' as pr_total_mlt_blck_rqsts,
'physical write IO requests' as pw_IO_rqsts,
'physical write total IO requests' as pw_ttl_IO_rqsts,
'physical write total multi block requests' as pw_ttl_mlt_blck_rqsts
)
 )
order by snap_time;
--------------------------------------------------------------------------------
--redo-group
SELECT t.group#,
       Round(t.bytes/1024/1024,2) AS size_mg,
       t.members, t.archived, t.status
FROM sys.wrh$_log t
WHERE t.dbid=&&v_dbid
  AND t.snap_id=&&v_esnap
;

-- Redo stats
select *
from (
with
local_data as (
select --Trunc(S.BEGIN_INTERVAL_TIME,'HH24') as snap_time,
       to_char(S.BEGIN_INTERVAL_TIME,'YYYY-MM-DD_hh24:MI') as snap_time,
       --S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  --AND s.snap_id NOT IN (&&v_skip_snaps)
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'redo KB read','redo KB read (memory)','redo KB read (memory) for transport','redo KB read for transport','redo blocks checksummed by FG (exclusive)','redo blocks checksummed by LGWR','redo blocks read for recovery','redo blocks written','redo buffer allocation retries','redo entries','redo entries for lost write detection','redo k-bytes read for recovery','redo k-bytes read for terminal recovery','redo log space requests','redo log space wait time','redo ordering marks','redo size','redo size for direct writes','redo size for lost write detection','redo subscn max counts','redo synch long waits','redo synch poll writes','redo synch polls','redo synch time','redo synch time (usec)','redo synch writes','redo wastage','redo write broadcast ack count','redo write broadcast ack time','redo write broadcast lgwr post count','redo write time','redo writes'
  )
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'redo KB read' as r_KB_read,
'redo KB read (memory)' as r_KB_read_memory,
'redo KB read (memory) for transport' as r_KB_read_mem4transport,
'redo KB read for transport' as r_KB_read4transport,
'redo blocks checksummed by FG (exclusive)' as r_blcks_chcksmmd_byFGexclusive,
'redo blocks checksummed by LGWR' as r_blocks_checksummed_by_LGWR,
'redo blocks read for recovery' as r_blocks_read4recovery,
'redo blocks written' as r_blocks_written,
'redo buffer allocation retries' as r_buffer_allocation_retries,
'redo entries' as r_entries,
'redo entries for lost write detection' as r_entries4lost_write_detection,
'redo k-bytes read for recovery' as r_kb_read4recovery,
'redo k-bytes read for terminal recovery' as r_kb_read4terminal_recovery,
'redo log space requests' as r_log_space_requests,
'redo log space wait time' as r_log_space_wait_time,
'redo ordering marks' as r_ordering_marks,
'redo size' as r_size,
'redo size for direct writes' as r_size4direct_writes,
'redo size for lost write detection' as r_size4lost_wr_detection,
'redo subscn max counts' as r_subscn_max_counts,
'redo synch long waits' as r_synch_long_waits,
'redo synch poll writes' as r_synch_poll_writes,
'redo synch polls' as r_synch_polls,
'redo synch time' as r_synch_time,
'redo synch time (usec)' as r_synch_time_usec,
'redo synch writes' as r_synch_writes,
'redo wastage' as r_wastage,
'redo write broadcast ack count' as rw_broadcast_ack_count,
'redo write broadcast ack time' as rw_broadcast_ack_time,
'redo write broadcast lgwr post count' as rw_broadcast_lgwr_post_count,
'redo write time' as rw_time,
'redo writes' as RedoWrites
)
 )
order by snap_time;
--------------------------------------------------------------------------------
-- Arclog size:

SELECT  Trunc(t.COMPLETION_TIME,'HH24') AS COMPLETION_TIME,
        Round(Sum(t.BLOCKS*t.BLOCK_SIZE)/1024/1024,2) AS arclogs_size_MB
FROM v$archived_log t
WHERE t.RESETLOGS_CHANGE#=(SELECT RESETLOGS_CHANGE# FROM v$database)
GROUP BY Trunc(t.COMPLETION_TIME,'HH24')
ORDER BY Trunc(t.COMPLETION_TIME,'HH24');


-- Commit stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'commit batch performed','commit batch requested','commit batch/immediate performed','commit batch/immediate requested','commit cleanout failures: block lost','commit cleanout failures: buffer being written','commit cleanout failures: callback failure ','commit cleanout failures: cannot pin','commit cleanout failures: hot backup in progress','commit cleanout failures: write disabled','commit cleanouts','commit cleanouts successfully completed','commit immediate performed','commit immediate requested','commit nowait performed','commit nowait requested','commit txn count during cleanout','commit wait performed','commit wait requested','commit wait/nowait performed','commit wait/nowait requested','user commits'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'commit batch performed' as c_batch_performed,
'commit batch requested' as c_batch_requested,
'commit batch/immediate performed' as c_batch_immediate_performed,
'commit batch/immediate requested' as c_batch_immediate_requested,
'commit cleanout failures: block lost' as c_cleanout_failures_block_lost,
'commit cleanout failures: buffer being written' as c_clnt_flrs_bffr_being_wrttn,
'commit cleanout failures: callback failure ' as c_clnt_flrs_cllbk_flr,
'commit cleanout failures: cannot pin' as c_cleanout_failures_cannot_pin,
'commit cleanout failures: hot backup in progress' as c_clnt_flrs_ht_bkp_in_prgrss,
'commit cleanout failures: write disabled' as c_clnt_flrs_wrt_dsbld,
'commit cleanouts' as c_cleanouts,
'commit cleanouts successfully completed' as c_clnts_sccssfll_cmpltd,
'commit immediate performed' as c_immediate_performed,
'commit immediate requested' as c_immediate_requested,
'commit nowait performed' as c_nowait_performed,
'commit nowait requested' as c_nowait_requested,
'commit txn count during cleanout' as c_txn_count_during_cleanout,
'commit wait performed' as c_wait_performed,
'commit wait requested' as c_wait_requested,
'commit wait/nowait performed' as c_wait_nowait_performed,
'commit wait/nowait requested' as c_wait_nowait_requested,
'user commits' as user_commits
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- Parse stat ------------------------------------------------------------------
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'parse time cpu','parse time elapsed','parse count (total)','parse count (hard)','parse count (failures)','parse count (describe)'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'parse time cpu' as parse_time_cpu,
'parse time elapsed' as parse_time_elapsed,
'parse count (total)' as parse_count_total,
'parse count (hard)' as parse_count_hard,
'parse count (failures)' as parse_count_failures,
'parse count (describe)' as parse_count_describe
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- IOtype : IO Req
--------------------------------------------------------------------------------
select *
from (
with local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FILETYPE_NAME as stat_name,
        /*sum(IFT.SMALL_READ_REQS) as SMALL_READ_REQS,sum(IFT.SMALL_WRITE_REQS) as SMALL_WRITE_REQS,
        sum(IFT.LARGE_READ_REQS) as LARGE_READ_REQS,sum(IFT.LARGE_WRITE_REQS) as LARGE_WRITE_REQS*/
        sum( nvl(IFT.SMALL_READ_REQS,0)+nvl(IFT.SMALL_WRITE_REQS,0)+nvl(IFT.LARGE_READ_REQS,0)+nvl(IFT.LARGE_WRITE_REQS,0) ) as stat_value
from WRH$_IOSTAT_FILETYPE ift, WRM$_SNAPSHOT s, sys.WRH$_IOSTAT_FILETYPE_NAME ifn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FILETYPE_ID=IFT.FILETYPE_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FILETYPE_NAME
--order by S.SNAP_ID
 ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value- b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as stat_value
/*        case when (e.SMALL_READ_REQS - b.SMALL_READ_REQS) < 0 then null else (e.SMALL_READ_REQS - b.SMALL_READ_REQS) end as SMALL_READ_REQS,
        case when (e.SMALL_WRITE_REQS - b.SMALL_WRITE_REQS) < 0 then null else (e.SMALL_WRITE_REQS - b.SMALL_WRITE_REQS) end as SMALL_WRITE_REQS,
        case when (e.LARGE_READ_REQS - b.LARGE_READ_REQS) < 0 then null else (e.LARGE_READ_REQS - b.LARGE_READ_REQS) end as LARGE_READ_REQS,
        case when (e.LARGE_WRITE_REQS - b.LARGE_WRITE_REQS) < 0 then null else (e.LARGE_WRITE_REQS - b.LARGE_WRITE_REQS) end as LARGE_WRITE_REQS*/
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
--max(SMALL_READ_REQS) as SMALL_READ_REQS,max(SMALL_WRITE_REQS) as SMALL_WRITE_REQS,max(LARGE_READ_REQS) as LARGE_READ_REQS,max(LARGE_WRITE_REQS) as LARGE_WRITE_REQS
max(stat_value)
for stat_name in (
'Other' as Other,
'Control File' as CntrlFile,
'Data File' as DataFile,
'Log File' as LogFile,
'Archive Log' as ArchLog,
'Temp File' as TempFile,
'Data File Backup' as DataFileBackup,
'Data File Incremental Backup' as DataFileIncBackup,
'Archive Log Backup' as ArchLogBackup,
'Data File Copy' as DataFileCopy,
'Flashback Log' as FlashbackLog,
'Data Pump Dump File' as DataPumpDumpFile
 )
    )
order by snap_id;
--------------------------------------------------------------------------------
-- IO by filetype: IO ServiceTime
--------------------------------------------------------------------------------
SELECT snap_time, snap_id,
       CASE WHEN prev_small_read_reqs>-1 AND small_read_reqs >= prev_small_read_reqs THEN  small_read_reqs-prev_small_read_reqs ELSE null END AS small_read_reqs,
       CASE WHEN prev_small_write_reqs>-1 AND small_write_reqs >= prev_small_write_reqs THEN  small_write_reqs-prev_small_write_reqs ELSE null END AS small_write_reqs,
       CASE WHEN prev_large_read_reqs>-1 AND large_read_reqs >= prev_large_read_reqs THEN  large_read_reqs-prev_large_read_reqs ELSE null END AS large_read_reqs,
       CASE WHEN prev_large_write_reqs>-1 AND large_write_reqs >= prev_large_write_reqs THEN  large_write_reqs-prev_large_write_reqs ELSE null END AS large_write_reqs

FROM (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ift.small_read_reqs,
        Lag(ift.small_read_reqs,1,-1) OVER (ORDER BY s.snap_id) AS prev_small_read_reqs,
        ift.small_write_reqs,
        Lag(ift.small_write_reqs,1,null) OVER (ORDER BY s.snap_id) AS prev_small_write_reqs,
        ift.large_read_reqs,
        Lag(ift.large_read_reqs,1,null) OVER (ORDER BY s.snap_id) AS prev_large_read_reqs,
        ift.large_write_reqs,
        Lag(ift.large_write_reqs,1,null) OVER (ORDER BY s.snap_id) AS prev_large_write_reqs
from WRH$_IOSTAT_FILETYPE ift, WRM$_SNAPSHOT s, WRH$_IOSTAT_FILETYPE_NAME ifn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FILETYPE_ID=IFT.FILETYPE_ID
  AND IFN.FILETYPE_NAME='Temp File'
order by S.SNAP_ID
 )
;

--------------------------------------------------------------------------------

-- IOStat by iofunction, waittime
select *
from (
with
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FUNCTION_NAME as stat_name,
        sum( nvl(IFT.WAIT_TIME,0) ) as stat_value
from WRH$_IOSTAT_FUNCTION ift, WRM$_SNAPSHOT s, WRH$_IOSTAT_FUNCTION_NAME ifn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FUNCTION_ID=IFT.FUNCTION_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FUNCTION_NAME
--order by S.SNAP_ID
 ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
--order by e.snap_id;
 ) v
pivot (
max(value_diff)
for stat_name in (
'RMAN' as RMAN,
'DBWR' as DBWR,
'LGWR' as LGWR,
'ARCH' as ARCH,
'XDB' as XDB,
'Streams AQ' as StreamsAQ,
'Data Pump' as DataPump,
'Recovery' as Recovery,
'Buffer Cache Reads' as BufferCacheReads,
'Direct Reads' as DirectReads,
'Direct Writes' as DirectWrites,
'Smart Scan' as SmartScan,
'Archive Manager' as ArchManager,
'Others' as Others
 )
    )
order by snap_id;
--------------------------------------------------------------------------------
SELECT *
FROM sys.wrh$_event_name t
WHERE t.dbid=&&v_dbid
  AND t.event_id IN (1136294303,2652584166,3955192389)
;
--------------------------------------------------------------------------------
-- AllStat

SELECT *
       --''''||stat_name||''' as s'||ROWNUM||',' AS col
FROM SYS.WRH$_STAT_NAME sn
WHERE sn.dbid=&&v_dbid
  AND sn.stat_id IN (1612053064,2146120386,3094453259,3455911385,45066233)
;

WITH DATA AS
(SELECT
'RowCR hits,redo write time,DBWR transaction table writes,prefetch clients - default'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as s'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;


-- Given statistics
select *
from (
WITH local_data as (
select --S.BEGIN_INTERVAL_TIME as snap_time,
       To_Char(S.BEGIN_INTERVAL_TIME,'dd/mm.yyyy hh24:mi') AS snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'RowCR hits','redo write time','DBWR transaction table writes','prefetch clients - default'
 )
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'RowCR hits' as s1,
'redo write time' as s2,
'DBWR transaction table writes' as s3,
'prefetch clients - default' as s4
)
 )
order by snap_time;
--------------------------------------------------------------------------------
SELECT listagg(''''||t.event_name||'''',',') within group (ORDER BY NULL) AS event_list
FROM sys.WRH$_EVENT_NAME t
WHERE t.dbid=&&v_dbid
  and t.event_id IN (3999721902,818280116,38438084,4266849434,2278252783)
;

WITH DATA AS
(SELECT
'class slave wait,external table seek,inactive session,latch free,log buffer space,oracle thread bootstrap,os thread creation,undo segment extension,virtual circuit wait'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as e'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;


-- Given events
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID
  --AND en.WAIT_CLASS='Application'
  AND en.event_name IN (
'DBMS_LDAP: LDAP operation ','DBMS_LDAP: LDAP operation ','DBMS_LDAP: LDAP operation ','LGWR wait for redo copy','LGWR wait for redo copy','LGWR wait for redo copy','PL/SQL lock timer','PL/SQL lock timer','PL/SQL lock timer','direct path write temp','direct path write temp','direct path write temp','log file parallel write','log file parallel write','log file parallel write'
  )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'SecureFile mutex' AS e1,'direct path write temp' AS e2
)
    )
order by snap_id;
--------------------------------------------------------------------------------------

-- Latch
SELECT DISTINCT t.where_in_code
FROM sys.wrh$_latch_misses_summary t
WHERE t.parent_name='shared pool'
  AND t.dbid=&&v_dbid AND t.snap_id between &&v_bsnap and &&v_esnap
--ORDER BY t.snap_id
;


SELECT *
FROM (
WITH local_data AS (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        SG.sleep_count AS stat_value,
        SG.where_in_code AS stat_name
from sys.wrh$_latch_misses_summary sg, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and SG.DBID=s.dbid and SG.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SG.SNAP_ID=S.SNAP_ID
  and sg.parent_name='shared pool'
  )
,
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
)
pivot (
 max(value_diff)
 for stat_name in (
'kgh: kghalloc_java_page' as kgh_kghalloc_java_page,
'kgh: kghfree_java_page' as kgh_kghfree_java_page,
'kgh: sim unpin' as kgh_sim_unpin,
'kgh: use reserved extent' as kgh_use_reserved_extent,
'kgh_heap_sizes' as kgh_heap_sizes,
'kghalo' as kghalo,
'kghalp' as kghalp,
'kghasp' as kghasp,
'kghdmp:old' as kghdmp_old,
'kghfnd: get next extent' as kghfnd_get_next_extent,
'kghfnd: min scan' as kghfnd_min_scan,
'kghfnd: req scan' as kghfnd_req_scan,
'kghfre' as kghfre,
'kghfrh' as kghfrh,
'kghfrunp' as kghfrunp,
'kghfrunp: alloc: cursor dur' as kghfrunp_alloc_cursor_dur,
'kghfrunp: alloc: session dur' as kghfrunp_alloc_session_dur,
'kghfrunp: alloc: wait' as kghfrunp_alloc_wait,
'kghfrunp: clatch: nowait' as kghfrunp_clatch_nowait,
'kghfrunp: clatch: wait' as kghfrunp_clatch_wait,
'kghfsh' as kghfsh,
'kghupr1' as kghupr1
 )
)
ORDER BY snap_id;


--------------------------------------------------------------------------------
-- SGASTAT
SELECT DISTINCT t.pool
FROM wrh$_sgastat t
WHERE t.dbid=&&v_dbid;

select *
from (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        SG.POOL,
        --SG.NAME,
        Round(SG.BYTES/1024/1024,2) AS bytes
from WRH$_SGASTAT sg, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and SG.DBID=s.dbid and SG.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SG.SNAP_ID=S.SNAP_ID
  --and sg.pool='shared pool'
  and SG.NAME = 'free memory'
  )
pivot (
 max(bytes)
 for pool in (
 'java pool' as java_pool,
 'large pool' as large_pool,
 'shared pool' as shared_pool,
 'streams pool' as streams_pool
 )
)
order by snap_id;
--------------------------------------------------------------------------------
SELECT DISTINCT t.name
FROM sys.wrh$_sgastat t
WHERE t.dbid=&&v_dbid AND t.pool='shared pool'
;

select *
from (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        --SG.POOL,
        SG.NAME,
        SG.BYTES
from WRH$_SGASTAT sg, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and SG.DBID=s.dbid and SG.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SG.SNAP_ID=S.SNAP_ID
  and sg.pool='shared pool'
  --and SG.NAME = 'free memory'
  )
pivot (
 max(bytes)
 for name in (
'SQLA' as SQLA,
'free memory' as free_memory,
'db_block_hash_buckets' as db_block_hash_buckets,
'KGLHD' as KGLHD,
'object queue hash buckets' as object_queue_hash_buckets,
'KGLH0' as KGLH0,
'KQR X SO' as KQR_X_SO,
'event statistics per sess' as event_statistics_per_sess,
'getl2emc-mem' as getl2emc_mem,
'keomg: entry list ' as keomg_entry_list,
'kglsim heap' as kglsim_heap,
'KQR M PO' as KQR_M_PO,
'KGLS' as KGLS,
'ASH buffers' as ASH_buffers,
'PRTDS' as PRTDS,
'getemc-mem' as getemc_mem,
'SQLP' as SQLP,
'Checkpoint queue' as CheckpointQueue,
'Result Cache' as Result_Cache,
'kglsim object batch' as kglsim_object_batch,
'KQR L PO' as KQR_L_PO,
'allocate segment latch re' as allocate_segment_latch_re,
'PRTMV' as PRTMV,
'KGLNA' as KGLNA,
'private strands' as private_strands
 )
)
order by snap_id;


-- Given SGA-SubPool stat
/*

select distinct s.pool
from WRH$_SGASTAT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap;

select distinct s.name
from WRH$_SGASTAT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  --and s.pool='shared pool'
  and s.pool='large pool'
;

*/

-- Shared pool stat
select *
from (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        --SG.POOL,
        SG.NAME,
        SG.BYTES
from WRH$_SGASTAT sg, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and SG.DBID=s.dbid and SG.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SG.SNAP_ID=S.SNAP_ID
  and sg.pool='large pool'
  --and SG.NAME = 'free memory'
  )
pivot (
 max(bytes)
 for name in (
'free memory' AS free_mem,
'PX msg pool' AS PX_msg_pool,
'session heap' AS session_heap
 )
)
order by snap_id;


-- Large pool stat
select *
from (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        --SG.POOL,
        SG.NAME,
        SG.BYTES
from WRH$_SGASTAT sg, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and SG.DBID=s.dbid and SG.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SG.SNAP_ID=S.SNAP_ID
  and sg.pool='large pool'
  --and SG.NAME = 'free memory'
  )
pivot (
 max(bytes)
 for name in (
'PX msg pool' AS PX_msg_pool,
'free memory' AS free_mem,
'session heap' AS sess_heap
 )
)
order by snap_id;


-- SGA mem dynamic
select *
from (
SELECT s.begin_interval_time AS datetime,
       sg.SNAP_ID as snap_id,
       sg.component AS component,
       sg.current_size AS current_size
FROM SYS.wrh$_mem_dynamic_comp sg, WRM$_SNAPSHOT s
where sg.dbid=&&v_dbid --and S.INSTANCE_NUMBER=1
  and Sg.snap_id between &&v_bsnap and &&v_esnap
  AND sg.dbid=s.dbid AND sg.instance_number=s.instance_number AND sg.snap_id=s.snap_id
  AND sg.component IN ('ASM Buffer Cache','DEFAULT 16K buffer cache','DEFAULT 2K buffer cache','DEFAULT 32K buffer cache','DEFAULT 4K buffer cache','DEFAULT 8K buffer cache','DEFAULT buffer cache','KEEP buffer cache','PGA Target','RECYCLE buffer cache','SGA Target','Shared IO Pool','java pool','large pool','shared pool','streams pool')
  )
pivot (
max(current_size)
for component in (
'ASM Buffer Cache' as q1,
'DEFAULT 16K buffer cache' as q2,
'DEFAULT 2K buffer cache' as q3,
'DEFAULT 32K buffer cache' as q4,
'DEFAULT 4K buffer cache' as q5,
'DEFAULT 8K buffer cache' as q6,
'DEFAULT buffer cache' as q7,
'KEEP buffer cache' as q8,
'PGA Target' as q9,
'RECYCLE buffer cache' as q10,
'SGA Target' as q11,
'Shared IO Pool' as q12,
'java pool' as q13,
'large pool' as q14,
'shared pool' as q15,
'streams pool' as q16
 )
  )
order by snap_id;

SELECT *
      --DISTINCT sg.component
FROM SYS.wrh$_mem_dynamic_comp sg
;
--------------------------------------------------------------------------------
select SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.snap_id between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by SE.EVENT_NAME
order by stat_value desc;

-- Load profile
select  snap_time as snap_time,
        snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
--  order by s.snap_id desc
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
pivot (
max(value_diff)
for stat_name in (
 'execute count' as executions,
 'logons cumulative' as logons,
 'sorts (memory)' as memory_sorts,
 'sorts (disk)' as disk_sorts,
 'parse count (hard)' as hard_parses,
 'parse count (total)' as parses,
 'user calls' as user_calls,
 'physical reads' as physical_reads,
 'physical writes' as physical_writes,
 'db block changes' as block_changes,
 'session logical reads' as logical_reads,
 'redo size' as redo_size,
 'user commits' as user_commit,
 'user rollbacks' as user_rollback)
 )
order by snap_id;

select *
from (
with b as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.POOL as pool,
        ST.BYTES as bytes
from WRM$_SNAPSHOT s, WRH$_SGASTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
e as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.POOL as pool,
        ST.BYTES as bytes
from WRM$_SNAPSHOT s, WRH$_SGASTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.pool as pool,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.pool=b.pool
 ) v
 pivot (
max(value_diff)
for pool in ( '' as other_pool, 'java pool' as java_pool, 'streams pool' as streams_pool, 'shared pool' as shared_pool, 'large pool' as large_pool )
 )
order by snap_time;


select distinct st.name
from WRH$_SGA st
where st.dbid=&&v_dbid and ST.INSTANCE_NUMBER=1 and ST.SNAP_ID between &&v_bsnap and &&v_esnap;


select *
from (
with b as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as pool,
        ST.value as bytes
from WRM$_SNAPSHOT s, WRH$_SGA st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
e as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as pool,
        ST.value as bytes
from WRM$_SNAPSHOT s, WRH$_SGA st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.pool as pool,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.pool=b.pool
 ) v
 pivot (
max(value_diff)
for pool in ( 'Database Buffers' as db_chache,'Redo Buffers' as redo_buffer,'Variable Size' as variable_size,'Fixed Size' as fixed_size )
 )
order by snap_time;

-- PGA Stat --------------------------------------------------------------------
select *
from (
with local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as stat_name,
        Round(ST.Value/1024/1024,2) as bytes
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.NAME in ('extra bytes read/written','total PGA inuse','total PGA allocated','maximum PGA allocated')
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 ) v
 pivot (
 max(value_diff)
for stat_name in (
'extra bytes read/written' as extra_bytes,
'total PGA inuse' as pga_inuse,
'total PGA allocated' as pga_alloc,
'maximum PGA allocated' as max_pga_alloc
 )
 )
order by snap_id asc;
-- SQL WA Stat -----------------------------------------------------------------
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.LOW_OPTIMAL_SIZE as LOW_OPTIMAL_SIZE,
        ST.HIGH_OPTIMAL_SIZE as HIGH_OPTIMAL_SIZE,
        ST.OPTIMAL_EXECUTIONS as OPTIMAL_EXECUTIONS,
        ST.ONEPASS_EXECUTIONS as ONEPASS_EXECUTIONS,
        ST.MULTIPASSES_EXECUTIONS as MULTIPASSES_EXECUTIONS,
        ST.TOTAL_EXECUTIONS as TOTAL_EXECUTIONS
from WRM$_SNAPSHOT s, WRH$_SQL_WORKAREA_HISTOGRAM st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
order by snap_time, LOW_OPTIMAL_SIZE;

--------------------------------------------------------------------------------

-- histogramm  HISTOGRAM
SELECT st.wait_time_milli,
       Trunc( Avg(st.wait_count), 4) AS average,
       Trunc( StdDev(st.wait_count), 4) AS std_deviation
FROM sys.WRM$_SNAPSHOT s, sys.wrh$_event_histogram st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  AND st.event_id=(SELECT en.event_id FROM sys.wrh$_event_name en WHERE en.dbid=&&v_dbid AND en.event_name='LNS wait on SENDREQ')
GROUP BY st.wait_time_milli
;

select en.event_name,  sum(eh.wait_count) as total_waits
from sys.wrh$_event_histogram eh, sys.wrh$_event_name en
where eh.dbid=&&v_dbid and eh.snap_id between &&v_bsnap and &&v_esnap
  and eh.dbid=en.dbid and eh.event_id=en.event_id
  --and lower(en.event_name) like '%temp%'
group by rollup(en.event_name)
order by 2 desc
;

select * 
from (
with snaps as (
               select s.snap_id as snap_id, s.begin_interval_time as snap_time
               from sys.WRM$_SNAPSHOT s
               where s.dbid=&&v_dbid and s.snap_id between &&v_bsnap and &&v_esnap and s.instance_number=&&v_insnum 
              ),
     eh as (
            select eh.snap_id as snap_id, eh.wait_time_milli as wait_time, eh.wait_count as wait_count
            from sys.wrh$_event_histogram eh, sys.wrh$_event_name en
            where eh.dbid=&&v_dbid and eh.snap_id between &&v_bsnap and &&v_esnap
              and eh.dbid=en.dbid and eh.event_id=en.event_id
              and lower(en.event_name) = 'db file scattered read'
            )
select snaps.snap_id, snaps.snap_time,
       eh.wait_time as wait_time, eh.wait_count as wait_count
from snaps, eh
where snaps.snap_id(+)=eh.snap_id 
 )
pivot (
 max(WAIT_COUNT)
 for WAIT_TIME in (
   '1' as ms1,
   '2' as ms2,
   '4' as ms4,
   '8' as ms8,
  '16' as ms16,
  '32' as ms32,
  '64' as ms64,
 '128' as ms128,
 '256' as ms256,
 '512' as ms512,
'1024' as ms1024,
'2048' as ms2048
 )
) 
order by snap_id asc
;

-- OSStat
select
v.snap_time as snap_time,
v.snap_id as snap_id,
v.NUM_CPUS as NUM_CPUS,
v.IDLE_TIME as IDLE_TIME,
v.BUSY_TIME as BUSY_TIME,
v.USER_TIME as USER_TIME,
v.SYS_TIME as SYS_TIME,
v.IOWAIT_TIME as IOWAIT_TIME,
v.NICE_TIME as NICE_TIME,
v.RSRC_MGR_CPU_WAIT_TIME as RSRC_MGR_CPU_WAIT_TIME,
v.LOAD as LOAD,
v.NUM_CPU_SOCKETS as NUM_CPU_SOCKETS,
v.PHYSICAL_MEMORY_BYTES as PHYSICAL_MEMORY_BYTES,
v.VM_IN_BYTES as VM_IN_BYTES,
v.VM_OUT_BYTES as VM_OUT_BYTES,
v.NUM_CPU_CORES AS NUM_CPU_CORES,
v.FREE_MEMORY_BYTES AS FREE_MEMORY_BYTES,
v.INACTIVE_MEMORY_BYTES AS INACTIVE_MEMORY_BYTES,
v.SWAP_FREE_BYTES AS SWAP_FREE_BYTES
from (
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from sys.WRM$_SNAPSHOT s, sys.WRH$_OSSTAT os, sys.WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,
'IDLE_TIME' as IDLE_TIME,
'BUSY_TIME' as BUSY_TIME,
'USER_TIME' as USER_TIME,
'SYS_TIME' as SYS_TIME,
'IOWAIT_TIME' as IOWAIT_TIME,
'NICE_TIME' as NICE_TIME,
'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,
'LOAD' as LOAD,
'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,
'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,
'VM_IN_BYTES' as VM_IN_BYTES,
'VM_OUT_BYTES' as VM_OUT_BYTES,
'NUM_CPU_CORES' AS NUM_CPU_CORES,
'FREE_MEMORY_BYTES' AS FREE_MEMORY_BYTES,
'INACTIVE_MEMORY_BYTES' AS INACTIVE_MEMORY_BYTES,
'SWAP_FREE_BYTES' AS SWAP_FREE_BYTES
)
)
 )  v
order by v.snap_id
;


select *
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('DB CPU','DB time','CPU used by this session')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('DB CPU','DB time','CPU used by this session')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'CPU used by this session' as cpu_usage,
'DB time' as db_time,
'DB CPU' as db_cpu
)
 )
order by snap_time;

select *
from WRH$_STAT_NAME sn
where SN.dbid=&&v_dbid and SN.STAT_NAME like 'DB %';

select *
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('buffer is not pinned count', 'buffer is pinned count', 'consistent gets from cache (fastpath)', 'no work - consistent read gets', 'parse count (failures)', 'parse count (hard)', 'physical reads', 'physical reads cache', 'physical write IO requests', 'physical writes from cache', 'redo subscn max counts', 'sql area purged', 'table fetch by rowid')
  and S.snap_id between &&v_bsnap and &&v_esnap
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('buffer is not pinned count', 'buffer is pinned count', 'consistent gets from cache (fastpath)', 'no work - consistent read gets', 'parse count (failures)', 'parse count (hard)', 'physical reads', 'physical reads cache', 'physical write IO requests', 'physical writes from cache', 'redo subscn max counts', 'sql area purged', 'table fetch by rowid')
  and S.snap_id between &&v_bsnap and &&v_esnap
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'buffer is not pinned count' as buffer_is_not_pinned_count,
'buffer is pinned count' as buffer_is_pinned_count,
'consistent gets from cache (fastpath)' as ConsGetsFromCacheFastpath,
'no work - consistent read gets' as no_work_consistent_read_gets,
'parse count (failures)' as parse_count_failures,
'parse count (hard)' as parse_count_hard,
'ph reads' as ph_reads,
'ph reads cache' as ph_reads_cache,
'ph write IO requests' as ph_write_IO_requests,
'ph writes from cache' as ph_writes_from_cache,
'redo subscn max counts' as redo_subscn_max_counts,
'sql area purged' as sql_area_purged,
'table fetch by rowid' as table_fetch_by_rowid)
 )
order by snap_time;

-- sga stat
select *
from (
 select s.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       decode( nvl(r.pool,''),'',r.name,r.pool ) as comp_name,
       round(sum(r.BYTES)/1024/1024,2) as size_mb
from WRH$_SGASTAT r, WRM$_SNAPSHOT s
where r.SNAP_ID=S.SNAP_ID and R.DBID=S.DBID and R.INSTANCE_NUMBER=S.INSTANCE_NUMBER
  and S.dbid=&&v_dbid
  and S.snap_id between &&v_bsnap and &&v_esnap
group by s.BEGIN_INTERVAL_TIME, s.snap_id, decode( nvl(r.pool,''),'',r.name,r.pool )
order by s.snap_id, comp_name
) v
 pivot (
max(size_mb)
for comp_name in ('buffer_cache' as buffer_cache, 'fixed_sga' as fixed_sga, 'java pool' as java_pool, 'large pool' as large_pool, 'log_buffer' as log_buffer, 'shared pool' as shared_pool, 'streams pool' as streams_pool)
 )
order by snap_time;

-----------

-- pga stat

select *
from
(with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap   ),
e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap   )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
)
pivot (
max(value_diff)
for stat_name in (
'PGA memory freed back to OS' as PGA_memory_freed_back_to_OS,
'aggregate PGA auto target' as aggregate_PGA_auto_target,
'aggregate PGA target parameter' as aggregate_PGA_target_parameter,
'bytes processed' as bytes_processed,
'cache hit percentage' as cache_hit_percentage,
'extra bytes read/written' as extra_bytes_read_written,
'global memory bound' as global_memory_bound,
'max processes count' as max_processes_count,
'maximum PGA allocated' as maximum_PGA_allocated,
'maximum PGA used for auto workareas' as maxPGA_used4auto_wa,
'maximum PGA used for manual workareas' as maxPGA_used4manual_wa,
'over allocation count' as over_allocation_count,
'process count' as process_count,
'recompute count (total)' as recompute_count__total_,
'total PGA allocated' as total_PGA_allocated,
'total PGA inuse' as total_PGA_inuse,
'total PGA used for auto workareas' as totalPGA_used4auto_wa,
'total freeable PGA memory' as total_freeable_PGA_memory
)
 )
order by snap_time;

select *
from (
with    b as (select rownum, S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from WRM$_SNAPSHOT s, WRH$_OSSTAT os, WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
        and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
 ),
        e as (select rownum, S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from WRM$_SNAPSHOT s, WRH$_OSSTAT os, WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,'IDLE_TIME' as IDLE_TIME,'BUSY_TIME' as BUSY_TIME,'USER_TIME' as USER_TIME,'SYS_TIME' as SYS_TIME,'IOWAIT_TIME' as IOWAIT_TIME,'NICE_TIME' as NICE_TIME,'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,'LOAD' as LOAD,'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,'VM_IN_BYTES' as VM_IN_BYTES,'VM_OUT_BYTES' as VM_OUT_BYTES)
)
order by snap_id;

-- AAS query --
select  d.snap_id as snap_id,
        S.BEGIN_INTERVAL_TIME as snap_time,
        round(d.total_active_sessions/d.total_samples,2) as avg_active_sessions
from (
select  snap_id,
        sum(session_count) as total_active_sessions,
        count(*) as total_samples
from (
select  ASH.SNAP_ID as snap_id,
        ASH.SAMPLE_TIME as sample_time,
        count(*) as session_count
from WRM$_SNAPSHOT s, WRH$_ACTIVE_SESSION_HISTORY ash
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and S.DBID=ash.dbid and S.INSTANCE_NUMBER=ash.INSTANCE_NUMBER and s.snap_id=ash.snap_id
  --and ASH.EVENT_ID=( select EN.EVENT_ID from WRH$_EVENT_NAME en where EN.dbid=&&v_dbid and EN.EVENT_NAME='db file sequential read')
  --and ASH.CURRENT_FILE# != 0 and ASH.CURRENT_BLOCK# != 0
group by ash.snap_id, ash.sample_time
order by ash.snap_id
 )
group by snap_id
order by snap_id
 ) d, WRM$_SNAPSHOT s
where s.snap_id=d.snap_id and s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1;


/*
SELECT *
FROM WRH$_STAT_NAME sn
WHERE sn.dbid=&&v_dbid
ORDER BY sn.stat_name;
*/

SELECT snap_time,
       snap_id,
       db_time_sec,
       ela_time_sec,
       Round(db_time_sec/ela_time_sec, 6) AS aas
FROM
 (
 SELECT  snap_time,
         snap_id,
         Round(db_time/Power(10,6),2) AS db_time_sec,  -- originally db_time is given in microseconds
         ela_time,
         extract(HOUR FROM ela_time)*3600 + extract(minute FROM ela_time)*60 + extract(second FROM ela_time)*3600 AS ela_time_sec
 FROM (
 with
 local_data as (select S.BEGIN_INTERVAL_TIME as snap_time,
        s.snap_id as snap_id,
        ST.VALUE as stat_value
        --,SN.STAT_NAME as stat_name
 from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
 where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
   and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
   and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'DB time' )
   and S.SNAP_ID between &&v_bsnap and &&v_esnap ),
 b as ( select * from local_data ),
 e as ( select * from local_data )
 select  e.snap_time as snap_time,
         e.snap_id as snap_id,
         e.snap_time-b.snap_time AS ela_time,
         --e.stat_name as stat_name,
         case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as db_time
 from b,e
 where e.snap_id=(b.snap_id + 1)
  )
 )
order by snap_id;


--------------------------------------------------------------------------------

SELECT *
FROM sys.v$tablespace t
;

SELECT *
FROM sys.dba_tablespaces t
;

SELECT ts#, NAME,
       ''''||name||''' as '||name||',' AS col
FROM sys.v$tablespace t;

SELECT 'when fs.TABLESPACE_ID in ('||ts#||') then '''||NAME||'''' AS col FROM sys.v$tablespace t;
/*
([0-9]+)\t(.*)
WHEN fs\.TABLESPACE_ID IN \(\1\) THEN '\2'
*/

SELECT *
FROM WRH$_TABLESPACE_SPACE_USAGE t
;

SELECT 'when fs.TABLESPACE_ID in ('||t.ts#||') then '''||t.tsNAME||'''' AS col,
       ''''||t.tsname||''' as '||t.tsname||',' AS col2
       --*
FROM sys.wrh$_tablespace_stat t
WHERE t.dbid=&&v_dbid
  AND t.snap_id=&&v_esnap
;

SELECT *
FROM (
SELECT  S.BEGIN_INTERVAL_TIME as snap_time,
        s.snap_id AS snap_id,
        --fs.TABLESPACE_ID AS stat_name,
        case
when fs.TABLESPACE_ID in (0) then 'SYSTEM'
when fs.TABLESPACE_ID in (1) then 'UNDOTBS1'
when fs.TABLESPACE_ID in (2) then 'SYSAUX'
when fs.TABLESPACE_ID in (4) then 'USERS'
when fs.TABLESPACE_ID in (6) then 'DATA'
when fs.TABLESPACE_ID in (7) then 'INDX'
when fs.TABLESPACE_ID in (9) then 'UNDOTBS'
when fs.TABLESPACE_ID in (10) then 'MONITOR'
        END AS stat_name,
        round(fs.TABLESPACE_SIZE*8192/1024/1024/1024,2) AS stat_value
FROM WRH$_TABLESPACE_SPACE_USAGE fs, sys.wrm$_snapshot s
WHERE s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 AND S.snap_id between &&v_bsnap and &&v_esnap
  AND fs.dbid=s.dbid AND fs.snap_id=s.snap_id
  ) v
pivot (
max(stat_value)
for stat_name in (
'SYSTEM' as SYSTEM,
'UNDOTBS1' as UNDOTBS1,
'SYSAUX' as SYSAUX,
'USERS' as USERS,
'DATA' as DATA,
'INDX' as INDX,
'UNDOTBS' as UNDOTBS,
'TEMP' as TEMP,
'TEMPORARY' as TEMPORARY,
'MONITOR' as MONITOR
 )
)
ORDER BY snap_id;


SELECT  t.ts#
        ,ts.TABLESPACE_NAME
        , ts.BLOCK_SIZE
        ,ts.contents
FROM sys.dba_tablespaces ts, sys.v$tablespace t
WHERE ts.TABLESPACE_NAME=t.NAME
  AND ts.CONTENTS!='TEMPORARY'
ORDER BY ts#;

-----------------------------------------------------------------------------------
/*
-- At given db-site:
SELECT 'WHEN fs.TABLESPACE_ID='||t.ts#||' THEN fs.TABLESPACE_SIZE*'||dt.block_size AS col
FROM v$tablespace t, sys.dba_tablespaces dt
WHERE t.name=dt.tablespace_name
  AND dt.CONTENTS != 'TEMPORARY';

*/

-- Space
-- DBSize
SELECT  snap_time, snap_id, Round( Sum(TABLESPACE_SIZE_BYTES)/1024/1024/1024, 2) AS DBSizeGB
FROM (
SELECT  s.BEGIN_INTERVAL_TIME AS snap_time,
        s.snap_id AS snap_id,
        fs.TABLESPACE_ID AS TABLESPACE_ID,
        CASE
WHEN fs.TABLESPACE_ID=0 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=1 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=2 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=4 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=7 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=10 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=11 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=12 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=16 THEN fs.TABLESPACE_SIZE*8192
WHEN fs.TABLESPACE_ID=17 THEN fs.TABLESPACE_SIZE*8192
        END AS TABLESPACE_SIZE_BYTES
        ,fs.TABLESPACE_SIZE
FROM WRH$_TABLESPACE_SPACE_USAGE fs, sys.wrm$_snapshot s
WHERE s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 AND S.snap_id between &&v_bsnap and &&v_esnap
  AND fs.dbid=s.dbid AND fs.snap_id=s.snap_id
  --ORDER BY s.snap_id
  )
  GROUP BY snap_time, snap_id
  ORDER BY snap_id;

-----------------------------------------------------------------------------------

/*
\t->,
SELECT ''''||NAME||''' as '||NAME||',' as col FROM sys.v_$tablespace t
;

select 'WHEN fs.FILE# IN ('||v.files_list||') then '''||v.ts_name||'''' as col
from (
select listagg(t.file#,',')  WITHIN GROUP (order by t.file#) as files_list,
       tb.name  as ts_name
from v$datafile t, v$tablespace tb
where t.ts#=tb.ts#
group by tb.name ) v
;

^(.*),([A-Z_0-9]+)
WHEN fs\.FILE\# IN \(\1\) THEN '\2'

*/

select *
FROM (
with
local_data as (
SELECT  snap_time, snap_id,
        TS_NAME AS stat_name,
        Sum(stat_value) AS stat_value
FROM (
SELECT  S.BEGIN_INTERVAL_TIME as snap_time,
        s.snap_id AS snap_id,
        --fs.FILE# AS file_id,
        CASE
WHEN fs.FILE# IN (5,10,11,12,13,14,15,16) then 'EXCELLENT'
WHEN fs.FILE# IN (2,6,17,18,19,20,21) then 'INDEX_ALL'
WHEN fs.FILE# IN (7) then 'MONITOR'
WHEN fs.FILE# IN (8) then 'MONITOR_LOB'
WHEN fs.FILE# IN (3) then 'SYSAUX'
WHEN fs.FILE# IN (1) then 'SYSTEM'
WHEN fs.FILE# IN (22) then 'UNDOTBS2'
WHEN fs.FILE# IN (4) then 'USERS'
WHEN fs.FILE# IN (9) then 'WEB'
        END AS TS_NAME,
        --fs.phyrds AS stat_value
        fs.phywrts AS stat_value
FROM WRH$_FILESTATXS fs, sys.wrm$_snapshot s
WHERE s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 AND S.snap_id between &&v_bsnap and &&v_esnap
  AND fs.dbid=s.dbid AND fs.INSTANCE_NUMBER=s.INSTANCE_NUMBER AND fs.snap_id=s.snap_id
  )
GROUP BY SNAP_TIME, SNAP_ID, TS_NAME
   ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  to_char(e.snap_time,'dd.mm.yyyy hh24:mi') as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'SYSTEM' as SYSTEM,
'SYSAUX' as SYSAUX,
'USERS' as USERS,
'TEMP' as TEMP,
'EXCELLENT' as EXCELLENT,
'INDEX_ALL' as INDEX_ALL,
'MONITOR' as MONITOR,
'MONITOR_LOB' as MONITOR_LOB,
'WEB' as WEB,
'UNDOTBS2' as UNDOTBS2
 )
)
order by snap_id;

-- TEMPORARY TBS STat

-- UNDO stat
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        round(PR.VALUE*US.ACTIVEBLKS/1024/1024/1024,2) as active_undo_Gb,
        round(PR.VALUE*US.UNEXPIREDBLKS/1024/1024/1024,2)  as unexp_undo_Gb,
        round(PR.VALUE*US.EXPIREDBLKS/1024/1024/1024,2)  as exp_undo_Gb,
        US.UNXPSTEALCNT as unexp_steals,
        US.EXPSTEALCNT as exp_steals,
        US.TUNED_UNDORETENTION as tuned_ur_sec
        --PR.VALUE as block_size
from WRH$_UNDOSTAT us, WRM$_SNAPSHOT s,
     WRH$_PARAMETER pr, WRH$_PARAMETER_NAME pn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and US.DBID=s.dbid and US.INSTANCE_NUMBER=s.INSTANCE_NUMBER and us.snap_id=s.snap_id
  and pr.DBID=s.dbid and pr.INSTANCE_NUMBER=s.INSTANCE_NUMBER and pr.snap_id=s.snap_id
  and pr.DBID=pn.dbid and PR.PARAMETER_HASH=PN.PARAMETER_HASH and PN.PARAMETER_NAME='db_block_size'
order by s.snap_id;

SELECT end_time,
       Round(undoblks*blk_size/1024/1024/1024,2) AS active_undo_Gb,
       Round(unexpiredblks*blk_size/1024/1024/1024,2) AS unexp_undo_Gb,
       Round(expiredblks*blk_size/1024/1024/1024,2) AS exp_undo_Gb
FROM (
SELECT t.end_time, t.undoblks, t.activeblks, t.unexpiredblks, t.expiredblks,
       (SELECT pr.Value fROM sys.v_$parameter pr WHERE pr.name='db_block_size') AS blk_size
FROM sys.v_$undostat t
 )
ORDER BY end_time
;

SELECT *
FROM sys.dba_hist_undostat t
WHERE t.dbid=&&v_dbid and t.INSTANCE_NUMBER=1 and t.snap_id between &&v_bsnap and &&v_esnap
ORDER BY t.begin_time asc
;

SELECT t.*
FROM sys.v_$parameter t
WHERE t.name LIKE '%cpu%'
;
--------------------------------------------------------------------------------
-- parameter
SELECT s.begin_interval_time, pr.snap_id,parameter_name,pr.Value,pr.isdefault
FROM sys.WRH$_PARAMETER pr, sys.WRH$_PARAMETER_NAME p, WRM$_SNAPSHOT s
WHERE s.dbid=&&v_dbid and s.INSTANCE_NUMBER=1 and s.snap_id between &&v_bsnap and &&v_esnap
  AND s.dbid=pr.dbid and s.INSTANCE_NUMBER=pr.INSTANCE_NUMBER and s.snap_id=pr.snap_id
  AND pr.parameter_hash=p.parameter_hash
  AND p.parameter_name='pga_aggregate_target'
ORDER BY pr.snap_id
;

SELECT p.parameter_name,pr.Value
FROM sys.WRH$_PARAMETER pr, sys.WRH$_PARAMETER_NAME p
WHERE pr.dbid=&&v_dbid and pr.INSTANCE_NUMBER=1 and pr.snap_id = &&v_esnap
  AND pr.parameter_hash=p.parameter_hash
  AND pr.dbid=p.dbid
  AND pr.isdefault!='TRUE'
ORDER BY p.parameter_name
;

--------------------------------------------------------------------------------
-- SQLTYPES
-- SQLCOMMAND
SELECT *
FROM sys.V_$SQLCOMMAND t
WHERE t.command_type IN (0,1,3,2,6,7,10,9,36,5,55,31,54,27,59,25)
ORDER BY t.command_type;


/*
when '\1'  then 1
*/

select t.sql_id AS sql_id,
       CASE t.sql_id
when 'd8w9259tpx7wh'  then 1
when '4b77w4mhpyndn'  then 2
when 'gvndq84ahpjk0'  then 3
when '9fdwmy1x646y7'  then 4
when 'ch6418t6ud3u3'  then 5
when 'dx1bvp3s2hzb4'  then 6
when '6n5fs9u3vgt4a'  then 7
when 'dghmp4mzz6ntg'  then 8
when '2g9htcqr263pn'  then 9
when '2w04uwxf00sp4'  then 10
end as weight,
       T.COMMAND_TYPE AS cmd_type,
       t.sql_text AS sql_text
from WRH$_SQLTEXT t
where T.dbid=&&v_dbid --and t.snap_id between &&v_bsnap and &&v_esnap
  and T.SQL_ID in (
'd8w9259tpx7wh','4b77w4mhpyndn','gvndq84ahpjk0','9fdwmy1x646y7','ch6418t6ud3u3','dx1bvp3s2hzb4','6n5fs9u3vgt4a','dghmp4mzz6ntg','2g9htcqr263pn','2w04uwxf00sp4'
  )
  --and upper(T.SQL_TEXT) like '%TP_MVTS_CDR%'
ORDER BY weight;

-------------------------------------------------------------------------------------
WITH DATA AS
(SELECT
'83619,83633,83628,84019,89890150,5397683,148753625,79497,148656120,148796384'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as o'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;

SELECT ''''||t.obj_num||''' as o'||t.obj_num||',' AS col
FROM top_objects_20181226 t;

/*
drop table system.top_objects_20181226;
create table system.top_objects_20181226 (obj_num number);

insert into top_objects_20181226 values\(\1\);
*/

SELECT sg.snap_id,
       --sg.obj#, sg.space_used_total
       --DISTINCT sg.obj#
       --Sum(sg.space_allocated_delta),
      --Sum(sg.db_block_changes_delta) AS stat_value
      Sum(sg.physical_reads_delta) AS stat_value
       --Sum(sg.physical_writes_delta)
FROM sys.wrh$_seg_stat sg--, SYS.WRM$_SNAPSHOT s
WHERE --s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
      sg.dbid=&&v_dbid and Sg.INSTANCE_NUMBER=1 and Sg.SNAP_ID between &&v_bsnap and &&v_esnap
  --AND sg.dbid=s.dbid AND sg.SNAP_ID=s.snap_id
  --AND sg.ts#=(SELECT ts.ts# FROM v$tablespace ts WHERE ts.name='DATA_SLOW')
  --AND sg.obj# IN ( SELECT obj_num FROM top_objects_20181226 )
/*  AND sg.obj# IN (
256687,1974587,5680865,148637590,148597564,148454523,29804094,21512185,13154098,148792426,17152608,146369802,15949077,43837229,13154093,146651243,2139054,14,83623
  )*/
GROUP BY sg.snap_id
ORDER BY sg.snap_id
;

SELECT t.owner||'.'||t.object_name, t.object_type, t.object_id
FROM sys.dba_objects t
WHERE t.object_id IN (58417,60538,1519635,1519636,70966,405692,614966,614964,60551)
;
--------------------------------------------------------------------------------

select --s.begin_interval_time,
       --DISTINCT t.sql_id
       t.snap_id, t.sql_id, t.plan_hash_value, t.object_alias, t.object_type, t.qblock_name, t.parent_id, t.id, t.depth, t.operation, t.options, t.object_owner, t.object_name, t.search_columns, t.cardinality, t.TIME, t.cost, t.cpu_cost, t.io_cost, t.temp_space, Round(t.bytes/1024/1024,0) AS MBytes
       --*
from sys.WRH$_SQL_PLAN t--, SYS.WRM$_SNAPSHOT s
where 1=1
  AND T.SQL_ID IN ('4c2z7ta4ssnwv')
  and t.dbid=&&v_dbid --AND t.snap_id between &&v_bsnap and &&v_esnap
  --AND t.plan_hash_value=
  --AND t.object_name LIKE 'DBA10499MV%'
ORDER BY t.plan_hash_value, t.ID asc
;


select t.*
from awr_publisher.DBID_DBNAME t
where --T.dbid=&&v_dbid;
     T.DB_TYPE='billing'
 and T.CITYNAME='Volgograd';
--order by T.CITYNAME;

select  min(S.SNAP_ID) as min_snap_id,
        max(s.snap_id) as max_snap_id,
        min(S.BEGIN_INTERVAL_TIME) as min_time,
        max(S.BEGIN_INTERVAL_TIME) as max_time
from WRM$_SNAPSHOT s
where s.dbid=&&v_dbid
--and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
;

select *
from WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
order by s.snap_id desc;

select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, TMN.STAT_NAME as stat_name, ST.VALUE as stat_value
                from wrm$_snapshot s, WRH$_SYS_TIME_MODEL st,
                     WRH$_STAT_NAME tmn, WRM$_DATABASE_INSTANCE d
                where S.SNAP_ID=ST.SNAP_ID and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER
                  and ST.STAT_ID=TMN.STAT_ID
                      and D.dbid=&&v_dbid and D.DBID=S.dbid and D.INSTANCE_NUMBER=S.INSTANCE_NUMBER
                  and D.STARTUP_TIME=S.STARTUP_TIME
                  and S.snap_id between &&v_bsnap and &&v_esnap
),
        b as ( select * from local_data ),
        e as ( select * from local_data )
select  to_char(e.snap_time,'dd.mm.yyyy hh24:mi') as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('DB time' as db_time,'DB CPU' as db_cpu,
      'background elapsed time' as bgrnd_el_tm,'background cpu time' as
      bgrnd_cpu_tm,'sequence load elapsed time' as seq_load_el_tm,
      'parse time elapsed' as parse_el_tm,'hard parse elapsed time' as
      hard_parse_el_tm,'sql execute elapsed time' as sql_exec_el_tm,
      'connection management call elapsed time' as conn_mgmnt_call_el_tm,
      'failed parse elapsed time' as failed_parse_el_tm,
      'failed parse (out of shared memory) elapsed time' as
      fail_parse_outofshmem_el_tm,'hard parse (sharing criteria) elapsed time' as hrd_parse_sharing_crit_el_tm,
      'hard parse (bind mismatch) elapsed time' as hrd_prs_bing_mismtch_el_tm,
      'PL/SQL execution elapsed time' as plsql_exec_el_tm,
      'inbound PL/SQL rpc elapsed time' as inbnd_plsql_rpc_el_tm,
      'PL/SQL compilation elapsed time' as plsql_compile_el_tm,
      'Java execution elapsed time' as java_exec_el_tm,
      'repeated bind elapsed time' as repeat_bind_el_tm,
      'RMAN cpu time (backup/restore)' as rman_bcp_rstr_cpu_tm)
)
where db_time is not null
order by snap_id;

--Wait time by wait clesses
select snap_time, snap_id, Concurrency, UserIO, awr_publisherIO, Administrative, Other, Configuration, Application, Network, Commit
from (
with    local_data as (select    S.BEGIN_INTERVAL_TIME as snap_time,
                        S.SNAP_ID as snap_id,
                        en.WAIT_CLASS as stat_name,
                        sum(SE.TIME_WAITED_MICRO) as stat_value
              from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
              where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
                    and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
                    and SE.EVENT_ID=EN.EVENT_ID and SE.DBID=EN.DBID
                    and S.SNAP_ID between &&v_bsnap and &&v_esnap
                group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.WAIT_CLASS
             ),
        b as (
                select * from local_data
             ),
        e as (
               select * from local_data
              )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in ('Cluster' as Clster, 'Concurrency' as Concurrency,'User I/O' as UserIO,'awr_publisher I/O' as awr_publisherIO,'Administrative' as Administrative,'Other' as Other,'Configuration' as Configuration,'Application' as Application,'Idle' as Idle,'Network' as Network,'Commit' as Commit)
    )
order by snap_id;

-- sql plan
SELECT *
FROM (
select s.snap_id, Count(t.OPERATION) AS op_count, t.OPERATION AS OPERATION
from sys.WRH$_SQL_PLAN t, SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid
  and S.snap_id between &&v_bsnap and &&v_esnap
  AND t.dbid=s.dbid AND t.snap_id=s.snap_id
GROUP BY --s.begin_interval_time,
s.snap_id, t.OPERATION
ORDER BY s.snap_id
)
pivot (
 Max(op_count)
 FOR OPERATION IN (
'BITMAP AND' as o1,
'BITMAP COMPACTION' as o2,
'BITMAP CONSTRUCTION' as o3,
'BITMAP CONVERSION' as o4,
'BITMAP INDEX' as o5,
'BITMAP KEY ITERATION' as o6,
'BITMAP MERGE' as o7,
'BITMAP MINUS' as o8,
'BITMAP OR' as o9,
'BUFFER' as o10,
'COLLECTION ITERATOR' as o11,
'CONCATENATION' as o12,
'CONNECT BY' as o13,
'CONNECT BY PUMP' as o14,
'COUNT' as o15,
'CREATE INDEX STATEMENT' as o16,
'CREATE TABLE STATEMENT' as o17,
'DELETE' as o18,
'DELETE STATEMENT' as o19,
'DOMAIN INDEX' as o20,
'EXTERNAL TABLE ACCESS' as o21,
'FAST DUAL' as o22,
'FILTER' as o23,
'FIXED TABLE' as o24,
'FOR UPDATE' as o25,
'HASH' as o26,
'HASH JOIN' as o27,
'INDEX' as o28,
'INDEX BUILD' as o29,
'INLIST ITERATOR' as o30,
'INSERT STATEMENT' as o31,
'JOIN FILTER' as o32,
'LOAD AS SELECT' as o33,
'LOAD TABLE CONVENTIONAL' as o34,
'MAT_VIEW ACCESS' as o35,
'MERGE' as o36,
'MERGE JOIN' as o37,
'MERGE STATEMENT' as o38,
'MINUS' as o39,
'NESTED LOOPS' as o40,
'OPTIMIZER STATISTICS GATHERING' as o41,
'PART JOIN FILTER' as o42,
'PARTITION LIST' as o43,
'PARTITION RANGE' as o44,
'PX COORDINATOR' as o45,
'PX SEND' as o46,
'REMOTE' as o47,
'RESULT CACHE' as o48,
'SELECT STATEMENT' as o49,
'SEQUENCE' as o50,
'SORT' as o51,
'SQL MODEL' as o52,
'STATISTICS COLLECTOR' as o53,
'TABLE ACCESS' as o54,
'TEMP TABLE TRANSFORMATION' as o55,
'TRANSPOSE' as o56,
'UNION ALL PUSHED PREDICATE' as o57,
'UNION-ALL' as o58,
'UNPIVOT' as o59,
'UPDATE' as o60,
'UPDATE STATEMENT' as o61,
'VIEW' as o62,
'VIEW PUSHED PREDICATE' as o63,
'WINDOW' as o64
 )
)
;
-- Application class
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in (
  'enq: PW - flush prewarm buffers','enq: RO - contention','enq: RO - fast object reuse','enq: KO - fast object checkpoint','enq: TM - contention','enq: TX - row lock contention','Wait for Table Lock','enq: RC - Result Cache: Contention','Streams capture: filter callback waiting for ruleset','Streams: apply reader waiting for DDL to apply','SQL*Net break/reset to client','SQL*Net break/reset to dblink','External Procedure initial connection','External Procedure call','enq: UL - contention','OLAP DML Sleep','WCR: replay lock order'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'enq: PW - flush prewarm buffers' as enqPW_flush_prewarm_buffers,
'enq: RO - contention' as eqnRO_contention,
'enq: RO - fast object reuse' as eqnRO_fast_object_reuse,
'enq: KO - fast object checkpoint' as eqnKO_fast_object_checkpoint,
'enq: TM - contention' as eqnTM_contention,
'enq: TX - row lock contention' as eqnTX_row_lock_contention,
'Wait for Table Lock' as Wait_for_Table_Lock,
'enq: RC - Result Cache: Contention' as eqnRC_ResultCacheContention,
'Streams capture: filter callback waiting for ruleset' as StrmsCptrFltrCallbackWt4rlst,
'Streams: apply reader waiting for DDL to apply' as StreamsApplRdrW4DDL2apply,
'SQL*Net break/reset to client' as SQL_Net_break_reset_to_client,
'SQL*Net break/reset to dblink' as SQL_Net_break_reset_to_dblink,
'External Procedure initial connection' as ExtProcInitialConnection,
'External Procedure call' as External_Procedure_call,
'enq: UL - contention' as eqnUL___contention,
'OLAP DML Sleep' as OLAP_DML_Sleep,
'WCR: replay lock order' as WCR__replay_lock_order)
    )
order by snap_id;

--------------------------------------------------------------------------------

-- Network class
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in (
  'remote db operation','remote db file read','remote db file write','ARCH wait for net re-connect','LGWR wait on ATTACH','ARCH wait on ATTACH','ARCH wait for netserver start','LNS wait on ATTACH','LNS wait on SENDREQ','LNS wait on DETACH','LGWR wait on SENDREQ','LGWR wait on DETACH','ARCH wait on SENDREQ','ARCH wait on DETACH','ARCH wait for netserver init 2','LNS wait on LGWR','LGWR wait on LNS','ARCH wait for flow-control','ARCH wait for netserver detach','TCP Socket (KGAS)','virtual circuit wait','dispatcher listen timer','dedicated server timer','SQL*Net message to client','SQL*Net message to dblink','SQL*Net more data to client','SQL*Net more data to dblink','SQL*Net more data from client','SQL*Net message from dblink','SQL*Net more data from dblink','SQL*Net vector data to client','SQL*Net vector data from client','SQL*Net vector data to dblink','SQL*Net vector data from dblink','TEXT: URL_DATASTORE network wait'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'remote db operation' as remote_db_operation,
'remote db file read' as remote_db_file_read,
'remote db file write' as remote_db_file_write,
'ARCH wait for net re-connect' as ARCH_wait_for_net_re_connect,
'LGWR wait on ATTACH' as LGWR_wait_on_ATTACH,
'ARCH wait on ATTACH' as ARCH_wait_on_ATTACH,
'ARCH wait for netserver start' as ARCH_wait_for_netserver_start,
'LNS wait on ATTACH' as LNS_wait_on_ATTACH,
'LNS wait on SENDREQ' as LNS_wait_on_SENDREQ,
'LNS wait on DETACH' as LNS_wait_on_DETACH,
'LGWR wait on SENDREQ' as LGWR_wait_on_SENDREQ,
'LGWR wait on DETACH' as LGWR_wait_on_DETACH,
'ARCH wait on SENDREQ' as ARCH_wait_on_SENDREQ,
'ARCH wait on DETACH' as ARCH_wait_on_DETACH,
'ARCH wait for netserver init 2' as ARCH_wait_for_netserver_init_2,
'LNS wait on LGWR' as LNS_wait_on_LGWR,
'LGWR wait on LNS' as LGWR_wait_on_LNS,
'ARCH wait for flow-control' as ARCH_wait_for_flow_control,
'ARCH wait for netserver detach' as ARCH_wait_for_netserver_detach,
'TCP Socket (KGAS)' as TCP_Socket__KGAS_,
'virtual circuit wait' as virtual_circuit_wait,
'dispatcher listen timer' as dispatcher_listen_timer,
'dedicated server timer' as dedicated_server_timer,
'SQL*Net message to client' as SQL_Net_message_to_client,
'SQL*Net message to dblink' as SQL_Net_message_to_dblink,
'SQL*Net more data to client' as SQL_Net_more_data_to_client,
'SQL*Net more data to dblink' as SQL_Net_more_data_to_dblink,
'SQL*Net more data from client' as SQL_Net_more_data_from_client,
'SQL*Net message from dblink' as SQL_Net_message_from_dblink,
'SQL*Net more data from dblink' as SQL_Net_more_data_from_dblink,
'SQL*Net vector data to client' as SQL_Net_vector_data_to_client,
'SQL*Net vector data from client' as SQLNet_vector_data_4fm_client,
'SQL*Net vector data to dblink' as SQL_Net_vector_data_to_dblink,
'SQL*Net vector data from dblink' as SQLNet_vector_data4rmdblink,
'TEXT: URL_DATASTORE network wait' as TEXT_URL_DATASTORE_ntwrk_wt
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Concurrency Class Wait Structure
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'buffer busy waits','cursor: mutex S','cursor: mutex X','cursor: pin S','cursor: pin S wait on X','cursor: pin X','db flash cache invalidate wait','enq: HV - contention','enq: TX - index contention','enq: WG - lock fso','latch: cache buffers chains','latch: In memory undo latch','latch: MQL Tracking Latch','latch: row cache objects','latch: shared pool','latch: Undo Hint Latch','libcache interrupt action by LCK','library cache load lock','library cache lock','library cache: mutex S','library cache: mutex X','library cache pin','logout restrictor','os thread startup','pipe put','resmgr:internal state change','resmgr:sessions to exit','row cache lock','row cache read','securefile chain update','SecureFile mutex','Shared IO Pool Memory','Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'buffer busy waits' as buffer_busy_waits,
'cursor: mutex S' as cursor__mutex_S,
'cursor: mutex X' as cursor__mutex_X,
'cursor: pin S' as cursor__pin_S,
'cursor: pin S wait on X' as cursor__pin_S_wait_on_X,
'cursor: pin X' as cursor__pin_X,
'db flash cache invalidate wait' as db_flash_cache_invalidate_wait,
'enq: HV - contention' as eqnHV___contention,
'enq: TX - index contention' as eqnTX___index_contention,
'enq: WG - lock fso' as eqnWG___lock_fso,
'latch: cache buffers chains' as latch__cache_buffers_chains,
'latch: In memory undo latch' as latch__In_memory_undo_latch,
'latch: MQL Tracking Latch' as latch__MQL_Tracking_Latch,
'latch: row cache objects' as latch__row_cache_objects,
'latch: shared pool' as latch__shared_pool,
'latch: Undo Hint Latch' as latch__Undo_Hint_Latch,
'libcache interrupt action by LCK' as lc_interrupt_action_by_LCK,
'library cache load lock' as library_cache_load_lock,
'library cache lock' as library_cache_lock,
'library cache: mutex S' as library_cache__mutex_S,
'library cache: mutex X' as library_cache__mutex_X,
'library cache pin' as library_cache_pin,
'logout restrictor' as logout_restrictor,
'os thread startup' as os_thread_startup,
'pipe put' as pipe_put,
'resmgr:internal state change' as resmgr_internal_state_change,
'resmgr:sessions to exit' as resmgr_sessions_to_exit,
'row cache lock' as row_cache_lock,
'row cache read' as row_cache_read,
'securefile chain update' as securefile_chain_update,
'SecureFile mutex' as SecureFile_mutex,
'Shared IO Pool Memory' as SharedIOPoolMemory,
'Streams apply: waiting for dependency' as StrmsApplyWt4dependency
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- UserIO Wait time structure
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'Archive Manager file transfer I/O','ASM Fixed Package I/O','ASM Staleness File I/O','BFILE read','buffer read retry','cell list of blocks physical read','cell multiblock physical read','cell single block physical read','cell smart file creation','cell smart index scan','cell smart table scan','cell statistics gather','Data file init write','Datapump dump file I/O','db file parallel read','db file scattered read','db file sequential read','db file single write','db flash cache multiblock physical read','db flash cache single block physical read','db flash cache write','dbms_file_transfer I/O','dbverify reads','DG Broker configuration file I/O','direct path read','direct path read temp','direct path sync','direct path write','direct path write temp','Disk file I/O Calibration','Disk file Mirror Read','Disk file Mirror/Media Repair Write','Disk file operations I/O','external table misc IO','external table open','external table read','external table seek','external table write','flashback log file sync','local write wait','Log file init write','Parameter File I/O','read by other session','securefile direct-read completion','securefile direct-write completion','Shared IO Pool IO Completion','TEXT: File awr_publisher I/O','utl_file I/O' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'Archive Manager file transfer I/O' as ArchManagerFileTransferIO,
'ASM Fixed Package I/O' as ASM_Fixed_Package_I_O,
'ASM Staleness File I/O' as ASM_Staleness_File_I_O,
'BFILE read' as BFILE_read,
'buffer read retry' as buffer_read_retry,
'cell list of blocks physical read' as cell_list_of_blcksPhRead,
'cell multiblock physical read' as cell_multiblock_physical_read,
'cell single block physical read' as cell_single_blockPhRead,
'cell smart file creation' as cell_smart_file_creation,
'cell smart index scan' as cell_smart_index_scan,
'cell smart table scan' as cell_smart_table_scan,
'cell statistics gather' as cell_statistics_gather,
'Data file init write' as Data_file_init_write,
'Datapump dump file I/O' as Datapump_dump_file_I_O,
'db file parallel read' as db_file_parallel_read,
'db file scattered read' as db_file_scattered_read,
'db file sequential read' as db_file_sequential_read,
'db file single write' as db_file_single_write,
'db flash cache multiblock physical read' as db_flash_cache_mblckPhRead,
'db flash cache single block physical read' as db_flash_cache_sblckPhRead,
'db flash cache write' as db_flash_cache_write,
'dbms_file_transfer I/O' as dbms_file_transfer_I_O,
'dbverify reads' as dbverify_reads,
'DG Broker configuration file I/O' as DGBConfFileIO,
'direct path read' as direct_path_read,
'direct path read temp' as direct_path_read_temp,
'direct path sync' as direct_path_sync,
'direct path write' as direct_path_write,
'direct path write temp' as direct_path_write_temp,
'Disk file I/O Calibration' as Disk_file_I_O_Calibration,
'Disk file Mirror Read' as Disk_file_Mirror_Read,
'Disk file Mirror/Media Repair Write' as DiskFileMirrorMediaRepairWrite,
'Disk file operations I/O' as Disk_file_operations_I_O,
'external table misc IO' as external_table_misc_IO,
'external table open' as external_table_open,
'external table read' as external_table_read,
'external table seek' as external_table_seek,
'external table write' as external_table_write,
'flashback log file sync' as flashback_log_file_sync,
'local write wait' as local_write_wait,
'Log file init write' as Log_file_init_write,
'Parameter File I/O' as Parameter_File_I_O,
'read by other session' as read_by_other_session,
'securefile direct-read completion' as securefileDirectRdCompletion,
'securefile direct-write completion' as securefileDirectWrCompletion,
'Shared IO Pool IO Completion' as Shared_IO_Pool_IO_Completion,
'TEXT: File awr_publisher I/O' as TEXT__File_SYSTEM_I_O,
'utl_file I/O' as utl_file_I_O
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Configuration Wait time structure
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'free buffer waits' as free_buffer_waits,
'checkpoint completed' as checkpoint_completed,
'write complete waits' as write_complete_waits,
'write complete waits: flash cache' as writeCompleteWaitsFlashCache,
'latch: redo writing' as latch__redo_writing,
'latch: redo copy' as latch__redo_copy,
'log buffer space' as log_buffer_space,
'log file switch (checkpoint incomplete)' as logFileSwitchChckptIncomplete_,
'log file switch (private strand flush incomplete)' as LFSwitchPrivStrandFlushIncmplt,
'log file switch (archiving needed)' as LFSwitchArchiving_needed,
'log file switch completion' as lfs_completion,
'flashback buf free by RVWR' as flashback_buf_free_by_RVWR,
'enq: ST - contention' as enqSTcontention,
'undo segment extension' as undo_segment_extension,
'undo segment tx slot' as undo_segment_tx_slot,
'enq: TX - allocate ITL entry' as enqTXallocate_ITL_entry,
'statement suspended, wait error to be cleared' as StmtSspnddWaitErrToBeCleared,
'enq: HW - contention' as enqHWcontention,
'enq: SS - contention' as enqSScontention,
'sort segment request' as sort_segment_request,
'enq: SQ - contention' as enqSQcontention,
'Global transaction acquire instance locks' as GlblTrnsAcquireInstanceLocks,
'Streams apply: waiting to commit' as StreamsApplyWaiting_to_commit,
'wait for EMON to process ntfns' as wait_for_EMON_to_process_ntfns
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Others
-- See R-script AnalyzeOthersWaitClass.r and do
-- cat ./class_events.txt | grep -f ./filter.txt at dwh
select  SNAP_ID,E2,E3,E4,E8,E26,E33,E47,E49,E73,E155,E167,E244,E281,E345,E357,E362,E479,E504,E531,E534,E535,E538,E539,E540,E547,E548,E551,E552,E553,E554,E559,E624,E656,E664,E687,E694,E736
        --*
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'ack for a broadcasted res from a remote instance' as e1,
'ADR block file read' as e2,
'ADR block file write' as e3,
'ADR file lock' as e4,
'affinity expansion in replay' as e5,
'AQ propagation connection' as e6,
'AQ spill debug idle' as e7,
'ARCH wait for archivelog lock' as e8,
'ARCH wait for process death 1' as e9,
'ARCH wait for process start 1' as e10,
'ARCH wait for process start 3' as e11,
'ARCH wait on c/f tx acquire 1' as e12,
'ASM background starting' as e13,
'ASM cluster file access' as e14,
'ASM db client exists' as e15,
'ASM DG Unblock' as e16,
'ASM file metadata operation' as e17,
'ASM Instance startup' as e18,
'ASM internal hang test' as e19,
'ASM: MARK subscribe to msg channel' as e20,
'ASM metadata cache frozen' as e21,
'ASM network foreground exits' as e22,
'ASM: OFS Cluster membership update' as e23,
'ASM PST operation' as e24,
'ASM Volume Background' as e25,
'asynch descriptor resize' as e26,
'Auto BMR completion' as e27,
'Auto BMR RPC standby catchup' as e28,
'AWR Flush' as e29,
'AWR Metric Capture' as e30,
'Backup Restore Event 19778 sleep' as e31,
'Backup Restore Switch Bitmap sleep' as e32,
'Backup Restore Throttle sleep' as e33,
'BFILE check if exists' as e34,
'BFILE check if open' as e35,
'BFILE closure' as e36,
'BFILE get length' as e37,
'BFILE get name object' as e38,
'BFILE get path object' as e39,
'BFILE internal seek' as e40,
'BFILE open' as e41,
'block change tracking buffer space' as e42,
'blocking txn id for DDL' as e43,
'broadcast mesg queue transition' as e44,
'broadcast mesg recovery queue transition' as e45,
'buffer busy' as e46,
'buffer deadlock' as e47,
'buffer dirty disabled' as e48,
'buffer exterminate' as e49,
'buffer freelistbusy' as e50,
'buffer invalidation wait' as e51,
'buffer latch' as e52,
'buffer rememberlist busy' as e53,
'buffer resize' as e54,
'buffer write wait' as e55,
'buffer writeList full' as e56,
'cell manager cancel work request' as e57,
'cell smart flash unkeep' as e58,
'cell worker online completion' as e59,
'cell worker retry ' as e60,
'CGS skgxn join retry' as e61,
'CGS wait for IPC msg' as e62,
'change tracking file parallel write' as e63,
'change tracking file synchronous read' as e64,
'change tracking file synchronous write' as e65,
'check CPU wait times' as e66,
'checkpoint advanced' as e67,
'cleanup of aborted process' as e68,
'Cluster stabilization wait' as e69,
'Cluster Suspension wait' as e70,
'Compression analysis' as e71,
'control file diagnostic dump' as e72,
'control file heartbeat' as e73,
'cr request retry' as e74,
'CRS call completion' as e75,
'CSS group membership query' as e76,
'CSS group registration' as e77,
'CSS initialization' as e78,
'CSS operation: action' as e79,
'CSS operation: data query' as e80,
'CSS operation: data update' as e81,
'CSS operation: diagnostic' as e82,
'CSS operation: query' as e83,
'CSS Xgrp shared operation' as e84,
'CTWR media recovery checkpoint request' as e85,
'Data Guard Broker Wait' as e86,
'Data Guard: process clean up' as e87,
'Data Guard: process exit' as e88,
'Data Guard: RFS disk I/O' as e89,
'Data Pump slave init' as e90,
'Data Pump slave startup' as e91,
'datafile move cleanup during resize' as e92,
'DBMS_LDAP: LDAP operation ' as e93,
'DBWR range invalidation sync' as e94,
'debugger command' as e95,
'DFS db file lock' as e96,
'DFS lock handle' as e97,
'dispatcher shutdown' as e98,
'dma prepare busy' as e99,
'DSKM to complete cell health check' as e100,
'dupl. cluster key' as e101,
'EMON slave messages' as e102,
'EMON termination' as e103,
'enq: AB - ABMR process initialized' as e104,
'enq: AB - ABMR process start/stop' as e105,
'enq: AD - allocate AU' as e106,
'enq: AD - deallocate AU' as e107,
'enq: AD - relocate AU' as e108,
'enq: AE - lock' as e109,
'enq: AF - task serialization' as e110,
'enq: AG - contention' as e111,
'enq: AM - ASM ACD Relocation' as e112,
'enq: AM - ASM Amdu Dump' as e113,
'enq: AM - ASM cache freeze' as e114,
'enq: AM - ASM disk based alloc/dealloc' as e115,
'enq: AM - ASM file descriptor' as e116,
'enq: AM - ASM File Destroy' as e117,
'enq: AM - ASM file relocation' as e118,
'enq: AM - ASM Grow ACD' as e119,
'enq: AM - ASM Password File Update' as e120,
'enq: AM - ASM reserved' as e121,
'enq: AM - ASM User' as e122,
'enq: AM - background COD reservation' as e123,
'enq: AM - block repair' as e124,
'enq: AM - client registration' as e125,
'enq: AM - disk offline' as e126,
'enq: AM - group block' as e127,
'enq: AM - group use' as e128,
'enq: AM - rollback COD reservation' as e129,
'enq: AM - shutdown' as e130,
'enq: AO - contention' as e131,
'enq: AP - contention' as e132,
'enq: AS - service activation' as e133,
'enq: AT - contention' as e134,
'enq: AV - add/enable first volume in DG' as e135,
'enq: AV - AVD client registration' as e136,
'enq: AV - persistent DG number' as e137,
'enq: AV - volume relocate' as e138,
'enq: AW - AW generation lock' as e139,
'enq: AW - AW state lock' as e140,
'enq: AW - AW$ table lock' as e141,
'enq: AW - user access for AW' as e142,
'enq: AY - contention' as e143,
'enq: BF - allocation contention' as e144,
'enq: BF - PMON Join Filter cleanup' as e145,
'enq: BM - clonedb bitmap file write' as e146,
'enq: BR - file shrink' as e147,
'enq: BR - multi-section restore header' as e148,
'enq: BR - multi-section restore section' as e149,
'enq: BR - perform autobackup' as e150,
'enq: BR - proxy-copy' as e151,
'enq: BR - request autobackup' as e152,
'enq: BR - space info datafile hdr update' as e153,
'enq: CA - contention' as e154,
'enq: CF - contention' as e155,
'enq: CI - contention' as e156,
'enq: CL - compare labels' as e157,
'enq: CL - drop label' as e158,
'enq: CM - diskgroup dismount' as e159,
'enq: CM - gate' as e160,
'enq: CM - instance' as e161,
'enq: CN - race with init' as e162,
'enq: CN - race with reg' as e163,
'enq: CN - race with txn' as e164,
'enq: CO - master slave det' as e165,
'enq: CQ - contention' as e166,
'enq: CR - block range reuse ckpt' as e167,
'enq: CT - change stream ownership' as e168,
'enq: CT - CTWR process start/stop' as e169,
'enq: CT - global space management' as e170,
'enq: CT - local space management' as e171,
'enq: CT - reading' as e172,
'enq: CT - state' as e173,
'enq: CT - state change gate 1' as e174,
'enq: CT - state change gate 2' as e175,
'enq: CU - contention' as e176,
'enq: CX - TEXT: Index Specific Lock' as e177,
'enq: DD - contention' as e178,
'enq: DF - contention' as e179,
'enq: DG - contention' as e180,
'enq: DL - contention' as e181,
'enq: DM - contention' as e182,
'enq: DN - contention' as e183,
'enq: DO - disk online' as e184,
'enq: DO - disk online operation' as e185,
'enq: DO - disk online recovery' as e186,
'enq: DO - Staleness Registry create' as e187,
'enq: DO - startup of MARK process' as e188,
'enq: DP - contention' as e189,
'enq: DR - contention' as e190,
'enq: DS - contention' as e191,
'enq: DT - contention' as e192,
'enq: DV - contention' as e193,
'enq: DW - contention' as e194,
'enq: DX - contention' as e195,
'enq: FA - access file' as e196,
'enq: FB - contention' as e197,
'enq: FC - open an ACD thread' as e198,
'enq: FC - recover an ACD thread' as e199,
'enq: FD - Flashback coordinator' as e200,
'enq: FD - Flashback logical operations' as e201,
'enq: FD - Flashback on/off' as e202,
'enq: FD - Marker generation' as e203,
'enq: FD - Restore point create/drop' as e204,
'enq: FD - Tablespace flashback on/off' as e205,
'enq: FE - contention' as e206,
'enq: FG - FG redo generation enq race' as e207,
'enq: FG - LGWR redo generation enq race' as e208,
'enq: FG - serialize ACD relocate' as e209,
'enq: FL - Flashback database log' as e210,
'enq: FL - Flashback db command' as e211,
'enq: FM - contention' as e212,
'enq: FP - global fob contention' as e213,
'enq: FR - contention' as e214,
'enq: FR - recover the thread' as e215,
'enq: FR - use the thread' as e216,
'enq: FS - contention' as e217,
'enq: FT - allow LGWR writes' as e218,
'enq: FT - disable LGWR writes' as e219,
'enq: FU - contention' as e220,
'enq: FX - issue ACD Xtnt Relocation CIC' as e221,
'enq: HD - contention' as e222,
'enq: HP - contention' as e223,
'enq: HQ - contention' as e224,
'enq: IA - contention' as e225,
'enq: ID - contention' as e226,
'enq: IL - contention' as e227,
'enq: IM - contention for blr' as e228,
'enq: IR - contention' as e229,
'enq: IR - contention2' as e230,
'enq: IS - contention' as e231,
'enq: IT - contention' as e232,
'enq: JD - contention' as e233,
'enq: JI - contention' as e234,
'enq: JQ - contention' as e235,
'enq: JS - aq sync' as e236,
'enq: JS - contention' as e237,
'enq: JS - evt notify' as e238,
'enq: JS - evtsub add' as e239,
'enq: JS - evtsub drop' as e240,
'enq: JS - job recov lock' as e241,
'enq: JS - job run lock - synchronize' as e242,
'enq: JS - q mem clnup lck' as e243,
'enq: JS - queue lock' as e244,
'enq: JS - sch locl enqs' as e245,
'enq: JS - wdw op' as e246,
'enq: KD - determine DBRM master' as e247,
'enq: KM - contention' as e248,
'enq: KP - contention' as e249,
'enq: KQ - access ASM attribute' as e250,
'enq: KT - contention' as e251,
'enq: MD - contention' as e252,
'enq: MH - contention' as e253,
'enq: MK - contention' as e254,
'enq: ML - contention' as e255,
'enq: MN - contention' as e256,
'enq: MO - contention' as e257,
'enq: MR - contention' as e258,
'enq: MR - standby role transition' as e259,
'enq: MS - contention' as e260,
'enq: MW - contention' as e261,
'enq: MX - sync storage server info' as e262,
'enq: OC - contention' as e263,
'enq: OD - Serializing DDLs' as e264,
'enq: OL - contention' as e265,
'enq: OQ - xsoqhiAlloc' as e266,
'enq: OQ - xsoqhiClose' as e267,
'enq: OQ - xsoqhiFlush' as e268,
'enq: OQ - xsoq*histrecb' as e269,
'enq: OQ - xsoqhistrecb' as e270,
'enq: OT - TEXT: Generic Lock' as e271,
'enq: OW - initialization' as e272,
'enq: OW - termination' as e273,
'enq: PD - contention' as e274,
'enq: PE - contention' as e275,
'enq: PF - contention' as e276,
'enq: PG - contention' as e277,
'enq: PH - contention' as e278,
'enq: PI - contention' as e279,
'enq: PL - contention' as e280,
'enq: PR - contention' as e281,
'enq: PS - contention' as e282,
'enq: PT - contention' as e283,
'enq: PV - syncshut' as e284,
'enq: PV - syncstart' as e285,
'enq: PW - perwarm status in dbw0' as e286,
'enq: RB - contention' as e287,
'enq: RD - RAC load' as e288,
'enq: RE - block repair contention' as e289,
'enq: RF - atomicity' as e290,
'enq: RF - DG Broker Current File ID' as e291,
'enq: RF - FSFO Observer Heartbeat' as e292,
'enq: RF - FSFO Primary Shutdown suspended' as e293,
'enq: RF - new AI' as e294,
'enq: RF - RF - Database Automatic Disable' as e295,
'enq: RF - synch: DG Broker metadata' as e296,
'enq: RF - synchronization: aifo master' as e297,
'enq: RF - synchronization: critical ai' as e298,
'enq: RK - set key' as e299,
'enq: RL - RAC wallet lock' as e300,
'enq: RN - contention' as e301,
'enq: RP - contention' as e302,
'enq: RR - contention' as e303,
'enq: RS - file delete' as e304,
'enq: RS - persist alert level' as e305,
'enq: RS - prevent aging list update' as e306,
'enq: RS - prevent file delete' as e307,
'enq: RS - read alert level' as e308,
'enq: RS - record reuse' as e309,
'enq: RS - write alert level' as e310,
'enq: RT - contention' as e311,
'enq: RT - thread internal enable/disable' as e312,
'enq: RU - contention' as e313,
'enq: RU - waiting' as e314,
'enq: RW - MV metadata contention' as e315,
'enq: RX - relocate extent' as e316,
'enq: RX - unlock extent' as e317,
'enq: SB - logical standby metadata' as e318,
'enq: SB - table instantiation' as e319,
'enq: SE - contention' as e320,
'enq: SF - contention' as e321,
'enq: SH - contention' as e322,
'enq: SI - contention' as e323,
'enq: SJ - Slave Task Cancel' as e324,
'enq: SK - contention' as e325,
'enq: SL - escalate lock' as e326,
'enq: SL - get lock' as e327,
'enq: SL - get lock for undo' as e328,
'enq: SO - contention' as e329,
'enq: SP - contention 1' as e330,
'enq: SP - contention 2' as e331,
'enq: SP - contention 3' as e332,
'enq: SP - contention 4' as e333,
'enq: SR - contention' as e334,
'enq: SU - contention' as e335,
'enq: SW - contention' as e336,
'enq: TA - contention' as e337,
'enq: TB - SQL Tuning Base Cache Load' as e338,
'enq: TB - SQL Tuning Base Cache Update' as e339,
'enq: TC - contention' as e340,
'enq: TC - contention2' as e341,
'enq: TD - KTF dump entries' as e342,
'enq: TE - KTF broadcast' as e343,
'enq: TF - contention' as e344,
'enq: TH - metric threshold evaluation' as e345,
'enq: TK - Auto Task Serialization' as e346,
'enq: TK - Auto Task Slave Lockout' as e347,
'enq: TL - contention' as e348,
'enq: TO - contention' as e349,
'enq: TP - contention' as e350,
'enq: TQ - DDL contention' as e351,
'enq: TQ - DDL-INI contention' as e352,
'enq: TQ - INI contention' as e353,
'enq: TQ - TM contention' as e354,
'enq: TS - contention' as e355,
'enq: TT - contention' as e356,
'enq: TX - contention' as e357,
'enq: US - contention' as e358,
'enq: WA - contention' as e359,
'enq: WF - contention' as e360,
'enq: WG - delete fso' as e361,
'enq: WL - contention' as e362,
'enq: WL - RAC-wide SGA contention' as e363,
'enq: WL - RFS global state contention' as e364,
'enq: WL - Test access/locking' as e365,
'enq: WM - WLM Plan activation' as e366,
'enq: WP - contention' as e367,
'enq: WR - contention' as e368,
'enq: XC - XDB Configuration' as e369,
'enq: XD - ASM disk drop/add' as e370,
'enq: XD - ASM disk OFFLINE' as e371,
'enq: XD - ASM disk ONLINE' as e372,
'enq: XH - contention' as e373,
'enq: XL - fault extent map' as e374,
'enq: XQ - purification' as e375,
'enq: XQ - recovery' as e376,
'enq: XQ - relocation' as e377,
'enq: XR - database force logging' as e378,
'enq: XR - quiesce database' as e379,
'enq: XY - contention' as e380,
'enq: ZA - add std audit table partition' as e381,
'enq: ZF - add fga audit table partition' as e382,
'enq: ZH - compression analysis' as e383,
'enq: ZZ - update hash tables' as e384,
'events in waitclass Other' as e385,
'extent map load/unlock' as e386,
'FAL archive wait 1 sec for REOPEN minimum' as e387,
'flashback free VI log' as e388,
'flashback log switch' as e389,
'free global transaction table entry' as e390,
'free process state object' as e391,
'GCR CSS join retry' as e392,
'GCR ctx lock acquisition' as e393,
'GCR lock acquisition' as e394,
'GCR member Data from CSS ' as e395,
'gcs ddet enter server mode' as e396,
'gcs domain validation' as e397,
'gcs drm freeze begin' as e398,
'gcs drm freeze in enter server mode' as e399,
'gcs enter server mode' as e400,
'gcs lmon dirtydetach step completion' as e401,
'GCS lock cancel' as e402,
'GCS lock cvt S' as e403,
'GCS lock cvt X' as e404,
'GCS lock esc' as e405,
'GCS lock esc X' as e406,
'GCS lock open' as e407,
'GCS lock open S' as e408,
'GCS lock open X' as e409,
'gcs log flush sync' as e410,
'GCS recovery lock convert' as e411,
'GCS recovery lock open' as e412,
'gcs remastering wait for read latch' as e413,
'gcs resource directory to be unfrozen' as e414,
'gcs retry nowait latch get' as e415,
'gcs to be enabled' as e416,
'ges cached resource cleanup' as e417,
'ges cancel' as e418,
'ges cgs registration' as e419,
'ges client process to exit' as e420,
'ges DFS hang analysis phase 2 acks' as e421,
'ges enter server mode' as e422,
'ges generic event' as e423,
'ges global resource directory to be frozen' as e424,
'ges inquiry response' as e425,
'ges lmd and pmon to attach' as e426,
'ges LMD suspend for testing event' as e427,
'ges lmd sync during reconfig' as e428,
'ges LMD to inherit communication channels' as e429,
'ges LMD to shutdown' as e430,
'ges lmd/lmses to freeze in rcfg' as e431,
'ges lmd/lmses to unfreeze in rcfg' as e432,
'ges LMON for send queues' as e433,
'ges LMON to get to FTDONE ' as e434,
'ges LMON to join CGS group' as e435,
'ges lms sync during dynamic remastering and reconfig' as e436,
'ges master to get established for SCN op' as e437,
'ges message buffer allocation' as e438,
'ges performance test completion' as e439,
'ges pmon to exit' as e440,
'ges process with outstanding i/o' as e441,
'ges resource cleanout during enqueue open' as e442,
'ges resource cleanout during enqueue open-cvt' as e443,
'ges resource directory to be unfrozen' as e444,
'ges retry query node' as e445,
'ges reusing os pid' as e446,
'ges RMS0 retry add redo log' as e447,
'ges user error' as e448,
'ges wait for lmon to be ready' as e449,
'ges yield cpu in reconfig' as e450,
'ges/gcs diag dump' as e451,
'ges1 LMON to wake up LMD - mrcvr' as e452,
'ges2 LMON to wake up LMD - mrcvr' as e453,
'ges2 LMON to wake up lms - mrcvr 2' as e454,
'ges2 LMON to wake up lms - mrcvr 3' as e455,
'ges2 proc latch in rm latch get 1' as e456,
'ges2 proc latch in rm latch get 2' as e457,
'GIPC operation: dump' as e458,
'global cache busy' as e459,
'global enqueue expand wait' as e460,
'global plug and play automatic resource creation' as e461,
'GPnP Get Error' as e462,
'GPnP Get Item' as e463,
'GPnP Initialization' as e464,
'GPnP Set Item' as e465,
'GPnP Termination' as e466,
'GV$: slave acquisition retry wait time' as e467,
'imm op' as e468,
'IMR CSS join retry' as e469,
'IMR disk votes' as e470,
'IMR membership resolution' as e471,
'IMR mount phase II completion' as e472,
'IMR net-check message ack' as e473,
'IMR rr lock release' as e474,
'IMR rr update' as e475,
'inactive session' as e476,
'inactive transaction branch' as e477,
'index block split' as e478,
'instance state change' as e479,
'IPC busy async request' as e480,
'IPC send completion sync' as e481,
'IPC wait for name service busy' as e482,
'IPC waiting for OSD resources' as e483,
'job scheduler coordinator slave wait' as e484,
'jobq slave shutdown wait' as e485,
'jobq slave TJ process wait' as e486,
'kcbzps' as e487,
'kdblil wait before retrying ORA-54' as e488,
'kdic_do_merge' as e489,
'kfcl: instance recovery' as e490,
'kgltwait' as e491,
'kjbdomalc allocate recovery domain - retry' as e492,
'kjbdrmcvtq lmon drm quiesce: ping completion' as e493,
'kjbopen wait for recovery domain attach' as e494,
'KJC: Wait for msg sends to complete' as e495,
'kjctcisnd: Queue/Send client message' as e496,
'kjctssqmg: quick message send wait' as e497,
'kjudomatt wait for recovery domain attach' as e498,
'kjudomdet wait for recovery domain detach' as e499,
'kjxgrtest' as e500,
'kkdlgon' as e501,
'kkdlhpon' as e502,
'kkdlsipon' as e503,
'kksfbc child completion' as e504,
'kksfbc research' as e505,
'kkshgnc reloop' as e506,
'kksscl hash split' as e507,
'knpc_acwm_AwaitChangedWaterMark' as e508,
'knpc_anq_AwaitNonemptyQueue' as e509,
'knpsmai' as e510,
'kpodplck wait before retrying ORA-54' as e511,
'ksbcic' as e512,
'ksbsrv' as e513,
'ksdxexeother' as e514,
'ksdxexeotherwait' as e515,
'ksim generic wait event' as e516,
'kslwait unit test event 1' as e517,
'kslwait unit test event 2' as e518,
'kslwait unit test event 3' as e519,
'ksv slave avail wait' as e520,
'ksxr poll remote instances' as e521,
'ksxr wait for mount shared' as e522,
'ktfbtgex' as e523,
'ktm: instance recovery' as e524,
'ktsambl' as e525,
'kttm2d' as e526,
'Kupp process shutdown' as e527,
'kupp process wait' as e528,
'kxfxse' as e529,
'kxfxsp' as e530,
'latch: active service list' as e531,
'latch activity' as e532,
'latch: cache buffer handles' as e533,
'latch: cache buffers lru chain' as e534,
'latch: call allocation' as e535,
'latch: change notification client cache latch' as e536,
'latch: Change Notification Hash table latch' as e537,
'latch: checkpoint queue latch' as e538,
'latch: enqueue hash chains' as e539,
'latch free' as e540,
'latch: gc element' as e541,
'latch: gcs resource hash' as e542,
'latch: ges resource hash list' as e543,
'latch: lob segment dispenser latch' as e544,
'latch: lob segment hash table latch' as e545,
'latch: lob segment query latch' as e546,
'latch: messages' as e547,
'latch: object queue header operation' as e548,
'latch: parallel query alloc buffer' as e549,
'latch: PX hash array latch' as e550,
'latch: redo allocation' as e551,
'latch: session allocation' as e552,
'latch: undo global data' as e553,
'latch: virtual circuit queues' as e554,
'latch: WCR: processes HT' as e555,
'latch: WCR: sync' as e556,
'LGWR ORL/NoExp FAL archival' as e557,
'LGWR simulation latency wait' as e558,
'LGWR wait for redo copy' as e559,
'LGWR-LNS wait on channel' as e560,
'library cache revalidation' as e561,
'library cache shutdown' as e562,
'listen endpoint status' as e563,
'listener registration dump' as e564,
'LMON global data update' as e565,
'lms flush message acks' as e566,
'LNS simulation latency wait' as e567,
'lock close' as e568,
'lock deadlock retry' as e569,
'lock escalate retry' as e570,
'lock release pending' as e571,
'log file switch (clearing log file)' as e572,
'log switch/archive' as e573,
'log write(even)' as e574,
'log write(odd)' as e575,
'Logical Standby Apply shutdown' as e576,
'Logical Standby Debug' as e577,
'Logical Standby dictionary build' as e578,
'Logical Standby pin transaction' as e579,
'Logical Standby Terminal Apply' as e580,
'L1 validation' as e581,
'master diskmon read' as e582,
'master diskmon startup' as e583,
'master exit' as e584,
'MMON (Lite) shutdown' as e585,
'MMON slave messages' as e586,
'MRP inactivation' as e587,
'MRP state inspection' as e588,
'MRP termination' as e589,
'MRP wait on archivelog archival' as e590,
'MRP wait on archivelog arrival' as e591,
'MRP wait on process restart' as e592,
'MRP wait on process start' as e593,
'MRP wait on startup clear' as e594,
'name-service call wait' as e595,
'NFS read delegation outstanding' as e596,
'no free buffers' as e597,
'no free locks' as e598,
'null event' as e599,
'OJVM: Generic' as e600,
'OLAP Aggregate Client Deq' as e601,
'OLAP Aggregate Client Enq' as e602,
'OLAP Aggregate Master Deq' as e603,
'OLAP Aggregate Master Enq' as e604,
'OLAP Null PQ Reason' as e605,
'OLAP Parallel Temp Grew' as e606,
'OLAP Parallel Temp Grow Request' as e607,
'OLAP Parallel Temp Grow Wait' as e608,
'OLAP Parallel Type Deq' as e609,
'opishd' as e610,
'optimizer stats update retry' as e611,
'OSD IPC library' as e612,
'parallel recovery change buffer free' as e613,
'parallel recovery coord send blocked' as e614,
'parallel recovery coord wait for reply' as e615,
'parallel recovery read buffer free' as e616,
'parallel recovery slave wait for change' as e617,
'pending global transaction(s)' as e618,
'pmon dblkr tst event' as e619,
'PMON to cleanup detached branches at shutdown' as e620,
'PMON to cleanup pseudo-branches at svc stop time' as e621,
'prewarm transfer retry' as e622,
'prior spawner clean up' as e623,
'process diagnostic dump' as e624,
'process shutdown' as e625,
'process startup' as e626,
'process terminate' as e627,
'PX create server' as e628,
'PX Deq Credit: free buffer' as e629,
'PX Deq Credit: Session Stats' as e630,
'PX Deq: OLAP Update Close' as e631,
'PX Deq: OLAP Update Execute' as e632,
'PX Deq: OLAP Update Reply' as e633,
'PX Deq: reap credit' as e634,
'PX Deq: Signal ACK EXT' as e635,
'PX Deq: Signal ACK RSG' as e636,
'PX Deq: Slave Join Frag' as e637,
'PX Deq: Slave Session Stats' as e638,
'PX Deq: Table Q Close' as e639,
'PX Deq: Table Q Get Keys' as e640,
'PX Deq: Table Q qref' as e641,
'PX Deq: Test for credit' as e642,
'PX Deq: Test for msg' as e643,
'PX hash elem being inserted' as e644,
'PX Nsq: PQ descriptor query' as e645,
'PX Nsq: PQ load info query' as e646,
'PX qref latch' as e647,
'PX Send Wait' as e648,
'PX server shutdown' as e649,
'PX signal server' as e650,
'PX slave connection' as e651,
'PX slave release' as e652,
'qerex_gdml' as e653,
'queue slave messages' as e654,
'rdbms ipc message block' as e655,
'rdbms ipc reply' as e656,
'readable standby redo apply remastering' as e657,
'recovery area: computing applied logs' as e658,
'recovery area: computing backed up files' as e659,
'recovery area: computing dropped files' as e660,
'recovery area: computing obsolete files' as e661,
'recovery buffer pinned' as e662,
'recovery instance recovery completion ' as e663,
'reliable message' as e664,
'Replication Dequeue ' as e665,
'resmgr:internal state cleanup' as e666,
'Resolution of in-doubt txns' as e667,
'RFS announce' as e668,
'RFS attach' as e669,
'RFS close' as e670,
'RFS create' as e671,
'RFS detach' as e672,
'RFS dispatch' as e673,
'RFS ping' as e674,
'RFS register' as e675,
'rollback operations active' as e676,
'rollback operations block full' as e677,
'rolling migration: cluster quiesce' as e678,
'row cache cleanup' as e679,
'row cache process' as e680,
'RSGA: RAC reconfiguration' as e681,
'RVWR wait for flashback copy' as e682,
'scginq AST call' as e683,
'secondary event' as e684,
'select wait' as e685,
'set director factor wait' as e686,
'SGA: allocation forcing component growth' as e687,
'SGA: sga_target resize' as e688,
'shutdown after switchover to standby' as e689,
'slave exit' as e690,
'Space Manager: slave messages' as e691,
'standby query scn advance' as e692,
'Streams AQ: emn coordinator waiting for slave to start' as e693,
'Streams AQ: qmn coordinator waiting for slave to start' as e694,
'Streams AQ: QueueTable kgl locks' as e695,
'Streams AQ: waiting for busy instance for instance_name' as e696,
'Streams capture: waiting for database startup' as e697,
'Streams miscellaneous event' as e698,
'Streams: RAC waiting for inter instance ack' as e699,
'SUPLOG PL wait for inflight pragma-d PL/SQL' as e700,
'Sync ASM rebalance' as e701,
'TEST: action hang' as e702,
'TEST: action sync' as e703,
'test long ops' as e704,
'timer in sksawat' as e705,
'transaction' as e706,
'TSE master key rekey' as e707,
'TSE SSO wallet reopen' as e708,
'tsm with timeout' as e709,
'txn to complete' as e710,
'unbound tx' as e711,
'undo segment recovery' as e712,
'undo_retention publish retry' as e713,
'unspecified wait event' as e714,
'wait active processes' as e715,
'wait for a paralle reco to abort' as e716,
'wait for a undo record' as e717,
'wait for another txn - rollback to savepoint' as e718,
'wait for another txn - txn abort' as e719,
'wait for another txn - undo rcv abort' as e720,
'wait for assert messages to be sent' as e721,
'wait for change' as e722,
'wait for EMON to spawn' as e723,
'wait for FMON to come up' as e724,
'wait for kkpo ref-partitioning *TEST EVENT*' as e725,
'wait for master scn' as e726,
'wait for MTTR advisory state object' as e727,
'wait for scn ack' as e728,
'Wait for shrink lock' as e729,
'Wait for shrink lock2' as e730,
'wait for stopper event to be increased' as e731,
'wait for sync ack' as e732,
'Wait for TT enqueue' as e733,
'wait for verification ack' as e734,
'wait list latch activity' as e735,
'wait list latch free' as e736,
'Wait on stby instance close' as e737,
'waiting to get CAS latch' as e738,
'waiting to get RM CAS latch' as e739,
'WCR: capture file IO write' as e740,
'WCR: RAC message context busy' as e741,
'WCR: Sync context busy' as e742,
'writes stopped by instance recovery or database suspension' as e743,
'xdb schema cache initialization' as e744,
'XDB SGA initialization' as e745
 )
  )
order by snap_id;
--------------
--Subset of Others class
select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'ADR block file read' as ADR_block_file_read,
'OJVM: Generic' as OJVM_Generic,
'DBMS_LDAP: LDAP operation ' as DBMS_LDAP_operation,
'latch free' as latch_free,
'kksfbc child completion' as kksfbc_child_completion,
'process diagnostic dump' as process_diagnostic_dump,
'LGWR wait for redo copy' as LGWR_wait_for_redo_copy,
'latch: enqueue hash chains' as latch__enqueue_hash_chains,
'asynch descriptor resize' as asynch_descriptor_resize,
'enq: CF - contention' as enq_CF_contention
)
  )
order by snap_id;
------------------------

select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'buffer busy waits', 'cursor: mutex S', 'cursor: mutex X', 'cursor: pin S', 'cursor: pin S wait on X', 'cursor: pin X', 'db flash cache invalidate wait', 'enq: HV - contention', 'enq: TX - index contention', 'enq: WG - lock fso', 'latch: cache buffers chains', 'latch: In memory undo latch', 'latch: MQL Tracking Latch', 'latch: row cache objects', 'latch: shared pool', 'latch: Undo Hint Latch', 'libcache interrupt action by LCK', 'library cache load lock', 'library cache lock', 'library cache: mutex S', 'library cache: mutex X', 'library cache pin', 'logout restrictor', 'os thread startup', 'pipe put', 'resmgr:internal state change', 'resmgr:sessions to exit', 'row cache lock', 'row cache read', 'securefile chain update', 'SecureFile mutex', 'Shared IO Pool Memory', 'Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'buffer busy waits', 'cursor: mutex S', 'cursor: mutex X', 'cursor: pin S', 'cursor: pin S wait on X', 'cursor: pin X', 'db flash cache invalidate wait', 'enq: HV - contention', 'enq: TX - index contention', 'enq: WG - lock fso', 'latch: cache buffers chains', 'latch: In memory undo latch', 'latch: MQL Tracking Latch', 'latch: row cache objects', 'latch: shared pool', 'latch: Undo Hint Latch', 'libcache interrupt action by LCK', 'library cache load lock', 'library cache lock', 'library cache: mutex S', 'library cache: mutex X', 'library cache pin', 'logout restrictor', 'os thread startup', 'pipe put', 'resmgr:internal state change', 'resmgr:sessions to exit', 'row cache lock', 'row cache read', 'securefile chain update', 'SecureFile mutex', 'Shared IO Pool Memory', 'Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'buffer busy waits' as buffer_busy_waits,
'cursor: mutex S' as cursor__mutex_S,
'cursor: mutex X' as cursor__mutex_X,
'cursor: pin S' as cursor__pin_S,
'cursor: pin S wait on X' as cursor__pin_S_wait_on_X,
'cursor: pin X' as cursor__pin_X,
'db flash cache invalidate wait' as db_flash_cache_invalidate_wait,
'enq: HV - contention' as eqnHV___contention,
'enq: TX - index contention' as eqnTX___index_contention,
'enq: WG - lock fso' as eqnWG___lock_fso,
'latch: cache buffers chains' as latch__cache_buffers_chains,
'latch: In memory undo latch' as latch__In_memory_undo_latch,
'latch: MQL Tracking Latch' as latch__MQL_Tracking_Latch,
'latch: row cache objects' as latch__row_cache_objects,
'latch: shared pool' as latch__shared_pool,
'latch: Undo Hint Latch' as latch__Undo_Hint_Latch,
'libcache interrupt action by LCK' as libcacheIntrrptActionByLCK,
'library cache load lock' as library_cache_load_lock,
'library cache lock' as library_cache_lock,
'library cache: mutex S' as library_cache__mutex_S,
'library cache: mutex X' as library_cache__mutex_X,
'library cache pin' as library_cache_pin,
'logout restrictor' as logout_restrictor,
'os thread startup' as os_thread_startup,
'pipe put' as pipe_put,
'resmgr:internal state change' as resmgr_internal_state_change,
'resmgr:sessions to exit' as resmgr_sessions_to_exit,
'row cache lock' as row_cache_lock,
'row cache read' as row_cache_read,
'securefile chain update' as securefile_chain_update,
'SecureFile mutex' as SecureFile_mutex,
'Shared IO Pool Memory' as Shared_IO_Pool_Memory,
'Streams apply: waiting for dependency' as StrmsApplyWaiting4dependency
)
    )
order by snap_id;

-- awr_publisherIO
select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and se.event_id=EN.EVENT_ID and se.dbid=en.dbid
  and EN.EVENT_NAME in (
'kst: async disk IO','ksfd: async disk IO','Log archive I/O','RMAN backup & recovery I/O','Standby redo I/O','io done','control file sequential read','control file single write','control file parallel write','recovery read','ARCH wait for pending I/Os','LNS ASYNC control file txn','LGWR sequential i/o','LGWR random i/o','RFS sequential i/o','RFS random i/o','RFS write','ARCH sequential i/o','ARCH random i/o','log file sequential read','log file single write','log file parallel write','db file parallel write','kfk: async disk IO'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and se.event_id=EN.EVENT_ID and se.dbid=en.dbid
  and EN.EVENT_NAME in (
'kst: async disk IO','ksfd: async disk IO','Log archive I/O','RMAN backup & recovery I/O','Standby redo I/O','io done','control file sequential read','control file single write','control file parallel write','recovery read','ARCH wait for pending I/Os','LNS ASYNC control file txn','LGWR sequential i/o','LGWR random i/o','RFS sequential i/o','RFS random i/o','RFS write','ARCH sequential i/o','ARCH random i/o','log file sequential read','log file single write','log file parallel write','db file parallel write','kfk: async disk IO'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'kst: async disk IO' as kst__async_disk_IO,
'ksfd: async disk IO' as ksfd__async_disk_IO,
'Log archive I/O' as Log_archive_I_O,
'RMAN backup & recovery I/O' as RMAN_backup___recovery_I_O,
'Standby redo I/O' as Standby_redo_I_O,
'io done' as io_done,
'control file sequential read' as control_file_sequential_read,
'control file single write' as control_file_single_write,
'control file parallel write' as control_file_parallel_write,
'recovery read' as recovery_read,
'ARCH wait for pending I/Os' as ARCH_wait_for_pending_I_Os,
'LNS ASYNC control file txn' as LNS_ASYNC_control_file_txn,
'LGWR sequential i/o' as LGWR_sequential_i_o,
'LGWR random i/o' as LGWR_random_i_o,
'RFS sequential i/o' as RFS_sequential_i_o,
'RFS random i/o' as RFS_random_i_o,
'RFS write' as RFS_write,
'ARCH sequential i/o' as ARCH_sequential_i_o,
'ARCH random i/o' as ARCH_random_i_o,
'log file sequential read' as log_file_sequential_read,
'log file single write' as log_file_single_write,
'log file parallel write' as log_file_parallel_write,
'db file parallel write' as db_file_parallel_write,
'kfk: async disk IO' as kfk__async_disk_IO
)
  )
order by snap_id;
------------------------

-- Event explanation
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
  --explain db file sequental reads
  'db file parallel read','pinned buffers inspected','physical writes from cache','physical writes','index fast full scans (full)','free buffer requested','free buffer inspected','user I/O wait time','physical reads','physical reads cache','file io wait time'
  --explain db file async io submit
  --'file io wait time','physical writes','physical writes from cache'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
--explain db file sequental reads
'db file parallel read' AS DbFilePRLLRd,'user I/O wait time' as userIOwt,'physical reads' as ph_reads,'physical reads cache' as ph_reads_cache,'free buffer inspected' as free_buff_insp,'free buffer requested' as free_buff_req,'pinned buffers inspected' as pin_buff_insp,'physical writes from cache' as ph_wr_from_bcache,'physical writes' as ph_writes,'index fast full scans (full)' as indx_ffs, 'file io wait time' AS file_io_wait_time
--explain db file async io submit
--'file io wait time' AS file_io_wait_time,'physical writes' AS phys_writes,'physical writes from cache' AS phys_wrtites_from_cache
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- Commit stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'commit batch performed','commit batch requested','commit batch/immediate performed','commit batch/immediate requested','commit immediate performed','commit immediate requested','commit nowait performed','commit nowait requested','commit wait performed','commit wait requested','commit wait/nowait performed','commit wait/nowait requested','user commits'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'commit batch performed' as cbatch_performed,
'commit batch requested' as cbatch_requested,
'commit batch/immediate performed' as cbatch_immediate_performed,
'commit batch/immediate requested' as cbatch_immediate_requested,
'commit immediate performed' as cimmediate_performed,
'commit immediate requested' as cimmediate_requested,
'commit nowait performed' as cnowait_performed,
'commit nowait requested' as cnowait_requested,
'commit wait performed' as ct_wait_performed,
'commit wait requested' as cwait_requested,
'commit wait/nowait performed' as cwait_nowait_performed,
'commit wait/nowait requested' as cwait_nowait_requested,
'user commits' as user_commits
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- Physical Reads stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical read total IO requests','physical read total multi block requests','physical reads','physical reads cache','physical read flash cache hits','physical reads direct','physical reads direct temporary tablespace','physical reads cache prefetch','physical reads prefetch warmup','physical reads retry corrupt','physical reads direct (lob)'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as (  select * from local_data ),
e as (  select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read total IO requests' as totalIO,
'physical read total multi block requests' as total_mblckIO,
'physical reads' as phr,
'physical reads cache' as phr_cache,
'physical read flash cache hits' as phr_flash_cache_hits,
'physical reads direct' as phr_direct,
'physical reads direct temporary tablespace' as phr_direct_tmp_tblspc,
'physical reads cache prefetch' as phr_cache_prefetch,
'physical reads prefetch warmup' as phr_prefetch_warmup,
'physical reads retry corrupt' as phr_retry_corrupt,
'physical reads direct (lob)' as phr_direct_lob
)
 )
order by snap_time;
--------------------------------------------------------------------------------
-- Physical Writes stats
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical write total IO requests','physical write total multi block requests','physical write total bytes','physical writes','physical writes direct','physical writes from cache','physical write IO requests','physical writes direct temporary tablespace','physical write bytes','physical writes non checkpoint','physical writes direct (lob)'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as (  select * from local_data ),
e as (  select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical write total IO requests' as pwr_totalIO_rqsts,
'physical write total multi block requests' as pwr_total_mb_rqsts,
'physical write total bytes' as pwr_total_b,
'physical writes' as pwrs,
'physical writes direct' as pwrs_direct,
'physical writes from cache' as pwrs_from_cache,
'physical write IO requests' as pwr_IOrqsts,
'physical writes direct temporary tablespace' as pwrs_direct_tmp_tbs,
'physical write bytes' as pwr_bytes,
'physical writes non checkpoint' as pwrs_non_checkpoint,
'physical writes direct (lob)' as pwrs_direct_lob
)
 )
order by snap_time;
--------------------------------------------------------------------------------


-- IO by filetype: IO Req
--------------------------------------------------------------------------------
select *
from (
with
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FILETYPE_NAME as stat_name,
        sum( nvl(IFT.SMALL_READ_REQS,0)+nvl(IFT.SMALL_WRITE_REQS,0)+nvl(IFT.LARGE_READ_REQS,0)+nvl(IFT.LARGE_WRITE_REQS,0) ) as stat_value
from WRH$_IOSTAT_FILETYPE ift, WRM$_SNAPSHOT s, WRH$_IOSTAT_FILETYPE_NAME ifn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FILETYPE_ID=IFT.FILETYPE_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FILETYPE_NAME
--order by S.SNAP_ID
 ),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
--order by e.snap_id;
 ) v
pivot (
max(value_diff)
for stat_name in (
'Other' as Other,
'Control File' as CntrlFile,
'Data File' as DataFile,
'Log File' as LogFile,
'Archive Log' as ArchLog,
'Temp File' as TempFile,
'Data File Backup' as DataFileBackup,
'Data File Incremental Backup' as DataFileIncBackup,
'Archive Log Backup' as ArchLogBackup,
'Data File Copy' as DataFileCopy,
'Flashback Log' as FlashbackLog,
'Data Pump Dump File' as DataPumpDumpFile
 )
    )
order by snap_id;
--------------------------------------------------------------------------------

-- IO by filetype: IO ServiceTime
--------------------------------------------------------------------------------
select *
from (
with
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FILETYPE_NAME as stat_name,
        sum( nvl(IFT.SMALL_READ_SERVICETIME ,0)+nvl(IFT.SMALL_WRITE_SERVICETIME,0)+nvl(IFT.LARGE_READ_SERVICETIME,0)+nvl(IFT.LARGE_WRITE_SERVICETIME,0) ) as stat_value
from WRH$_IOSTAT_FILETYPE ift, WRM$_SNAPSHOT s, WRH$_IOSTAT_FILETYPE_NAME ifn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FILETYPE_ID=IFT.FILETYPE_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FILETYPE_NAME
--order by S.SNAP_ID
 ),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
--order by e.snap_id;
 ) v
pivot (
max(value_diff)
for stat_name in (
'Other' as Other,
'Control File' as CntrlFile,
'Data File' as DataFile,
'Log File' as LogFile,
'Archive Log' as ArchLog,
'Temp File' as TempFile,
'Data File Backup' as DataFileBackup,
'Data File Incremental Backup' as DataFileIncBackup,
'Archive Log Backup' as ArchLogBackup,
'Data File Copy' as DataFileCopy,
'Flashback Log' as FlashbackLog,
'Data Pump Dump File' as DataPumpDumpFile
 )
    )
order by snap_id;
--------------------------------------------------------------------------------

-- IOStat by iofunction, waittime
select *
from (
with
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FUNCTION_NAME as stat_name,
        sum( nvl(IFT.WAIT_TIME,0) ) as stat_value
from WRH$_IOSTAT_FUNCTION ift, WRM$_SNAPSHOT s, WRH$_IOSTAT_FUNCTION_NAME ifn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FUNCTION_ID=IFT.FUNCTION_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FUNCTION_NAME
--order by S.SNAP_ID
 ),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
--order by e.snap_id;
 ) v
pivot (
max(value_diff)
for stat_name in (
'RMAN' as RMAN,
'DBWR' as DBWR,
'LGWR' as LGWR,
'ARCH' as ARCH,
'XDB' as XDB,
'Streams AQ' as StreamsAQ,
'Data Pump' as DataPump,
'Recovery' as Recovery,
'Buffer Cache Reads' as BufferCacheReads,
'Direct Reads' as DirectReads,
'Direct Writes' as DirectWrites,
'Smart Scan' as SmartScan,
'Archive Manager' as ArchManager,
'Others' as Others
 )
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Given statistics
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'DBWR undo block writes','failed probes on index block reclamation','IMU- failed to get a private strand','index fast full scans (full)','java call heap object count','lob reads','redo synch writes'
  )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'DBWR undo block writes' as s1,
'failed probes on index block reclamation' as s2,
'IMU- failed to get a private strand' as s3,
'index fast full scans (full)' as s4,
'java call heap object count' as s5,
'lob reads' as s6,
'redo synch writes' as s7
 )
 )
order by snap_time;
--------------------------------------------------------------------------------



select SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.snap_id between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by SE.EVENT_NAME
order by stat_value desc;

-- Load profile
select  snap_time as snap_time,
        snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
--  order by s.snap_id desc
),
b as ( select * from local_data ),
e as ( select * from local_data )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in ('execute count' as executions,'logons cumulative' as logons,'sorts (memory)' as memory_sorts,'sorts (disk)' as disk_sorts,'parse count (hard)' as hard_parses,'parse count (total)' as parses,'user calls' as user_calls,'physical reads' as physical_reads,'physical writes' as physical_writes,'db block changes' as block_changes,'session logical reads' as logical_reads,'redo size' as redo_size, 'user commits' as user_commit,'user rollbacks' as user_rollback)
 )
order by snap_id;

-- PGA Stat --------------------------------------------------------------------
select *
from (
with b as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as stat_name,
        ST.value as bytes
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.NAME in ('extra bytes read/written','total PGA inuse','total PGA allocated','maximum PGA allocated')
),
e as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as stat_name,
        ST.value as bytes
from WRM$_SNAPSHOT s, WRH$_PGASTAT st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.NAME in ('extra bytes read/written','total PGA inuse','total PGA allocated','maximum PGA allocated')
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 ) v
 pivot (
max(value_diff)
for stat_name in (
'extra bytes read/written' as extra_bytes,
'total PGA inuse' as pga_inuse,
'total PGA allocated' as pga_alloc,
'maximum PGA allocated' as max_pga_alloc
 )
 )
order by snap_time;
-- SQL WA Stat -----------------------------------------------------------------
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.LOW_OPTIMAL_SIZE as LOW_OPTIMAL_SIZE,
        ST.HIGH_OPTIMAL_SIZE as HIGH_OPTIMAL_SIZE,
        ST.OPTIMAL_EXECUTIONS as OPTIMAL_EXECUTIONS,
        ST.ONEPASS_EXECUTIONS as ONEPASS_EXECUTIONS,
        ST.MULTIPASSES_EXECUTIONS as MULTIPASSES_EXECUTIONS,
        ST.TOTAL_EXECUTIONS as TOTAL_EXECUTIONS
from WRM$_SNAPSHOT s, WRH$_SQL_WORKAREA_HISTOGRAM st
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
order by snap_time, LOW_OPTIMAL_SIZE;

--------------------------------------------------------------------------------

-- OSstat
select
v.snap_time as snap_time,
v.snap_id as snap_id,
v.NUM_CPUS as NUM_CPUS,
v.IDLE_TIME as IDLE_TIME,
v.BUSY_TIME as BUSY_TIME,
v.USER_TIME as USER_TIME,
v.SYS_TIME as SYS_TIME,
v.IOWAIT_TIME as IOWAIT_TIME,
v.NICE_TIME as NICE_TIME,
v.RSRC_MGR_CPU_WAIT_TIME as RSRC_MGR_CPU_WAIT_TIME,
v.LOAD as LOAD,
v.NUM_CPU_SOCKETS as NUM_CPU_SOCKETS,
v.PHYSICAL_MEMORY_BYTES as PHYSICAL_MEMORY_BYTES,
v.VM_IN_BYTES as VM_IN_BYTES,
v.VM_OUT_BYTES as VM_OUT_BYTES
from (
select *
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from WRM$_SNAPSHOT s, WRH$_OSSTAT os, WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
),
b as (
  select * from local_data
 ),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,'IDLE_TIME' as IDLE_TIME,'BUSY_TIME' as BUSY_TIME,'USER_TIME' as USER_TIME,'SYS_TIME' as SYS_TIME,'IOWAIT_TIME' as IOWAIT_TIME,'NICE_TIME' as NICE_TIME,'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,'LOAD' as LOAD,'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,'VM_IN_BYTES' as VM_IN_BYTES,'VM_OUT_BYTES' as VM_OUT_BYTES)
)
 ) v
order by v.snap_id;



select *
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('DB CPU','DB time','CPU used by this session')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('DB CPU','DB time','CPU used by this session')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'CPU used by this session' as cpu_usage,
'DB time' as db_time,
'DB CPU' as db_cpu
)
 )
order by snap_time;


select *
from (
with    b as (select rownum, S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from WRM$_SNAPSHOT s, WRH$_OSSTAT os, WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
        and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
 ),
        e as (select rownum, S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from WRM$_SNAPSHOT s, WRH$_OSSTAT os, WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,'IDLE_TIME' as IDLE_TIME,'BUSY_TIME' as BUSY_TIME,'USER_TIME' as USER_TIME,'SYS_TIME' as SYS_TIME,'IOWAIT_TIME' as IOWAIT_TIME,'NICE_TIME' as NICE_TIME,'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,'LOAD' as LOAD,'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,'VM_IN_BYTES' as VM_IN_BYTES,'VM_OUT_BYTES' as VM_OUT_BYTES)
)
order by snap_id;


select *
from WRH$_LATCH_NAME l
where l.dbid=&&v_dbid;


select distinct sn.stat_name from WRH$_STAT_NAME sn where SN.dbid=&&v_dbid;
select *
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical read IO requests', 'physical read total IO requests', 'physical read total multi block requests', 'physical reads', 'physical reads cache', 'physical reads cache prefetch', 'physical reads direct', 'physical reads direct (lob)', 'physical reads direct temporary tablespace', 'physical reads for flashback new', 'physical reads prefetch warmup', 'physical reads retry corrupt' )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical read IO requests', 'physical read total IO requests', 'physical read total multi block requests', 'physical reads', 'physical reads cache', 'physical reads cache prefetch', 'physical reads direct', 'physical reads direct (lob)', 'physical reads direct temporary tablespace', 'physical reads for flashback new', 'physical reads prefetch warmup', 'physical reads retry corrupt' )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read IO requests' as phr_IO_requests,
'physical read total IO requests' as phr_ttl_IO_requests,
'physical read total multi block requests' as phr_ttl_mblock_rqsts,
'physical reads' as phrs,
'physical reads cache' as phrs_cache,
'physical reads cache prefetch' as phrs_cache_prefetch,
'physical reads direct' as phrs_direct,
'physical reads direct (lob)' as phrs_direct__lob_,
'physical reads direct temporary tablespace' as phrs_direct_temp_tblspc,
'physical reads for flashback new' as phrs_for_flashback_new,
'physical reads prefetch warmup' as phrs_prefetch_warmup,
'physical reads retry corrupt' as phrs_retry_corrupt
)
 )
order by snap_time;


select *
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical reads', 'physical writes' )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from WRM$_SNAPSHOT s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical reads', 'physical writes' )
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical reads' as phrds,
'physical writes' as phwrs
)
 )
order by snap_time;


select *
from (
with
    b as (select  snap_time, snap_id, item_name, sum(PHYRDS) as PHYRDS, sum(PHYWRTS) as PHYWRTS
        from (
        select  S.BEGIN_INTERVAL_TIME as snap_time,
                S.SNAP_ID as snap_id,
                regexp_substr(SE.FILENAME,'^\+[A-Z]{3,4}[0-9]{1}') as item_name,
                SE.PHYRDS as PHYRDS,
                SE.PHYWRTS as PHYWRTS
        from WRM$_SNAPSHOT s, DBA_HIST_FILESTATXS se
        where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
          and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
          and S.snap_id between &&v_bsnap and &&v_esnap
          )
        group by snap_time, snap_id, item_name
),
    e as (select  snap_time, snap_id, item_name, sum(PHYRDS) as PHYRDS, sum(PHYWRTS) as PHYWRTS
        from (
        select  S.BEGIN_INTERVAL_TIME as snap_time,
                S.SNAP_ID as snap_id,
                regexp_substr(SE.FILENAME,'^\+[A-Z]{3,4}[0-9]{1}') as item_name,
                SE.PHYRDS as PHYRDS,
                SE.PHYWRTS as PHYWRTS
        from WRM$_SNAPSHOT s, DBA_HIST_FILESTATXS se
        where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
          and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
          and S.snap_id between &&v_bsnap and &&v_esnap
           )
        group by snap_time, snap_id, item_name
        )
select  e.snap_time as snap_time,
        e.item_name as item_name,
        nvl(e.PHYRDS,0)-nvl(b.PHYRDS,0) as PHYRDS,
        nvl(e.PHYWRTS,0)-nvl(b.PHYWRTS,0) as PHYWRTS
from b,e
where e.snap_id=(b.snap_id + 1) and e.item_name=b.item_name
)
pivot (
max(PHYRDS) as PHYRDS, max(PHYWRTS) as PHYWRTS
for item_name in ('+SATA1' as SATA1, '+SAS1' as SAS1, '+SSD1' as SSD1)
 )
order by snap_time;


-- Event List
select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.snap_id between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'i/o slave wait','io done','log file parallel write','db file parallel write','log file sequential read','rdbms ipc reply','log buffer space','log file sync','SQL*Net more data to client' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from WRM$_SNAPSHOT s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.snap_id between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'i/o slave wait','io done','log file parallel write','db file parallel write','log file sequential read','rdbms ipc reply','log buffer space','log file sync','SQL*Net more data to client' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'i/o slave wait' as i_o_slave_wait,
'io done' as io_done,
'log file parallel write' as log_file_parallel_write,
'db file parallel write' as db_file_parallel_write,
'log file sequential read' as log_file_sequential_read,
'rdbms ipc reply' as rdbms_ipc_reply,
'log buffer space' as log_buffer_space,
'log file sync' as log_file_sync,
'SQL*Net more data to client' as SQL_Net_more_data_to_client
)
    )
order by snap_id;

-- UNDO stat
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        round(PR.VALUE*US.ACTIVEBLKS/1024/1024/1024,2) as active_undo_Gb,
        round(PR.VALUE*US.UNEXPIREDBLKS/1024/1024/1024,2)  as unexp_undo_Gb,
        round(PR.VALUE*US.EXPIREDBLKS/1024/1024/1024,2)  as exp_undo_Gb,
        US.UNXPSTEALCNT as unexp_steals,
        US.EXPSTEALCNT as exp_steals,
        US.TUNED_UNDORETENTION as tuned_ur_sec
        --PR.VALUE as block_size
from WRH$_UNDOSTAT us, WRM$_SNAPSHOT s,
     WRH$_PARAMETER pr, WRH$_PARAMETER_NAME pn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and US.DBID=s.dbid and US.INSTANCE_NUMBER=s.INSTANCE_NUMBER and us.snap_id=s.snap_id
  and pr.DBID=s.dbid and pr.INSTANCE_NUMBER=s.INSTANCE_NUMBER and pr.snap_id=s.snap_id
  and pr.DBID=pn.dbid and PR.PARAMETER_HASH=PN.PARAMETER_HASH and PN.PARAMETER_NAME='db_block_size'
order by s.snap_id;
--------------------------------------------------------------------------------
-- given parameter value
SELECT pr.*
FROM sys.WRH$_PARAMETER pr, WRH$_PARAMETER_NAME pn, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.snap_id between &&v_bsnap and &&v_esnap
  and pr.DBID=s.dbid and pr.INSTANCE_NUMBER=s.INSTANCE_NUMBER and pr.snap_id=s.snap_id
  and pr.DBID=pn.dbid and PR.PARAMETER_HASH=PN.PARAMETER_HASH and PN.PARAMETER_NAME LIKE 'cpu_count'
;

select  count(*) as case_count,
        bucket_num
from (
select width_bucket(sql_rt_sec, 0.000353040983721778, 0.0124591386414693, 10 ) as bucket_num
       --min(sql_rt_sec), max(sql_rt_sec)
from (
select  S.snap_id as snap_time,
        --sum(ST.EXECUTIONS_DELTA) as sql_executions,
        --sum(ST.ELAPSED_TIME_DELTA) as sql_ela_time,
        ( sum(ST.ELAPSED_TIME_DELTA)/sum(ST.EXECUTIONS_DELTA) )/1000000 as sql_rt_sec
from WRH$_SQLSTAT st, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.snap_id between &&v_bsnap and &&v_esnap
group by S.snap_id
order by snap_time
 )
  )
group by bucket_num
order by bucket_num;

-----------------------------
WITH DATA AS
(SELECT
'cq8hzxwd7mk8d,85a2uhya4ax2q,1v717nvrhgbn9,fngg0vqhsbfwd,1n0tjkfgzwuz2,0k8522rmdzg4k,a3w52032jbswj,7vcqq5fjdp4y5,g41n1r60y3d71,5804gmvbhf10x,7qz03bvxfkjv2,6wy6mfghjqxd3,cb21bacyh3c7d,fu9yq36sbpkam,4w6m3yf017uzq,0ws7ahf1d78qa,at2h5x34yj2c4,g6ky64f3vvg23,459f3z9u4fb3u,2tux0wub2f3t4,4hyqc1fk1yqzq,4yb79gnqp1v90,7wnqpm1bxscd2,1nwrv4j8s51bb,7sjvgj5x5wyfq,92cp129v7stqm,6kgy4g774qdxc'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as q'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;
-- Given SQL_ID -------------
select *
from (
with
local_data as (
select  --S.BEGIN_INTERVAL_TIME as snap_time,
        St.SNAP_ID as snap_id,
        ST.SQL_ID as sql_id,
        --st.iowait_delta AS stat_value
        --Nvl(st.DISK_READS_DELTA,0) AS stat_value
        --st.CPU_TIME_DELTA as stat_value
        Nvl(st.executions_delta,0) as stat_value
        --Decode ( Nvl(st.executions_delta,0), 0, 0, Round( Nvl(st.elapsed_time_delta,0)/Nvl(st.executions_delta,0) ,2)  ) as stat_value
        --st.rows_processed_delta as stat_value
        --st.BUFFER_GETS_DELTA AS stat_value
        --st.elapsed_time_delta as stat_value
        --st.parse_calls_delta as stat_value
        --st.physical_write_bytes_delta AS stat_value
        --st.physical_read_bytes_delta AS stat_value
        --st.disk_reads_delta AS stat_value
        --st.direct_writes_delta AS stat_value
from --sys.WRM$_SNAPSHOT s ,
     sys.WRH$_SQLSTAT st
where St.dbid=&&v_dbid and St.INSTANCE_NUMBER=1 and St.snap_id between &&v_bsnap and &&v_esnap
  --and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and ST.SQL_ID in (
'cq8hzxwd7mk8d','85a2uhya4ax2q','1v717nvrhgbn9','fngg0vqhsbfwd','1n0tjkfgzwuz2','0k8522rmdzg4k','a3w52032jbswj','7vcqq5fjdp4y5','g41n1r60y3d71','5804gmvbhf10x','7qz03bvxfkjv2','6wy6mfghjqxd3','cb21bacyh3c7d','fu9yq36sbpkam','4w6m3yf017uzq','0ws7ahf1d78qa','at2h5x34yj2c4','g6ky64f3vvg23','459f3z9u4fb3u','2tux0wub2f3t4','4hyqc1fk1yqzq','4yb79gnqp1v90','7wnqpm1bxscd2','1nwrv4j8s51bb','7sjvgj5x5wyfq','92cp129v7stqm','6kgy4g774qdxc'
  )
),
b as ( select * from local_data),
e as ( select * from local_data)
select --e.snap_time as snap_time,
       e.snap_id as snap_id, e.sql_id as sql_id,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.sql_id=b.sql_id
) v
pivot (
max(value_diff)
for sql_id in (
'cq8hzxwd7mk8d' as q1,
'85a2uhya4ax2q' as q2,
'1v717nvrhgbn9' as q3,
'fngg0vqhsbfwd' as q4,
'1n0tjkfgzwuz2' as q5,
'0k8522rmdzg4k' as q6,
'a3w52032jbswj' as q7,
'7vcqq5fjdp4y5' as q8,
'g41n1r60y3d71' as q9,
'5804gmvbhf10x' as q10,
'7qz03bvxfkjv2' as q11,
'6wy6mfghjqxd3' as q12,
'cb21bacyh3c7d' as q13,
'fu9yq36sbpkam' as q14,
'4w6m3yf017uzq' as q15,
'0ws7ahf1d78qa' as q16,
'at2h5x34yj2c4' as q17,
'g6ky64f3vvg23' as q18,
'459f3z9u4fb3u' as q19,
'2tux0wub2f3t4' as q20,
'4hyqc1fk1yqzq' as q21,
'4yb79gnqp1v90' as q22,
'7wnqpm1bxscd2' as q23,
'1nwrv4j8s51bb' as q24,
'7sjvgj5x5wyfq' as q25,
'92cp129v7stqm' as q26,
'6kgy4g774qdxc' as q27
 )
)
order by snap_id;
--------------------------------------------------------------------------------

/*
drop TABLE sys.temp_sql_stat;
TRUNCATE TABLE sys.temp_sql_stat REUSE STORAGE;
CREATE TABLE sys.temp_sql_stat (sql_id varchar2(15), metric number) TABLESPACE excellent;
insert into temp_sql_stat \(sql_id\) values\('\1'\);

([^\t]+)\t([^\t]+)\r\n
insert into temp_sql_stat \(sql_id, metric\) values\('\1', \2\);\r\n
 +([0-9]+),([0-9]+)
 \1\.\2
*/
-- SQL_STAT
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.snap_id as snap_id,
        --Sum(st.version_count) AS version_count
        sum(ST.ROWS_PROCESSED_DELTA) as rows_processed,
        --Sum(st.invalidations_delta) AS invalidations
        --sum(ST.PARSE_CALLS_DELTA) AS parse_calls
        sum(ST.EXECUTIONS_DELTA) as sql_execution,
        --sum(ST.parse_calls_delta) as sql_parse
        --sum(ST.DISK_READS_DELTA) as disk_reads
        --sum(ST.physical_read_requests_delta) as preads_rq
        --sum(ST.DIRECT_WRITES_DELTA) as sql_stat
        --sum(ST.sharable_mem) as sharable_mem,
        --sum(ST.loaded_versions) as loaded_versions
        --sum(ST.version_count) as version_count,
        sum(ST.ELAPSED_TIME_DELTA) as ela_time,
        CASE WHEN Sum(st.EXECUTIONS_DELTA)>0 THEN Round(Sum(st.ELAPSED_TIME_DELTA)/Sum(st.EXECUTIONS_DELTA),0) ELSE 0 END AS avg_elatime
        --sum(ST.parse_calls_delta) as parse_calls
       -- sum(ST.CPU_TIME_DELTA) as cpu_time,
       -- sum(ST.BUFFER_GETS_DELTA) as buffers_get,
       -- sum(ST.IOWAIT_DELTA) as iowait_time,
       -- sum(ST.fetches_delta) as fetches_delta
        --sum(ST.PHYSICAL_READ_BYTES_DELTA) as PHYSICAL_READ_BYTES
        --Sum(st.physical_read_requests_delta) AS physical_read_requests
        --sum(ST.CLWAIT_DELTA) as clwait_time,
        --sum(ST.APWAIT_DELTA) as apwait_time,
        --sum(ST.CCWAIT_DELTA) as ccwait_time,
        --Sum(st.cpu_time_delta) AS cputime
        --sum(ST.javexec_time_delta) as jexec_time
        --sum(ST.plsexec_time_delta) as plsql_time
        --sum(ST.PHYSICAL_WRITE_REQUESTS_DELTA) as PHYSICAL_WRITE_REQUESTS
        --sum(physical_write_bytes_delta) as PHYSICAL_WRITE_BYTES
        --sum(PHYSICAL_READ_BYTES_DELTA) as PHYSICAL_READS_BYTES
        --( sum(ST.ELAPSED_TIME_DELTA)/sum(ST.EXECUTIONS_DELTA) )/1000000 as sql_rt_sec
from sys.WRH$_SQLSTAT st, sys.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.snap_id between &&v_bsnap and &&v_esnap
  --and ST.SQL_ID in ( SELECT t1.sql_id FROM SYSTEM.sql_ids t1 WHERE id > 1450 )
 AND st.sql_id IN (
'cs4y0n3t66jud','cp0cptxxcs8p9','8upp8qqgscaq6','7mqgmkz7gv0wa','0kcnt0dtfb4gh','anz3uqwg1gyb3','cv1skp3a87w2z','3ybjcwufr25w9','dugfkyy4fjh20','3vdgr4p69ry6v','95zpxwf5600qb','105vd9cbb0a97','fuf770zdcuy20','aj5z140jurb8b','53jh1h74hsd1g','4mgruk6ca8v5j','0f9qbh0n6vbg8','8vcnrrcrsynkb','6xv3ykktr0fwq','13pzr0u8a35dx','86cwhdbgafgtg','cgjvg63w8jwxv','8fmayu98cd5kr','b9m655yx1mac2','8fvasq9n2qnar','2u4j36tjpscx0','4wr0h15gbfmvy','2guhujdvfk5mf','46w05fav2a5nw','940ppdp997htr','87anbaahsk0cv','11g1ac8hs91sd','7yp8b2cjvs429','8x7aq06v8rpu2','grt79mnr8tywk','czhhdp5vwj9rx','1kt3a0xfrdcsu','597tr691vvz7n','9dvzad363adn4','a8u0kfjzqdrpn','c6u32svcytgvu','c1und0vaparc6','8kf2wqwyw9507','bw988bqdmfj5h','bt4rz7k15ytmc','5r337x1nrrjmg','df69jyybqwt2n','6ksrgjtbms6mv','979v4urd4rpvp','0gguqtgbqfhcb','d6gzrr8fxqvy3','1d9nxdudswgwm','fvyh5h3wjb5rp','dksf2r9u29dkn','8v19fu2c55fhc','3b7xaj3sx73rb','g3401myfwq90z','0j8x17cx2kasw','0qrqr9x30cu68','c6nhvma679jqn','0j16zkr783b0k','c0x9w8v6s4p6d','3axj47bqapj0x','6p92y335h6s9t','4c6kq27ukv1qy','32ybz0nf68h5w','bhzdbp9gr5sxj','8pdmz3tyaz31q','8vysntgzqtj8s','gm345u67r2fz4','g7ry8wkd8ut58','cayjgzzst7rj2','f9dhddbnac88j','1djhrbxu0rjfu','205c0wxbw9rp7','187md7qjqtarp','d86fws5x4kzzv','agbwmndjwbxzf','69mk2jskwfyry','7af2f6p1v577j','7h4s77rr5tfmp','6x3sd1txw83da','9nbpqrna74cr1','6vc4qtzy6bcmj','7my27pc9kq6z0','bvw5n176sc30f','dqrgpnx65wzxs','dnn5p5knxapxq','cqtrfz7t25zgz','f60c58nfs01xq','04bkp63wpxdj0','g7j4t0h71tp8p','a60qq7ftm3rck','g2x6q703uxz66','1na81r14zfztp','91rzyq6g33zw0','fztz75nuaxqdf','66nr8hqj1sujm','379jzmjgfgnzw','d9bfsftcq7d82','2gxbj9ucfuq8u','ffxw0sr9t2uka','f1vkynznhm5rp','6usrjdz8vwh8d','bk061n3b1wxaz','46f5c2xhk95md','3ujs4b9pms613','9k3dvn4bgfk91','6ct4pax6huf9t','76gtvxvdj7yff','fwzhkcj0h9vyd','fmpn23dmx5tx9','8yrc9ycmx2h5u','57f82mpnvy3zc','adkj4843yv6mw','frmz22xm9sz63','gxfzg2v19x30c','7az6aqwbymbu0','9y3ym0065knpp','6cgcmq6g5uv8b','430qzw0sg422r','8zv4r4dx56fus','740xa0088ww00','ghtzbh1vgr592','1q1dpdyh42405','4wvcshavu446n','27cbd33g6q5gx','3nunwjcj5mb8z','ga48hcbap5nnx','3ft5rjtw09jgz','550cz96nkqs1n','d8uz3jq7hwqp3','02nytfkhpdm2n','2warap7k9j7mh','6733gg2u4ph00','gu5g2f5vtvsph','802d50bw5zpv4','g21r05965yrx5','ctzfsz91mx8ac','fug4tfh6ah61z','12axxmtz3kv8k','524upzxa6gn0z','cbs4hqf6fgzq9','3sk2nykbgrk9g','03kv4dzbwsfm2','26xnxk61d1gw5','ch82h3yya0guv','3khak0zjyqp49','ghs73kvd158sr','5fbrfv1dgxdva','3ggvf415dvjpp','b1ujpcy93d5jz','b17q9cqnnh3kc','9jw5rtd2kw619','8hpja4dwyt5f6','afu2w3kqa682p','5p325tb3kyu37','b1tr6t9q2qx06','52xft0vbxbsq1','6u058h7qg7bpf','24cuvvysc74wn','ca15vqwz4qy25','0pabs5z579qfc','cngs1q4szypqn','5q3nfabjbb2k2','9p8a1j3mx4v34','aycar5nyztbxh','6t3hwf63hwaup','c2jmkyzjy069v','65c5afvp2vb0j','4jt7tk5gxbqfx','6k5fsxy84p264','1cds8smkkuz4u','12cu6wg2mqfys','0a8nn78cvwha9','7w91jzuz22kj0','ad63hqhupn276','akga6s2tsxmwy','0j6qtczu1hcpj','0rf1jf031ztn9','d6x61ygppsgph','520mx4g9h2yrf','awmsaqbrv52x9','70nwqbgddrczb','4wr60gmfftv1q','7hs25dz85ppcm','arwbmytd1r7nc','dgth0rr3udnh0','8f8864n873d4a','2vt49ptzpnum0','c29fb8691akxu','9f5280f94nxza','fybbsmu0nbjsy','gmtrgnyx5b81j','6za32th8v8rrs','7wuya16fu7qsj','09xx6ayzndkzr','anns9ks50dr2a','541k7vnpg0prg','9rzzzzzbbv5ms','cuwnu044hbc33','2dd4kfdam60fu','2jhmdrr19jzay','d0zqayt9cdzpb','26mthvjq424b8','27abd2xvqzr8m','1xdu72nphxzwm','0hjmz3stpjyqr','f3ahk3akaf22c','24dsbyyd2vvzt','d9a9fzqdjbz31','bqpg45qryuh7v','a6sxs9kntm3za','6d7zjymj50ufk','251guxvkwdaqw','9rsg3p7t95ftc','a4y666a78xg09','93a986sxsc9v7','8368rr45wrgsu','d2uu4j1vwya1z','8c161y02mwbmp','4158xxr59ur6c','fv4qbcnr10cxc','g0razvkrvmct9','9fyzsfdpv8xdb','6zcu2j0mfkc3w','bnfx6vnt0dy65','10azu8yjyuadc','990dxgudngt20','3pp67p4nywwv0','bv6ja4s9uyj4p','2r987g9nnnt1w','1tq7384ar7zh9','0aq7a049ja9d0','3rap95sjr1up7','g9ragmk8q9v3f','gkq0jm31yyzq9','7ybw81db110ks','835bfnvhmp2hd','7a48jnc41384a','a4nffcdwqrv95','29r5attgr6hga','83bw12m36zcf4','av5p3jfx7tpnv','6bw9xt9gt2rn6','9yymabs8fk395','d98udhjp7hz1d','694bpf4uq8qqv','6dnq6synszb50','6578y6pbzzfyu','8402y9c6jw0d3','4f8m6cuvd16ku','92wx8f5gu3yqz','573p188zzzpbz','0b6dqnvm961u9','19vph8utbc115','d4gbsr9969jdm','2rky7ymgfg3q0','6az34260mh00k','765yv3m9tjq08','1hxwvgq0bu709','5r12knq7mnzct','d439jv74trkfg','btf4qmycn6n1m','fgv5ty9g9uxbc','60zc87vsn3yyr','0n9cj2ua1p5wn','9c5a4ftq949qf','9bf6kf1r98xnr','1ak2h4jpr3xqr','cqazmab4w8qmx','7z7ycyg0zym9n','1j77fhspa3dqw','7pdwwv7vj9juc','28gs5p699nc2f','7cw8gk0ffutun','akw46445kc02b','8zrmmug6grcvc','6vz9g53yvuctp','5y1ywhqw5v3dr','bvz5xt8ngx65v','2gmfc37vua7am','7r68ducbg6vnn','62auh5tbfq1v6','8zt3f323kfdcm','521hynya42yfx','g6qsw4rrxyvb6','brf4sfqfy400n','f8q2wsy07pp8a','0ka8yn6g80uxm','gtsjzkzrgctv4','4cvpaguzz2a3w','1ufsnbvg7tkaz','axj7rrpxyt61y','dzp56yxc9kn30','8sjks17uy5cda','8x9wms98f7p48','0ruqp00uymyq6','57kzurq8umcua','gvza51661dwug','d124bnw6pnyzt','43nr1wx5wjdcs','9sb3w9pnpba29','a5p4vtyfvuf45','4vzxqxybjvrmv','4wdk39z4ymn50','davpadnuq3ngj','2y87jr8zz1xs6','fgwsdf1bsscn9','7dc08yrufhfhp','92y194jg9s903','983w66f7znd33','gart3553rp78x','d5us2tr3gh2r2','29bb5wsmr7gb3','94sdb0xfh73sm','b9b804uvfm493','7fw6aj11q2d2u','5sqx4nfanp338','2knc6v2yjtntb','2j8tm18fd3zym','b7yx930nr3hq6','85w3spbwtmk0w','3v1zx824huus0','auunkvpvn8r3g','atvsh3mqmxm76','dnwcav6ntc63w','96f3229spkksq','6qqhgzxskzwan','f9z3cm50f2rgx','5wxczzmt1zhx6','2ukxw9bbrw6us','gz3z88wgnd1jg','0v0xxn98sdhvw','5mv0ah399fnaz','2vf90ytj08huq','d3v02akk8u6g6','6nbbb9c4rj9pz','4gk689dudmpa0','3tsju3zgrhdyf','g2z4x12bz14vk','cx1dsvhh04uyj','84vjdmc8kgjf9','74fp8yg2gy0xx','6t9dmd2w5vyxt','3g17uuchatujs','gujr56sp4y9d3','06pjb2ckp70gn','0t87k22u8a8c4','2h6xj7cu786vc','9d8q5zdqwwp90','cdr2c381z31n9','9qwabffvm5jgt','bgmxsf8vgb7rw','fa0bf1zhn7wkt','fg5xdap4hpz17','1193ckjg4rm4c','46kq75vwgxt33','34n1f1qxa1cmg','cwj1jddzhpy5v','f60cbpxj9uhvn','37s3665y588gm','f8ggtxskmpkf8','2hbrmxh5yvya5','crh1jjtjvxytx','06qbhyak67v1w','614bj0tjfmynx','gghf6zug4npxk','7vp6xhzxafwbq','bkhzqra85amza','64dh3s8pj4rrx','fgywx3fg3xffc','dbr17f14wbr99','5dy37x40mjtfp','cwgwfyfjsxpbr','bdwppv834m7pp','dmtrtjc6b6ms2','59g4yx1c0mjft','02wv9rwc2ahh5','7ykgkm7gfvv3g','fawtwkvhb7m1n','g6fur29bj3v3h','2z7pwmsv03kp5','0hn4pmq6h1540','20713mwzs2wf5','2puj9qs2gfc1m','66xbwf55p41dx','c7a1zcft48rbx','214jujpwb3wyw','88xw3k4b5udrw','89yfwg5494agj','4wxudrhqm9nhu','5g57fsfmxatss','62c850sp7qv49','gmy8vsbdxr8m9','24cf3s4vbu4qk','duza6bh3y1kws','3m8u5dzqna7u5','1z5sbv1t41uz8','g39fc34m29y7a','2xhbm6tva49bt','49gshz11qb1n6','b0ky9k3g7k879','7nt0kptxkp90h','45vhd7au73hx5','bsdn8x3wvut99','1kzytcbwntz1s','aj7m58has62dh','ck5jps6y8p2pt','aswg0gp8d9f9d','1b7nmd223zvt5','djwd4a527czcv','5vtb4cydsxvvd','07gj28z3ujx70','3pmx7n670fbvq','gb1vcj7sp0ryq','dx508p9ba0uxx','9b16pffn49mr9','bkwpzcuc47c0x','44hrx1g8hcjrt','3sjn5ktupcha0','3nc86ggxms89t','auqknk7rywjpf','a035fj97kcmx5','8x1nypkrarjvq','0v6v9k4pv9hww','83uyxr7pwxxm2','31jnkznk8p7mq','8ftm1cu32k0c5','3ad48fcvbwtwh','874fatrprgz0a','6za9rg82138vs','9jpgpy3aauj0b','6uabwjsh26zpa','dn35v50zw0j90','aqsatsaqd3fyy','ds494xhtxcx1u','cpyn66fkahhz8','a6wjx06tq409t','91jg8qbgvhmst','a5q95qqk6qup9','9d5d8y6nt95t6','8g9mnnj33c7p1','78wfjxnjcgb3p','gjy0pat86ujm9','gus1uch9547bf','6w5gb5jyj1vk6','6phk82u4buwjh','873jvv9ah8ta3','gwtjw57kdrp1k','fqzf9tcd4zs7f','375kzrnajpqsw','09hdcgacmktzg','8u1z86183c5xg','440yktzcdwh0u','f4p3n44xh3mvb','byah541jv7uct','dnyhs4nzvxda5','7yqda7kuktgqz','69tk7uddpqtga','bzk3g0gz0jv5n','09zc4q0bkm600','dn4tfvkwcuvpn','6rcts3a8jsy6t','6atu76qck2dfr','22ryvsjgpuuu4','5cj5r1smj62hm','7m2c87bjy2r92','ba9br45u1z43d','ch2dshwvbjt9a','5d1131qhb9b4v'
  )
group by    S.BEGIN_INTERVAL_TIME,S.snap_id
order by s.snap_id asc;

select  DISTINCT st.sql_id
from WRH$_SQLSTAT st, WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.snap_id between  &&v_bsnap and &&v_esnap
  and ST.SQL_ID in ( SELECT t1.sql_id FROM SYSTEM.sql_ids t1 )
;


SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.top_level_sql_id='5mz15ym294fjn'
  --AND t.session_state='ON CPU'
--GROUP BY
;

SELECT *
FROM (
SELECT  t.snap_id AS snap_id,
        t.event AS event_name,
        Count(*) AS wait_count
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.top_level_sql_id='5mz15ym294fjn'
GROUP BY t.snap_id,t.event
 )
pivot (
Max(wait_count)
FOR event_name IN (
'library cache pin' as q1,
'buffer busy waits' as q2,
'enq: TX - row lock contention' as q3,
'db file sequential read' as q4,
'enq: TX - contention' as q5,
'library cache: mutex X' as q6,
'db file scattered read' as q7,
'latch: In memory undo latch' as q8,
'log file sync' as q9,
'log file switch completion' as q10
 )
)
ORDER BY snap_id
;

select t.sql_id, T.COMMAND_TYPE, t.sql_text
from WRH$_SQLTEXT t
where T.dbid=&&v_dbid --and t.snap_id between &&v_bsnap and &&v_esnap
  and T.SQL_ID in (
  'fsd0bkhq6bf7z','4u97t5dquxqzh','f7hppc6q7a0br','91aqxkvh17zgs','836469hd344ab','0ttnwxyust0cv','gn0z3tucrt52j','119aka0abd2z3','f6y8k2z6n7hak','dghmp4mzz6ntg','04b1jzxwzrhdm','5pw0j39fw03q2','5pmcu11vxgu0j','49dmwph7ks0gv','5vx54pr6augn3','bxcgrsm4hfhpk','8d9qgjhgsj2um','2mzrp420c0rv9','1a3mc2hfp6g73','4vt6ja3jttb0q'
  )
  --and upper(T.SQL_TEXT) like '%TMP_AGR_ACTIVE_RESOURCES%'
  ORDER BY T.COMMAND_TYPE
  ;

select  T.SNAP_ID as snap_id,
        --sum(T.DB_BLOCK_CHANGES_DELTA) as DB_BLOCK_CHANGES
        --sum(T.logical_reads_delta) as logical_reads_delta,
        sum(T.physical_reads_direct_delta) as stat_value
        --sum(T.physical_read_requests_delta) as stat_value
        --sum(T.physical_reads_direct_delta) as s_stat_value
        --, max(T.PHYSICAL_READS_DELTA) as m_stat_value
        --sum(T.PHYSICAL_WRITES_DELTA) as PHYSICAL_WRITES
        --sum(T.physical_writes_direct_delta) as PHYSICAL_WRITES_DIRECT
        --sum(T.chain_row_excess_delta) as chain_row_excess_delta
from sys.WRH$_SEG_STAT t
where T.dbid=&&v_dbid and T.INSTANCE_NUMBER=1 and T.SNAP_ID between &&v_bsnap and &&v_esnap
/*   and T.OBJ# in (
6556686,83628,2546577,9990771,83633,257604,2534701
  )*/
group by t.snap_id
ORDER BY t.snap_id;


WITH DATA AS
(SELECT
'6556686,83628,2546577,9990771,83633,257604,2534701'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as o'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;

/*
truncate table sys.temp_segments_name reuse storage;
create table sys.temp_segments_name(owner varchar2(30), name varchar2(30)) tablespace excellent;
 +\r\n
 \r\n
([^\.]+)\.([\w\$]+)\r\n
insert into sys\.temp_segments_name\(owner,name\) values\('\1', '\2'\);\r\n
*/

-- seg_stat
SELECT *
FROM (
select  s.begin_interval_time AS snap_time,
        T.SNAP_ID as snap_id,
        t.obj# AS object_num,
        --Sum(t.DB_BLOCK_CHANGES_DELTA) as seg_stat
        --Sum(t.table_scans_delta) as seg_stat
        --Sum(t.physical_writes_delta) as seg_stat
        --Sum(t.logical_reads_delta) as seg_stat
        Sum(PHYSICAL_READS_DELTA) as seg_stat
        --Sum(PHYSICAL_WRITES_DELTA) AS seg_stat
from sys.WRH$_SEG_STAT t, sys.wrm$_snapshot s
where s.dbid=&&v_dbid and s.INSTANCE_NUMBER=1 and s.SNAP_ID between &&v_bsnap and &&v_esnap
  AND s.dbid=T.dbid AND s.snap_id=T.SNAP_ID
  and T.OBJ#  in (
6556686,83628,2546577,9990771,83633,257604,2534701
  )
GROUP BY s.begin_interval_time, t.snap_id, t.obj#
   )
pivot (
max(seg_stat)
for object_num in (
'6556686' as o1,
'83628' as o2,
'2546577' as o3,
'9990771' as o4,
'83633' as o5,
'257604' as o6,
'2534701' as o7
 )
)
ORDER BY snap_id
;


SELECT *
FROM sys.WRH$_SEG_STAT s
where s.dbid=&&v_dbid and s.INSTANCE_NUMBER=1 and s.SNAP_ID between 66478 AND 66491
  AND s.obj#=52343
ORDER BY s.snap_id
;

SELECT t.object_id, t.object_type, t.owner||'.'||t.object_name AS full_obj_name
FROM sys.dba_objects t
WHERE t.object_id IN (6556686,83628,2546577,9990771,83633,257604,2534701)
      --t.object_name IN ('PE_PAYMENT_REQUEST_STEPS','I_PE_RQ_ST_ELIST_ACTIVE')
ORDER BY t.object_id asc
;

-- AAS query --
select  d.snap_id as snap_id,
        S.BEGIN_INTERVAL_TIME as snap_time,
        round(d.total_active_sessions/d.total_samples,2) as avg_active_sessions
from (
select  snap_id,
        sum(session_count) as total_active_sessions,
        count(*) as total_samples
from (
select  ASH.SNAP_ID as snap_id,
        ASH.SAMPLE_TIME as sample_time,
        count(*) as session_count
from WRM$_SNAPSHOT s, WRH$_ACTIVE_SESSION_HISTORY ash
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=ash.dbid and S.INSTANCE_NUMBER=ash.INSTANCE_NUMBER and s.snap_id=ash.snap_id
  and S.snap_id between &&v_bsnap and &&v_esnap
  and ASH.EVENT_ID=( select EN.EVENT_ID from WRH$_EVENT_NAME en where EN.dbid=&&v_dbid and EN.EVENT_NAME='db file sequential read')
  and ASH.CURRENT_FILE# != 0 and ASH.CURRENT_BLOCK# != 0
group by ash.snap_id, ash.sample_time
order by ash.snap_id
 )
group by snap_id
order by snap_id
 ) d, WRM$_SNAPSHOT s
where s.snap_id=d.snap_id and s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1;
--------------------------------------------------------------------------------


-- Undostat
SELECT  t.begin_time AS snap_time,
        Round(t.activeblks*32768/1024/1024/1024,2) AS active_data_GB,
        Round(t.unexpiredblks*32768/1024/1024/1024,2) AS unexp_data_GB,
        Round(t.expiredblks*32768/1024/1024/1024,2) AS exp_data_GB
FROM v$undostat t
ORDER BY t.begin_time
;

-- Delete alien awr-snapshits ---------------------------------------------------------------
DECLARE
 v_total_snapshots      NUMBER;
 CURSOR c1 IS
 SELECT s.dbid AS dbid,
        s.snap_id AS snap_id
 FROM SYS.WRM$_SNAPSHOT s
 where s.dbid!=&&v_dbid
 ORDER BY s.dbid, s.snap_id asc;

BEGIN
 SELECT Count(*)
 INTO v_total_snapshots
 FROM SYS.WRM$_SNAPSHOT s
 where s.dbid!=&&v_dbid;

 FOR i IN c1
 loop
  DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE(i.snap_id,i.snap_id,i.dbid);
  COMMIT;
  v_total_snapshots := v_total_snapshots-1;
  Dbms_Application_Info.set_action(v_total_snapshots||' left');
 END LOOP;
END;
/
