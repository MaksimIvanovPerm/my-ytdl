define v_dbid=3220346047
define v_bsnap=89898
define v_esnap=89901

define v_b_sample_time="12.12.2017 13:55:23.133"
define v_e_sample_time="29.04.2017 02:46:46.079"
define sql_sess_sid=2063
define sql_sess_serial=51977
define data_structure="V$ACTIVE_SESSION_HISTORY"

SELECT --*
 t.sql_id,t.sql_text
 --t.sql_id
FROM sys.wrh$_sqltext t
WHERE t.dbid=&&v_dbid
  --AND t.sql_id IN ( '1wh2fm6m0yzsy' )
  --AND t.sql_text LIKE '%���������� ���������%' ESCAPE '\'
  --AND t.command_type IN (3, 47) -- select,plsql
  --AND t.command_type NOT IN (3, 2,6,7, 47) -- select,plsql
  --AND t.command_type IN (2,6,7) --dml
  --AND t.command_type IN (3,2,6,7) --dml+select
  --AND t.command_type =3 -- select
  --AND t.command_type NOT IN (SELECT v.command_type FROM V$SQLCOMMAND v WHERE v.command_name='PL/SQL EXECUTE')
  AND upper(t.sql_text) LIKE '%SAP\_CHARGE\_TRANS\_DOCS\_DATA%' ESCAPE '\'
  --AND regexp_like(Upper(t.sql_text),' [\.]?OS_LIB.REF_BOOK_COLUMNS[^_A-Za-z0-9$#]')
ORDER BY t.sql_id asc
;

SELECT *
FROM sys.V_$SQLCOMMAND t
WHERE Lower(t.command_name) LIKE '%merge%'
ORDER BY t.
;

SELECT *
FROM v$sql t
WHERE upper(t.sql_text) LIKE '%MA\_ADDENDA%' ESCAPE '\'
;
 insert /*+ append */ into sys.ora_temp_1_ds_53125
 SELECT /*+  no_parallel(t) no_parallel_index(t) dbms_stats cursor_sharing_exact use_weak_name_resl dynamic_sampling(0) no_monitoring no_substrb_pad  */
        "ACTION","EXT_IP","START_PORT","END_PORT","NAT_IP","IN_DATE","END_DATE","SUBSCRIBER"
 from "DATA_TMN"."NAT_TRANSLATIONS_WORK" sample (  1.9053161786)  t  UNION ALL SELECT  "ACTION", "EXT_IP", "START_PORT", "END_PORT", "NAT_IP", "IN_DATE", "END_DATE", "SUBSCRIBER" FROM sys.ora_temp_1_ds_53125 WHERE 1 = 0

SELECT t.sql_id, Count(*)
FROM sys.v_$active_session_history t
where t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  AND t.session_type='FOREGROUND'
GROUP BY t.sql_id
ORDER BY 2 desc
;

-------------------------------------------------------

define sql_sess_sid=3487
define sql_sess_serial=42756
-- 1203.8;      1191,7; 1192.11;   1180.2782
define sql_exec_id=
define v_b_sample_time="21.02.2019 15:25:00.000"


SELECT --t.sql_id, Count(*) AS cnt
       t.*
       --t.sample_time, t.sample_id
       --DISTINCT t.top_level_sql_id
       --DISTINCT t.sql_id
       --t.plsql_object_id||' '||t.plsql_subprogram_id AS proc_id, Count(*) AS cnt
FROM sys.dba_hist_active_sess_history t
WHERE --t.session_type='FOREGROUND' AND
  t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.snap_id >=&&v_bsnap
  --AND t.sample_id>=248961637
  --AND t.plsql_entry_object_id=100637
  --AND t.plsql_object_id=101715
  --AND t.MODULE LIKE '%PROD\_PERIOD\_IVR\_�������%' ESCAPE '\'
  --AND t.machine='uk-billing-ivanovm'
  --AND t.action='dwh_charges_support2'
  AND t.top_level_sql_id IN ('1wh2fm6m0yzsy')
  --AND t.user_id=(SELECT u.user_id FROM sys.dba_users u WHERE u.username='RADIUS_TT')
  --AND t.session_id = &&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  --AND t.blocking_session=&&sql_sess_sid
  --AND t.blocking_session_serial#=&&sql_sess_serial
  --AND t.blocking_session_status='VALID'
  ---AND t.session_state='ON CPU'
  --AND t.sql_opcode NOT IN (3, 47)
  --AND t.event_id=(SELECT event_id FROM wrh$_event_name WHERE dbid=&&v_dbid and event_name='latch: cache buffers chains') --SELECT * FROM wrh$_event_name WHERE dbid=&&v_dbid order by event_name;
  AND t.sql_id IN ('10vqmz6dubcks','813523ygtzx47')
  --AND t.current_obj# = 47649
  --AND t.sql_id IN ('8qnfup47m44vt', '2u98rsx9p81ad')
  --AND t.sql_opcode=44
  --AND t.sample_time >= To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.xid='38001B00C0DD0600'
  --AND t.user_id=126
--GROUP BY t.sql_id ORDER BY cnt desc
ORDER BY t.sample_id asc
--ORDER BY t.session_id, t.session_serial#,t.sample_id
;

SELECT Count(*) AS cnt, t.sql_plan_line_id, t.sql_plan_operation||'-'||t.sql_plan_options AS plan_operation_info
FROM sys.dba_hist_active_sess_history t --, sys.dba_objects obj
WHERE t.dbid=&&v_dbid
  --AND t.snap_id BETWEEN &&v_esnap AND &&v_esnap
  AND t.session_id = &&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  AND t.sql_exec_id=&&sql_exec_id
  --AND obj.object_id=t.current_obj# AND obj.owner||'.'||obj.object_name='EXCELLENT.PHONE_NUMBERS'
GROUP BY t.sql_plan_line_id, t.sql_plan_operation||'-'||t.sql_plan_options
ORDER BY 1 desc
;

-- by sql operation
SELECT t.sql_plan_hash_value, t.sql_plan_line_id, Count(*) AS case_count
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='5ky344upbqk9h'
GROUP BY t.sql_plan_hash_value, t.sql_plan_line_id
ORDER BY t.sql_plan_hash_value, case_count desc
;

SELECT en.name, obj.owner||'.'||obj.object_name AS db_objects, v.sample_count
FROM (
SELECT t.event_id, t.current_obj#, Count(*) AS sample_count
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  AND t.session_id = &&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  AND t.sql_exec_id=&&sql_exec_id
GROUP BY t.event_id, t.current_obj#  ) v, sys.v_$event_name en, sys.dba_objects obj
WHERE en.event_id=v.event_id
  AND obj.object_id=v.current_obj#
ORDER BY v.sample_count DESC
;


SELECT t.sql_id, t.sql_exec_id,  max(t.sample_time-t.sql_exec_start) AS ela_time
FROM sys.dba_hist_active_sess_history t
WHERE --t.session_type='FOREGROUND' AND
  t.dbid=&&v_dbid
  AND t.session_id = &&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
GROUP BY t.sql_id, t.sql_exec_id
ORDER BY ela_time desc
;

SELECT *
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  AND t.sql_id='6gq846fdw7m3n'
  AND t.MODULE='adendas_wo_licfee_discount_agr_1 04.2018'
ORDER BY t.sample_id
;

SELECT --Max(t.sample_time)-Min(t.sample_time) AS ela_time,
       Min(t.sample_time), Max(t.sample_time) AS ela_time
       --*
       --DISTINCT t.sql_id
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.snap_id >= &&v_bsnap
  --AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
ORDER BY t.sample_id
;

SELECT t.session_id||' '||t.session_serial#, count(*)
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  --AND t.session_state='ON CPU'
GROUP BY t.session_id||' '||t.session_serial#
ORDER BY 2 desc
;

SELECT --Count(*),
       Sum(t.delta_write_io_requests),
       t.sql_id
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  --AND t.session_state='ON CPU'
  --AND t.sql_opcode IN (1,2,3,6,7,9,44)
  AND t.sql_id IN ('76shzdw9qu0gm','5kbp8h9cfy8v7','atdcazyzjx9tc','bqfnkjunhbm5c','2n17329sw5g8t')
GROUP BY t.sql_id
ORDER BY 1 desc
;

SELECT t.sample_id, t.sample_time, t.sql_exec_id, t.sql_exec_start, To_Char(t.sample_time-t.sql_exec_start,'SS.FF4') AS delta
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='0ttnwxyust0cv'
ORDER BY t.sample_id
;

SELECT sql_exec_id, start_exec_time, stop_exec_time,
       To_Number(REPLACE(regexp_substr( to_char(stop_exec_time-start_exec_time),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
FROM (
SELECT t.sql_exec_id,
       Min(t.sql_exec_start) AS start_exec_time,
       Max(t.sample_time) AS stop_exec_time
FROM sys.wrh$_active_session_history t
WHERE t.session_type=1
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='7zh8ka84gjzkw'
group BY t.sql_exec_id
ORDER BY 2
)
;

SELECT Trunc(t.sample_time,'mi') AS sample_time,
       Count(t.sql_exec_id) AS exec_count
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='1zzyt552hub4s'
GROUP BY Trunc(t.sample_time,'mi')
ORDER BY Trunc(t.sample_time,'mi')
;


SELECT t.sample_id, t.sample_time, Count(t.blocking_session_status)
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.snap_id >= &&v_bsnap
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TM - contention')
  --AND t.current_obj#=951465
GROUP BY t.sample_id, t.sample_time
ORDER BY t.sample_time
;

-- By event
SELECT Count(*), t.event
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_type='FOREGROUND'
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  --AND t.session_state='ON CPU'
  --AND t.sql_id='5mz15ym294fjn'
  --AND t.top_level_sql_id='5mz15ym294fjn'
  AND t.MODULE='FreeRadius_auth_support' --AND t.action='waiting for request'
  --AND t.machine='vradius2'
  AND t.user_id=70
GROUP BY t.event
ORDER BY 1 DESC
;

-- By temp-space usage
define v_bsampleid="295477607"
define v_esampleid="295499137"
SELECT *
FROM (
WITH all_ash AS (SELECT t.sample_time AS sample_time, t.sample_id AS sample_id
                 FROM sys.wrh$_active_session_history t
                 WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
                   --AND t.sample_id BETWEEN &&v_bsampleid AND &&v_esampleid
                 ),
    data_ash AS (SELECT t1.sample_id as s_id, 
                        --Round(Sum( Nvl(t1.pga_allocated,0) )/1024/1024,2) AS stat_value
                        --Max( Round(Nvl(t1.temp_space_allocated,0)/1024/1024,2) ) AS stat_value
                        sum( Round(Nvl(t1.temp_space_allocated,0)/1024/1024,2) ) AS stat_value
                 FROM sys.wrh$_active_session_history t1
                 WHERE t1.dbid=&&v_dbid AND t1.instance_number=1 AND t1.snap_id BETWEEN &&v_bsnap AND &&v_esnap
                  --AND t1.sample_id BETWEEN &&v_bsampleid AND &&v_esampleid
                GROUP BY t1.sample_id
                )
SELECT all_ash.sample_id AS sample_id, all_ash.sample_time, ROWNUM AS rid, data_ash.stat_value
FROM all_ash, data_ash
WHERE all_ash.sample_id=data_ash.s_id(+)
ORDER BY all_ash.sample_id ASC
 )
 WHERE Mod(rid,50)=0
;


-- By event parameter
SELECT Count(*), t.p2 AS event_param_value
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  AND t.event_id=(SELECT event_id FROM wrh$_event_name WHERE dbid=&&v_dbid and event_name='enq: HW - contention')
  --AND t.sql_opcode != 47
  --AND t.sql_id='gktyvcsdrg84c'
GROUP BY t.p2
ORDER BY 1 desc
;

define sql_sess_sid=847
define sql_sess_serial=31569


SELECT * --DISTINCT t.sql_id
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid --AND t.instance_number=1
  --AND t.snap_id=&&v_bsnap
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_id BETWEEN 30062977 AND 30064187
  AND t.session_type='FOREGROUND'
  --AND t.sample_time between To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3') AND To_timestamp('&&v_e_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.sample_time=To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND T.SAMPLE_ID BETWEEN 224693220-2 AND 224693220+2
  --AND t.session_id=407 AND t.session_serial#=9
  --AND t.MODULE='wcc2_main.search_result'
  --AND t.action='webcab_xml_proc.tv_packets_list'
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TM - contention')
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.current_obj#=48060
  --AND t.sql_opcode IN (44,45)
  --AND t.p1=796946708
  AND t.sql_id = '1c6ny3ghh5fbq'
  AND T.top_level_sql_id='gyvf484hbarpr'
  --AND t.user_id IN (131,145,146)
  --AND t.program='sqlldr.exe'
  --AND t.action='s_cf\13_gis_house_geometry.CTL'
  --AND t.MODULE='cch_month_erase_old_rows'
  --AND t.sql_id IN ('ctjjjppd1kvm2','2j334bydycyqj','c6mb4r2z9w78x','bw85h88b3nv9m','57jy8yhvjfh7a','6kbtkv9uxnzmb','arv8kk3hymug5','ctjjjppd1kvm2','ctjjjppd1kvm2','6kbtkv9uxnzmb','6kbtkv9uxnzmb','57jy8yhvjfh7a','57jy8yhvjfh7a','arv8kk3hymug5','arv8kk3hymug5','bw85h88b3nv9m','bw85h88b3nv9m','c6mb4r2z9w78x','c6mb4r2z9w78x','2j334bydycyqj','2j334bydycyqj')
ORDER BY t.sample_id desc --, t.session_id, t.session_serial#
;

-- By sql
SELECT Count(*), t.sql_id
 --*
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.snap_id >= &&v_bsnap
  AND t.session_type=1
  --AND t.session_id=1815 AND t.session_serial#=8481
  AND t.wait_time!=0 -- "ON CPU"
  --AND t.sql_opcode IN (2,6,7)
  AND t.event_id=(SELECT event_id FROM wrh$_event_name WHERE dbid=&&v_dbid and event_name='latch: cache buffers chains')
  --AND t.sample_time between To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3') AND To_timestamp('&&v_e_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.sql_opcode in (2,6,7) --dml
  --AND t.program='sqlldr.exe'
  --AND t.action='s_cf\13_gis_house_geometry.CTL'
  --AND t.MODULE='SQL Loader Conventional Path Load'
  --AND t.top_level_sql_id='581sb14qmn1yx'
  AND t.sample_time>=(SYSDATE-20/(24*60))
GROUP BY t.sql_id
ORDER BY 1 desc
;

-- By current_obj#
SELECT Count(*), t.current_obj#
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.session_id=1815 AND t.session_serial#=8481
  AND t.wait_time!=0 -- "ON CPU"
  --AND t.sql_opcode IN (2,6,7)
  --AND t.event_id=(SELECT event_id FROM wrh$_event_name WHERE dbid=&&v_dbid and event_name='latch: cache buffers chains')
  --AND t.sample_time between To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3') AND To_timestamp('&&v_e_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.sql_opcode in (2,6,7) --dml
  --AND t.program='sqlldr.exe'
  --AND t.action='s_cf\13_gis_house_geometry.CTL'
  --AND t.MODULE='SQL Loader Conventional Path Load'
  AND t.top_level_sql_id='8dqus4xf3ascf'
  AND t.sql_id='2bybwjgz5ar44'
GROUP BY t.current_obj#
ORDER BY 1 desc
;


-- count distinct sql-session
SELECT t.sample_time, Count(DISTINCT t.session_id||','||t.session_serial#) AS distinct_sql_sessions
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='buffer busy waits')
  --AND t.sql_opcode != 47
  --AND t.program='sqlldr.exe'
  --AND t.action='s_cf\13_gis_house_geometry.CTL'
  --AND t.MODULE='SQL Loader Conventional Path Load'
  AND t.sql_id=' 7zh8ka84gjzkw'
GROUP BY t.sample_time
ORDER BY 1 desc
;


-- By UserId
SELECT Count(*), t.user_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: UL - contention')
  --AND t.sql_opcode != 47
  AND t.sql_id='0rq88u0sdqw6b'
GROUP BY t.user_id
ORDER BY 1 desc
;

-- By sql-session
SELECT Count(*), t.session_id||','||t.session_serial# AS sql_session
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: UL - contention')
  --AND t.sql_opcode != 47
  --AND t.sql_id='5sgm63awqdmfa'
GROUP BY t.session_id||','||t.session_serial#
ORDER BY 1 desc
;

-- By object_id
SELECT Count(*), t.current_obj#
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  --AND t.sql_id='0n6hxqcav7r7a'
GROUP BY t.current_obj#
ORDER BY 1 desc
;

-- By blocking sql-session
SELECT Count(*), t.blocking_session||' '||t.blocking_session_serial# AS blocking_session
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.sample_time BETWEEN To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3') AND To_timestamp('&&v_e_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.wait_time!=0 -- "ON CPU"
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='buffer busy waits')
  --AND t.sql_id='0v12sgnv3780u'
GROUP BY t.blocking_session||' '||t.blocking_session_serial#
ORDER BY 1 desc
;


-- by top_level_sql_id
SELECT t.sql_id, t.top_level_sql_id, Count(*)
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.snap_id > &&v_bsnap
  --AND t.sample_time BETWEEN To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3') AND To_timestamp('&&v_e_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: UL - contention')
  AND t.sql_id IN ('79mb9aq1cvs0u')
  --AND t.MODULE = 'mx_rq_interface.show_web_face'
  --AND t.action='mx_rq_cursors.get_my_active_requ'
  --AND t.user_id IN (146)
  --AND t.sql_opcode=44
  --AND t.xid IS NOT NULL
  --AND t.program='sqlldr.exe'
  --AND t.action='s_cf\13_gis_house_geometry.CTL'
  --AND t.MODULE='SQL Loader Conventional Path Load'
GROUP BY t.sql_id, t.top_level_sql_id
ORDER BY 1, 3 desc
;

-- By sql_id
SELECT Count(*), t.sql_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.snap_id > &&v_bsnap
  --AND t.sample_time BETWEEN To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3') AND To_timestamp('&&v_e_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  AND t.session_type=1
  AND t.wait_time!=0 -- "ON CPU"
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='latch: cache buffers chains')
  --AND t.MODULE = 'mx_rq_interface.show_web_face'
  --AND t.action='mx_rq_cursors.get_my_active_requ'
  --AND t.user_id IN (146)
  --AND t.sql_opcode=44
  --AND t.xid IS NOT NULL
  --AND t.program='sqlldr.exe'
  --AND t.action='s_cf\13_gis_house_geometry.CTL'
  --AND t.MODULE='SQL Loader Conventional Path Load'
GROUP BY t.sql_id
ORDER BY 1 desc
;

-- By user_id
SELECT Count(*), t.user_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  AND t.sql_id='f9qk3ppc3n8cp'
  --AND t.top_level_sql_id='09khhzjx9137f'
  --AND t.sql_opcode=44
  --AND t.xid IS NOT NULL
GROUP BY t.user_id
ORDER BY 1 desc
;

-- By Action
SELECT Count(*), t.action
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  AND t.sql_id='f9qk3ppc3n8cp'
  --AND t.top_level_sql_id='09khhzjx9137f'
  --AND t.sql_opcode=44
  --AND t.xid IS NOT NULL
GROUP BY t.action
ORDER BY 1 desc
;

-- By module
SELECT Count(*), t.module
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  AND t.sql_id='8qbdfshh4v0jy'
  --AND t.top_level_sql_id='09khhzjx9137f'
  --AND t.sql_opcode=44
  --AND t.xid IS NOT NULL
GROUP BY t.module
ORDER BY 1 desc
;

-- By program
SELECT Count(*), t.program
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  AND t.sql_id='fngg0vqhsbfwd'
  --AND t.sql_opcode=44
  --AND t.xid IS NOT NULL
GROUP BY t.program
ORDER BY 1 desc
;



SELECT Count(*)
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  AND t.sql_id = '9f98vny25n0qf'
  --AND t.sql_opcode=44
  --AND t.xid IS NOT NULL
;

SELECT Count(*), t.sql_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='latch: cache buffers chains')
  --AND t.top_level_sql_id='5ktf77c2xs4c5'
GROUP BY t.sql_id
ORDER BY 1 desc
;

SELECT t.sql_id, Count(*)
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  --AND t.sql_id IN ('9f98vny25n0qf','71s027p3sta35','04b1jzxwzrhdm')
  AND t.sql_id IN ('14v8mamsspfwf','dkwxrwu3fddhu','ftq5y9kfq36zp','0n6hxqcav7r7a','2f8ruatqppbd4','5cu01174d7h9s','88hhr4kc0ztyu','gujkabu5kfnv3','f7t25g4y5ggfs','34rn9sc1zkf3r','5xqknv5vd3p3h','b2bg95un474xv','1smyfumgh5mmm')
  AND t.sql_opcode in (2,6,7) --dml
  AND t.current_file# IS NOT null
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='log file sync')
  --AND t.top_level_sql_id='1vrw3naztt0qm'
--ORDER BY t.snap_id
--ORDER BY t.sample_id
--ORDER BY t.sql_exec_id, t.sample_id
GROUP BY t.sql_id
ORDER BY 2 desc
;

SELECT Count(*), t.current_obj#
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.wait_time!=0 -- "ON CPU"
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='latch: cache buffers chains')
  AND t.sql_id='5pw0j39fw03q2'
GROUP BY t.current_obj#
ORDER BY 1 desc
;


SELECT Count(*), t.event_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id >= 43190
  AND t.session_type=1
  AND t.sql_id='5mt8xgqnby1zg'
  AND t.wait_time!=0 -- "ON CPU"
GROUP BY t.event_id
ORDER BY 1 desc
;

SELECT * FROM v$event_name WHERE event_id IN (2779959231);

-- Which top-level plsql-objects are currently executed
SELECT Count(*), t.plsql_entry_object_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.sql_id='871q1pcffs21b'
  --AND t.top_level_sql_id='c1h9vtda3g22p'
GROUP BY t.plsql_entry_object_id
ORDER BY 1 desc
;

SELECT Count(*), t.plsql_entry_subprogram_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.sql_id='871q1pcffs21b'
  --AND t.top_level_sql_id='09khhzjx9137f'
  AND t.plsql_entry_object_id=54782
GROUP BY t.plsql_entry_subprogram_id
ORDER BY 1 desc
;
-----------------------------------------------------
-- Which plsql-objects are currently executed --
SELECT Count(*), t.plsql_object_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.sql_id='3x4qt7jwfzb95'
  --AND t.top_level_sql_id='c1h9vtda3g22p'
GROUP BY t.plsql_object_id
ORDER BY 1 desc
;

SELECT Count(*), t.plsql_subprogram_id
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.sql_id='6jcvqdwpg611u'
  --AND t.top_level_sql_id='7gz04fx5ja17n'
  AND t.plsql_object_id=63492
GROUP BY t.plsql_subprogram_id
ORDER BY 1 desc
;
-----------------------------------------------------

SELECT Count(*), t.MODULE||' '||t.action AS module_action
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  AND t.plsql_object_id=51594
  AND t.plsql_subprogram_id=4
  AND t.sql_id='64udvbrqthk2n'
GROUP BY t.MODULE||' '||t.action
ORDER BY 1 desc
;

SELECT *
FROM sys.dba_procedures t
WHERE t.object_id=17803718
  --and t.object_name='phone_correct_support' 4046	89
  --and t.subprogram_id=4
ORDER BY t.subprogram_id
;

SELECT *
FROM sys.dba_objects t
WHERE --t.object_id=56619
      t.owner='EXCELLENT2' AND t.object_name='FACT_CITIES'
;

SELECT *
FROM V$SQLCOMMAND t
;

-- Given session
SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  AND t.session_id=1148
  --AND t.sql_opcode IN (2,6,7)
ORDER BY t.sample_time
;

SELECT distinct t.sql_id
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  AND t.session_id=1148
  AND t.sql_opcode IN (2,6,7)
--ORDER BY t.sample_time
;

-- Parsing reasons
SELECT *
FROM V$SQL_SHARED_CURSOR t
WHERE t.sql_id IN ('8rc7psphvxm1n','ctshk7try04xm','3dba8xn6quqd2','2xnbvgsg8sux0')
;

-- Who and how many times was blocked by LGWR, that is 'log file sync' analysis
SELECT s.sid, s.state
FROM V$BGPROCESS t, v$session s
WHERE Upper(t.name) = 'LGWR'
  AND s.paddr=t.paddr
;


-- Blocking analyze
define event_name="enq: TM - contention"

SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_id=163901409
  AND t.blocking_session_status='VALID'
  AND t.session_id=158
  AND t.session_serial#=9713
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='&&event_name')
;

SELECT  Count( DISTINCT t.session_id||','||t.session_serial# ) AS blocked_sess_count,
        t.sample_id AS sample_id
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_id=162451989
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='&&event_name')
  AND t.blocking_session_status='VALID'
GROUP BY t.sample_id
ORDER BY 2 desc
;


SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_id=163906809
  --AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  --AND t.blocking_session_status='VALID'
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TX - row lock contention')
  AND t.session_id=167
  AND t.session_serial#=63065
--ORDER BY t.sample_time
;

SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sample_id=163905539
  --AND t.blocking_session_status='VALID'
  AND t.blocking_session=158
  AND t.blocking_session_serial#=9713
ORDER BY t.sample_time
;

SELECT Count(*), t.current_obj#
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  AND t.blocking_session_status='VALID'
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TX - row lock contention')
GROUP BY t.current_obj#
ORDER BY 1 desc
;

SELECT Count(*), t.blocking_session||','||t.blocking_session_serial#
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  AND t.blocking_session_status='VALID'
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TX - row lock contention')
GROUP BY t.blocking_session||','||t.blocking_session_serial#
ORDER BY 1 desc
;

SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id=1693 AND t.session_serial#=24783
ORDER BY t.sample_time
;

SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.session_id=929 AND t.session_serial#=35347
ORDER BY t.sample_time
;

SELECT *
FROM sys.wrh$_sql_plan t
WHERE t.sql_id='7vxq0p5gahjbf'
  AND t.dbid=&&v_dbid --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
;

SELECT t.snap_id,
       Round( Sum(t.temp_space)/1024/1024/1024, 2) AS temp_space_used_Gb
FROM sys.wrh$_sql_plan t
WHERE t.dbid=&&v_dbid --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY t.snap_id
ORDER BY t.snap_id
;


-- V$ACTIVE_SESSION_HISTORY queries --------------------------------------------
SELECT *
FROM sys.V_$ACTIVE_SESSION_HISTORY t
WHERE 1=1
  --AND t.session_type='FOREGROUND' AND t.session_state='ON CPU'
  --AND t.sql_id='4nbgtpx2anq6q'
  AND t.session_id=511 AND t.session_serial#=51631
;

SELECT Count(*), t.sql_id
FROM V$ACTIVE_SESSION_HISTORY t
WHERE t.session_type='FOREGROUND'
  AND t.session_state='ON CPU'
GROUP BY t.sql_id
ORDER BY 1 desc
;

SELECT *
FROM V$ACTIVE_SESSION_HISTORY t
WHERE t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  AND t.sql_id='76t6zfksah1nc'
;

SELECT Count(*), t.event
FROM V$ACTIVE_SESSION_HISTORY t
WHERE t.session_type='FOREGROUND'
  --AND t.session_state='ON CPU'
  AND t.sql_id='3u0nk8y1x4nvb'
GROUP BY t.event
ORDER BY 1 desc
;

--------------------------------------------------------------------------------
-- PGA
-- Temp
define v_bsnap="83510"
define v_esnap="83800"

SELECT t.sample_time, Count(*) AS cnt
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.current_file# IN (1002, 1003, 1004)
GROUP BY t.sample_time
ORDER BY t.sample_time asc
;

SELECT t.current_file# AS file_id, Count(*) AS cnt
FROM dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY t.current_file#
ORDER BY file_id asc
;

SELECT t.event, Count(*) AS cnt
FROM dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY t.event
ORDER BY cnt DESC
;

SELECT t.sample_id, t.sample_time, Round(Sum( Nvl(t.pga_allocated,0) )/1024/1024,2) AS pga_allocated
       --t.sample_id, t.sample_time, Max( Round(Nvl(t.temp_space_allocated,0)/1024/1024,2) ) AS temp_allocated
       --t.sample_id, t.sample_time, sum( Round(Nvl(t.temp_space_allocated,0)/1024/1024,2) ) AS temp_allocated
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.snap_id = &&v_bsnap
  --AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TX - row lock contention')
  --AND t.sql_opcode != 47
GROUP BY t.sample_id, t.sample_time
ORDER BY t.sample_id
;



SELECT t.session_id||' '||t.session_serial# AS sid_serial, Round(t.pga_allocated/1024/1024,2) AS pga_allocatedMb--, t.temp_space_allocated
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sample_id=121361511
  --AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TX - row lock contention')
  --AND t.sql_opcode != 47
--GROUP BY t.sql_id
--ORDER BY t.sample_id
ORDER BY t.pga_allocated desc
;

-- temp
SELECT sample_time,pga_allocated_Mb,temp_space_allocated_Mb
FROM (
SELECT sample_time,pga_allocated_Mb,temp_space_allocated_Mb,
       ROWNUM AS id
FROM (
SELECT  t.sample_time AS sample_time,
        Round(Sum(t.pga_allocated)/1024/1024,2) AS pga_allocated_Mb,
        Round(Sum(t.temp_space_allocated)/1024/1024,2) AS temp_space_allocated_Mb
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  --AND t.snap_id >= &&v_bsnap
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
GROUP BY t.sample_time
ORDER BY t.sample_time
 )
  ) WHERE Mod(id,20)=0
;

SELECT  t.SAMPLE_TIME, t.SAMPLE_ID, t.SESSION_ID, t.SESSION_SERIAL#, t.SQL_ID, t.TOP_LEVEL_SQL_ID, t.SQL_PLAN_OPERATION, t.SQL_PLAN_OPTIONS, t.PROGRAM, t.MODULE, t.ACTION,
        Round(t.pga_allocated/1024/1024,2) AS PGA_ALLOC_MB,
        Round(t.temp_space_allocated/1024/1024,2) AS TEMP_ALLOC_MB
FROM sys.wrh$_active_session_history t, sys.WRH$_EVENT_NAME en
WHERE t.dbid=&&v_dbid AND t.instance_number=1
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_id=178803743
  AND t.dbid=en.dbid AND t.event_id=En.event_id
  --AND t.session_type=1
  --AND t.wait_time!=0 -- "ON CPU"
  --AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TX - row lock contention')
  --AND t.sql_opcode != 47
  --AND t.session_id=40 AND t.session_serial#=13575
ORDER BY t.sample_id
;

-- Query parallelism
SELECT  t.sample_id AS sample_id, t.sample_time AS sample_time,
        Count(DISTINCT t.session_id||','||t.session_serial#) AS sql_sessions
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_type=1
  AND t.sql_id='04b1jzxwzrhdm'
GROUP BY t.sample_id, t.sample_time
ORDER BY t.sample_id, t.sample_time
;

SELECT *
FROM sys.wrh$_service_name s
WHERE s.dbid=&&v_dbid --AND s.snap_id BETWEEN &&v_bsnap AND &&v_esnap
;

-- By service hash
SELECT *
FROM (
WITH ash_data AS (SELECT t.sample_time, t.service_hash, Count(DISTINCT t.session_id||','||t.session_serial#) AS sess_count
                  FROM sys.wrh$_active_session_history t
                  WHERE t.dbid=&&v_dbid AND t.instance_number=1 AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
                    AND t.session_type=1
                  GROUP BY t.sample_time, t.service_hash
                  --ORDER BY t.sample_time, t.service_hash
                  )
SELECT ash_data.sample_time AS sample_time,
       s.service_name AS service_name,
       ash_data.sess_count AS sess_count
FROM ash_data, sys.wrh$_service_name s
WHERE s.dbid=&&v_dbid
  AND s.service_name_hash=ash_data.service_hash
  )
pivot (
Max(sess_count)
FOR service_name IN (
'SYS$BACKGROUND' as sys_bckgrnd,
'fr-gsv-auth.samara.ertelecom.ru' as fr_gsv_auth,
'fr-int-acct.samara.ertelecom.ru' as fr_int_acct,
'fr-wifi-auth.samara.ertelecom.ru' as fr_wifi_auth,
'fr-gsv-acct.samara.ertelecom.ru' as fr_gsv_acct,
'fr-int-auth.samara.ertelecom.ru' as fr_int_auth,
'SYS$USERS' as sys_users,
'fr-wifi-acct.samara.ertelecom.ru' as fr_wifi_acct,
'raddb.samara.ertelecom.ru' as raddb
)
)
ORDER BY sample_time asc
;

define v_bsnap=47467
define v_esnap=47469
define v_b_sample_time="21.11.2018 12:24:23.961"
define v_e_sample_time="30.10.2018 17:11:36.686"
define v_sample_id=322727171
define v_b_sample_id=285137546
define v_e_sample_id=285138156
define event_name="enq: TM - contention"
define sql_sess_sid=513
define sql_sess_serial=54635

SELECT *
       /*
       t.sample_id, t.sample_time, t.session_id, t.session_serial#, t.session_type, t.user_id,
       t.sql_id, t.sql_opname, t.top_level_sql_id, t.sql_plan_hash_value, t.sql_exec_id, t.sql_exec_start,
       t.plsql_entry_object_id, t.plsql_entry_subprogram_id, t.plsql_object_id, t.plsql_subprogram_id,
       t.event, t.p1, mod(p1,16) as "mode", t.p2, t.p3, t.blocking_session_status, t.blocking_session, t.blocking_session_serial#,
       t.current_obj#, t.XID, t.program, t.MODULE, t.action, t.machine,
       Round(t.pga_allocated/1024/1024,2) AS pga_allocated_Mb,
       Round(t.temp_space_allocated/1024/1024,2) AS temp_allocated_Mb
       --*/
FROM sys.dba_hist_active_sess_history t
     --sys.wrh$_active_session_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.snap_id >= &&v_bsnap
  --AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  --AND t.sql_opcode!=3
  --AND t.sample_time BETWEEN To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3') AND To_timestamp('&&v_e_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.event_id=(SELECT event_id FROM sys.wrh$_event_name WHERE event_name='&&event_name' AND dbid=&&v_dbid) --1729366244
  --AND t.sample_id IN (229115898,229115908,229115918,229115928,229115938)
  --AND t.blocking_session_status='VALID'
  AND t.sample_id=&&v_sample_id
  --AND t.MODULE='pppoe_sessions_detail_move.move_sessions'
--GROUP BY t.sql_id ORDER BY 2 desc
--ORDER BY t.sample_id asc
ORDER BY t.action asc
;

define v_field="SQL_ID"
SELECT t.&&v_field, Count(*) AS cnt
FROM sys.dba_hist_active_sess_history t
     --sys.wrh$_active_session_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.MODULE='web_cabinet.get_info'
  AND t.action='webcab_tv.tv_packets_list'
  AND t.sql_opcode != 47
GROUP BY t.&&v_field
ORDER BY cnt desc
;

SELECT *
FROM (
SELECT  t.sample_time,
        t.&&v_field AS stat_name, Count(*) AS stat
FROM sys.dba_hist_active_sess_history t
WHERE 1=1
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.MODULE='web_cabinet.get_info'
  AND t.action='webcab_tv.tv_packets_list'
  and t.&&v_field IN ('813523ygtzx47','10vqmz6dubcks','gtp9y7nzhr2bq','45nx804bz2hmw','6d4bvf2aqm1qk','dtzhga332dwhv','1sdgwhru0g37p','4tss1rgjwd2qt','a20w2gkn4mt4m','guv8jgdq48hx2','4rduv3x008k1y','9y6rhxh103r1p','0t1n7c9samuwd','gub5y0xmd32zb','4v0zmfbb8b3yj','fdhkhn9ym29fd','1gxdhbc3dmyx8','91cnrg236uzay','dcmb3at7baqww','fyr1ywgv5gf1w','84qzsr7qa8r1m','47taz7p4d9yc8','4y7f8mczpnqrd','b9w6z577gt27u','4w9vbn6zm0zba','cavus742m88y8','00rxhmfjqg0cs','1tvx5qmn59s5x','5cvdt1d093p4d')
 GROUP BY t.sample_time, t.&&v_field )
pivot (
max(stat)
FOR stat_name IN (
'813523ygtzx47' as s1,
'10vqmz6dubcks' as s2,
'gtp9y7nzhr2bq' as s3,
'45nx804bz2hmw' as s4,
'6d4bvf2aqm1qk' as s5,
'dtzhga332dwhv' as s6,
'1sdgwhru0g37p' as s7,
'4tss1rgjwd2qt' as s8,
'a20w2gkn4mt4m' as s9,
'guv8jgdq48hx2' as s10,
'4rduv3x008k1y' as s11,
'9y6rhxh103r1p' as s12,
'0t1n7c9samuwd' as s13,
'gub5y0xmd32zb' as s14,
'4v0zmfbb8b3yj' as s15,
'fdhkhn9ym29fd' as s16,
'1gxdhbc3dmyx8' as s17,
'91cnrg236uzay' as s18,
'dcmb3at7baqww' as s19,
'fyr1ywgv5gf1w' as s20,
'84qzsr7qa8r1m' as s21,
'47taz7p4d9yc8' as s22,
'4y7f8mczpnqrd' as s23,
'b9w6z577gt27u' as s24,
'4w9vbn6zm0zba' as s25,
'cavus742m88y8' as s26,
'00rxhmfjqg0cs' as s27,
'1tvx5qmn59s5x' as s28,
'5cvdt1d093p4d' as s29
 )
);



SELECT DISTINCT t1.sql_id
FROM sys.dba_hist_active_sess_history t1
WHERE t1.session_id||','||t1.session_serial# IN (
SELECT DISTINCT t.session_id||','||t.session_serial#
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  AND t.event_id=(SELECT event_id FROM v$event_name WHERE name='enq: TM - contention')
   )
;

SELECT Count(*), t.blocking_session||','||t.blocking_session_serial# AS blocker
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  AND t.event_id=(SELECT event_id FROM sys.wrh$_event_name WHERE event_name='&&event_name' AND dbid=&&v_dbid)
GROUP BY t.blocking_session||','||t.blocking_session_serial#
ORDER BY 1 DESC;

SELECT t.sample_id, t.sample_time,  Count(DISTINCT t.session_id||','||t.session_serial#) AS sql_session
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.event_id=(SELECT event_id FROM sys.wrh$_event_name WHERE event_name='&&event_name' AND dbid=&&v_dbid)
  AND t.sql_id='5b8vsdf23vv4w'
GROUP BY t.sample_id, t.sample_time
ORDER BY 1 asc;


SELECT Count(*), t.sql_id
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  --AND t.event_id=(SELECT event_id FROM wrh$_event_name WHERE event_name='&&event_name' AND dbid=&&v_dbid) --1729366244

GROUP BY t.sql_id
ORDER BY 1 DESC;

SELECT Count(*), t.sql_plan_hash_value, t.sql_plan_line_id
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
  AND t.event_id=(SELECT event_id FROM wrh$_event_name WHERE event_name='&&event_name' AND dbid=&&v_dbid) --1729366244
  AND t.sql_id='3x4qt7jwfzb95'
GROUP BY t.sql_plan_hash_value, t.sql_plan_line_id
ORDER BY 1 DESC;

--session count -----------------------------------------------------------------------------------------------
WITH data as (SELECT t.sample_id AS sample_id,
       --t.sample_time,
       --Count(DISTINCT t.session_id||' '||t.session_serial#) AS sql_sess,
       Count(*) AS sql_sess
FROM sys.dba_hist_active_sess_history t
WHERE
  t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.blocking_session_status='VALID'
  AND t.event='latch: cache buffers chains'
GROUP BY t.sample_id),
data2 as (SELECT t.sample_id AS sample_id,
       Count(*) AS total_sql_sess
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY t.sample_id),
v AS (SELECT DISTINCT s.sample_id AS sample_id, s.sample_time AS sample_time
FROM sys.dba_hist_active_sess_history s
WHERE s.dbid=&&v_dbid AND s.snap_id BETWEEN &&v_bsnap AND &&v_esnap AND ROWNUM=rownum)
SELECT v.sample_id, v.sample_time, data.sql_sess AS blocked_sessions, data2.total_sql_sess
FROM data, v, data2
WHERE v.sample_id=data.sample_id(+) AND v.sample_id=data2.sample_id(+)
  --AND Mod(v.rnum,10)=0
ORDER BY v.sample_id asc
;

SELECT DISTINCT t.event
FROM sys.dba_hist_active_sess_history t
WHERE --t.session_type='FOREGROUND' AND
  t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sample_id BETWEEN &&v_b_sample_id AND &&v_e_sample_id
  AND t.SESSION_STATE='WAITING'
  --AND t.user_id=189
;

define v_attribute="event"
SELECT *
FROM (
SELECT t.sample_id AS sample_id,
       t.sample_time AS sample_time,
       --t.user_id AS parameter,
       t.&&v_attribute AS parameter,
       Count(*) AS sql_sess
FROM sys.dba_hist_active_sess_history t
WHERE --t.session_type='FOREGROUND' AND
  t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sample_id BETWEEN &&v_b_sample_id AND &&v_e_sample_id
  and t.&&v_attribute  in (
'LGWR wait for redo copy','RMAN backup & recovery I/O','SQL*Net more data to client','TCP Socket (KGAS)','buffer busy waits','control file sequential read','db file parallel write','db file scattered read','db file sequential read','enq: CR - block range reuse ckpt','enq: SQ - contention','enq: TX - index contention','enq: TX - row lock contention','latch free','latch: shared pool','library cache: mutex X','log buffer space','log file parallel write','log file switch (checkpoint incomplete)','log file switch completion','log file sync','os thread startup','read by other session','row cache lock','virtual circuit wait'
  )
GROUP BY t.sample_id, t.sample_time, t.&&v_attribute
   )
pivot (
max(sql_sess)
for parameter in (
'LGWR wait for redo copy' as q1,
'RMAN backup & recovery I/O' as q2,
'SQL*Net more data to client' as q3,
'TCP Socket (KGAS)' as q4,
'buffer busy waits' as q5,
'control file sequential read' as q6,
'db file parallel write' as q7,
'db file scattered read' as q8,
'db file sequential read' as q9,
'enq: CR - block range reuse ckpt' as q10,
'enq: SQ - contention' as q11,
'enq: TX - index contention' as q12,
'enq: TX - row lock contention' as q13,
'latch free' as q14,
'latch: shared pool' as q15,
'library cache: mutex X' as q16,
'log buffer space' as q17,
'log file parallel write' as q18,
'log file switch (checkpoint incomplete)' as q19,
'log file switch completion' as q20,
'log file sync' as q21,
'os thread startup' as q22,
'read by other session' as q23,
'row cache lock' as q24,
'virtual circuit wait' as q25
 )
)
ORDER BY sample_id
;

------------------------------------------------------------------------------------------------------------------

SELECT *
FROM (
SELECT t.sample_id, Nvl(t.event,'NW') AS event, Count(*) AS cnt
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY t.sample_id, t.event
 )
 pivot (
 max(cnt)
 FOR event IN (
'NW' as e1,
'latch: row cache objects' as e2,
'latch: library cache' as e3,
'cursor: pin S wait on X' as e4,
'TCP Socket (KGAS)' as e5,
'log file sync' as e6,
'db file sequential read' as e7,
'SQL*Net more data to client' as e8,
'db file scattered read' as e9,
'latch: library cache lock' as e10,
'library cache pin' as e11,
'SQL*Net more data from client' as e12,
'enq: TM - contention' as e13,
'null event' as e14,
'direct path sync' as e15,
'latch: cache buffers chains' as e16,
'kksfbc child completion' as e17,
'utl_file I/O' as e18,
'enq: TX - row lock contention' as e19,
'log file switch completion' as e20,
'latch: shared pool' as e21,
'library cache lock' as e22,
'cursor: pin S' as e23,
'log buffer space' as e24,
'control file sequential read' as e25,
'SQL*Net message from dblink' as e26,
'enq: RO - fast object reuse' as e27,
'latch free' as e28
  )
 )
ORDER BY sample_id asc;

-- PGA stat
SELECT Trunc(sample_time,'MI') AS sample_time,
       Avg(pga_allocated_Mb) AS pga_allocated_Mb
FROM (
SELECT t.sample_time AS sample_time,
       Round(Sum(t.pga_allocated)/1024/1024,2) AS pga_allocated_Mb
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY t.sample_time
ORDER BY t.sample_time
)
 GROUP BY Trunc(sample_time,'MI')
 ORDER BY 1
;

SELECT t.sample_time AS sample_time,
       Round(Sum(t.pga_allocated)/1024/1024,2) AS pga_allocated_Mb
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
HAVING Round(Sum(t.pga_allocated)/1024/1024,2) > 5*1024
GROUP BY t.sample_time
ORDER BY pga_allocated_Mb desc
;
-- then histogramm data

define v_b_sample_time="21.11.2018 15:09:03.485"
define sql_sess_sid=2846
define sql_sess_serial=11705

SELECT t.session_id||','||t.session_serial#||'' AS sess_id,
       Round(Max(t.pga_allocated)/1024/1024,2) AS pga_allocated_Mb
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
GROUP BY t.session_id||','||t.session_serial#
ORDER BY pga_allocated_Mb desc
;

SELECT DISTINCT sql_id
FROM (
SELECT t.session_id||','||t.session_serial#||'' AS sess_id,
       t.sql_id,
       Round(Max(t.pga_allocated)/1024/1024,2) AS pga_allocated_Mb
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sample_time = To_timestamp('&&v_b_sample_time','dd.mm.yyyy hh24:mi:ss.ff3')
GROUP BY t.session_id||','||t.session_serial#, t.sql_id
HAVING Round(Max(t.pga_allocated)/1024/1024,2) > 1024
ORDER BY pga_allocated_Mb DESC )
;

SELECT *
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  --AND t.program='sqlplus@eqmdb.msk.ertelecom.ru (TNS V1-V3)'
ORDER BY t.pga_allocated desc
;

--------------------------------------------------------------------------------
-- sql_exec_id
SELECT *
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='0ttnwxyust0cv'
ORDER BY t.sample_id ASC
;

define sql_sess_sid=137
define sql_sess_serial=45293

SELECT *
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
ORDER BY t.sample_id ASC
;

SELECT ''''||event||''' as e'||ROWNUM||',' AS clmn
FROM (
SELECT DISTINCT t.event AS event
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  )
;
-- by events
SELECT *
FROM (
SELECT t.sample_id AS sample_id, t.event AS event, Count(*) AS cnt
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sql_id='5mz15ym294fjn'
  --AND t.event='library cache: mutex X'
GROUP BY t.sample_id, t.event )
pivot (
Max(cnt)
FOR event IN (
'LGWR wait for redo copy' as e1,
'RMAN backup & recovery I/O' as e2,
'SQL*Net break/reset to client' as e3,
'SQL*Net more data from client' as e4,
'SQL*Net more data to client' as e5,
'TCP Socket (KGAS)' as e6,
'buffer busy waits' as e7,
'control file parallel write' as e8,
'control file sequential read' as e9,
'cursor: mutex S' as e10,
'db file scattered read' as e11,
'db file sequential read' as e12,
'enq: CF - contention' as e13,
'enq: CI - contention' as e14,
'enq: HW - contention' as e15,
'enq: RO - fast object reuse' as e16,
'enq: SQ - contention' as e17,
'enq: TC - contention' as e18,
'enq: TM - contention' as e19,
'enq: TX - allocate ITL entry' as e20,
'enq: TX - contention' as e21,
'enq: TX - index contention' as e22,
'enq: TX - row lock contention' as e23,
'enq: WL - contention' as e24,
'io done' as e25,
'kksfbc child completion' as e26,
'latch free' as e27,
'latch: cache buffers chains' as e28,
'latch: cache buffers lru chain' as e29,
'latch: library cache' as e30,
'latch: library cache pin' as e31,
'latch: object queue header operation' as e32,
'latch: redo allocation' as e33,
'latch: row cache objects' as e34,
'latch: session allocation' as e35,
'latch: shared pool' as e36,
'library cache pin' as e37,
'local write wait' as e38,
'log file sequential read' as e39,
'log file switch completion' as e40,
'log file sync' as e41,
'null event' as e42,
'rdbms ipc reply' as e43,
'read by other session' as e44,
'row cache lock' as e45,
'switch logfile command' as e46,
'undo segment extension' as e47,
'write complete waits' as e48
 )
)
;

SELECT *
FROM sys.v_$event_name t
WHERE t.name='&&event_name'
;
define event_name="enq: HW - contention"
SELECT * FROM sys.v_$tablespace;
-- event count
SELECT *
FROM (
SELECT cnt, sample_time, stat_value, ROWNUM AS rnum
FROM (
SELECT Count(*) AS cnt, Trunc(t.sample_time,'MI') AS sample_time, t.p2 AS stat_value
--t.sample_time, t.session_id, t.session_serial#, t.user_id, t.sql_id, t.sql_exec_start, t.plsql_entry_object_id, t.plsql_entry_subprogram_id,t.program, t.MODULE, t.action
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.event_id=(SELECT event_id FROM sys.wrh$_event_name WHERE event_name='&&event_name' AND dbid=&&v_dbid)
GROUP BY Trunc(t.sample_time,'MI'), t.p2
ORDER BY Trunc(t.sample_time,'MI') ASC )
 )
 --WHERE Mod(rnum,20)=0
;


-- exec_stat
define v_sql_id="5yah3vfnjjvwz"
define v_hp_bsnap="85373"
define v_hp_esnap="85426"

SELECT *
FROM (
SELECT ROWNUM AS rnum, v.*
FROM (
SELECT --count(*)
       --all_samples.sample_id AS sample_id,
       all_samples.sample_time AS sample_time,
       --sql_stat.sql_exec_id,
       Round(Avg(sql_stat.ela_time),2) AS ela_time
FROM (
SELECT Min(t.sample_id) AS sample_id, t.sql_exec_id, To_Number(REPLACE(regexp_substr( to_char(max(t.sample_time-t.sql_exec_start)),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='&&v_sql_id'
GROUP BY t.sql_exec_id
--ORDER BY sample_id asc
 ) sql_stat,
(SELECT DISTINCT t.sample_id, Trunc(t.sample_time,'mi') AS sample_time
 FROM sys.wrh$_active_session_history t
 WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
 --ORDER BY t.sample_id desc
 ) all_samples
WHERE all_samples.sample_id=sql_stat.sample_id(+)
GROUP BY all_samples.sample_time
ORDER BY all_samples.sample_time ASC ) v
 ) v1
 WHERE 1=1
   AND Mod(v1.rnum,2)=0
   --AND ela_time>2.12
;
define v_sql_id="b15qzy3zcya49"
SELECT  Count(*) AS executions,
        Min(ela_time) AS min_elatime,
        percentile_disc(0.25) within group (order by ela_time) as q25,
        percentile_disc(0.5) within group  (order by ela_time) as q50,
        percentile_disc(0.75) within group (order by ela_time) as q75,
        percentile_disc(0.85) within group (order by ela_time) as q85,
        percentile_disc(0.95) within group (order by ela_time) as q95,
        Max(ela_time) AS max_value
FROM (
SELECT t.sql_exec_id,
       To_Number(REPLACE(regexp_substr( to_char(max(t.sample_time-t.sql_exec_start)),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='&&v_sql_id'
GROUP BY t.session_id, t.session_serial#, t.sql_exec_id )
;

SELECT *
FROM SYSTEM.ash_sql_stat t
WHERE t.sql_id='&&v_sql_id'
  --AND t.sql_exec_id=16777216
  --AND t.sample_id=308416621
  --AND t.session_id=2247 and t.session_serial#=56805
ORDER BY t.sample_id asc
;

SELECT  Min(t.sample_id) AS start_sample_id,
        Count(*) AS samples,
        t.sql_exec_id,
        To_Number(REPLACE(regexp_substr( to_char(max(t.sample_time-t.sql_exec_start)),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
FROM SYSTEM.ash_sql_stat t
WHERE 1=1
  AND t.sql_id='&&v_sql_id'
GROUP BY t.session_id, t.session_serial#, t.sql_exec_id
--ORDER BY ela_time asc
ORDER BY start_sample_id asc
;

DROP TABLE SYSTEM.ash_sql_stat;
CREATE TABLE SYSTEM.ash_sql_stat TABLESPACE excellent AS
SELECT t.*
FROM sys.wrh$_active_session_history t
WHERE t.sql_id IN ('348pxp291v7px','2bjpjcm0duxk0','7khzbp8z1nb8n','88k25tpzqs1nv','2wd21hxbxab3a','5krrgrhqqmchg','dgh6fx9hu7xkv','byz87b8067gpx','ak22pnb77hrdy','5yah3vfnjjvwz')
;
----------------------------------------------------------------------------------------------------------------
SELECT --DISTINCT t.top_level_sql_id
       t.*
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.snap_id not BETWEEN &&v_hp_bsnap AND &&v_hp_esnap
  AND t.session_type=1 --FOREGROUD
  AND regexp_like(Lower(t.machine),'www[0-9]')
--ORDER BY t.sample_id asc
;

WITH top_level_sqls AS (SELECT --DISTINCT t.top_level_sql_id AS top_level_sql_id
                               DISTINCT t.sql_id AS top_level_sql_id
                        FROM sys.wrh$_active_session_history t
                        WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
                          AND t.session_type=1 --FOREGROUD
                          AND regexp_like(Lower(t.machine),'www[0-9]')
                       )
SELECT  v.sql_id AS sql_id,
                 Count(*) AS executions,
                 percentile_disc(0.5) within group  (order by v.ela_time) as q50
                 FROM ( SELECT t1.sql_id AS sql_id,
                               Min(t1.sample_id) AS sample_id,
                               t1.sql_exec_id,
                               To_Number(REPLACE(regexp_substr( to_char(max(t1.sample_time-t1.sql_exec_start)),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
                        FROM sys.wrh$_active_session_history t1
                        WHERE t1.dbid=&&v_dbid AND t1.snap_id NOT BETWEEN &&v_hp_bsnap AND &&v_hp_esnap
                          AND t1.sql_id IN (SELECT top_level_sql_id FROM top_level_sqls)
                        GROUP BY t1.sql_id, t1.sql_exec_id ) v
                 GROUP BY v.sql_id
;

WITH top_level_sqls AS (SELECT --DISTINCT t.top_level_sql_id AS top_level_sql_id
                                DISTINCT t.sql_id AS top_level_sql_id
                        FROM sys.wrh$_active_session_history t
                        WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
                          AND t.session_type=1 --FOREGROUD
                          AND regexp_like(Lower(t.machine),'www[0-9]')
                       ),
     hl_period AS (SELECT  v.sql_id AS sql_id,
                 Count(*) AS executions,
                 percentile_disc(0.5) within group  (order by v.ela_time) as q50
                 FROM ( SELECT t1.sql_id AS sql_id,
                               Min(t1.sample_id) AS sample_id,
                               t1.sql_exec_id,
                               To_Number(REPLACE(regexp_substr( to_char(max(t1.sample_time-t1.sql_exec_start)),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
                        FROM sys.wrh$_active_session_history t1
                        WHERE t1.dbid=&&v_dbid AND t1.snap_id BETWEEN &&v_hp_bsnap AND &&v_hp_esnap
                          AND t1.sql_id IN (SELECT top_level_sql_id FROM top_level_sqls)
                        GROUP BY t1.sql_id, t1.sql_exec_id ) v
                 GROUP BY v.sql_id ),
   nohl_period AS (SELECT  v.sql_id AS sql_id,
                 Count(*) AS executions,
                 percentile_disc(0.5) within group  (order by v.ela_time) as q50
                 FROM ( SELECT t1.sql_id AS sql_id,
                               Min(t1.sample_id) AS sample_id,
                               t1.sql_exec_id,
                               To_Number(REPLACE(regexp_substr( to_char(max(t1.sample_time-t1.sql_exec_start)),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
                        FROM sys.wrh$_active_session_history t1
                        WHERE t1.dbid=&&v_dbid AND t1.snap_id NOT BETWEEN &&v_hp_bsnap AND &&v_hp_esnap
                          AND t1.sql_id IN (SELECT top_level_sql_id FROM top_level_sqls)
                        GROUP BY t1.sql_id, t1.sql_exec_id ) v
                 GROUP BY v.sql_id )
SELECT hl_period.sql_id AS sql_id,
       nohl_period.executions AS nohl_executions,
       nohl_period.q50 AS nohl_q50,
       hl_period.executions AS hl_executions,
       hl_period.q50 AS hl_q50,
       CASE
       WHEN nohl_period.q50<hl_period.q50 THEN hl_period.q50-nohl_period.q50
       ELSE 0
       END delta
FROM nohl_period, hl_period
WHERE hl_period.sql_id=nohl_period.sql_id
ORDER BY DELTA DESC nulls last
;



SELECT v.sql_id, Count(v.sql_exec_id) AS exec_count,
                 Sum(v.ela_time) AS total_elatime,
                 Min(v.ela_time) AS min_elatime,
                 percentile_disc(0.25) within group (order by v.ela_time) as q25,
                 percentile_disc(0.5) within group  (order by v.ela_time) as q50,
                 percentile_disc(0.75) within group (order by v.ela_time) as q75,
                 Max(v.ela_time) AS max_value
FROM (
SELECT t.sql_id, t.sql_exec_id, To_Number(REPLACE(regexp_substr( to_char(max(t.sample_time-t.sql_exec_start)),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  --AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.sql_id='0ttnwxyust0cv'
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
GROUP BY t.sql_id, t.sql_exec_id
ORDER BY t.sql_id, t.sql_exec_id ) v
 GROUP BY v.sql_id
 ORDER BY total_elatime desc
;

SELECT Min(ela_time) AS min_value,
       percentile_disc(0.25) within group (order by ela_time) as q25,
       percentile_disc(0.5) within group (order by ela_time) as q50,
       percentile_disc(0.75) within group (order by ela_time) as q75,
       Max(ela_time) AS max_value
FROM (
SELECT t.sql_exec_id, max(t.sample_time-t.sql_exec_start) AS ela_time
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='0ttnwxyust0cv'
GROUP BY t.sql_exec_id
ORDER BY ela_time )
;

SELECT sql_id, Sum(ela_time) AS ela_time, Sum(cnt) AS cnt
FROM (
SELECT sql_id, To_Number(REPLACE(regexp_substr( to_char(delta),'[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{2}'),':',''),'999999.99') AS ela_time, cnt
FROM (
SELECT t.sql_id, t.sql_exec_id, max(t.sample_time)-Min(t.sql_exec_start) AS DELTA, Count(*) AS cnt
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.top_level_sql_id='5mz15ym294fjn'
  AND t.sql_id IS NOT NULL
  AND t.sql_exec_id IS NOT null
GROUP BY t.sql_id, t.sql_exec_id
--ORDER by t.sql_id, t.sql_exec_id
 )
  )
GROUP BY sql_id
ORDER BY 2 desc
;

SELECT *
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.sql_id='5pw0j39fw03q2'
  AND t.sql_exec_id IN (17811078,17813598,17814141,17815193,17817414,17819547)
;

------------------------------------------------------------------------------------------------------------------------
define v_dbid=3433988060
define v_bsnap=45278
define v_esnap=45290
define sql_sess_sid=616
define sql_sess_serial=196

SELECT Count(*)
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
;

SELECT DISTINCT Nvl(t.top_level_sql_id,'none') AS top_level_sql_id
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
;

SELECT *
FROM sys.dba_hist_active_sess_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  --AND t.top_level_sql_id='2pp20zcx8f2xw'
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
;

SELECT --*
       DISTINCT top_level_sql_id
FROM (
SELECT sample_time, cnt, top_level_sql_id,
       Row_Number() OVER (PARTITION BY sample_time ORDER BY cnt desc) AS rnum
FROM (
SELECT Trunc(t.sample_time,'MI') AS sample_time, Count(*) AS cnt, Nvl(t.top_level_sql_id,'none') AS top_level_sql_id
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY Trunc(t.sample_time,'MI'), Nvl(t.top_level_sql_id,'none')
ORDER BY Trunc(t.sample_time,'MI') ASC
)
 )
 WHERE rnum<=3
;


SELECT *
FROM (
SELECT sample_time, cnt, top_level_sql_id
FROM (
SELECT sample_time, cnt, top_level_sql_id,
       Row_Number() OVER (PARTITION BY sample_time ORDER BY cnt desc) AS rnum
FROM (
SELECT Trunc(t.sample_time,'MI') AS sample_time, Count(*) AS cnt, Nvl(t.top_level_sql_id,'none') AS top_level_sql_id
FROM sys.dba_hist_active_sess_history t
WHERE 1=1 --t.session_type='FOREGROUND'
  AND t.dbid=&&v_dbid
  AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
GROUP BY Trunc(t.sample_time,'MI'), Nvl(t.top_level_sql_id,'none')
ORDER BY Trunc(t.sample_time,'MI') ASC
)
 )
 WHERE rnum<=3
  )
  pivot (
   Max(cnt) FOR top_level_sql_id in (
'00kx682nxma6u' as q1,
'04qrx0q3f3mmv' as q2,
'05mfjfad0ddrg' as q3,
'0796kh7mwxm5n' as q4,
'07ft235twbsfc' as q5,
'09b7spc085k44' as q6,
'0b5jkf1n5135z' as q7,
'0b863nr0n1rrc' as q8,
'0hj47fhdm2r63' as q9,
'0jstg1ft1r63a' as q10,
'0szw3y4k6s78x' as q11,
'13ww38q1uvvum' as q12,
'15d334p7wvpvr' as q13,
'19xbm3bjthnst' as q14,
'1m5jf0uv1xnnm' as q15,
'1q3mzmq9sdhqw' as q16,
'1rrj8bkwdgwbs' as q17,
'1s23215vxp6r2' as q18,
'1x9y6hw0chuqz' as q19,
'22m99pj5k8v64' as q20,
'23b4xg4vcj56z' as q21,
'24ks93kh75agm' as q22,
'2gtk1nzx9sfnn' as q23,
'2jxf9ntszazsy' as q24,
'2ntd18dt07kmh' as q25,
'2tb8jk2dncng0' as q26,
'2u3bpb1vxww4q' as q27,
'2zh7hj5p36f5w' as q28,
'313w9f91j7g06' as q29,
'37twkqgvwu20w' as q30,
'391jczcaa3mp8' as q31,
'3cvxqjh9uf0n6' as q32,
'3gn4ax9umn23z' as q33,
'3upzzt96jg5t3' as q34,
'416usxj1y9zq3' as q35,
'41pzzb3zq0kds' as q36,
'47w1ha63gjnbb' as q37,
'4rarvjdjcdxnn' as q38,
'4rpvwp42439yb' as q39,
'4v0ng8ua592d7' as q40,
'4xqt5dnyyax4n' as q41,
'55swm3ss4shy9' as q42,
'56ctcppwjfjy1' as q43,
'58grks0y025yt' as q44,
'58q1u07xam20p' as q45,
'5gbqkctyydjdq' as q46,
'5n3mj7766yyqy' as q47,
'5npqv1m7suw2j' as q48,
'5tmmgkgk7h3dc' as q49,
'60ynwky3gy4p4' as q50,
'66gc7hh9qptc6' as q51,
'6d5vywpvamy51' as q52,
'6gwquz84wgw08' as q53,
'6pfdv6qmqdrrg' as q54,
'749qbg8zzhdx4' as q55,
'79r9bf159g8qr' as q56,
'79vqcsw851rkq' as q57,
'7dp1ga2gshft2' as q58,
'7tdrpvpfr99kz' as q59,
'7tw0ukt81c3z1' as q60,
'7yfr2myg9h1cf' as q61,
'8a6g97w9zumww' as q62,
'8drqxjnqnz0dz' as q63,
'8gkcsxj531281' as q64,
'92k69a6xgdsw1' as q65,
'97avjw12qm5rs' as q66,
'9amh1s66v1528' as q67,
'9wrjwdnm9588z' as q68,
'9y8hk652kytf8' as q69,
'a1pxpmutkpjn3' as q70,
'a3t73uaw2u3tx' as q71,
'a41n5t7207vab' as q72,
'a7819gna2zxuh' as q73,
'a8y4b30t903xs' as q74,
'afxwhwjpkptkw' as q75,
'aht04f2c1x31j' as q76,
'atdrqp45v2703' as q77,
'au99vzdsztryc' as q78,
'avuu4h1s36qt4' as q79,
'b2z1yvd7qrjzj' as q80,
'b4kdd6ngm22mx' as q81,
'bjph3g04hd2s0' as q82,
'bqg3d97h4v43j' as q83,
'bv920psqmvd14' as q84,
'c7vyvq8u8583b' as q85,
'cjnspdf22ubzz' as q86,
'cud4tyusc60g5' as q87,
'cy26mp5xgvb13' as q88,
'd037ssj61k89u' as q89,
'd3903cvapw1tf' as q90,
'd5k0f9dnur9xb' as q91,
'dbs2ztg8mm71h' as q92,
'ddgmaxqm0rmr4' as q93,
'dfvyx1mu8bvh0' as q94,
'dj42b6nqadzs5' as q95,
'dkf31s8h3kkym' as q96,
'dr2tf4unbhr82' as q97,
'dt166vpjur6uu' as q98,
'f77x5pvt3xp1x' as q99,
'fgt83mt6z4ct9' as q100,
'fh55dcx85jkdp' as q101,
'fhpksrqag2j5h' as q102,
'fmb6hhuzc251m' as q103,
'fquua34tvp2y4' as q104,
'fvuu22dz9n9z1' as q105,
'fy0wfvy03wnr2' as q106,
'fy3fk0dxrrq73' as q107,
'fy63trxj618y9' as q108,
'g3kdvpkc65y9p' as q109,
'g7knq49dpm4ts' as q110,
'g84vxx4ju3uc9' as q111,
'g9dprqdfcrmrk' as q112,
'gaacsqgvbxpz8' as q113,
'gku5qksmrd633' as q114,
'gmjbz9x1gxm8p' as q115,
'gpac0nvx6z3t6' as q116,
'gz9u14xusp1rr' as q117,
'none' as q118
    )
  )

;
