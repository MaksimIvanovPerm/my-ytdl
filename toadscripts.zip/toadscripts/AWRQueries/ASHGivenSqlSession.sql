-- 19/04/2016
define v_bsnap=48074
define v_esnap=48097
define sql_sess_sid=529
define sql_sess_serial=61833


SELECT Count(*), t.session_id||','||t.session_serial#
FROM sys.wrh$_active_session_history t
WHERE t.session_type=1
  AND t.MODULE LIKE 'dwh_charges_support%'
  AND regexp_like(program,'sqlplus@db[0-9]+ .*')
  AND t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN  &&v_bsnap and &&v_esnap
GROUP BY t.session_id||','||t.session_serial#
ORDER BY 1 desc;

SELECT t.*
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN  &&v_bsnap and &&v_esnap
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
ORDER BY t.sample_id
;

SELECT t.event_id, Sum(t.time_waited) AS time_waited, Count(*)
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN  &&v_bsnap and &&v_esnap
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
GROUP BY t.event_id
ORDER BY time_waited desc
;

SELECT * FROM v$event_name WHERE event_id IN (2652584166,506183215,861319509)
;

SELECT t.sql_exec_id, --t.sql_exec_start, t.sample_time, t.sample_time-t.sql_exec_start AS delta
       Max(t.sample_time-t.sql_exec_start) AS ela_time
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN  &&v_bsnap and &&v_esnap
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
GROUP BY t.sql_exec_id
ORDER BY ela_time desc
;

SELECT t.*
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN  &&v_bsnap and &&v_esnap
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  AND t.sql_exec_id=16777224
ORDER BY t.sample_id
;

-- 33nvhyjsthp0k

SELECT t.*
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid  AND t.instance_number=1 AND t.snap_id BETWEEN  &&v_bsnap and &&v_esnap
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  AND t.sql_id='33nvhyjsthp0k'
ORDER BY t.sample_id
;

SELECT *
FROM v$event_name t
WHERE --t.name LIKE '%latch%'
      t.event_id=2900469894
ORDER BY t.name
;

SELECT *
FROM sys.wrh$_active_session_history t
WHERE t.sql_id='7nv1kfms0xybp'
;

SELECT *
FROM sys.v_$active_session_history t
WHERE t.sql_id='7nv1kfms0xybp'
;
