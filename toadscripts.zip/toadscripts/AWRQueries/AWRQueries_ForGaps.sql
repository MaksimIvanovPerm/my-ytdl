select *
from WRM$_DATABASE_INSTANCE t
where T.dbid=&&v_dbid
ORDER BY t.STARTUP_TIME DESC
;
-- ALTER SESSION SET nls_date_format='yyyy.mm.dd hh24:mi:ss';
SET define off
ALTER SESSION SET current_schema=AWR12C;
define awr_schema="AWR12C"

ALTER SESSION SET current_schema=SYS;
define awr_schema="SYS"
define awr_schema="awr_publisher"

SELECT --*
dbid
from sys.v_$database;

SELECT * FROM sys.v_$version;

SELECT sysdate, t.* FROM sys.v_$instance t;

SELECT * FROM sys.V_$CONTROLFILE_RECORD_SECTION;

define v_dbid=3220346047
define v_bsnap=85881
define v_esnap=86457
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ', ';
ALTER SESSION SET nls_date_format='yyyy.mm.dd hh24:mi:ss';


select cast(s.begin_interval_time AS TIMESTAMP(0)) AS snap_time,
       substr(extract(day from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')) * 24 * 60 * 60 +
       extract(hour from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')) * 60 * 60 +
       extract(minute from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')) * 60 +
       trunc(extract(second from (s.begin_interval_time - timestamp '1970-01-01 00:00:00')),0),0,15) as snap_timestamp,
       s.snap_id
from SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
  AND s.snap_id between &&v_bsnap and &&v_esnap
  --AND s.begin_interval_time>SYSDATE-15
order by s.snap_id asc;

select --Trunc(s.begin_interval_time,'HH24') AS snap_time, snap_id
       --To_Char(s.begin_interval_time,'yyyy-mm-dd_hh24:mi') AS DATETIME
       --s.begin_interval_time, s.begin_interval_time-3/24
       --Min(s.begin_interval_time)
       *
       --Min(s.snap_id), Max(s.snap_id)
       --s.snap_id, s.begin_interval_time, extract(minute from (s.begin_interval_time)) AS minutes
from SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
--and s.BEGIN_INTERVAL_TIME>=To_Date('01.06.2015 00:00:00','dd.mm.yyyy hh24:mi:ss')
  --AND s.flush_elapsed IS NOT NULL
  --AND s.snap_timezone IS NOT NULL
  --s.snap_id=356
  --AND extract(minute from (s.begin_interval_time)) > 10
order by s.snap_id asc;

select Min(s.snap_id) AS bsnap_id, Max(s.snap_id) AS esnap_id, extract(hour from (s.begin_interval_time)) AS hh24,
       'exec DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE('||Min(s.snap_id)||', '||Max(s.snap_id)||', &&v_dbid);' AS cmd
from SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
  AND extract(minute from (s.begin_interval_time)) > 10
GROUP BY extract (hour from (s.begin_interval_time))
--order by s.snap_id ASC
;

select --s.snap_id,
       'exec DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE('||s.snap_id||', '||s.snap_id||', &&v_dbid);' AS cmd
from SYS.WRM$_SNAPSHOT s
where s.dbid=&&v_dbid --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
  AND extract(minute from (s.begin_interval_time)) > 10
order by s.snap_id ASC
;

SELECT *
FROM sys.wrm$_snap_error t
;

/*
exec DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE(&&v_bsnap,&&v_esnap,&&v_dbid);
commit;
EXECUTE DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS( interval  =>  10);
EXECUTE DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS( interval  =>  60, retention => (14*24*60));
EXECUTE DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS( interval  =>  10, retention => (7*24*60));
commit;
exec DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();
*/
EXEC DBMS_WORKLOAD_REPOSITORY.modify_baseline_window_size(window_size =>7);
SELECT * FROM DBA_HIST_BASELINE WHERE BASELINE_NAME='SYSTEM_MOVING_WINDOW';

set pagesize 0
set linesize 128
select OCCUPANT_NAME||' '||OCCUPANT_DESC||' '||SCHEMA_NAME||' '||MOVE_PROCEDURE||' '||MOVE_PROCEDURE_DESC||' '||SPACE_USAGE_KBYTES from V$SYSAUX_OCCUPANTS order by SPACE_USAGE_KBYTES;

SELECT *
       --t.snap_interval, t.retention
FROM sys.dba_hist_wr_control t
WHERE t.dbid=&&v_dbid
;

-- select * from sys.wrm$_wr_control;
-- fsm_444 13915 10-min snaps

SELECT * FROM PRODUCT_COMPONENT_VERSION;

SELECT *
FROM V$SYSAUX_OCCUPANTS t
ORDER BY t.space_usage_kbytes desc
;

/*
-- Usage and Storage Management of SYSAUX tablespace occupants SM/AWR, SM/ADVISOR, SM/OPTSTAT and SM/OTHER (Doc ID 329984.1)
select dbms_stats.get_stats_history_retention from dual;
exec dbms_stats.alter_stats_history_retention(7);
exec dbms_stats.purge_stats(CURRENT_TIMESTAMP);
*/

--@?/rdbms/admin/awrinfo.sql

-- truncate table WRH$_SYSMETRIC_SUMMARY drop storage;
-- truncate table WRH$_WAITCLASSMETRIC_HISTORY drop storage;
-- truncate table WRH$_SYSMETRIC_HISTORY drop storage;
-- truncate table WRH$_STREAMS_POOL_ADVICE drop storage;
-- truncate table WRH$_SGA_TARGET_ADVICE drop storage;
-- truncate table WRH$_JAVA_POOL_ADVICE drop storage;
-- truncate table WRH$_PGA_TARGET_ADVICE drop storage;
-- truncate table WRH$_RSRC_CONSUMER_GROUP drop storage;
-- eqmmon only
-- truncate table SYS.WRH$_SQL_PLAN drop storage;
-- truncate table SYS.WRH$_LATCH drop storage;

select *
from WRM$_DATABASE_INSTANCE t
--where T.dbid=&&v_dbid
--ORDER BY t.STARTUP_TIME DESC
;


SELECT --t.retention||' '||t.snap_interval AS col
       t.*
FROM sys.DBA_HIST_WR_CONTROL t
WHERE t.dbid=(SELECT dbid FROM v$database)
;

-- rdbms service time
SELECT *
FROM (
WITH snaps AS (SELECT s.dbid AS dbid, s.instance_number, s.begin_interval_time,
       s.snap_id AS snap_id
       ,Lag(s.snap_id,1,null) OVER( ORDER BY s.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot s
WHERE s.dbid=&&v_dbid AND s.snap_id between &&v_bsnap and &&v_esnap
ORDER BY s.snap_id ASC ),
e AS (SELECT Sn.BEGIN_INTERVAL_TIME as snap_time, st.snap_id as snap_id, TMN.STAT_NAME as stat_name, ST.VALUE as stat_value, sn.prev_snap_id
FROM snaps sn, sys.WRH$_SYS_TIME_MODEL st, sys.WRH$_STAT_NAME tmn
where ST.STAT_ID=TMN.STAT_ID AND tmn.dbid=&&v_dbid  --AND tmn.stat_name='DB time'
  and Sn.snap_id=st.snap_id AND st.instance_number=sn.instance_number AND sn.dbid=st.dbid),
b AS (SELECT Sn.BEGIN_INTERVAL_TIME as snap_time, st.snap_id as snap_id, TMN.STAT_NAME as stat_name, ST.VALUE as stat_value
FROM snaps sn, sys.WRH$_SYS_TIME_MODEL st, sys.WRH$_STAT_NAME tmn
where ST.STAT_ID=TMN.STAT_ID AND tmn.dbid=&&v_dbid  --AND tmn.stat_name='DB time'
  and Sn.prev_snap_id=st.snap_id AND st.instance_number=sn.instance_number AND sn.dbid=st.dbid)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
WHERE e.prev_snap_id=b.snap_id
  and e.stat_name=b.stat_name
order by e.snap_id )
pivot (
max(value_diff)
for stat_name in ('DB time' as db_time,'DB CPU' as db_cpu,
      'background elapsed time' as bgrnd_el_tm,
      'background cpu time' AS bgrnd_cpu_tm,
      'sequence load elapsed time' as seq_load_el_tm,
      'parse time elapsed' as parse_el_tm,
      'hard parse elapsed time' as  hard_parse_el_tm,
      'sql execute elapsed time' as sql_exec_el_tm,
      'connection management call elapsed time' as conn_mgmnt_call_el_tm,
      'failed parse elapsed time' as failed_parse_el_tm,
      'failed parse (out of shared memory) elapsed time' AS fail_parse_outofshmem_el_tm,
      'hard parse (sharing criteria) elapsed time' as hrd_parse_sharing_crit_el_tm,
      'hard parse (bind mismatch) elapsed time' as hrd_prs_bing_mismtch_el_tm,
      'PL/SQL execution elapsed time' as plsql_exec_el_tm,
      'inbound PL/SQL rpc elapsed time' as inbnd_plsql_rpc_el_tm,
      'PL/SQL compilation elapsed time' as plsql_compile_el_tm,
      'Java execution elapsed time' as java_exec_el_tm,
      'repeated bind elapsed time' as repeat_bind_el_tm,
      'RMAN cpu time (backup/restore)' as rman_bcp_rstr_cpu_tm,
      'scheduler wait time' AS sched_wait_time
      )
)
where db_time is not null
order by snap_id;



SELECT *
FROM WRM$_SNAPSHOT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 --and S.SNAP_ID between &&v_bsnap and &&v_esnap
ORDER BY s.snap_id;

SELECT *
FROM WRH$_SYSTEM_EVENT s
WHERE s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
ORDER BY s.snap_id;

-- Wait time by wait cl�sses
select snap_time, snap_id, Concurrency, UserIO, SystemIO, Administrative, Other, Scheduler, Configuration, "Cluster", Application, Queueing, Network, Commit
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select S.BEGIN_INTERVAL_TIME as snap_time,
                      S.SNAP_ID as snap_id,
                      en.WAIT_CLASS as stat_name,
                      sum(SE.TIME_WAITED_MICRO) as stat_value
              from snaps s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
              where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
                    and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
                    and SE.EVENT_ID=EN.EVENT_ID and SE.DBID=EN.DBID
              group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.WAIT_CLASS
             ),
b as (select S.BEGIN_INTERVAL_TIME as snap_time,
                      S.SNAP_ID as snap_id,
                      en.WAIT_CLASS as stat_name,
                      sum(SE.TIME_WAITED_MICRO) as stat_value
              from snaps s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
              where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
                    and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.prev_snap_id=se.snap_id
                    and SE.EVENT_ID=EN.EVENT_ID and SE.DBID=EN.DBID
              group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.WAIT_CLASS
             )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'Concurrency' as Concurrency,
'User I/O' as UserIO,
'System I/O' as SystemIO,
'Administrative' as Administrative,
'Other' as Other,
'Scheduler' as Scheduler,
'Configuration' as Configuration,
'Cluster' as "Cluster",
'Application' as Application,
'Idle' as Idle,
'Queueing' as Queueing,
'Network' as Network,
'Commit' as Commit
)
    )
order by snap_id;

-- System IO
select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='System I/O'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME ),
b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, WRH$_SYSTEM_EVENT se, WRH$_EVENT_NAME en
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.prev_snap_id=se.snap_id
  AND en.DBID=se.DBID AND en.EVENT_ID=se.EVENT_ID AND en.WAIT_CLASS='System I/O'
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'Clonedb bitmap file write' as Clonedbbitmapfilewrite,
'Log archive I/O' as LogarchiveIO,
'RMAN backup & recovery I/O' as RMANbackupRecoveryIO,
'Standby redo I/O' as StandbyredoIO,
'Network file transfer' as Networkfiletransfer,
'io done' as iodone,
'RMAN Disk slave I/O' as RMANDiskslaveIO,
'RMAN Tape slave I/O' as RMANTapeslaveIO,
'DBWR slave I/O' as DBWRslaveIO,
'LGWR slave I/O' as LGWRslaveIO,
'Archiver slave I/O' as ArchiverslaveIO,
'control file sequential read' as controlfilesequentialread,
'control file single write' as controlfilesinglewrite,
'control file parallel write' as controlfileparallelwrite,
'recovery read' as recoveryread,
'RFS sequential i/o' as RFSsequentialio,
'RFS random i/o' as RFSrandomio,
'RFS write' as RFSwrite,
'log file sequential read' as logfilesequentialread,
'log file single write' as logfilesinglewrite,
'log file parallel write' as logfileparallelwrite,
'db file parallel write' as dbfileparallelwrite,
'db file async I/O submit' as dbfileasyncIOsubmit,
'flashback log file write' as flashbacklogfilewrite,
'flashback log file read' as flashbacklogfileread,
'cell smart incremental backup' as cellsmartincrementalbackup,
'cell smart restore from backup' as cellsmartrestorefrombackup,
'kfk: async disk IO' as kfkasyncdiskIO,
'cell manager opening cell' as cellmanageropeningcell,
'cell manager closing cell' as cellmanagerclosingcell,
'cell manager discovering disks' as cellmanagerdiscoveringdisks
)
    )
order by snap_id;

-- Commit waits
select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'remote log force - commit','log file sync','nologging standby txn commit','enq: BB - 2PC across RAC instances' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.prev_snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'remote log force - commit','log file sync','nologging standby txn commit','enq: BB - 2PC across RAC instances' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'remote log force - commit' AS rem_log_force_cmt,
'log file sync' AS log_file_sync,
'nologging standby txn commit' AS nologg_stb_txn_cmt,
'enq: BB - 2PC across RAC instances' AS enq_BB_2PC_acr
    )
     )
order by snap_id;

-- UserIO Wait time structure
select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'Parameter File I/O','Disk file operations I/O','Disk file I/O Calibration','Disk file Mirror Read','Disk file Mirror/Media Repair Write','direct path sync','Datapump dump file I/O','dbms_file_transfer I/O','DG Broker configuration file I/O','Data file init write','Log file init write','Pluggable Database file copy','File Copy','Shared IO Pool IO Completion','local write wait','buffer read retry','read by other session','db flash cache single block physical read','db flash cache multiblock physical read','db flash cache write','db file sequential read','db file scattered read','db file single write','db file parallel read','direct path read','direct path read temp','direct path write','direct path write temp','flashback log file sync','cell smart table scan','cell smart index scan','cell external table smart scan','cell statistics gather','cell smart file creation','Archive Manager file transfer I/O','securefile direct-read completion','securefile direct-write completion','BFILE read','utl_file I/O','external table read','external table write','external table open','external table seek','external table misc IO','dbverify reads','TEXT: File System I/O','ASM sync cache disk read','ASM Fixed Package I/O','ASM Staleness File I/O','cell single block physical read','cell multiblock physical read','cell list of blocks physical read','cell physical read no I/O','cell single block read request','cell multiblock read request','cell list of blocks read request' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as ( select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.prev_snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'Parameter File I/O','Disk file operations I/O','Disk file I/O Calibration','Disk file Mirror Read','Disk file Mirror/Media Repair Write','direct path sync','Datapump dump file I/O','dbms_file_transfer I/O','DG Broker configuration file I/O','Data file init write','Log file init write','Pluggable Database file copy','File Copy','Shared IO Pool IO Completion','local write wait','buffer read retry','read by other session','db flash cache single block physical read','db flash cache multiblock physical read','db flash cache write','db file sequential read','db file scattered read','db file single write','db file parallel read','direct path read','direct path read temp','direct path write','direct path write temp','flashback log file sync','cell smart table scan','cell smart index scan','cell external table smart scan','cell statistics gather','cell smart file creation','Archive Manager file transfer I/O','securefile direct-read completion','securefile direct-write completion','BFILE read','utl_file I/O','external table read','external table write','external table open','external table seek','external table misc IO','dbverify reads','TEXT: File System I/O','ASM sync cache disk read','ASM Fixed Package I/O','ASM Staleness File I/O','cell single block physical read','cell multiblock physical read','cell list of blocks physical read','cell physical read no I/O','cell single block read request','cell multiblock read request','cell list of blocks read request' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME )
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id  and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'Parameter File I/O' as ParameterFileIO,
'Disk file operations I/O' as DiskfileoperationsIO,
'Disk file I/O Calibration' as DiskfileIOCalibration,
'Disk file Mirror Read' as DiskfileMirrorRead,
'Disk file Mirror/Media Repair Write' as DiskfileMirrorMediaRepairWrite,
'direct path sync' as directpathsync,
'Datapump dump file I/O' as DatapumpdumpfileIO,
'dbms_file_transfer I/O' as dbms_file_transferIO,
'DG Broker configuration file I/O' as DGBrokerconfigurationfileIO,
'Data file init write' as Datafileinitwrite,
'Log file init write' as Logfileinitwrite,
'Pluggable Database file copy' as PluggableDatabasefilecopy,
'File Copy' as FileCopy,
'Shared IO Pool IO Completion' as SharedIOPoolIOCompletion,
'local write wait' as localwritewait,
'buffer read retry' as bufferreadretry,
'read by other session' as readbyothersession,
'db flash cache single block physical read' as dbflashcacheSblckphysread,
'db flash cache multiblock physical read' as dbflashcacheMblckphysread,
'db flash cache write' as dbflashcachewrite,
'db file sequential read' as dbfilesequentialread,
'db file scattered read' as dbfilescatteredread,
'db file single write' as dbfilesinglewrite,
'db file parallel read' as dbfileparallelread,
'direct path read' as directpathread,
'direct path read temp' as directpathreadtemp,
'direct path write' as directpathwrite,
'direct path write temp' as directpathwritetemp,
'flashback log file sync' as flashbacklogfilesync,
'cell smart table scan' as cellsmarttablescan,
'cell smart index scan' as cellsmartindexscan,
'cell external table smart scan' as cellexternaltablesmartscan,
'cell statistics gather' as cellstatisticWRH_ther,
'cell smart file creation' as cellsmartfilecreation,
'Archive Manager file transfer I/O' as ArchiveManagerfiletransferIO,
'securefile direct-read completion' as ScrfileDrct_rdcompletion,
'securefile direct-write completion' as ScrfileDrct_wrcompletion,
'BFILE read' as BFILEread,
'utl_file I/O' as utl_fileIO,
'external table read' as externaltableread,
'external table write' as externaltablewrite,
'external table open' as externaltableopen,
'external table seek' as externaltableseek,
'external table misc IO' as externaltablemiscIO,
'dbverify reads' as dbverifyreads,
'TEXT: File System I/O' as TEXT_FileSystemIO,
'ASM sync cache disk read' as ASMsynccachediskread,
'ASM Fixed Package I/O' as ASMFixedPackageIO,
'ASM Staleness File I/O' as ASMStalenessFileIO,
'cell single block physical read' as cellsingleblockphysicalread,
'cell multiblock physical read' as cellmultiblockphysicalread,
'cell list of blocks physical read' as celllistofblocksphysicalread,
'cell physical read no I/O' as cellphysicalreadnoIO,
'cell single block read request' as cellsingleblockreadrequest,
'cell multiblock read request' as cellmultiblockreadrequest,
'cell list of blocks read request' as celllistofblocksreadrequest
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Application class
select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'enq: PW - flush prewarm buffers','enq: RO - contention','enq: RO - fast object reuse','enq: KO - fast object checkpoint','enq: TM - contention','enq: TX - row lock contention','Wait for Table Lock','enq: RC - Result Cache: Contention','Streams capture: filter callback waiting for ruleset','Streams: apply reader waiting for DDL to apply','SQL*Net break/reset to client','SQL*Net break/reset to dblink','External Procedure initial connection','External Procedure call','enq: UL - contention','OLAP DML Sleep','WCR: replay lock order' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.prev_snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'enq: PW - flush prewarm buffers','enq: RO - contention','enq: RO - fast object reuse','enq: KO - fast object checkpoint','enq: TM - contention','enq: TX - row lock contention','Wait for Table Lock','enq: RC - Result Cache: Contention','Streams capture: filter callback waiting for ruleset','Streams: apply reader waiting for DDL to apply','SQL*Net break/reset to client','SQL*Net break/reset to dblink','External Procedure initial connection','External Procedure call','enq: UL - contention','OLAP DML Sleep','WCR: replay lock order' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'enq: PW - flush prewarm buffers' as enqPW_flush_prewarm_buffers,
'enq: RO - contention' as eqnRO_contention,
'enq: RO - fast object reuse' as eqnRO_fast_object_reuse,
'enq: KO - fast object checkpoint' as eqnKO_fast_object_checkpoint,
'enq: TM - contention' as eqnTM_contention,
'enq: TX - row lock contention' as eqnTX_row_lock_contention,
'Wait for Table Lock' as Wait_for_Table_Lock,
'enq: RC - Result Cache: Contention' as eqnRC_ResultCacheContention,
'Streams capture: filter callback waiting for ruleset' as StrmsCptrFltrCallbackWt4rlst,
'Streams: apply reader waiting for DDL to apply' as StreamsApplRdrW4DDL2apply,
'SQL*Net break/reset to client' as SQL_Net_break_reset_to_client,
'SQL*Net break/reset to dblink' as SQL_Net_break_reset_to_dblink,
'External Procedure initial connection' as ExtProcInitialConnection,
'External Procedure call' as External_Procedure_call,
'enq: UL - contention' as eqnUL___contention,
'OLAP DML Sleep' as OLAP_DML_Sleep,
'WCR: replay lock order' as WCR__replay_lock_order)
    )
order by snap_id;

--------------------------------------------------------------------------------

-- Configuration Wait time structure
select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME),
b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value
from snaps s, DBA_HIST_SYSTEM_EVENT se
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.prev_snap_id=se.snap_id
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in
(
'free buffer waits' as free_buffer_waits,
'checkpoint completed' as checkpoint_completed,
'write complete waits' as write_complete_waits,
'write complete waits: flash cache' as writeCompleteWaitsFlashCache,
'latch: redo writing' as latch__redo_writing,
'latch: redo copy' as latch__redo_copy,
'log buffer space' as log_buffer_space,
'log file switch (checkpoint incomplete)' as logFileSwitchChckptIncomplete_,
'log file switch (private strand flush incomplete)' as LFSwitchPrivStrandFlushIncmplt,
'log file switch (archiving needed)' as LFSwitchArchiving_needed,
'log file switch completion' as lfs_completion,
'flashback buf free by RVWR' as flashback_buf_free_by_RVWR,
'enq: ST - contention' as enqSTcontention,
'undo segment extension' as undo_segment_extension,
'undo segment tx slot' as undo_segment_tx_slot,
'enq: TX - allocate ITL entry' as enqTXallocate_ITL_entry,
'statement suspended, wait error to be cleared' as StmtSspnddWaitErrToBeCleared,
'enq: HW - contention' as enqHWcontention,
'enq: SS - contention' as enqSScontention,
'sort segment request' as sort_segment_request,
'enq: SQ - contention' as enqSQcontention,
'Global transaction acquire instance locks' as GlblTrnsAcquireInstanceLocks,
'Streams apply: waiting to commit' as StreamsApplyWaiting_to_commit,
'wait for EMON to process ntfns' as wait_for_EMON_to_process_ntfns
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Given statistics
SELECT *
       --''''||stat_name||''' as s'||ROWNUM||',' AS col
FROM SYS.WRH$_STAT_NAME sn
WHERE sn.dbid=&&v_dbid
  --AND sn.stat_id IN (1612053064,2146120386,3094453259,3455911385,45066233)
  AND sn.stat_name LIKE 'free buff%'
;

WITH DATA AS
(SELECT
'RowCR hits,redo write time,DBWR transaction table writes,prefetch clients - default'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as s'||ROWNUM||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;

select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select --S.BEGIN_INTERVAL_TIME as snap_time,
       To_Char(S.BEGIN_INTERVAL_TIME,'dd/mm.yyyy hh24:mi') AS snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from snaps s, sys.WRH$_SYSSTAT st, sys.WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'user I/O wait time','physical reads','physical reads cache','free buffer inspected','free buffer requested'
 )
),
b as ( select --S.BEGIN_INTERVAL_TIME as snap_time,
       To_Char(S.BEGIN_INTERVAL_TIME,'dd/mm.yyyy hh24:mi') AS snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from snaps s, sys.WRH$_SYSSTAT st, sys.WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.prev_snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'user I/O wait time','physical reads','physical reads cache','free buffer inspected','free buffer requested'
 )
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id+1 and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'user I/O wait time' AS user_io_wt,
'physical reads' AS phs_rd,
'physical reads cache' AS phs_rdc,
'free buffer inspected' AS fbi,
'free buffer requested' AS fbr
)
 )
order by snap_time;

-- Load profile
select  snap_time as snap_time,
        snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from snaps s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
),
b as ( select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from snaps s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.prev_snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  and S.SNAP_ID between &&v_bsnap and &&v_esnap )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
  ) v
pivot (
max(value_diff)
for stat_name in (
 'execute count' as executions,
 'logons cumulative' as logons,
 'sorts (memory)' as memory_sorts,
 'sorts (disk)' as disk_sorts,
 'parse count (hard)' as hard_parses,
 'parse count (total)' as parses,
 'user calls' as user_calls,
 'physical reads' as physical_reads,
 'physical writes' as physical_writes,
 'db block changes' as block_changes,
 'session logical reads' as logical_reads,
 'redo size' as redo_size,
 'user commits' as user_commit,
 'user rollbacks' as user_rollback)
 )
order by snap_id;

-- OSStat
select
v.snap_time as snap_time,
v.snap_id as snap_id,
v.NUM_CPUS as NUM_CPUS,
v.IDLE_TIME as IDLE_TIME,
v.BUSY_TIME as BUSY_TIME,
v.USER_TIME as USER_TIME,
v.SYS_TIME as SYS_TIME,
v.IOWAIT_TIME as IOWAIT_TIME,
v.NICE_TIME as NICE_TIME,
v.RSRC_MGR_CPU_WAIT_TIME as RSRC_MGR_CPU_WAIT_TIME,
v.LOAD as LOAD,
v.NUM_CPU_SOCKETS as NUM_CPU_SOCKETS,
v.PHYSICAL_MEMORY_BYTES as PHYSICAL_MEMORY_BYTES,
v.VM_IN_BYTES as VM_IN_BYTES,
v.VM_OUT_BYTES as VM_OUT_BYTES,
v.NUM_CPU_CORES AS NUM_CPU_CORES,
v.FREE_MEMORY_BYTES AS FREE_MEMORY_BYTES,
v.INACTIVE_MEMORY_BYTES AS INACTIVE_MEMORY_BYTES,
v.SWAP_FREE_BYTES AS SWAP_FREE_BYTES
from (
select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from snaps s, sys.WRH$_OSSTAT os, sys.WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID),
b as ( select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value
from snaps s, sys.WRH$_OSSTAT os, sys.WRH$_OSSTAT_NAME osn
where   S.dbid=&&v_dbid
    and S.SNAP_ID between &&v_bsnap and &&v_esnap
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.prev_snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,
'IDLE_TIME' as IDLE_TIME,
'BUSY_TIME' as BUSY_TIME,
'USER_TIME' as USER_TIME,
'SYS_TIME' as SYS_TIME,
'IOWAIT_TIME' as IOWAIT_TIME,
'NICE_TIME' as NICE_TIME,
'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,
'LOAD' as LOAD,
'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,
'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,
'VM_IN_BYTES' as VM_IN_BYTES,
'VM_OUT_BYTES' as VM_OUT_BYTES,
'NUM_CPU_CORES' AS NUM_CPU_CORES,
'FREE_MEMORY_BYTES' AS FREE_MEMORY_BYTES,
'INACTIVE_MEMORY_BYTES' AS INACTIVE_MEMORY_BYTES,
'SWAP_FREE_BYTES' AS SWAP_FREE_BYTES
)
)
 )  v
order by v.snap_id
;

-- Redo stats
select *
from (
WITH snaps AS (SELECT sn.dbid AS dbid, sn.instance_number, sn.begin_interval_time, sn.snap_id AS snap_id
       ,Lag(sn.snap_id,1,null) OVER( ORDER BY sn.snap_id asc ) AS prev_snap_id
FROM sys.wrm$_snapshot sn
WHERE sn.dbid=&&v_dbid AND sn.snap_id between &&v_bsnap and &&v_esnap ORDER BY sn.snap_id ASC ),
e as (select --Trunc(S.BEGIN_INTERVAL_TIME,'HH24') as snap_time,
       to_char(S.BEGIN_INTERVAL_TIME,'YYYY-MM-DD_hh24:MI') as snap_time,
       --S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from snaps s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  --AND s.snap_id NOT IN (&&v_skip_snaps)
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'redo KB read','redo KB read (memory)','redo KB read (memory) for transport','redo KB read for transport','redo blocks checksummed by FG (exclusive)','redo blocks checksummed by LGWR','redo blocks read for recovery','redo blocks written','redo buffer allocation retries','redo entries','redo entries for lost write detection','redo k-bytes read for recovery','redo k-bytes read for terminal recovery','redo log space requests','redo log space wait time','redo ordering marks','redo size','redo size for direct writes','redo size for lost write detection','redo subscn max counts','redo synch long waits','redo synch poll writes','redo synch polls','redo synch time','redo synch time (usec)','redo synch writes','redo wastage','redo write broadcast ack count','redo write broadcast ack time','redo write broadcast lgwr post count','redo write time','redo writes'   )
),
b as ( select --Trunc(S.BEGIN_INTERVAL_TIME,'HH24') as snap_time,
       to_char(S.BEGIN_INTERVAL_TIME,'YYYY-MM-DD_hh24:MI') as snap_time,
       --S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from snaps s, WRH$_SYSSTAT st, WRH$_STAT_NAME sn
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1
  and S.SNAP_ID between &&v_bsnap and &&v_esnap
  --AND s.snap_id NOT IN (&&v_skip_snaps)
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.prev_snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'redo KB read','redo KB read (memory)','redo KB read (memory) for transport','redo KB read for transport','redo blocks checksummed by FG (exclusive)','redo blocks checksummed by LGWR','redo blocks read for recovery','redo blocks written','redo buffer allocation retries','redo entries','redo entries for lost write detection','redo k-bytes read for recovery','redo k-bytes read for terminal recovery','redo log space requests','redo log space wait time','redo ordering marks','redo size','redo size for direct writes','redo size for lost write detection','redo subscn max counts','redo synch long waits','redo synch poll writes','redo synch polls','redo synch time','redo synch time (usec)','redo synch writes','redo wastage','redo write broadcast ack count','redo write broadcast ack time','redo write broadcast lgwr post count','redo write time','redo writes'   )
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=b.snap_id and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'redo KB read' as r_KB_read,
'redo KB read (memory)' as r_KB_read_memory,
'redo KB read (memory) for transport' as r_KB_read_mem4transport,
'redo KB read for transport' as r_KB_read4transport,
'redo blocks checksummed by FG (exclusive)' as r_blcks_chcksmmd_byFGexclusive,
'redo blocks checksummed by LGWR' as r_blocks_checksummed_by_LGWR,
'redo blocks read for recovery' as r_blocks_read4recovery,
'redo blocks written' as r_blocks_written,
'redo buffer allocation retries' as r_buffer_allocation_retries,
'redo entries' as r_entries,
'redo entries for lost write detection' as r_entries4lost_write_detection,
'redo k-bytes read for recovery' as r_kb_read4recovery,
'redo k-bytes read for terminal recovery' as r_kb_read4terminal_recovery,
'redo log space requests' as r_log_space_requests,
'redo log space wait time' as r_log_space_wait_time,
'redo ordering marks' as r_ordering_marks,
'redo size' as r_size,
'redo size for direct writes' as r_size4direct_writes,
'redo size for lost write detection' as r_size4lost_wr_detection,
'redo subscn max counts' as r_subscn_max_counts,
'redo synch long waits' as r_synch_long_waits,
'redo synch poll writes' as r_synch_poll_writes,
'redo synch polls' as r_synch_polls,
'redo synch time' as r_synch_time,
'redo synch time (usec)' as r_synch_time_usec,
'redo synch writes' as r_synch_writes,
'redo wastage' as r_wastage,
'redo write broadcast ack count' as rw_broadcast_ack_count,
'redo write broadcast ack time' as rw_broadcast_ack_time,
'redo write broadcast lgwr post count' as rw_broadcast_lgwr_post_count,
'redo write time' as rw_time,
'redo writes' as RedoWrites
)
 )
order by snap_time;
--------------------------------------------------------------------------------
