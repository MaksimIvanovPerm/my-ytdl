CREATE USER DBA8077 IDENTIFIED BY "0JLRgiDQvN" DEFAULT TABLESPACE excellent TEMPORARY TABLESPACE temp PROFILE DEFAULT;
GRANT CREATE SESSION, CREATE TABLE, unlimited TO DBA8077;
GRANT UNLIMITED TABLESPACE TO DBA8077;

define table_name="DBA8077.statdata_2"
PROMPT CREATE TABLE &&table_name
CREATE TABLE &&table_name (
  hostname   VARCHAR2(32) NULL,
  freerad    VARCHAR2(32) NULL,
  timestamp  NUMBER       NULL,
  median     NUMBER       NULL,
  mean       NUMBER       NULL,
  q3         NUMBER       NULL,
  maximum    NUMBER       NULL,
  ops        NUMBER       NULL,
  etime      NUMBER       NULL,
  measure_id NUMBER       NULL
);

comment on table &&table_name is 'Table for storaging latency-data about auth|acct-operations, see DBA-8077';
comment on column &&table_name..measure_id is 'Number of measure of data from the given host';
comment on column &&table_name..etime is 'Amount of time for watching for new data in log of the given freeradius';
comment on column &&table_name..ops is 'Amount of new operations which where noticed during watching new data in log of the given freeradius';
comment on column &&table_name..timestamp is 'Unix-timestamp, it is time when new data of the given freeradius was observed';
comment on column &&table_name..freerad is 'Name of a freeradius, which log-data will be analyzed;';


ALTER TABLE DBA8077.statdata RENAME TO DBA8077.statdata_1;
CREATE OR REPLACE synonym DBA8077.statdata FOR &&table_name;


SELECT *
FROM sys.dba_segments t
WHERE t.owner='DBA8077' AND t.segment_name='STATDATA'
;

SELECT t.* FROM DBA8077.statdata t;
SELECT DISTINCT  t.hostname FROM DBA8077.statdata t;
--DELETE FROM DBA8077.statdata t WHERE t.hostname='chelny';
--COMMIT;

SELECT t.hostname, Count(DISTINCT t.measure_id) AS observations
FROM DBA8077.statdata t
GROUP BY t.hostname
ORDER BY observations desc
;

SELECT t.hostname, t.TIMESTAMP
FROM DBA8077.statdata t
ORDER BY t.TIMESTAMP desc
;

SELECT DISTINCT t.hostname
FROM DBA8077.statdata t
;

SELECT t.*
FROM DBA8077.statdata t
WHERE Lower(t.hostname) LIKE '%nsk%'
ORDER BY t.TIMESTAMP desc
;

define v_city="oren"
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ', ';
SELECT  t.measure_id AS id,
        To_Date(to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(t.TIMESTAMP+5*3600,'SECOND'),'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') AS datetime,
        t.hostname, t.freerad, t.median, t.mean, t.q3, t.maximum, t.ops, --t.etime,
        CASE WHEN t.etime>0 THEN Round(t.ops/t.etime, 2)
        ELSE NULL END AS RPS
FROM DBA8077.statdata t
WHERE 1=1
AND t.hostname IN ('vradius-dhcp1.&&v_city','vradius-grsv1.&&v_city','vradius-wifi1.&&v_city','vradius1.&&v_city','radius1.&&v_city')
--AND t.hostname IN ('vradius-dhcp1.&&v_city','vradius-grsv1.&&v_city','vradius-wifi1.&&v_city','vradius1.&&v_city')
--AND t.hostname IN ('vradius-dhcp2.&&v_city','vradius-grsv2.&&v_city','vradius-wifi2.&&v_city','vradius2.&&v_city')
--AND t.hostname IN ('vradius-dhcp2.&&v_city','vradius-grsv2.&&v_city','vradius-wifi2.&&v_city','vradius2.&&v_city','radius2.&&v_city')
--AND t.measure_id=1558783420
-- AND t.freerad='dhcp_acct_start'
-- AND t.freerad='dhcp_acct_stop'
-- AND t.freerad='dhcp_acct_update'
--AND t.freerad='dhcp_auth'
-- AND t.freerad='grsv_acct_start'
-- AND t.freerad='grsv_acct_stop'
-- AND t.freerad='grsv_auth'
--AND t.freerad='inet_acct_start'
--AND t.freerad='inet_acct_stop'
--AND t.freerad='inet_acct_update'
AND t.freerad='inet_auth'
-- AND t.freerad='wifipeap_acct_start'
-- AND t.freerad='wifipeap_acct_stop'
-- AND t.freerad='wifipeap_acct_update'
-- AND t.freerad='wifipeap_auth'
-- AND t.freerad='wifiportal_acct_start'
-- AND t.freerad='wifiportal_acct_stop'
-- AND t.freerad='wifiportal_acct_update'
-- AND t.freerad='wifiportal_auth'
AND t.measure_id IS NOT null
ORDER BY t.measure_id asc, t.hostname, t.freerad
;


define v_statname="median"
SELECT v2.datetime AS datetime,
       v1.*
FROM (
SELECT *
FROM (
SELECT  t.measure_id AS timestamp,
        t.freerad AS freerad,
        t.&&v_statname AS statvalue
FROM DBA8077.statdata t
WHERE 1=1
AND t.hostname IN ('vradius-dhcp1.&&v_city','vradius-grsv1.&&v_city','vradius-wifi1.&&v_city','vradius1.&&v_city','radius1.&&v_city')
--AND t.hostname IN ('vradius-dhcp1.&&v_city','vradius-grsv1.&&v_city','vradius-wifi1.&&v_city','vradius1.&&v_city')
--AND t.hostname IN ('vradius-dhcp2.&&v_city','vradius-grsv2.&&v_city','vradius-wifi2.&&v_city','vradius2.&&v_city')
--AND t.hostname IN ('vradius-dhcp2.&&v_city','vradius-grsv2.&&v_city','vradius-wifi2.&&v_city','vradius2.&&v_city','radius2.&&v_city')
AND t.measure_id IS NOT null
ORDER BY t.measure_id asc, t.freerad
 )
pivot (
 max(statvalue)
 FOR freerad IN (
'dhcp_acct_start' as dhcp_acct_start,
'dhcp_acct_stop' as dhcp_acct_stop,
'dhcp_acct_update' as dhcp_acct_update,
'dhcp_auth' as dhcp_auth,
'grsv_acct_start' as grsv_acct_start,
'grsv_acct_stop' as grsv_acct_stop,
'grsv_auth' as grsv_auth,
'inet_acct_start' as inet_acct_start,
'inet_acct_stop' as inet_acct_stop,
'inet_acct_update' as inet_acct_update,
'inet_auth' as inet_auth,
'wifipeap_acct_start' as wifipeap_acct_start,
'wifipeap_acct_stop' as wifipeap_acct_stop,
'wifipeap_acct_update' as wifipeap_acct_update,
'wifipeap_auth' as wifipeap_auth,
'wifiportal_acct_start' as wifiportal_acct_start,
'wifiportal_acct_stop' as wifiportal_acct_stop,
'wifiportal_acct_update' as wifiportal_acct_update,
'wifiportal_auth' as wifiportal_auth
  )
 )
ORDER BY timestamp ) v1,
(SELECT id,
       To_Date(to_char(to_date('1970-01-01','YYYY-MM-DD') + NumToDSInterval(id+5*3600,'SECOND'),'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') AS datetime
FROM (
SELECT DISTINCT t.measure_id AS id
FROM DBA8077.statdata t
WHERE 1=1
AND t.hostname IN ('vradius-dhcp1.&&v_city','vradius-grsv1.&&v_city','vradius-wifi1.&&v_city','vradius1.&&v_city','radius1.&&v_city')
--AND t.hostname IN ('vradius-dhcp1.&&v_city','vradius-grsv1.&&v_city','vradius-wifi1.&&v_city','vradius1.&&v_city')
--AND t.hostname IN ('vradius-dhcp2.&&v_city','vradius-grsv2.&&v_city','vradius-wifi2.&&v_city','vradius2.&&v_city')
--AND t.hostname IN ('vradius-dhcp2.&&v_city','vradius-grsv2.&&v_city','vradius-wifi2.&&v_city','vradius2.&&v_city','radius2.&&v_city')
AND t.measure_id IS NOT null
ORDER BY t.measure_id ASC )
) v2
WHERE v1.timestamp=v2.id
;

--DELETE FROM DBA8077.statdata t WHERE t.hostname='samara' and t.measure_id=1558871281;
--COMMIT;

-- Perm inet_auth full model
select *
from (
with
local_data as (
select --S.BEGIN_INTERVAL_TIME as snap_time,
       --To_Char(S.BEGIN_INTERVAL_TIME,'dd/mm.yyyy hh24:mi') AS snap_time,
       s.snap_id as snap_id,
       S.VALUE as stat_value,
       S.STAT_id as stat_name
from WRH$_SYSSTAT s
where s.dbid=&&v_dbid and S.INSTANCE_NUMBER=1 and S.SNAP_ID between &&v_bsnap and &&v_esnap
  AND S.STAT_id in (
225051972,625960724,750832557,1099569955,1118776443,1312802324,1400824662,1661140639,1701530557,1862536587,2284697213,2510746206,2847404927,2964139762,3332107451,3411924934,3585877838
  )
),
b as ( select * from local_data ),
e as ( select * from local_data )
select --e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
225051972 as s225051972,
625960724 as s625960724,
750832557 as s750832557,
1099569955 as s1099569955,
1118776443 as s1118776443,
1312802324 as s1312802324,
1400824662 as s1400824662,
1661140639 as s1661140639,
1701530557 as s1701530557,
1862536587 as s1862536587,
2284697213 as s2284697213,
2510746206 as s2510746206,
2847404927 as s2847404927,
2964139762 as s2964139762,
3332107451 as s3332107451,
3411924934 as s3411924934,
3585877838 as s3585877838
)
 )
order by snap_id;


SELECT t.hostname AS hostname,
       --Avg(t.mean) AS avg_mean,
       --StdDev(t.mean) AS stddev_mean,
       Round((Avg(t.mean)+StdDev(t.mean))-(Avg(t.mean)-StdDev(t.mean)), 6) AS delta
FROM DBA8077.statdata t
WHERE 1=1 --t.hostname='ekat'
  AND t.freerad='inet_auth'
  AND t.measure_id IS NOT NULL
GROUP BY t.hostname
ORDER BY DELTA desc
;

SELECT t.hostname AS hostname,
       --Avg(t.mean) AS avg_mean,
       --StdDev(t.mean) AS stddev_mean,
       --Min(t.measure_id) AS metric
       Sum(t.mean) AS metric
FROM DBA8077.statdata t
WHERE 1=1 --t.hostname='ekat'
  AND t.freerad='inet_auth'
  AND t.measure_id IS NOT NULL
  AND t.measure_id > 1558881602
GROUP BY t.hostname
ORDER BY metric asc
;