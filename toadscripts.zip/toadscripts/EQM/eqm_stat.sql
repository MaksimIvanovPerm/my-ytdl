SELECT * FROM eqm_stat.eqm_stat t;

define operation_id=1502018873

SELECT *
FROM eqm_stat.eqm_stat t
WHERE t.id=&&operation_id
ORDER BY t.time_in_seconds;


SELECT Max(time_in_seconds)-Min(time_in_seconds) AS elapsed_time_sec
FROM eqm_stat.eqm_stat t
WHERE t.id=&&operation_id
;

SELECT TIME, action_ela_time,
       Round(action_ela_time/total_sum*100,2) AS action_pct,
       Round(cum_sum/total_sum*100,2) AS cum_action_pct,
       action, action_layer_code
FROM (
SELECT t.TIME AS time, t.DELTA AS action_ela_time, t.action,
       Sum(t.delta) OVER (ORDER BY t.DELTA DESC ROWS BETWEEN unbounded preceding AND CURRENT row) cum_sum,
       t.action_layer_code,
       Sum(t.delta) OVER (ORDER BY null) total_sum
FROM eqm_stat.eqm_stat t
WHERE t.id=&&operation_id
ORDER BY t.DELTA DESC
 );


SELECT Sum(t.DELTA) AS layer_time_consume_sec,
       t.action_layer_code
FROM eqm_stat.eqm_stat t
WHERE t.id=&&operation_id
GROUP BY t.action_layer_code
ORDER BY layer_time_consume_sec DESC
;


