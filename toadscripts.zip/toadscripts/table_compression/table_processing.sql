set serveroutput on size unlimited;
set linesize 128
set echo off;
set feedback off;
set verify off

define towner="&1"
define tname="&2"

spool alter_partitons.sql replace

declare
    v_owner         varchar2(30) := upper('&&towner');
    v_table_name    varchar2(30) := upper('&&tname');
    v_partitioned   varchar2(3);
    v_dop           number := 4;
    
    cursor c1(p_owner in varchar2,p_tname in varchar2) is
    select T.PARTITION_NAME as part_name
    from SYS.DBA_TAB_PARTITIONS t
    where T.TABLE_OWNER=p_owner and T.TABLE_NAME=p_tname;

begin
    dbms_output.put_line('set echo on');
    
    select T.PARTITIONED
    into v_partitioned
    from SYS.DBA_TABLES t
    where T.OWNER=v_owner and T.TABLE_NAME=v_table_name;
    
    if v_partitioned!='YES'
    then
        dbms_output.put_line('alter table '||v_owner||'.'||v_table_name||' move online compress for oltp;');
    else
        for i in c1(v_owner, v_table_name)
        loop
            dbms_output.put_line('alter table '||v_owner||'.'||v_table_name||' move partition '||i.part_name||' compress for oltp parallel '||v_dop||';');
        end loop;
    end if;

end;
/

spool off;

@alter_partitons.sql

set echo off;
set feedback off;
spool alter_indexes.sql replace

declare
    v_owner         varchar2(30) := upper('&&towner');
    v_table_name    varchar2(30) := upper('&&tname');
    v_partitioned   varchar2(3);
    v_dop           number := 4;

    cursor c2(p_owner in varchar2,p_tname in varchar2) is
    select T.OWNER as owner, T.INDEX_NAME as index_name, T.PARTITIONED as partitioned, t.status as status
    from dba_indexes t
    where T.TABLE_OWNER=p_owner and T.TABLE_NAME=p_tname;

    cursor c3(p_owner in varchar2,p_tname in varchar2) is
    select T.PARTITION_NAME as partition_name, T.STATUS as status
    from SYS.DBA_IND_PARTITIONS t
    where T.INDEX_OWNER=p_owner and T.INDEX_NAME=p_tname;

begin
    dbms_output.put_line('set echo on');   
    for i in c2(v_owner, v_table_name)     
    loop
    if i.partitioned!='YES' and i.status!='VALID'
    then
        dbms_output.put_line('alter index '||i.owner||'.'||i.index_name||' rebuild online parallel '||v_dop||';');
    end if;
    if i.partitioned='YES'
    then
       for j in c3(i.owner,i.index_name)
       loop
          if j.status!='USABLE'
          then
        dbms_output.put_line('alter index '||i.owner||'.'||i.index_name||' rebuild partition '||j.partition_name||' online parallel '||v_dop||';');
          end if;
       end loop;
    end if;

    end loop;
end;
/

spool off;

@alter_indexes.sql

select T.PARTITION_NAME, T.STATUS
from SYS.DBA_IND_PARTITIONS t
where T.INDEX_OWNER='&&towner' and T.INDEX_NAME='&&tname' and T.STATUS!='USABLE';

