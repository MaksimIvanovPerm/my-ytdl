-- Elapsed time by Chikurov
select l2.day, sum(l2.time)*24 AS elatime
    from
    (
      select l.sl_function_id, trunc(l.time_start) day, max(l.time) time
      from
      (
        select sll.sl_log_id, sll.sl_function_id, time_stop, time_start, time_stop - time_start time
        from excellent.sl_logs sll
            ,excellent.sl_functions slf
        where sll.sl_function_id = slf.sl_function_id
          and slf.stream = 7
          ----
          and sll.time_start >= SYSDATE-365 --to_date('03.11.2015','dd.mm.yyyy')
          and sll.time_start <= SYSDATE --to_date('03.11.2016','dd.mm.yyyy')
          ----
      ) l
      where l.time >= 0
      group by l.sl_function_id, trunc(l.time_start)
    ) l2
    group by l2.day
    order by l2.DAY
;

--Elapsed time by �nbaev
select trunc(l.time_start) day,
       substr(extract(day from (trunc(l.time_start) - timestamp '1970-01-01 00:00:00')) * 24 * 60 * 60 +
       extract(hour from (trunc(l.time_start) - timestamp '1970-01-01 00:00:00')) * 60 * 60 +
       extract(minute from (trunc(l.time_start) - timestamp '1970-01-01 00:00:00')) * 60 +
       trunc(extract(second from (trunc(l.time_start) - timestamp '1970-01-01 00:00:00')),0),0,15) as snap_timestamp,
       min(l.time_start) time_start,
       max(l.time_start) time_stop,
       round((max(l.time_stop) - min(l.time_start)) * 24, 4) duration
from   (select sll.sl_log_id, sll.sl_function_id, slf.function_name, slf.priority, time_stop,
                time_start, time_stop - time_start time
         from   excellent.sl_logs sll, excellent.sl_functions slf
         where  sll.sl_function_id = slf.sl_function_id
         and    slf.stream = 7
         and    sll.time_start >= SYSDATE-365
         and    sll.time_start <= sysdate
         ) l
where  l.time >= 0
group  by trunc(l.time_start)
;


-- Elapsed time by Enbaev
SELECT *
FROM excellent.sl_logs sll
WHERE sll.time_start>=Trunc(sysdate)
ORDER BY sll.sl_function_id asc
;

SELECT *
FROM excellent.sl_functions slf
WHERE slf.sl_function_id=2361
;

SELECT sll.sl_function_id, max(sll.restarted) AS restarted, round( (Max(time_start)-Min(time_start))*24,4) AS ela_time, Max(time_start), Min(time_start)
FROM excellent.sl_logs sll
WHERE sll.time_start>=Trunc(sysdate)
GROUP BY sll.sl_function_id
ORDER BY sll.sl_function_id
;


-- Profiling -----------------------------------------------------------------
select DISTINCT f.function_name
from excellent.sl_logs l, excellent.sl_functions f
where l.time_start between SYSDATE-365 and sysdate
and f.sl_function_id = l.sl_function_id
and f.stream in (5, 7)
and l.restarted = 0
and f.priority <= 130
;

SELECT *
FROM (
select trunc(l.time_start,'dd') AS datetime,
       f.function_name,
       Round((l.time_stop - l.time_start) * 86400,2) as dur_seconds
from excellent.sl_logs l, excellent.sl_functions f
where l.time_start between SYSDATE-365 and sysdate
and f.sl_function_id = l.sl_function_id
and f.stream in (5, 7)
and l.restarted = 0
and f.priority <= 130
)
pivot (
 Max(dur_seconds)
 FOR function_name IN (
'accumulate_support.accumulate_night_by_cron' as f1,
'check_bills_support.check_reglam_bills_f' as f2,
'dwh_charges_future_calc.clear_wrong_prep_sess_next_m_j' as f3,
'dwh_charges_inc_support.ins_earnings_incremental' as f4,
'dwh_charges_support2.clear_err_on_base_data' as f5,
'dwh_charges_support2.clear_old_prep_sess' as f6,
'dwh_charges_support2.clear_wrong_prep_sess' as f7,
'dwh_charges_support2.create_prepared_sessions' as f8,
'dwh_charges_support2.ins_earns_into_dwh_tbl_ctv' as f9,
'dwh_charges_support2.ins_earns_into_dwh_tbl_dom_tv' as f10,
'dwh_charges_support2.ins_earns_into_dwh_tbl_int' as f11,
'dwh_charges_support2.ins_earns_into_dwh_tbl_last' as f12,
'dwh_charges_support2.ins_earns_into_dwh_tbl_others' as f13,
'dwh_charges_support2.ins_earns_into_dwh_tbl_tel_fiz' as f14,
'dwh_charges_support2.ins_earns_into_dwh_tbl_tel_j' as f15,
'dwh_charges_support2.ins_earns_into_dwh_tbl_tel_out' as f16,
'dwh_charges_support2.ins_earns_into_dwh_tbl_tel_ul' as f17,
'dwh_charges_support2.license_fee_fill' as f18,
'ri_lf_discount_supp.make_discount_hash' as f19
 )
)
ORDER BY datetime
;
------------------------------------------------------------------------------

SELECT Trunc(sll.time_start) AS time_start,
       Round((Max(sll.time_stop)-Min(sll.time_start))*24,4) AS duration_hh
FROM excellent.sl_logs sll
WHERE sll.time_start >= to_date('05.09.2016', 'dd.mm.yyyy') AND  sll.time_start <= to_date('05.10.2016', 'dd.mm.yyyy')
  AND sll.sl_function_id=681
GROUP BY Trunc(sll.time_start)
ORDER BY time_start
;

SELECT sll.SL_LOG_ID, sll.restarted, sll.time_start, sll.TIME_STOP, substr(sll.RESULT,1,9) as result,
       Round((sll.time_stop - sll.time_start)*24,4) AS duration_hh
FROM excellent.sl_logs sll
WHERE --sll.time_start >= to_date('05.09.2016', 'dd.mm.yyyy') AND  sll.time_start <= to_date('05.10.2016', 'dd.mm.yyyy')
      sll.time_start >= to_date('28.11.2019', 'dd.mm.yyyy')
  AND sll.sl_function_id=726
ORDER BY time_start
;

-- Decomposition pf elapsed time by function's elapsed time;

SELECT --*
       DISTINCT sll.sl_function_id
FROM excellent.sl_logs sll
WHERE sll.time_start >= to_date('28.11.2019', 'dd.mm.yyyy') --AND  sll.time_start <= to_date('05.10.2016', 'dd.mm.yyyy')
;

SELECT --*
       --DISTINCT sll.sl_function_id
       sl_log_id, sl_function_id, restarted, time_start, time_stop, result
       ,Round((time_stop-time_start)*24,2) AS duration
FROM excellent.sl_logs sll
WHERE --sll.time_start >= Trunc((SYSDATE-365),'DD')
      sll.time_start >= to_date('28.11.2019', 'dd.mm.yyyy')
  AND sll.sl_function_id=114
ORDER BY sll.time_start asc
;

SELECT Trunc(sll.time_start, 'DD'),
       Round(( max(time_stop)-Min(time_start))*24,2) AS duration
FROM excellent.sl_logs sll
WHERE --sll.time_start >= Trunc((SYSDATE-365),'DD')
      sll.time_start >= to_date('28.11.2019', 'dd.mm.yyyy')
  AND sll.sl_function_id=2122
GROUP BY Trunc(sll.time_start, 'DD')
ORDER BY Trunc(sll.time_start, 'DD') asc
;


SELECT *
FROM excellent.sl_functions slf
WHERE 1=1
  --AND slf.sl_function_id IN (2361, 2021, 645, 2122, 114, 109, 1359, 937)
;

WITH DATA AS
(SELECT
'35,42,81,82,101,102,103,104,106,108,109,110,111,113,114,115,116,117,118,121,122,123,124,125,129,131,132,133,134,135,136,141,161,162,163,164,165,166,169,170,171,172,173,174,175,176,177,178,179,181,182,203,204,218,241,242,261,262,283,284,285,302,342,390,391,401,402,403,404,405,421,462,463,464,465,481,482,483,486,487,501,502,542,543,581,582,601,603,623,624,641,642,643,644,645,650,651,652,678,679,701,703,704,705,726,741,743,744,746,747,750,751,752,753,755,756,801,806,807,808,809,841,842,851,861,881,882,890,901,910,911,912,914,930,931,935,937,938,1302,1342,1345,1346,1347,1348,1349,1357,1358,1359,1409,1482,1564,1566,1581,1601,1602,1623,1641,1661,1682,1683,1701,1741,1801,1841,1941,2001,2021,2041,2061,2081,2101,2121,2122,2141,2161,2162,2321,2341,2361,2401,2402,2421,2441,2461,2481,2501,2502,2503,2521,2542,2543,2544,2545,2546,2547,2561,2581,2582,2583,2584,2585,2621,2622,2623,2642,2643,2644,2662,2742,2761,2762,2763,2764,2765,2766'
AS str
FROM dual
)
SELECT ''''||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||''' as id'||trim(regexp_substr(str, '[^,]+', 1, LEVEL))||',' str
FROM DATA
CONNECT BY regexp_substr(str , '[^,]+', 1, LEVEL) IS NOT NULL
;


SELECT *
FROM (
SELECT  Trunc(sll.time_start,'DD') AS datetime,
        sll.sl_function_id AS function_id,
        Round((Max(sll.time_stop)-Min(sll.time_start))*24,4) AS duration
FROM excellent.sl_logs sll
WHERE sll.time_start >= to_date('28.11.2019', 'dd.mm.yyyy') --AND  sll.time_start <= to_date('05.10.2016', 'dd.mm.yyyy')
      --sll.time_start>= Trunc((SYSDATE-390),'DD')
      --AND sll.result='OK'
      AND sll.sl_function_id IN (35,42,81,82,101,102,103,104,106,108,109,110,111,113,114,115,116,117,118,121,122,123,124,125,129,131,132,133,134,135,136,141,161,162,163,164,165,166,169,170,171,172,173,174,175,176,177,178,179,181,182,203,204,218,241,242,261,262,283,284,285,302,342,390,391,401,402,403,404,405,421,462,463,464,465,481,482,483,486,487,501,502,542,543,581,582,601,603,623,624,641,642,643,644,645,650,651,652,678,679,701,703,704,705,726,741,743,744,746,747,750,751,752,753,755,756,801,806,807,808,809,841,842,851,861,881,882,890,901,910,911,912,914,930,931,935,937,938,1302,1342,1345,1346,1347,1348,1349,1357,1358,1359,1409,1482,1564,1566,1581,1601,1602,1623,1641,1661,1682,1683,1701,1741,1801,1841,1941,2001,2021,2041,2061,2081,2101,2121,2122,2141,2161,2162,2321,2341,2361,2401,2402,2421,2441,2461,2481,2501,2502,2503,2521,2542,2543,2544,2545,2546,2547,2561,2581,2582,2583,2584,2585,2621,2622,2623,2642,2643,2644,2662,2742,2761,2762,2763,2764,2765,2766)
GROUP BY Trunc(sll.time_start, 'DD'), sll.sl_function_id
 )
 pivot (
  Max(duration)
  FOR function_id IN (
'35' as id35,
'42' as id42,
'81' as id81,
'82' as id82,
'101' as id101,
'102' as id102,
'103' as id103,
'104' as id104,
'106' as id106,
'108' as id108,
'109' as id109,
'110' as id110,
'111' as id111,
'113' as id113,
'114' as id114,
'115' as id115,
'116' as id116,
'117' as id117,
'118' as id118,
'121' as id121,
'122' as id122,
'123' as id123,
'124' as id124,
'125' as id125,
'129' as id129,
'131' as id131,
'132' as id132,
'133' as id133,
'134' as id134,
'135' as id135,
'136' as id136,
'141' as id141,
'161' as id161,
'162' as id162,
'163' as id163,
'164' as id164,
'165' as id165,
'166' as id166,
'169' as id169,
'170' as id170,
'171' as id171,
'172' as id172,
'173' as id173,
'174' as id174,
'175' as id175,
'176' as id176,
'177' as id177,
'178' as id178,
'179' as id179,
'181' as id181,
'182' as id182,
'203' as id203,
'204' as id204,
'218' as id218,
'241' as id241,
'242' as id242,
'261' as id261,
'262' as id262,
'283' as id283,
'284' as id284,
'285' as id285,
'302' as id302,
'342' as id342,
'390' as id390,
'391' as id391,
'401' as id401,
'402' as id402,
'403' as id403,
'404' as id404,
'405' as id405,
'421' as id421,
'462' as id462,
'463' as id463,
'464' as id464,
'465' as id465,
'481' as id481,
'482' as id482,
'483' as id483,
'486' as id486,
'487' as id487,
'501' as id501,
'502' as id502,
'542' as id542,
'543' as id543,
'581' as id581,
'582' as id582,
'601' as id601,
'603' as id603,
'623' as id623,
'624' as id624,
'641' as id641,
'642' as id642,
'643' as id643,
'644' as id644,
'645' as id645,
'650' as id650,
'651' as id651,
'652' as id652,
'678' as id678,
'679' as id679,
'701' as id701,
'703' as id703,
'704' as id704,
'705' as id705,
'726' as id726,
'741' as id741,
'743' as id743,
'744' as id744,
'746' as id746,
'747' as id747,
'750' as id750,
'751' as id751,
'752' as id752,
'753' as id753,
'755' as id755,
'756' as id756,
'801' as id801,
'806' as id806,
'807' as id807,
'808' as id808,
'809' as id809,
'841' as id841,
'842' as id842,
'851' as id851,
'861' as id861,
'881' as id881,
'882' as id882,
'890' as id890,
'901' as id901,
'910' as id910,
'911' as id911,
'912' as id912,
'914' as id914,
'930' as id930,
'931' as id931,
'935' as id935,
'937' as id937,
'938' as id938,
'1302' as id1302,
'1342' as id1342,
'1345' as id1345,
'1346' as id1346,
'1347' as id1347,
'1348' as id1348,
'1349' as id1349,
'1357' as id1357,
'1358' as id1358,
'1359' as id1359,
'1409' as id1409,
'1482' as id1482,
'1564' as id1564,
'1566' as id1566,
'1581' as id1581,
'1601' as id1601,
'1602' as id1602,
'1623' as id1623,
'1641' as id1641,
'1661' as id1661,
'1682' as id1682,
'1683' as id1683,
'1701' as id1701,
'1741' as id1741,
'1801' as id1801,
'1841' as id1841,
'1941' as id1941,
'2001' as id2001,
'2021' as id2021,
'2041' as id2041,
'2061' as id2061,
'2081' as id2081,
'2101' as id2101,
'2121' as id2121,
'2122' as id2122,
'2141' as id2141,
'2161' as id2161,
'2162' as id2162,
'2321' as id2321,
'2341' as id2341,
'2361' as id2361,
'2401' as id2401,
'2402' as id2402,
'2421' as id2421,
'2441' as id2441,
'2461' as id2461,
'2481' as id2481,
'2501' as id2501,
'2502' as id2502,
'2503' as id2503,
'2521' as id2521,
'2542' as id2542,
'2543' as id2543,
'2544' as id2544,
'2545' as id2545,
'2546' as id2546,
'2547' as id2547,
'2561' as id2561,
'2581' as id2581,
'2582' as id2582,
'2583' as id2583,
'2584' as id2584,
'2585' as id2585,
'2621' as id2621,
'2622' as id2622,
'2623' as id2623,
'2642' as id2642,
'2643' as id2643,
'2644' as id2644,
'2662' as id2662,
'2742' as id2742,
'2761' as id2761,
'2762' as id2762,
'2763' as id2763,
'2764' as id2764,
'2765' as id2765,
'2766' as id2766
  )
 )
 ORDER BY datetime asc
;

-- ASH
define v_dbid=3158406466
define v_bsnap=50090
define v_esnap=50102
define v_b_sample_time="24.09.2016 04:21:30.619"
define v_e_sample_time="24.09.2016 07:27:23.972"
define sql_sess_sid=362
define sql_sess_serial=37495
define data_structure="V$ACTIVE_SESSION_HISTORY"
ALTER SESSION SET nls_date_format='yyyy.mm.dd hh24:mi:ss';

-- Elatime of the given sql_id
SELECT DISTINCT Trunc(t.sample_time) AS datetime, t.session_id, t.session_serial#
FROM sys.wrh$_active_session_history t
WHERE t.sql_id='33nvhyjsthp0k'
  AND t.dbid=&&v_dbid
--ORDER BY 1
;

DROP TABLE query_stat;
CREATE TABLE query_stat as
SELECT To_Date('20.09.2016','dd.mm.yyyy') AS datetime, sql_id,
       Count(sql_exec_id) AS exec_count,
       Round(min(elatime),2) AS min_elatime,
       Round(Avg(elatime),2) AS avg_elatime,
       Round(max(elatime),2) AS max_elatime
FROM (
SELECT sample_time,
       Round(extract(SECOND FROM (sample_time-prev_sample_time))*1+extract(minute FROM (sample_time-prev_sample_time))*60,0) AS sampe_period,
       sql_id,sql_exec_id,sql_exec_start,
       Round(extract(SECOND FROM (sample_time-sql_exec_start))*1+extract(minute FROM (sample_time-sql_exec_start))*60+extract(hour FROM (sample_time-sql_exec_start))*3600,0) AS elatime
FROM (
SELECT t.sample_id,
       t.sample_time,
       t.sql_id,
       t.sql_exec_id,
       t.sql_exec_start,
       row_number() OVER (PARTITION BY sql_id, sql_exec_id ORDER BY sample_id desc) AS rn,
       Lag(t.sample_time,1,t.sample_time) OVER (ORDER BY sample_id) AS prev_sample_time
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid
  AND t.session_id=&&sql_sess_sid AND t.session_serial#=&&sql_sess_serial
  AND t.sql_id IS NOT NULL AND t.sql_exec_id IS NOT NULL AND t.sql_exec_start IS NOT null
ORDER BY t.sample_id
 )
 WHERE rn=1
  )
  GROUP BY sql_id
  ORDER BY sql_id
;


TRUNCATE TABLE query_stat;

/*
([^\t]+)\t([^\t]+)\t(.*+)\r\n
add_data\(To_Date\('\1','dd\.mm\.yyyy'\), \2, \3\)\;\r\n
*/

DECLARE
PROCEDURE add_data (p_datetime IN date, p_sid IN NUMBER, p_sserial IN number)
is
BEGIN
INSERT INTO query_stat
SELECT p_datetime datetime, sql_id,
       Count(sql_exec_id) AS exec_count,
       Round(min(elatime),2) AS min_elatime,
       Round(Avg(elatime),2) AS avg_elatime,
       Round(max(elatime),2) AS max_elatime
FROM (
SELECT sample_time,
       Round(extract(SECOND FROM (sample_time-prev_sample_time))*1+extract(minute FROM (sample_time-prev_sample_time))*60,0) AS sampe_period,
       sql_id,sql_exec_id,sql_exec_start,
       Round(extract(SECOND FROM (sample_time-sql_exec_start))*1+extract(minute FROM (sample_time-sql_exec_start))*60+extract(hour FROM (sample_time-sql_exec_start))*3600,0) AS elatime
FROM (
SELECT t.sample_id,
       t.sample_time,
       t.sql_id,
       t.sql_exec_id,
       t.sql_exec_start,
       row_number() OVER (PARTITION BY sql_id, sql_exec_id ORDER BY sample_id desc) AS rn,
       Lag(t.sample_time,1,t.sample_time) OVER (ORDER BY sample_id) AS prev_sample_time
FROM sys.wrh$_active_session_history t
WHERE t.dbid=3220346047
  AND t.session_id=p_sid AND t.session_serial#=p_sserial
  AND t.sql_id IS NOT NULL AND t.sql_exec_id IS NOT NULL AND t.sql_exec_start IS NOT null
ORDER BY t.sample_id
 )
 WHERE rn=1
  )
  GROUP BY sql_id
  ORDER BY sql_id
;
END;

BEGIN
add_data(To_Date('20.09.2016','dd.mm.yyyy'), 301, 41621);
add_data(To_Date('21.09.2016','dd.mm.yyyy'), 1368, 43531);
add_data(To_Date('22.09.2016','dd.mm.yyyy'), 280, 833);
add_data(To_Date('22.09.2016','dd.mm.yyyy'), 1307, 33017);
add_data(To_Date('23.09.2016','dd.mm.yyyy'), 1534, 12579);
add_data(To_Date('24.09.2016','dd.mm.yyyy'), 605, 17635);
add_data(To_Date('25.09.2016','dd.mm.yyyy'), 1701, 39033);
add_data(To_Date('26.09.2016','dd.mm.yyyy'), 437, 12123);
add_data(To_Date('27.09.2016','dd.mm.yyyy'), 83, 34815);
add_data(To_Date('28.09.2016','dd.mm.yyyy'), 82, 53287);
add_data(To_Date('29.09.2016','dd.mm.yyyy'), 1322, 20447);
add_data(To_Date('30.09.2016','dd.mm.yyyy'), 1341, 62161);
add_data(To_Date('01.10.2016','dd.mm.yyyy'), 1341, 64285);
add_data(To_Date('02.10.2016','dd.mm.yyyy'), 1004, 42477);
add_data(To_Date('02.10.2016','dd.mm.yyyy'), 1438, 36161);
add_data(To_Date('03.10.2016','dd.mm.yyyy'), 161, 32527);
add_data(To_Date('03.10.2016','dd.mm.yyyy'), 1430, 6393);
add_data(To_Date('04.10.2016','dd.mm.yyyy'), 682, 62025);
add_data(To_Date('04.10.2016','dd.mm.yyyy'), 1482, 54669);
commit;
END;
/

SELECT DISTINCT sql_id FROM query_stat;

SELECT *
FROM query_stat t
WHERE t.sql_id='5up7rsmfb841u'
ORDER BY t.datetime
;


SELECT *
FROM ( SELECT t.datetime, t.sql_id, t.avg_elatime AS stat_value FROM query_stat t )
pivot (
Max(stat_value)
FOR sql_id IN (
'018kfm09w8bn2' as q018kfm09w8bn2,
'01f1h67r5ccp9' as q01f1h67r5ccp9,
'01r75qtx3qz59' as q01r75qtx3qz59,
'03gs8fwmhywkk' as q03gs8fwmhywkk,
'044qyn2v7sdd9' as q044qyn2v7sdd9,
'04hvtna6abgh4' as q04hvtna6abgh4,
'0565u372956vw' as q0565u372956vw,
'088yw03pss5kd' as q088yw03pss5kd,
'09409rjhqxzvm' as q09409rjhqxzvm,
'0b1s89txaryd9' as q0b1s89txaryd9,
'0dvwd37d519d5' as q0dvwd37d519d5,
'0jyxy2314n08r' as q0jyxy2314n08r,
'0mr8cawqd07gz' as q0mr8cawqd07gz,
'0n64pnm3q2tr5' as q0n64pnm3q2tr5,
'0vx0h6v63tzn6' as q0vx0h6v63tzn6,
'0zassmwf0tvwa' as q0zassmwf0tvwa,
'0zs9mjnxzqad1' as q0zs9mjnxzqad1,
'18m8raydh86x3' as q18m8raydh86x3,
'1dbbagcjrjbjw' as q1dbbagcjrjbjw,
'1j8mcbbhsny62' as q1j8mcbbhsny62,
'1jrd7kh4p82hm' as q1jrd7kh4p82hm,
'1jysct63fz9sx' as q1jysct63fz9sx,
'1k9f09fwysvb1' as q1k9f09fwysvb1,
'1wvq2x1umkd5f' as q1wvq2x1umkd5f,
'20sxxzyy8swc5' as q20sxxzyy8swc5,
'210yrmr96zznz' as q210yrmr96zznz,
'22hg4kb67zqj1' as q22hg4kb67zqj1,
'25tyamb8cga70' as q25tyamb8cga70,
'28ybj65ju2g2x' as q28ybj65ju2g2x,
'29yx4h229kwtg' as q29yx4h229kwtg,
'2bj0089vmk44m' as q2bj0089vmk44m,
'2f1rcp4s8pv4b' as q2f1rcp4s8pv4b,
'2hzvwf5j6rz2z' as q2hzvwf5j6rz2z,
'2nv0jnpfbck0x' as q2nv0jnpfbck0x,
'2pb0s3rx7uyn8' as q2pb0s3rx7uyn8,
'2pjc5v11p6nw8' as q2pjc5v11p6nw8,
'2r5658jpsqjhj' as q2r5658jpsqjhj,
'2twcr7qjq4vus' as q2twcr7qjq4vus,
'2utyrqxdpva1j' as q2utyrqxdpva1j,
'30jx8q17zcvtn' as q30jx8q17zcvtn,
'31y2pyd4c64rm' as q31y2pyd4c64rm,
'32fu5wyz1jdkb' as q32fu5wyz1jdkb,
'33tjx657ha3uw' as q33tjx657ha3uw,
'36hn09tbz7du8' as q36hn09tbz7du8,
'3ajygka850aru' as q3ajygka850aru,
'3bhxsz96pzfwc' as q3bhxsz96pzfwc,
'3fybj6jhjkkb0' as q3fybj6jhjkkb0,
'3hx6qab8cxd6r' as q3hx6qab8cxd6r,
'3ph08k97tudnf' as q3ph08k97tudnf,
'3v24ncy09xsj2' as q3v24ncy09xsj2,
'3v9gdkhunghpc' as q3v9gdkhunghpc,
'43kayupbckfya' as q43kayupbckfya,
'45zb58x3vpkp5' as q45zb58x3vpkp5,
'460pupvsuunwy' as q460pupvsuunwy,
'46qqhp7m13xvy' as q46qqhp7m13xvy,
'4cf8cqpsmpv1k' as q4cf8cqpsmpv1k,
'4g1jghr0sg6a8' as q4g1jghr0sg6a8,
'4m7m0t6fjcs5x' as q4m7m0t6fjcs5x,
'4ndrp4n551zdt' as q4ndrp4n551zdt,
'4vg3jaz1dkq80' as q4vg3jaz1dkq80,
'4w6n0vnkj9a71' as q4w6n0vnkj9a71,
'4wu2hgdbxbrfg' as q4wu2hgdbxbrfg,
'52wwd1105sm7d' as q52wwd1105sm7d,
'59u996zt2z0t8' as q59u996zt2z0t8,
'5abfnsyp1xhz0' as q5abfnsyp1xhz0,
'5hwaqcwmqwd1a' as q5hwaqcwmqwd1a,
'5pb0m6zzvm9n4' as q5pb0m6zzvm9n4,
'5t1yfhtg0rhwz' as q5t1yfhtg0rhwz,
'5v7zyntth82bq' as q5v7zyntth82bq,
'5zufbkd6823uy' as q5zufbkd6823uy,
'60zz6q6b5kdu7' as q60zz6q6b5kdu7,
'654ujkh7rn3z7' as q654ujkh7rn3z7,
'65gcy1gsqujmr' as q65gcy1gsqujmr,
'66yq421mzydg1' as q66yq421mzydg1,
'68f3t04rvd6fs' as q68f3t04rvd6fs,
'6dq1q4w48yxxk' as q6dq1q4w48yxxk,
'6nk41n0h40ja0' as q6nk41n0h40ja0,
'6nzwgrwvzgtvh' as q6nzwgrwvzgtvh,
'6p92m9pzh5252' as q6p92m9pzh5252,
'6r43pxhtgvthv' as q6r43pxhtgvthv,
'6r704bp5g8n84' as q6r704bp5g8n84,
'6rsy55gpkt3n1' as q6rsy55gpkt3n1,
'6ut82hx9n9g2g' as q6ut82hx9n9g2g,
'6wqh3azzyz2y4' as q6wqh3azzyz2y4,
'6xny580vz1pk9' as q6xny580vz1pk9,
'70q2zv0nbwkj4' as q70q2zv0nbwkj4,
'71bcf3n769kss' as q71bcf3n769kss,
'72hgxhcxmxm1p' as q72hgxhcxmxm1p,
'73859v5h1y79j' as q73859v5h1y79j,
'754nfqnpf6x07' as q754nfqnpf6x07,
'75qc41bzxynzh' as q75qc41bzxynzh,
'76st1v9wr41s6' as q76st1v9wr41s6,
'7784u5b7tkvvb' as q7784u5b7tkvvb,
'7atqkmw75jpqb' as q7atqkmw75jpqb,
'7bkzuxy8th10s' as q7bkzuxy8th10s,
'7byurk74yzzwz' as q7byurk74yzzwz,
'7c9uj7ktdzz48' as q7c9uj7ktdzz48,
'7cmc7npanzhkw' as q7cmc7npanzhkw,
'7g2jm77a4c3z6' as q7g2jm77a4c3z6,
'7jtu8v0162pwy' as q7jtu8v0162pwy,
'7ps7naadhc7c2' as q7ps7naadhc7c2,
'7qzx7a9nhc5u4' as q7qzx7a9nhc5u4,
'7t8ru9crkbwqx' as q7t8ru9crkbwqx,
'7vcc9qnbnpavx' as q7vcc9qnbnpavx,
'7y01xxtdnsdzx' as q7y01xxtdnsdzx,
'83ry5zu77scwh' as q83ry5zu77scwh,
'84qzsr7qa8r1m' as q84qzsr7qa8r1m,
'86q1m61bsy72k' as q86q1m61bsy72k,
'88hhr4kc0ztyu' as q88hhr4kc0ztyu,
'89s57xkbm90vh' as q89s57xkbm90vh,
'8daj81t43k1wc' as q8daj81t43k1wc,
'8g61pqu435gvx' as q8g61pqu435gvx,
'8p29jf54nqzr1' as q8p29jf54nqzr1,
'8p77mazd9z1ns' as q8p77mazd9z1ns,
'8qpcv7qcjc2m3' as q8qpcv7qcjc2m3,
'8rt50g6uvvnas' as q8rt50g6uvvnas,
'8s4q7haks0y9m' as q8s4q7haks0y9m,
'8sfd87s5zdxf9' as q8sfd87s5zdxf9,
'8xf38dsrbp8h8' as q8xf38dsrbp8h8,
'8zy8xb1r2fws8' as q8zy8xb1r2fws8,
'91wzxqswx5zw9' as q91wzxqswx5zw9,
'95p6m4vu62a84' as q95p6m4vu62a84,
'96f2vbsf2qtn8' as q96f2vbsf2qtn8,
'99pkg7gfr6gnq' as q99pkg7gfr6gnq,
'9bp0d1tpucrf7' as q9bp0d1tpucrf7,
'9fzqjkd9cu635' as q9fzqjkd9cu635,
'9w1ajjsfttxju' as q9w1ajjsfttxju,
'a0zfugkfp41pr' as qa0zfugkfp41pr,
'a1t7ccks2qbv1' as qa1t7ccks2qbv1,
'a3chk54a0dj6y' as qa3chk54a0dj6y,
'a5av1t7mmqy2d' as qa5av1t7mmqy2d,
'adp9wqhk9hpq1' as qadp9wqhk9hpq1,
'adyt94hvbvqhy' as qadyt94hvbvqhy,
'af9rsdnxd3c5u' as qaf9rsdnxd3c5u,
'ahwfvu005npfz' as qahwfvu005npfz,
'aka8du7bppwsc' as qaka8du7bppwsc,
'akc7fks2ppqf8' as qakc7fks2ppqf8,
'am106supdqqss' as qam106supdqqss,
'am50stnj1hqcf' as qam50stnj1hqcf,
'amtzw2wbyp35m' as qamtzw2wbyp35m,
'asyr4y55jahd5' as qasyr4y55jahd5,
'ayvqu911ju7v2' as qayvqu911ju7v2,
'b17a1t19swjnz' as qb17a1t19swjnz,
'b31ypxn0zgsvj' as qb31ypxn0zgsvj,
'b4dbuqzg12zps' as qb4dbuqzg12zps,
'bgtfqkrkjygay' as qbgtfqkrkjygay,
'bp03aq7yq54nt' as qbp03aq7yq54nt,
'bqvg571myj45h' as qbqvg571myj45h,
'bw3y22dsr9fw9' as qbw3y22dsr9fw9,
'by6sb7a83y3b8' as qby6sb7a83y3b8,
'bzpuxv5mvzmc2' as qbzpuxv5mvzmc2,
'c3pkmk2fuy1f8' as qc3pkmk2fuy1f8,
'c4rxnch81h04g' as qc4rxnch81h04g,
'c8qz15u0tpdkw' as qc8qz15u0tpdkw,
'cf1dbpgu3msd7' as qcf1dbpgu3msd7,
'cfscqzry3g1ua' as qcfscqzry3g1ua,
'chbn34a8cdy27' as qchbn34a8cdy27,
'chd3bj3cqkzax' as qchd3bj3cqkzax,
'chpv45xp47g6z' as qchpv45xp47g6z,
'cj5hq8rg9f75g' as qcj5hq8rg9f75g,
'ck344xb4s1sjb' as qck344xb4s1sjb,
'cr61nsjs9q27k' as qcr61nsjs9q27k,
'cvpz29pn1yh6r' as qcvpz29pn1yh6r,
'cvwy4q195spyw' as qcvwy4q195spyw,
'cw2fug9uywjgr' as qcw2fug9uywjgr,
'cy2m9ctm5jg29' as qcy2m9ctm5jg29,
'd07pqqafzz407' as qd07pqqafzz407,
'd1bymu2gudw43' as qd1bymu2gudw43,
'd2q8dt7rjzvty' as qd2q8dt7rjzvty,
'd8c6hc9cax37p' as qd8c6hc9cax37p,
'd940dc2wh8jx7' as qd940dc2wh8jx7,
'dn2cxxrsd7jk1' as qdn2cxxrsd7jk1,
'dqsxhvwrtbmqn' as qdqsxhvwrtbmqn,
'dwcbjawr3ngna' as qdwcbjawr3ngna,
'dxmuaa4ww9sqn' as qdxmuaa4ww9sqn,
'dz55x44hsjjwh' as qdz55x44hsjjwh,
'f1g7sfuhr76af' as qf1g7sfuhr76af,
'f4x7fvgwaj760' as qf4x7fvgwaj760,
'f5q9hcw49yuva' as qf5q9hcw49yuva,
'f845fqf1z42zz' as qf845fqf1z42zz,
'fc2szcjm4kxc6' as qfc2szcjm4kxc6,
'fhr6yyk81n45v' as qfhr6yyk81n45v,
'fmpuxbpr9gvf2' as qfmpuxbpr9gvf2,
'fq32r8tm4n29z' as qfq32r8tm4n29z,
'fqd9aywsx1pkd' as qfqd9aywsx1pkd,
'fqrp33u6w55qt' as qfqrp33u6w55qt,
'fquj0jxtavp87' as qfquj0jxtavp87,
'ftq5y9kfq36zp' as qftq5y9kfq36zp,
'fuw9xvq6hfc4s' as qfuw9xvq6hfc4s,
'fvwrtpz6v3ctx' as qfvwrtpz6v3ctx,
'fzb2c54m4hb2m' as qfzb2c54m4hb2m,
'g0jqwxv9rym15' as qg0jqwxv9rym15,
'g0qrws69wy854' as qg0qrws69wy854,
'g2t76j0f28t7a' as qg2t76j0f28t7a,
'g2xfhvp50pm3s' as qg2xfhvp50pm3s,
'g439mk5g9tfn0' as qg439mk5g9tfn0,
'g65wzuvkxu9pm' as qg65wzuvkxu9pm,
'ganfqcc8ahwyq' as qganfqcc8ahwyq,
'gbn9dpafdhhp6' as qgbn9dpafdhhp6,
'gdgbm003vtq0y' as qgdgbm003vtq0y,
'gjg3575ukx8r6' as qgjg3575ukx8r6,
'gk1a3fwmbha1r' as qgk1a3fwmbha1r,
'gng1af8nb1tzg' as qgng1af8nb1tzg,
'gnsr85rmq0wmd' as qgnsr85rmq0wmd,
'gvt03z8q0wy3t' as qgvt03z8q0wy3t,
'gw5k5qqbxhvvv' as qgw5k5qqbxhvvv,
'gx8y968p42my6' as qgx8y968p42my6,
'gy8b4qx5rzs0g' as qgy8b4qx5rzs0g
 )
)
ORDER BY datetime
;
----------------------------------------------------------------------------------------------
--DBA-10377
SELECT sll.sl_function_id, max(sll.restarted) AS restarted, round( (Max(time_start)-Min(time_start))*24,4) AS ela_time, Max(time_start), Min(time_start)
FROM excellent.sl_logs sll
WHERE sll.time_start>=To_Date('2020.10.07 12:00:00','yyyy.mm.dd hh24:mi:ss')
GROUP BY sll.sl_function_id
ORDER BY sll.sl_function_id
;

SELECT slf.function_name, sll.*, round( (time_stop-time_start)*24,4) AS ela_tim
FROM excellent.sl_logs sll, excellent.sl_functions slf
WHERE sll.time_start>=To_Date('2020.10.07 09:30:00','yyyy.mm.dd hh24:mi:ss')
  AND sll.sl_function_id = slf.sl_function_id
ORDER BY sll.time_start asc
;

define v_sid="410"
define v_serial="16189"

SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  --AND t.event IN ('db file sequential read','db file scattered read')
ORDER BY t.sample_id asc
;

SELECT *
FROM sys.v_$active_session_history t
WHERE t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  --AND t.event IN ('db file sequential read','db file scattered read')
ORDER BY t.sample_id ASC
;

SELECT t.sql_plan_operation, t.sql_plan_options, Count(*) cases
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
GROUP BY t.sql_plan_operation, t.sql_plan_options
ORDER BY cases desc
;

SELECT t.current_obj#, Count(*) AS cases
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  --AND t.sql_plan_operation='INDEX' AND t.sql_plan_options='RANGE SCAN'
GROUP BY t.current_obj#
ORDER BY cases desc
;

SELECT t.event, Count(*) cases
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
GROUP BY t.event
ORDER BY cases desc
;

--where time is spent and how many time is spet
SELECT  t.sql_id, Count(*) AS cases  --t.sql_exec_id,  max(t.sample_time)-Min(t.sql_exec_start) AS ela_time
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND
  t.dbid=&&v_dbid
  AND t.snap_id  BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  --AND t.sql_opname NOT IN ('PL/SQL EXECUTE')
GROUP BY t.sql_id--, t.sql_exec_id
ORDER BY cases DESC NULLs last
;

define v_sql_id="4j4uj7ttt7bax"
SELECT t.*
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  AND t.sql_id='&&v_sql_id'
ORDER BY t.sample_id asc
;

SELECT Min(ela_time) AS min_elatime,
        percentile_disc(0.25) within group (order by ela_time) as q25,
        percentile_disc(0.5) within group  (order by ela_time) as q50,
        percentile_disc(0.75) within group (order by ela_time) as q75,
        percentile_disc(0.85) within group (order by ela_time) as q85,
        percentile_disc(0.95) within group (order by ela_time) as q95,
        Max(ela_time) AS max_value,
        Sum(ela_time) AS total,
        Count(*) AS executions
FROM (
SELECT sql_id, sql_exec_id
       ,(extract (hour FROM ela_time)*3600)+(extract (minute FROM ela_time)*60)+(extract (SECOND FROM ela_time)) AS ela_time
FROM (
SELECT  t.sql_id, t.sql_exec_id,  max(t.sample_time)-Min(t.sql_exec_start) AS ela_time
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  AND t.sql_id='&&v_sql_id'
GROUP BY t.sql_id, t.sql_exec_id
 )
)
;

SELECT ela_time
       ,extract (SECOND FROM ela_time) AS ela_ss
       ,extract (minute FROM ela_time) AS ela_mi
       ,extract (hour FROM ela_time) AS ela_hh
       ,(extract (hour FROM ela_time)*3600)+(extract (minute FROM ela_time)*60)+(extract (SECOND FROM ela_time)) AS ela_time2
FROM (
 SELECT localtimestamp-(SYSDATE-3665/86400) AS ela_time FROM dual
);

SELECT v.cases, dp.owner||'.'||dp.object_name||'.'||dp.procedure_name AS proc_name
FROM (SELECT t.plsql_object_id, t.plsql_subprogram_id, Count(*) AS cases
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  AND t.sql_id='&&v_sql_id'
GROUP BY t.plsql_object_id, t.plsql_subprogram_id
ORDER BY cases DESC nulls last) v, sys.dba_procedures dp
WHERE dp.object_id(+)=v.plsql_object_id AND dp.subprogram_id(+)=v.plsql_subprogram_id
;

SELECT t.top_level_sql_id, Count(*) AS cases
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  AND t.sql_id='&&v_sql_id'
GROUP BY t.top_level_sql_id
ORDER BY cases desc
;

SELECT v.sql_plan_hash_value, v.sql_plan_line_id, v.cases, sp.operation , sp.options, sp.object_owner||'.'||sp.object_name AS obj_name
FROM (SELECT t.sql_plan_hash_value, t.sql_plan_line_id, Count(*) AS cases
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  AND t.sql_id='&&v_sql_id'
GROUP BY t.sql_plan_hash_value, t.sql_plan_line_id) v, sys.WRH$_SQL_PLAN sp
WHERE sp.plan_hash_value(+)=v.sql_plan_hash_value AND sp.id(+)=v.sql_plan_line_id
  AND sp.dbid=&&v_dbid --AND sp.snap_id BETWEEN &&v_bsnap AND &&v_esnap
ORDER BY v.cases desc
;

SELECT Count(*) AS total_cases,
       Count(DISTINCT t.sql_exec_id) AS executions
FROM sys.dba_hist_active_sess_history t
WHERE t.session_type='FOREGROUND' AND t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap
  AND t.session_id = &&v_sid AND t.session_serial#=&&v_serial
  AND t.sql_id='&&v_sql_id'
ORDER BY t.sample_id asc
;

define v_module="pppoe_sessions_detail_move.move_sessions"
CREATE TABLE SYSTEM.sql_sess TABLESPACE excellent AS
SELECT DISTINCT t.session_id, t.session_serial#
FROM sys.wrh$_active_session_history t
WHERE t.dbid=&&v_dbid AND t.snap_id BETWEEN &&v_bsnap AND &&v_esnap AND t.MODULE='&&v_module'
;

SELECT a_session, start_time, end_time, end_time-start_time AS duration
FROM (
SELECT t1.session_id||'.'||t1.session_serial# AS a_session, --Min(t1.sample_time), Min(t1.sql_exec_start), Max(t1.sample_time),
       CASE
       WHEN Nvl( Min(t1.sample_time), SYSDATE) < Nvl( Min(t1.sql_exec_start), SYSDATE) THEN Min(t1.sample_time)
       WHEN Nvl( Min(t1.sample_time), SYSDATE) > Nvl( Min(t1.sql_exec_start), SYSDATE) THEN Min(t1.sql_exec_start)
       END AS start_time,
       Max(t1.sample_time) AS end_time
FROM sys.wrh$_active_session_history t1, SYSTEM.sql_sess sql_sess
WHERE t1.dbid=&&v_dbid AND t1.snap_id BETWEEN &&v_bsnap AND &&v_esnap AND t1.instance_number=1
  AND t1.session_id=sql_sess.session_id AND t1.session_serial#=sql_sess.session_serial#
GROUP BY t1.session_id||'.'||t1.session_serial#
ORDER BY start_time ASC )
;

SELECT *
FROM v$shared_server;

SELECT *
FROM sys.v_$dispatcher t
;

SELECT *
FROM V$DISPATCHER_CONFIG t
;

SELECT *
FROM V$DISPATCHER_RATE t
;

select * from v$resource_limit;
