DROP TABLE excellent.test_stat;
create table excellent.test_stat (test_id number, test_state CHAR(1), stat_name varchar2(64), stat_value number);

define test_id=2;
define test_state="B";
INSERT INTO excellent.test_stat
SELECT  &&test_id, '&&test_state', sn.name AS stat_name, ms.value
FROM  v$mystat ms, sys.v_$statname sn
WHERE ms.statistic#=sn.statistic#
  and ms.Value > 0
;
COMMIT;

SELECT Count(*) FROM sys.dba_objects a, sys.dba_objects b;

define test_state="A";
INSERT INTO excellent.test_stat
SELECT  &&test_id, '&&test_state', sn.name AS stat_name, ms.value
FROM  v$mystat ms, sys.v_$statname sn
WHERE ms.statistic#=sn.statistic#
  and ms.Value > 0
;
COMMIT;


DROP TABLE excellent.test_event;
create table excellent.test_event (test_id number, test_state CHAR(1), event_name varchar2(64), TIME_WAITED number);

SELECT *
FROM sys.V_$SESSION_EVENT t
WHERE t.sid=(SELECT DISTINCT sid FROM v$mystat)
;

define test_id=3;
define test_state="B";
INSERT INTO excellent.test_event
SELECT  &&test_id, '&&test_state', es.event AS event_name, es.time_waited
FROM  V_$SESSION_EVENT es
WHERE es.sid=(SELECT DISTINCT sid FROM v$mystat) AND es.time_waited > 0
;
COMMIT;

SELECT Count(*) FROM sys.dba_objects a;

define test_state="A";
INSERT INTO excellent.test_event
SELECT  &&test_id, '&&test_state', es.event AS event_name, es.time_waited
FROM  V_$SESSION_EVENT es
WHERE es.sid=(SELECT DISTINCT sid FROM v$mystat) AND es.time_waited > 0
;
COMMIT;

SELECT *
FROM excellent.test_event t
WHERE t.test_id=&&test_id
;

define test_id=1;

SELECT a.event_name AS event_name,
       a.time_waited-Nvl(b.time_waited,0) AS DELTA
FROM
( SELECT * FROM excellent.test_event t WHERE t.test_id=&&test_id AND t.test_state='A' ) a,
( SELECT * FROM excellent.test_event t WHERE t.test_id=&&test_id AND t.test_state='B' ) b
WHERE a.event_name=b.event_name(+)
  AND a.time_waited-Nvl(b.time_waited,0) > 0
ORDER BY DELTA DESC
;

SELECT a.stat_name AS stan_name,
       a.stat_value-Nvl(b.stat_value,0) AS DELTA
FROM
( SELECT * FROM excellent.test_stat t WHERE t.test_id=&&test_id AND t.test_state='A' ) a,
( SELECT * FROM excellent.test_stat t WHERE t.test_id=&&test_id AND t.test_state='B' ) b
WHERE a.stat_name=b.stat_name(+)
  and a.stat_value-Nvl(b.stat_value,0) > 0
ORDER BY DELTA DESC
;


define test_id="earn_20160614"

SELECT *
FROM excellent.plsql_profiler_runs t
WHERE t.run_comment='&&test_id'
;

SELECT u.unit_type, u.unit_owner||'.'||u.unit_name AS unit, u.total_time
FROM excellent.plsql_profiler_units u,
     excellent.plsql_profiler_runs r
WHERE r.run_comment='&&test_id'
  AND r.runid=u.runid
ORDER BY u.total_time desc
;

SELECT u.unit_owner||'.'||u.unit_name AS unit,
       v.line#, v.total_occur, v.total_time, v.min_time, v.max_time, v.runid
FROM (
SELECT d.unit_number, d.line#, d.total_occur, d.total_time, d.min_time, d.max_time, d.runid
FROM excellent.plsql_profiler_data d
ORDER BY d.total_time DESC
 ) v, excellent.plsql_profiler_units u
 WHERE v.runid=u.runid AND v.unit_number=u.unit_number;

SELECT *
FROM (
SELECT u.unit_type, u.unit_owner||'.'||u.unit_name AS unit, d.line#, d.total_occur,d.total_time,
       Round(d.total_time/r.run_total_time*100,2) AS PctOfTotalTime,
       d.min_time,d.max_time
FROM excellent.plsql_profiler_data d,
     excellent.plsql_profiler_runs r,
     excellent.plsql_profiler_units u
WHERE r.run_comment='&&test_id'
  AND r.runid=d.runid
  AND r.runid=u.runid AND u.unit_number = d.unit_number
  AND u.unit_type != 'ANONYMOUS BLOCK'
ORDER BY PctOfTotalTime DESC
)
 WHERE PctOfTotalTime > 0
;