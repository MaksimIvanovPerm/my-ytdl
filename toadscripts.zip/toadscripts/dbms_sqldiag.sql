--https://oraclesurvivaldiary.wordpress.com/2018/11/26/apply-hint-on-sql-statement-without-changing-its-code/
--https://iusoltsev.wordpress.com/2016/10/17/12c-wrong-results-px-ofe/
--https://iusoltsev.wordpress.com/2011/09/30/bug-performance-2/
--https://sqlmaria.com/2020/03/10/what-are-query-block-names-and-how-to-find-them/
define v_sql_id="5pcctpbj8tsvn"
define v_ph="586745886"
define v_taskid="mytask1"
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ', ';
ALTER SESSION SET nls_date_format='yyyy.mm.dd-hh24:mi:ss';

DECLARE
l_task VARCHAR2(50);
l_report CLOB;
BEGIN
l_task := DBMS_SQLDIAG.create_diagnosis_task(sql_id=>'&&v_sql_id', plan_hash_value=>&&v_ph, task_name=>'&&v_taskid', 
problem_type => DBMS_SQLDIAG.PROBLEM_TYPE_PERFORMANCE );
dbms_sqltune.set_tuning_task_parameter(l_task, '_SQLDIAG_FINDING_MODE', DBMS_SQLDIAG.SQLDIAG_FINDINGS_FILTER_PLANS);
end;
/

select *
from sys.DBA_ADVISOR_TASKS t
where t.task_name='&&v_taskid'
;
 
exec DBMS_SQLDIAG.execute_diagnosis_task(task_name=>'&&v_taskid');
 
SET LONG 1000000 LONGCHUNKSIZE 1000000 LINESIZE 1000 PAGESIZE 0 TRIM ON TRIMSPOOL ON ECHO OFF FEEDBACK OFF
select dbms_sqldiag.report_diagnosis_task ('&&v_taskid')   as recommendations  from dual;
--select DBMS_SQLDIAG.report_diagnosis_task(taskname=>'&&v_taskid', type=>'TYPE_TEXT', level=>'LEVEL_ALL', section=>'SECTION_ALL') as report from dual;

DECLARE
v_sql CLOB;
BEGIN
--select sql_text into v_sql from dba_hist_sqltext where sql_id='bn7zqwkfgtr38';
--DBMS_SQLDIAG.CREATE_SQL_PATCH >=12.2
--dbms_sqldiag_internal.i_create_patch it applies hints directly, without accept_sql_patch routine
dbms_sqldiag_internal.i_create_patch(SQL_TEXT=>'select /*+ no_merge(v) */ count(*) from (select /*+ monitor */ * from testtab20210601 t where t.object_id=:b1) v', HINT_TEXT=>'ALL_ROWS', DESCRIPTION=>'&&v_taskid');
end;
/

select *
from sys.DBA_SQL_PATCHES t
where t.description='&&v_taskid'
;

exec DBMS_SQLDIAG.DROP_DIAGNOSIS_TASK(task_name=>'&&v_taskid'); 

exec DBMS_SQLDIAG.drop_sql_patch(name => 'SYS_SQLPTCH_0179c7c5f4b40000');


/*
OFF 0
ON 1
ALTER SYSTEM SET "_fix_control"='6377505:OFF','6006300:OFF';
OPT_PARAM('_fix_control' '6377505:OFF')
ALTER SYSTEM RESET "_fix_control";
*/
select t.* --t.bugno, t.value, t.is_default
from v$session_fix_control t
where t.session_id=926
  and t.sql_feature like '%7215982%'
;

select *
from v$system_fix_control t
where t.bugno in (26664361, 16732417, 20243268)
--order by t.event asc
;

select *
from v$parameter_valid_values t
order by t.num asc, t.ordinal asc
;
