SELECT *
FROM v$instance t;

SELECT *
FROM v$database t;

SELECT *
FROM sys.v$session_io t;

SELECT *
FROM sys.dba_segments t
WHERE t.owner='EXCELLENT'
ORDER BY t.bytes DESC;


SELECT Round(1439404/1024/1024/1024,2) AS val
FROM dual;

SELECT *
FROM sys.dba_directories t;

CREATE OR REPLACE DIRECTORY DBA_1126_DIR AS '/db/u03/backup/raddb/expdp';

SELECT *
FROM dba_ind_columns t
WHERE t.table_owner='EXCELLENT' AND t.table_name='GSV_AUTH_LOG_LIST';

SELECT  sn.name,
        t.value
FROM V$SESSTAT t, v$statname sn
WHERE t.sid=397
  AND t.STATISTIC#=sn.STATISTIC#
ORDER BY t.Value desc;


SELECT t.event, t.
FROM SYS.V_$SESSION_WAIT_HISTORY t
WHERE t.sid=397;

SELECT *
FROM sys.DBA_SCHEDULER_JOBS t
WHERE t.job_name='ACTIVE_AGREEMENTS_REFRESHER';

SELECT *
FROM SYS.DBA_SCHEDULER_JOB_RUN_DETAILS t
WHERE t.job_name='ACTIVE_AGREEMENTS_REFRESHER'
ORDER BY t.ACTUAL_START_DATE DESC;

SELECT t.username AS usr_name
FROM sys.dba_users t
WHERE regexp_like(t.username,'^EXCELLENT[0-9]?');

select  T.*
from SYS.DBA_TRIGGERS t
where T.TRIGGERING_EVENT='DDL ' and T.OWNER not in ('SYS','WMSYS','SYSTEM','SYSTEM','SYSMAN');

SELECT *
FROM sys.DBA_HIST_ACTIVE_SESS_HISTORY t
WHERE Trunc(t.sample_time,'DD')=To_Date('03.12.2014','dd.mm.yyyy')
  AND ROWNUM <= 10;

SELECT *
FROM sys.dba_users t
WHERE t.username='ERTEL_USER';

SELECT *
FROM dba_db_links t
WHERE Upper(t.username)='ERTEL_USER'
ORDER BY t.username;


SELECT *
FROM v$event_name t
WHERE t.name LIKE '%os%';

SELECT *
FROM v$event_name t
WHERE t.name LIKE '%thread%';

SELECT *
FROM sys.dba_data_files t
WHERE t.tablespace_name='SYSTEM';

SELECT *
FROM dba_directories t;

CREATE OR REPLACE DIRECTORY RAT_CAPTURE AS '/db/ratdata/dwh/';

SELECT *
FROM sys.DBA_WORKLOAD_CAPTURES t
WHERE t.id=11;

SELECT *
FROM sys.DBA_WORKLOAD_REPLAYS t
WHERE t.id=1;

SELECT  t.* -- DISTINCT regexp_substr(Lower(t.capture_conn),'host=[^\)]+')
FROM DBA_WORKLOAD_CONNECTION_MAP t
where
 -- replay_conn IS null and
 t.REPLAY_ID=2;

SELECT t.*
FROM dba_db_links t
ORDER BY t.owner;


SELECT 'drop database link '||t.owner||'.'||t.db_link AS cmd
FROM dba_db_links t
ORDER BY t.owner;

SELECT *
FROM  V$WORKLOAD_REPLAY_THREAD t;

SELECT Count(*)
FROM sys.DBA_WORKLOAD_REPLAY_DIVERGENCE t
WHERE t.replay_id=2;

SELECT Count(*),
       t.IS_ERROR_DIVERGENCE
FROM SYS.DBA_WORKLOAD_REPLAY_DIVERGENCE t
WHERE t.REPLAY_ID=2
GROUP BY t.IS_ERROR_DIVERGENCE
ORDER BY 1 DESC;

SELECT *
FROM (
SELECT  Count(*) AS err_count,
        t.sql_id AS sql_id
FROM SYS.DBA_WORKLOAD_REPLAY_DIVERGENCE t
WHERE t.REPLAY_ID=2
  AND t.IS_ERROR_DIVERGENCE='Y'
GROUP BY t.sql_id
ORDER BY 1 DESC
 )
 WHERE ROWNUM <= 25;

SELECT count(DISTINCT t.OBSERVED_ERROR#) AS obs_err
FROM SYS.DBA_WORKLOAD_REPLAY_DIVERGENCE t
WHERE t.REPLAY_ID=2
  AND t.IS_ERROR_DIVERGENCE='Y'
  AND t.sql_id='7yy34bcx0rwbc';

SELECT  count(*) AS err_count,
        t.OBSERVED_ERROR# AS obs_err
FROM SYS.DBA_WORKLOAD_REPLAY_DIVERGENCE t
WHERE t.REPLAY_ID=2
  AND t.IS_ERROR_DIVERGENCE='Y'
  AND t.sql_id='7yy34bcx0rwbc'
GROUP BY t.OBSERVED_ERROR#
ORDER BY 1 desc;

SELECT distinct t.OBSERVED_ERROR_MESSAGE
FROM SYS.DBA_WORKLOAD_REPLAY_DIVERGENCE t
WHERE t.REPLAY_ID=2
  AND t.IS_ERROR_DIVERGENCE='Y'
  AND t.sql_id='7yy34bcx0rwbc'
  and t.OBSERVED_ERROR#=24374;


SELECT *
FROM sys.dba_hist_wr_control t
WHERE t.dbid=(SELECT dbid FROM v$database);

EXEC DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(INTERVAL=>60);

select *
from SYS.WRM$_SNAPSHOT s
where s.dbid=2041257920 --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd')
order by s.snap_id DESC;


SELECT *
FROM dba_directories;

create or replace directory rat_capture as '/db/ratdata/dwh';

BEGIN
  DBMS_WORKLOAD_CAPTURE.ADD_FILTER (fname => 'USER_DBSNMP',fattribute => 'USER',fvalue => 'DBSNMP');
  DBMS_WORKLOAD_CAPTURE.ADD_FILTER (fname => 'USER_SYS',fattribute => 'USER',fvalue => 'SYS');
  DBMS_WORKLOAD_CAPTURE.ADD_FILTER (fname => 'USER_SYSMAN',fattribute => 'USER',fvalue => 'SYSMAN');
  DBMS_WORKLOAD_CAPTURE.ADD_FILTER (fname => 'USER_SYSTEM',fattribute => 'USER',fvalue => 'SYSTEM');
END;
/

select *
from DBA_WORKLOAD_FILTERS t
WHERE t.status='NEW';

SELECT *
FROM dba_users t
ORDER BY t.username;


SELECT *
FROM sys.wrh$_sqltext t
where t.dbid=3219746350
  AND t.sql_id='bspb8vzxhb5rk';

SELECT *
FROM sys.DBA_PROCEDURES t  WHERE t.object_id=139787;


BEGIN
/*auto_unrestrict=>FALSE should be if database, where capturing is started, had been fully opened already;
*/
  DBMS_WORKLOAD_CAPTURE.START_CAPTURE (name=>'03122014_cap',dir=>'RAT_CAPTURE',duration => (60*60*24),default_action=>'INCLUDE', auto_unrestrict=>FALSE);
END;
/

SELECT * FROM SYS.DBA_WORKLOAD_CAPTURES;

select  T.STATUS,
        t.START_TIME, t.END_TIME,
        T.FILTERS_USED,
        T.USER_CALLS_TOTAL, T.USER_CALLS,
        round(T.USER_CALLS/T.USER_CALLS_TOTAL, 2) as calls_pct,
        T.TRANSACTIONS_TOTAL,
        T.TRANSACTIONS,
        round(T.TRANSACTIONS/T.TRANSACTIONS_TOTAL, 2) as trans_pct,
        round(T.DBTIME/T.DBTIME_TOTAL, 2) as dbtime_pct,
        trunc(T.CAPTURE_SIZE/1024/1024,2) as captured_size_mb
from DBA_WORKLOAD_CAPTURES t
where t.id=11;