SELECT t.name||' '||t.DISPLAY_VALUE
FROM v$parameter t
WHERE t.name LIKE 'db_recover%';

SELECT t.OLDEST_FLASHBACK_SCN, t.OLDEST_FLASHBACK_TIME, Round(t.FLASHBACK_SIZE/1024/1024/1024,2) AS FLASHBACK_SIZE_GB
FROM V$FLASHBACK_DATABASE_LOG t;

SELECT * FROM V$FLASHBACK_DATABASE_LOGFILE t;

SELECT * FROM V$FLASHBACK_DATABASE_STAT t;

select *
from V$WORKLOAD_REPLAY_THREAD
where event not in ('WCR: replay client notify','SQL*Net message from client');

SELECT *
FROM sys.DBA_WORKLOAD_REPLAYS t;

SELECT  Count( Decode(t.IS_QUERY_DATA_DIVERGENCE,'Y',1,null) ) AS QUERY_DATA_DIVERGENCE,
        Count( Decode(t.IS_DML_DATA_DIVERGENCE,'Y',1,null) ) AS DML_DATA_DIVERGENCE,
        Count( Decode(t.IS_ERROR_DIVERGENCE,'Y',1,null) ) AS ERROR_DIVERGENCE,
        Count( Decode(t.IS_THREAD_FAILURE,'Y',1,null) ) AS THREAD_FAILURE,
        Count(*) AS total
FROM sys.DBA_WORKLOAD_REPLAY_DIVERGENCE t;

SELECT Count(*) AS err_count,
       t.SQL_ID
FROM sys.DBA_WORKLOAD_REPLAY_DIVERGENCE t
GROUP BY t.sql_id
ORDER BY 1 desc;


SELECT * FROM v$sql t WHERE t.sql_id='6jhp1jcsqyyaj';

SELECT *
FROM sys.wrh$_sqltext t
WHERE t.sql_id='6jhp1jcsqyyaj';








