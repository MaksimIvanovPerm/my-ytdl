select name from v$restore_point;
select open_mode, flashback_on from v$database;
select current_scn-(select scn from v$restore_point where name='R1')||'' as diff from v$database;
!ps aux | grep tnsl
!hostname -f
exit


sed --in-place -e "s/mass_test6/mass_test7/" ./cmd.sh; cat ./cmd.sh
at -f /home/oracle/cmd.sh now +30 minutes
cat /dev/null > cmd.log; tail -f -n 25 cmd.log
select GROUP#||' '||SEQUENCE#||' '||round(BYTES/1024/1024/1024,2)||' '||STATUS from  V$STANDBY_LOG;
select l.GROUP#||' '||l.status||' '||l.SEQUENCE#||' '||round(l.BYTES/1024/1024,2)||' '||l.STATUS||' '||l.ARCHIVED||' '||lf.member||' '||lf.type
from v$log l, v$logfile lf
where l.GROUP#=lf.GROUP#
order by lf.GROUP#;
select lf.member||' '||lf.type from v$logfile lf;
select DIRECTORY_NAME||' '||DIRECTORY_PATH from dba_directories order by DIRECTORY_NAME;
select name||' '||value from v$diag_info where NAME='Diag Trace';
-- exec DBMS_WORKLOAD_REPLAY.PROCESS_CAPTURE('RAT_CAPTURE');

@export_awr_snapshots.sql "3337426658" "61" "120" "RAT_CAPTURE"


alter session set nls_date_format='dd.mm.yyyy hh24:mi:ss';
select snap_id||' '||BEGIN_INTERVAL_TIME||' '||dbid
from  sys.wrm$_snapshot t
--where BEGIN_INTERVAL_TIME between  to_date('24.03.2014 17:00:00','dd-mm-yyyy hh24:mi:ss') and to_date('25.03.2014 15:05:14','dd-mm-yyyy hh24:mi:ss')
where t.snap_id > 299
and dbid=(select dbid from v$database)
order by snap_id;
-- 1-127

select min(snap_id), max(snap_id)
from  sys.wrm$_snapshot t
where BEGIN_INTERVAL_TIME between  to_date('24.07.2014 18:39:00','dd.mm.yyyy hh24:mi:ss') and to_date(' 28.07.2014 05:00:00','dd.mm.yyyy hh24:mi:ss')
and dbid=(select dbid from v$database)
order by snap_id;

--less /var/log/oracle/billing/diag/rdbms/billing/billing/trace/alert_billing.log
--$ORACLE_HOME/bin/nid target=sys/qwerty

shutdown immediate
startup mount
flashback database to restore point R1;
alter database open resetlogs;
drop restore point R1;
archive log list
--!rm -r /db/archive/billing/*.arclog
--!rm -f /u01/archive/billing/*.arclog
$ORACLE_HOME/bin/sqlplus -S "/ as sysdba" << __EOFF__
set pagesize 0
select LOG_MODE||' '||FORCE_LOGGING||' '||FLASHBACK_ON from  v\$database;
select FLASHBACK_ON||' '||name from v\$tablespace order by FLASHBACK_ON;
exit;
__EOFF__

alter system archive log current;
create restore point R1 guarantee flashback database;
select GUARANTEE_FLASHBACK_DATABASE||' '||name||' '||scn||' '||(select current_scn||'' from v$database) from v$restore_point;

alter user sys identified by qwerty;
alter user system identified by qwerty123;
!$ORACLE_HOME/bin/lsnrctl start; $ORACLE_HOME/bin/lsnrctl start mts_1522 $ORACLE_HOME/bin/lsnrctl start mts_1523
alter system register;
!$ORACLE_HOME/bin/lsnrctl status
alter session set nls_date_format='dd.mm.yyyy hh24:mi:ss';
select id||' '||name||' '||START_TIME||' '||END_TIME||' '||CAPTURE_ID||' '||STATUS||' '||SYNCHRONIZATION||' '||THINK_TIME_SCALE||' '||THINK_TIME_AUTO_CORRECT from DBA_WORKLOAD_REPLAYS;
select id||' '||name||' '||CAPTURE_ID||' '||STATUS||' '||SYNCHRONIZATION||' '||start_time from DBA_WORKLOAD_REPLAYS where id=3;
--exec DBMS_WORKLOAD_REPLAY.PROCESS_CAPTURE('RAT_CAPTURE');
--exec DBMS_WORKLOAD_REPLAY.CANCEL_REPLAY;
set verify off
define test_name="test1"
exec DBMS_WORKLOAD_REPLAY.INITIALIZE_REPLAY('&&test_name','RAT_CAPTURE');
select id||' '||name||' '||START_TIME||' '||END_TIME||' '||trunc((END_TIME-START_TIME)*24,2)||' '||CAPTURE_ID||' '||STATUS||' '||SYNCHRONIZATION||' '||THINK_TIME_SCALE||' '||THINK_TIME_AUTO_CORRECT from DBA_WORKLOAD_REPLAYS where name='&&test_name';
undefine test_name;

RAT_DIR="/db/ratdata/dwh/"
$ORACLE_HOME/bin/wrc mode=calibrate replaydir=$RAT_DIR

set pagesize 0
@./remap_conn.sql "17"
select REPLAY_ID||' '||CONN_ID||' '||CAPTURE_CONN||' '||REPLAY_CONN
from DBA_WORKLOAD_CONNECTION_MAP
where replay_conn IS null
 and REPLAY_ID=( select id from DBA_WORKLOAD_REPLAYS where name='&&test_name' );
@redefine_db_links.sql

conn / as sysdba
select dbid from v$database;

!rm -rf /home/oracle/oradiag_oracle
set serveroutput on
DECLARE
  v_current_max_snap_id   NUMBER;
  v_target_snap_id        NUMBER := &1;
begin
SELECT Max(snap_id) INTO v_current_max_snap_id
FROM sys.wrm$_snapshot
WHERE dbid=(SELECT dbid FROM v$database);
  Dbms_Output.put_line('Current max snap_id is: '||v_current_max_snap_id);
  IF v_current_max_snap_id <=  v_target_snap_id
  THEN
       FOR i IN  v_current_max_snap_id..v_target_snap_id
       LOOP
           DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();
            Dbms_Output.put_line('Current snap_id is: '||i);
       END LOOP;
  END IF;
  DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(retention=>20160, INTERVAL=>10);
END;
/

--EXEC DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();
EXEC DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(retention=>20160, INTERVAL=>10);
select DBID||' '||SNAP_INTERVAL||' '||RETENTION from DBA_HIST_WR_CONTROL where dbid=(select dbid from v$database);
select max(snap_id) from sys.wrm$_snapshot where DBID=(select dbid from v$database);
--exec dbms_workload_repository.create_snapshot;
--! rm -f /var/log/oracle/billing/diag/rdbms/billing/billing/trace/*.tr*
--! rm -f  /var/log/oracle/diag/tnslsnr/db3/listener/alert/*.xml
--! cat /dev/null > /var/log/oracle/diag/tnslsnr/db3/listener/trace/listener.log
--! rm -f /var/log/oracle/billing/audit/*.aud
exec DBMS_WORKLOAD_REPLAY.PREPARE_REPLAY (synchronization =>'OFF');
exec DBMS_WORKLOAD_REPLAY.PREPARE_REPLAY (synchronization =>'OFF',think_time_scale=>1,think_time_auto_correct=>FALSE);

-- $ORACLE_HOME/bin/wrc system/qwerty123@local mode=raplay REPLAYDIR=$RAT_DIR
!./startwrc.sh
!ps aux | grep wrc
--!ps -ael|grep wrc
set pagesize 0
alter session set nls_date_format='dd.mm.yyyy hh24:mi:ss';
exec DBMS_WORKLOAD_REPLAY.START_REPLAY();
!date
select SID||' '||SERIAL#||' '||LOGON_USER||' '||EVENT
from V$WORKLOAD_REPLAY_THREAD
where event not in ('WCR: replay client notify','SQL*Net message from client');

exec DBMS_WORKLOAD_REPLAY.CANCEL_REPLAY();

select COMPONENT||' '||CURRENT_SIZE||' '||OPER_COUNT||' '||USER_SPECIFIED_SIZE||' '||LAST_OPER_TYPE||' '||LAST_OPER_MODE from  v$sga_dynamic_components;

--!vim ./awr_dump_maker.sql
set feedback off
set echo off
set head off
set serveroutput on
spool ./make_awr_dump.sql replace
declare
    v_dbid      number;
    v_date      varchar2(16);
    v_b_snap_id number := &1;
    v_e_snap_id number := &2;
    v_host_name varchar2(30);
begin
    select dbid into v_dbid from v$database;
    select to_char(sysdate,'dd_mm_yyyy') into v_date from dual;
    select host_name into v_host_name from v$instance;
    dbms_output.put_line('define dbid = "'||v_dbid||'";');
    dbms_output.put_line('define num_days = 0;');
    dbms_output.put_line('define begin_snap = '||v_b_snap_id||';');
    dbms_output.put_line('define end_snap = '||v_e_snap_id||';');
    dbms_output.put_line('define directory_name = "TEMP_DIR"');
    dbms_output.put_line('define file_name      = "awr_'||v_host_name||'_'||v_date||'.dat"');
    dbms_output.put_line('@$ORACLE_HOME/rdbms/admin/awrextr.sql');
end;
/
spool off;
@./make_awr_dump.sql

@./awr_dump_maker.sql


vim get_new_dump_file.sh
#!/bin/bash

rm -f ./awr*
sudo mv /db/u13/backup/billing/awr_db*.dmp ./
sudo rm -f /db/u13/backup/billing/awr_db*
sudo chown maksimivanov:maksimivanov ./awr*
CMD=`ls -lt awr_db*.dmp | awk '{print "zip -9 "$9".zip "$9}'`
eval "$CMD"
ls -lth ./awr*
hostname -f

chmod u+x get_new_dump_file.sh

decalre
	v_x				number;
	v_point_name	varchar2(30) := 'R1';
	v_str			varchar2(30);
	fail_state		EXCEPTION;
begin
	select count(*)
	into v_x
	from v$restore_point where name=v_point_name;

	if v_x = 0
	then
		raise fail_state;
	end if;

	select GUARANTEE_FLASHBACK_DATABASE into v_str from v$restore_point where name=v_point_name;
	if v_str != 'YES'
	then
		raise fail_state;
	end if;

	dbms_output.put_line('ok restore point exists and it is guaranted point');

exception
	when fail_state then dbms_output.put_line('Workload replaying was not started;');
end;
/
