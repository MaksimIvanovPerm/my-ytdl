define tsk_name="CHKIDXFRAG"

SELECT *
FROM DBA_ADVISOR_DEFINITIONS t;


SELECT *
FROM dba_users t;

SELECT *
FROM sys.dba_segments t;

SELECT  t.OWNER AS owner,
        Round(Sum(t.BYTES)/1024/1024/1024,2) AS schema_size_Gb
FROM sys.dba_segments t
GROUP BY t.owner
ORDER BY 2 DESC;

SELECT  t.TABLESPACE_NAME,
        Round(Sum(t.BYTES)/1024/1024/1024,2) AS schema_size_Gb
FROM sys.dba_segments t
GROUP BY t.TABLESPACE_NAME
ORDER BY 2 DESC;

SELECT  t.SEGMENT_TYPE AS owner,
        Round(Sum(t.BYTES)/1024/1024/1024,2) AS schema_size_Gb
FROM sys.dba_segments t
WHERE t.owner='OKC'
GROUP BY t.SEGMENT_TYPE
ORDER BY 2 DESC;


SELECT Round(Sum(t.BYTES)/1024/1024/1024,2) AS DB_Size_Gb
FROM sys.dba_data_files t
WHERE t.TABLESPACE_NAME!='UNDOTBS1';

SELECT *
FROM sys.dba_data_files t;

SELECT * FROM V$TEMPSEG_USAGE t
ORDER BY t.BLOCKS desc

SELECT *
FROM sys.DBA_ADVISOR_TASKS t
WHERE t.task_name='&&tsk_name'
ORDER BY t.task_id desc;

SELECT *
FROM sys.DBA_ADVISOR_OBJECTS t
WHERE t.task_name='&&tsk_name'
ORDER BY t.OBJECT_ID;


SELECT *
FROM sys.DBA_ADVISOR_PARAMETERS t
WHERE t.task_name='&&tsk_name';

SELECT  alloc_space_mb,
        used_space_mb,
        CASE
        WHEN (alloc_space_mb - used_space_mb) > 0 THEN  (alloc_space_mb - used_space_mb)
        ELSE null
        END AS reclaimable_space_mb,
        obj_owner,
        obj_name
FROM (
SELECT  round(regexp_substr(regexp_substr(FND.MORE_INFO,'Allocated Space:[0-9]+'),'[0-9]+')/1024/1024,2) as alloc_space_mb,
        round(regexp_substr(regexp_substr(FND.MORE_INFO,'Used Space:[0-9]+'),'[0-9]+')/1024/1024,2) as used_space_mb,
        OBJ.ATTR1 as obj_owner,
        OBJ.ATTR2 as obj_name,
        obj.ATTR3 AS part_name
FROM sys.DBA_ADVISOR_FINDINGS fnd, sys.DBA_ADVISOR_OBJECTS obj
WHERE fnd.task_name='&&tsk_name'
  and FND.TASK_ID=OBJ.TASK_ID and FND.OBJECT_ID=OBJ.OBJECT_ID
  )
  ORDER BY reclaimable_space_mb desc;


SELECT *
FROM sys.DBA_ADVISOR_FINDINGS fnd
wherE fnd.task_name='&&tsk_name';

SELECT *
FROM sys.DBA_ADVISOR_OBJECTS obj
wherE obj.task_name='&&tsk_name';

SELECT * FROM v$log;

SELECT * FROM v$logfile;


SELECT *
FROM sys.dba_tables t
WHERE t.OWNER='OKC' AND t.PARTITIONED='NO';

SELECT *
FROM sys.dba_tab_partitions t
WHERE t.TABLE_OWNER='OKC';


SELECT DISTINCT t.OBJECT_NAME, t.SUBOBJECT_NAME, t.OBJECT_TYPE
FROM sys.dba_objects t
WHERE t.object_id IN ( select T.ITEM_NAME
from SYSTEM.temp_explains t
where T.METRIC > 280502151.4508*1.0054597
 )
AND t.owner='OKC'
ORDER BY t.OBJECT_TYPE;


select Count(T.ITEM_NAME)
from SYSTEM.temp_explains t
where T.METRIC > 280502151.4508*1.0054597;


SELECT *
FROM sys.dba_segments t
WHERE t.OWNER='OKC' AND t.SEGMENT_NAME='CISCO_AGENT_STATE_TRACE_PARTED' AND t.PARTITION_NAME='SYS_SUBP3530';


SELECT  v.OBJECT_NAME AS OBJECT_NAME,
        v.SUBOBJECT_NAME AS SUBOBJECT_NAME,
        v.object_type AS object_type,
        sg.bytes
FROM (
SELECT t.OBJECT_NAME, t.SUBOBJECT_NAME, t.object_type
FROM sys.dba_objects t
WHERE t.object_id IN ( select T.ITEM_NAME
from SYSTEM.temp_explains t
where T.METRIC > 280502151.4508*1.0054597
 )
AND t.owner='OKC' AND t.SUBOBJECT_NAME IS NOT NULL ) v,
sys.dba_segments sg
WHERE sg.SEGMENT_NAME=v.OBJECT_NAME AND sg.PARTITION_NAME=v.SUBOBJECT_NAME;


SELECT  v.OBJECT_NAME AS OBJECT_NAME,
        v.object_type AS object_type,
        sg.bytes
FROM (
SELECT t.OBJECT_NAME, t.object_type
FROM sys.dba_objects t
WHERE t.object_id IN ( select T.ITEM_NAME
from SYSTEM.temp_explains t
where T.METRIC > 280502151.4508*1.0054597
 )
AND t.owner='OKC' AND t.SUBOBJECT_NAME IS NULL ) v,
sys.dba_segments sg
WHERE sg.SEGMENT_NAME=v.OBJECT_NAME AND sg.PARTITION_NAME IS null;
