/*
drop table excellent.perf_data;
CREATE TABLE excellent.perf_data (
id NUMBER,
proc_num NUMBER,
SECOND NUMBER,
microsecond NUMBER,
runid number,
func_name VARCHAR2(128),
mod_name VARCHAR2(256)
);
*/

SELECT *
FROM excellent.perf_data t
;

SELECT t.SECOND*100000+t.microsecond AS microseconds,
       t.runid
FROM excellent.perf_data t
;

SELECT t.func_name, t.mod_name,
       t.runid
FROM excellent.perf_data t
;

define avg_sample_time="0.275374"

SELECT v1.runid_duration AS run_duration,
       v1.runid AS runid,
       v2.func_name, v2.mod_name
FROM (
SELECT CASE
        WHEN ( Max(t.SECOND*100000+t.microsecond) - Min(t.SECOND*100000+t.microsecond) ) > 0 THEN ( Max(t.SECOND*100000+t.microsecond) - Min(t.SECOND*100000+t.microsecond) )
        ELSE  &&avg_sample_time/2
       END AS runid_duration,
       t.runid
FROM excellent.perf_data t
GROUP BY t.runid
) v1,
(SELECT t2.func_name, t2.mod_name, t2.runid
FROM excellent.perf_data t2) v2
WHERE v1.runid=v2.runid
  --AND v2.func_name='spl_kmem_cache_alloc'
ORDER BY run_duration DESC
;

SELECT Sum(v1.runid_duration)/1000000 AS run_duration,
       v2.mod_name AS MODULE,
       v2.func_name AS func_name
FROM (
SELECT CASE
        WHEN ( Max(t.SECOND*100000+t.microsecond) - Min(t.SECOND*100000+t.microsecond) ) > 0 THEN ( Max(t.SECOND*100000+t.microsecond) - Min(t.SECOND*100000+t.microsecond) )
        ELSE &&avg_sample_time/2
       END AS runid_duration,
       t.runid
FROM excellent.perf_data t
GROUP BY t.runid
) v1,
(SELECT t2.func_name, t2.mod_name, t2.runid
FROM excellent.perf_data t2) v2
WHERE v1.runid=v2.runid
GROUP BY v2.mod_name,v2.func_name
ORDER BY run_duration DESC
;

SELECT Sum(v1.runid_duration)/1000000 AS run_duration,
        --v2.func_name AS func_name,
        v2.mod_name AS MODULE
FROM (
SELECT CASE
        WHEN ( Max(t.SECOND*100000+t.microsecond) - Min(t.SECOND*100000+t.microsecond) ) > 0 THEN ( Max(t.SECOND*100000+t.microsecond) - Min(t.SECOND*100000+t.microsecond) )
        ELSE &&avg_sample_time/2
       END AS runid_duration,
       t.runid
FROM excellent.perf_data t
GROUP BY t.runid
) v1,
(SELECT t2.func_name, t2.mod_name, t2.runid
FROM excellent.perf_data t2) v2
WHERE v1.runid=v2.runid
  AND v2.func_name NOT IN ('function_trace_call','ftrace_caller','ftrace_test_stop_func','ftrace_stub')
GROUP BY v2.mod_name
ORDER BY run_duration desc
;