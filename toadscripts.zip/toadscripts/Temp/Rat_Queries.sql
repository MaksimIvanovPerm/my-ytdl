select * from dba_directories; 

select * from v$database;

select *
from SYS.WRM$_DATABASE_INSTANCE t
where T.dbid=3432209923;

select t.*
from AWR_PUBLISHER.DBID_DBNAME t 
where --T.dbid=3432209923; 
     T.DB_TYPE='eqm'
 and T.CITYNAME='samara';
--order by T.CITYNAME;

select  min(S.SNAP_ID) as min_snap_id,
        max(s.snap_id) as max_snap_id,
        min(S.BEGIN_INTERVAL_TIME) as min_time,
        max(S.BEGIN_INTERVAL_TIME) as max_time
from SYS.WRM$_SNAPSHOT s
where s.dbid=3432209923 
--and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd') 
;

select *
from SYS.WRM$_SNAPSHOT s
where s.dbid=3432209923 --and S.BEGIN_INTERVAL_TIME between to_date('2013.08.01','yyyy.mm.dd') and to_date('2013.10.10','yyyy.mm.dd') 
order by s.snap_id desc;

select *
from (
with    
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, TMN.STAT_NAME as stat_name, ST.VALUE as stat_value
                from SYS.wrm$_snapshot s, SYS.WRH$_SYS_TIME_MODEL st,
                     SYS.WRH$_STAT_NAME tmn, SYS.WRM$_DATABASE_INSTANCE d
                where S.SNAP_ID=ST.SNAP_ID and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER
                  and ST.STAT_ID=TMN.STAT_ID
                      and D.dbid=3432209923 and D.DBID=S.dbid and D.INSTANCE_NUMBER=S.INSTANCE_NUMBER
                  and D.STARTUP_TIME=S.STARTUP_TIME
                  and S.snap_id between 4333 and 4692
),
        b as ( select * from local_data ),
        e as ( select * from local_data )
select  to_char(e.snap_time,'dd.mm.yyyy hh24:mi') as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('DB time' as db_time,'DB CPU' as db_cpu,
      'background elapsed time' as bgrnd_el_tm,'background cpu time' as
      bgrnd_cpu_tm,'sequence load elapsed time' as seq_load_el_tm,
      'parse time elapsed' as parse_el_tm,'hard parse elapsed time' as
      hard_parse_el_tm,'sql execute elapsed time' as sql_exec_el_tm,
      'connection management call elapsed time' as conn_mgmnt_call_el_tm,
      'failed parse elapsed time' as failed_parse_el_tm,
      'failed parse (out of shared memory) elapsed time' as
      fail_parse_outofshmem_el_tm,'hard parse (sharing criteria) elapsed time' as hrd_parse_sharing_crit_el_tm,
      'hard parse (bind mismatch) elapsed time' as hrd_prs_bing_mismtch_el_tm,
      'PL/SQL execution elapsed time' as plsql_exec_el_tm,
      'inbound PL/SQL rpc elapsed time' as inbnd_plsql_rpc_el_tm,
      'PL/SQL compilation elapsed time' as plsql_compile_el_tm,
      'Java execution elapsed time' as java_exec_el_tm,
      'repeated bind elapsed time' as repeat_bind_el_tm,
      'RMAN cpu time (backup/restore)' as rman_bcp_rstr_cpu_tm)
)
where db_time is not null
order by snap_id;

--Wait time by wait clesses
select snap_time, snap_id, Concurrency, UserIO, SystemIO, Administrative, Other, Configuration, Application, Network, Commit
from (
with    local_data as (select    S.BEGIN_INTERVAL_TIME as snap_time,
                        S.SNAP_ID as snap_id,
                        en.WAIT_CLASS as stat_name,
                        sum(SE.TIME_WAITED_MICRO) as stat_value
              from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSTEM_EVENT se, SYS.WRH$_EVENT_NAME en
              where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
                    and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
                    and SE.EVENT_ID=EN.EVENT_ID and SE.DBID=EN.DBID
                    and S.SNAP_ID between 4333 and 4692  
                group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.WAIT_CLASS
             ),
        b as (
                select * from local_data
             ),
        e as (
               select * from local_data
              )
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in ('Cluster' as Clster, 'Concurrency' as Concurrency,'User I/O' as UserIO,'System I/O' as SystemIO,'Administrative' as Administrative,'Other' as Other,'Configuration' as Configuration,'Application' as Application,'Idle' as Idle,'Network' as Network,'Commit' as Commit)
    )
order by snap_id;

-- Application class
select *
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 
  'enq: PW - flush prewarm buffers','enq: RO - contention','enq: RO - fast object reuse','enq: KO - fast object checkpoint','enq: TM - contention','enq: TX - row lock contention','Wait for Table Lock','enq: RC - Result Cache: Contention','Streams capture: filter callback waiting for ruleset','Streams: apply reader waiting for DDL to apply','SQL*Net break/reset to client','SQL*Net break/reset to dblink','External Procedure initial connection','External Procedure call','enq: UL - contention','OLAP DML Sleep','WCR: replay lock order'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in 
(
'enq: PW - flush prewarm buffers' as enqPW_flush_prewarm_buffers,
'enq: RO - contention' as eqnRO_contention,
'enq: RO - fast object reuse' as eqnRO_fast_object_reuse,
'enq: KO - fast object checkpoint' as eqnKO_fast_object_checkpoint,
'enq: TM - contention' as eqnTM_contention,
'enq: TX - row lock contention' as eqnTX_row_lock_contention,
'Wait for Table Lock' as Wait_for_Table_Lock,
'enq: RC - Result Cache: Contention' as eqnRC_ResultCacheContention,
'Streams capture: filter callback waiting for ruleset' as StrmsCptrFltrCallbackWt4rlst,
'Streams: apply reader waiting for DDL to apply' as StreamsApplRdrW4DDL2apply,
'SQL*Net break/reset to client' as SQL_Net_break_reset_to_client,
'SQL*Net break/reset to dblink' as SQL_Net_break_reset_to_dblink,
'External Procedure initial connection' as ExtProcInitialConnection,
'External Procedure call' as External_Procedure_call,
'enq: UL - contention' as eqnUL___contention,
'OLAP DML Sleep' as OLAP_DML_Sleep,
'WCR: replay lock order' as WCR__replay_lock_order)
    )
order by snap_id;

--------------------------------------------------------------------------------

-- Network class
select *
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 
  'remote db operation','remote db file read','remote db file write','ARCH wait for net re-connect','LGWR wait on ATTACH','ARCH wait on ATTACH','ARCH wait for netserver start','LNS wait on ATTACH','LNS wait on SENDREQ','LNS wait on DETACH','LGWR wait on SENDREQ','LGWR wait on DETACH','ARCH wait on SENDREQ','ARCH wait on DETACH','ARCH wait for netserver init 2','LNS wait on LGWR','LGWR wait on LNS','ARCH wait for flow-control','ARCH wait for netserver detach','TCP Socket (KGAS)','virtual circuit wait','dispatcher listen timer','dedicated server timer','SQL*Net message to client','SQL*Net message to dblink','SQL*Net more data to client','SQL*Net more data to dblink','SQL*Net more data from client','SQL*Net message from dblink','SQL*Net more data from dblink','SQL*Net vector data to client','SQL*Net vector data from client','SQL*Net vector data to dblink','SQL*Net vector data from dblink','TEXT: URL_DATASTORE network wait'
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in 
(
'remote db operation' as remote_db_operation,
'remote db file read' as remote_db_file_read,
'remote db file write' as remote_db_file_write,
'ARCH wait for net re-connect' as ARCH_wait_for_net_re_connect,
'LGWR wait on ATTACH' as LGWR_wait_on_ATTACH,
'ARCH wait on ATTACH' as ARCH_wait_on_ATTACH,
'ARCH wait for netserver start' as ARCH_wait_for_netserver_start,
'LNS wait on ATTACH' as LNS_wait_on_ATTACH,
'LNS wait on SENDREQ' as LNS_wait_on_SENDREQ,
'LNS wait on DETACH' as LNS_wait_on_DETACH,
'LGWR wait on SENDREQ' as LGWR_wait_on_SENDREQ,
'LGWR wait on DETACH' as LGWR_wait_on_DETACH,
'ARCH wait on SENDREQ' as ARCH_wait_on_SENDREQ,
'ARCH wait on DETACH' as ARCH_wait_on_DETACH,
'ARCH wait for netserver init 2' as ARCH_wait_for_netserver_init_2,
'LNS wait on LGWR' as LNS_wait_on_LGWR,
'LGWR wait on LNS' as LGWR_wait_on_LNS,
'ARCH wait for flow-control' as ARCH_wait_for_flow_control,
'ARCH wait for netserver detach' as ARCH_wait_for_netserver_detach,
'TCP Socket (KGAS)' as TCP_Socket__KGAS_,
'virtual circuit wait' as virtual_circuit_wait,
'dispatcher listen timer' as dispatcher_listen_timer,
'dedicated server timer' as dedicated_server_timer,
'SQL*Net message to client' as SQL_Net_message_to_client,
'SQL*Net message to dblink' as SQL_Net_message_to_dblink,
'SQL*Net more data to client' as SQL_Net_more_data_to_client,
'SQL*Net more data to dblink' as SQL_Net_more_data_to_dblink,
'SQL*Net more data from client' as SQL_Net_more_data_from_client,
'SQL*Net message from dblink' as SQL_Net_message_from_dblink,
'SQL*Net more data from dblink' as SQL_Net_more_data_from_dblink,
'SQL*Net vector data to client' as SQL_Net_vector_data_to_client,
'SQL*Net vector data from client' as SQLNet_vector_data_4fm_client,
'SQL*Net vector data to dblink' as SQL_Net_vector_data_to_dblink,
'SQL*Net vector data from dblink' as SQLNet_vector_data4rmdblink,
'TEXT: URL_DATASTORE network wait' as TEXT_URL_DATASTORE_ntwrk_wt
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Concurrency Class Wait Structure
select *
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'buffer busy waits','cursor: mutex S','cursor: mutex X','cursor: pin S','cursor: pin S wait on X','cursor: pin X','db flash cache invalidate wait','enq: HV - contention','enq: TX - index contention','enq: WG - lock fso','latch: cache buffers chains','latch: In memory undo latch','latch: MQL Tracking Latch','latch: row cache objects','latch: shared pool','latch: Undo Hint Latch','libcache interrupt action by LCK','library cache load lock','library cache lock','library cache: mutex S','library cache: mutex X','library cache pin','logout restrictor','os thread startup','pipe put','resmgr:internal state change','resmgr:sessions to exit','row cache lock','row cache read','securefile chain update','SecureFile mutex','Shared IO Pool Memory','Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from loca_data
),
e as (
  select * from loca_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in 
(
'buffer busy waits' as buffer_busy_waits,
'cursor: mutex S' as cursor__mutex_S,
'cursor: mutex X' as cursor__mutex_X,
'cursor: pin S' as cursor__pin_S,
'cursor: pin S wait on X' as cursor__pin_S_wait_on_X,
'cursor: pin X' as cursor__pin_X,
'db flash cache invalidate wait' as db_flash_cache_invalidate_wait,
'enq: HV - contention' as eqnHV___contention,
'enq: TX - index contention' as eqnTX___index_contention,
'enq: WG - lock fso' as eqnWG___lock_fso,
'latch: cache buffers chains' as latch__cache_buffers_chains,
'latch: In memory undo latch' as latch__In_memory_undo_latch,
'latch: MQL Tracking Latch' as latch__MQL_Tracking_Latch,
'latch: row cache objects' as latch__row_cache_objects,
'latch: shared pool' as latch__shared_pool,
'latch: Undo Hint Latch' as latch__Undo_Hint_Latch,
'libcache interrupt action by LCK' as lc_interrupt_action_by_LCK,
'library cache load lock' as library_cache_load_lock,
'library cache lock' as library_cache_lock,
'library cache: mutex S' as library_cache__mutex_S,
'library cache: mutex X' as library_cache__mutex_X,
'library cache pin' as library_cache_pin,
'logout restrictor' as logout_restrictor,
'os thread startup' as os_thread_startup,
'pipe put' as pipe_put,
'resmgr:internal state change' as resmgr_internal_state_change,
'resmgr:sessions to exit' as resmgr_sessions_to_exit,
'row cache lock' as row_cache_lock,
'row cache read' as row_cache_read,
'securefile chain update' as securefile_chain_update,
'SecureFile mutex' as SecureFile_mutex,
'Shared IO Pool Memory' as SharedIOPoolMemory,
'Streams apply: waiting for dependency' as StrmsApplyWt4dependency
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- UserIO Wait time structure
select *
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'Archive Manager file transfer I/O','ASM Fixed Package I/O','ASM Staleness File I/O','BFILE read','buffer read retry','cell list of blocks physical read','cell multiblock physical read','cell single block physical read','cell smart file creation','cell smart index scan','cell smart table scan','cell statistics gather','Data file init write','Datapump dump file I/O','db file parallel read','db file scattered read','db file sequential read','db file single write','db flash cache multiblock physical read','db flash cache single block physical read','db flash cache write','dbms_file_transfer I/O','dbverify reads','DG Broker configuration file I/O','direct path read','direct path read temp','direct path sync','direct path write','direct path write temp','Disk file I/O Calibration','Disk file Mirror Read','Disk file Mirror/Media Repair Write','Disk file operations I/O','external table misc IO','external table open','external table read','external table seek','external table write','flashback log file sync','local write wait','Log file init write','Parameter File I/O','read by other session','securefile direct-read completion','securefile direct-write completion','Shared IO Pool IO Completion','TEXT: File System I/O','utl_file I/O' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'Archive Manager file transfer I/O' as ArchManagerFileTransferIO,
'ASM Fixed Package I/O' as ASM_Fixed_Package_I_O,
'ASM Staleness File I/O' as ASM_Staleness_File_I_O,
'BFILE read' as BFILE_read,
'buffer read retry' as buffer_read_retry,
'cell list of blocks physical read' as cell_list_of_blcksPhRead,
'cell multiblock physical read' as cell_multiblock_physical_read,
'cell single block physical read' as cell_single_blockPhRead,
'cell smart file creation' as cell_smart_file_creation,
'cell smart index scan' as cell_smart_index_scan,
'cell smart table scan' as cell_smart_table_scan,
'cell statistics gather' as cell_statistics_gather,
'Data file init write' as Data_file_init_write,
'Datapump dump file I/O' as Datapump_dump_file_I_O,
'db file parallel read' as db_file_parallel_read,
'db file scattered read' as db_file_scattered_read,
'db file sequential read' as db_file_sequential_read,
'db file single write' as db_file_single_write,
'db flash cache multiblock physical read' as db_flash_cache_mblckPhRead,
'db flash cache single block physical read' as db_flash_cache_sblckPhRead,
'db flash cache write' as db_flash_cache_write,
'dbms_file_transfer I/O' as dbms_file_transfer_I_O,
'dbverify reads' as dbverify_reads,
'DG Broker configuration file I/O' as DGBConfFileIO,
'direct path read' as direct_path_read,
'direct path read temp' as direct_path_read_temp,
'direct path sync' as direct_path_sync,
'direct path write' as direct_path_write,
'direct path write temp' as direct_path_write_temp,
'Disk file I/O Calibration' as Disk_file_I_O_Calibration,
'Disk file Mirror Read' as Disk_file_Mirror_Read,
'Disk file Mirror/Media Repair Write' as DiskFileMirrorMediaRepairWrite,
'Disk file operations I/O' as Disk_file_operations_I_O,
'external table misc IO' as external_table_misc_IO,
'external table open' as external_table_open,
'external table read' as external_table_read,
'external table seek' as external_table_seek,
'external table write' as external_table_write,
'flashback log file sync' as flashback_log_file_sync,
'local write wait' as local_write_wait,
'Log file init write' as Log_file_init_write,
'Parameter File I/O' as Parameter_File_I_O,
'read by other session' as read_by_other_session,
'securefile direct-read completion' as securefileDirectRdCompletion,
'securefile direct-write completion' as securefileDirectWrCompletion,
'Shared IO Pool IO Completion' as Shared_IO_Pool_IO_Completion,
'TEXT: File System I/O' as TEXT__File_System_I_O,
'utl_file I/O' as utl_file_I_O
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Configuration Wait time structure
select *
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'free buffer waits','checkpoint completed','write complete waits','write complete waits: flash cache','latch: redo writing','latch: redo copy','log buffer space','log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','flashback buf free by RVWR','enq: ST - contention','undo segment extension','undo segment tx slot','enq: TX - allocate ITL entry','statement suspended, wait error to be cleared','enq: HW - contention','enq: SS - contention','sort segment request','enq: SQ - contention','Global transaction acquire instance locks','Streams apply: waiting to commit','wait for EMON to process ntfns' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in 
(
'free buffer waits' as free_buffer_waits,
'checkpoint completed' as checkpoint_completed,
'write complete waits' as write_complete_waits,
'write complete waits: flash cache' as writeCompleteWaitsFlashCache,
'latch: redo writing' as latch__redo_writing,
'latch: redo copy' as latch__redo_copy,
'log buffer space' as log_buffer_space,
'log file switch (checkpoint incomplete)' as logFileSwitchChckptIncomplete_,
'log file switch (private strand flush incomplete)' as LFSwitchPrivStrandFlushIncmplt,
'log file switch (archiving needed)' as LFSwitchArchiving_needed,
'log file switch completion' as lfs_completion,
'flashback buf free by RVWR' as flashback_buf_free_by_RVWR,
'enq: ST - contention' as enqSTcontention,
'undo segment extension' as undo_segment_extension,
'undo segment tx slot' as undo_segment_tx_slot,
'enq: TX - allocate ITL entry' as enqTXallocate_ITL_entry,
'statement suspended, wait error to be cleared' as StmtSspnddWaitErrToBeCleared,
'enq: HW - contention' as enqHWcontention,
'enq: SS - contention' as enqSScontention,
'sort segment request' as sort_segment_request,
'enq: SQ - contention' as enqSQcontention,
'Global transaction acquire instance locks' as GlblTrnsAcquireInstanceLocks,
'Streams apply: waiting to commit' as StreamsApplyWaiting_to_commit,
'wait for EMON to process ntfns' as wait_for_EMON_to_process_ntfns
)
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Others
-- See R-script AnalyzeOthersWaitClass.r and do
-- cat ./class_events.txt | grep -f ./filter.txt at dwh
select  snap_time,
        snap_id,
        E47,E49,E155,E197,E244,E340,E351,E357,E358,E362,E504,E528,E533,E534,E538,E539,E540,E547,E548,E551,E552,E553,E554,E559,E656,E664,E694,E736
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'ack for a broadcasted res from a remote instance' as e1,
'ADR block file read' as e2,
'ADR block file write' as e3,
'ADR file lock' as e4,
'affinity expansion in replay' as e5,
'AQ propagation connection' as e6,
'AQ spill debug idle' as e7,
'ARCH wait for archivelog lock' as e8,
'ARCH wait for process death 1' as e9,
'ARCH wait for process start 1' as e10,
'ARCH wait for process start 3' as e11,
'ARCH wait on c/f tx acquire 1' as e12,
'ASM background starting' as e13,
'ASM cluster file access' as e14,
'ASM db client exists' as e15,
'ASM DG Unblock' as e16,
'ASM file metadata operation' as e17,
'ASM Instance startup' as e18,
'ASM internal hang test' as e19,
'ASM: MARK subscribe to msg channel' as e20,
'ASM metadata cache frozen' as e21,
'ASM network foreground exits' as e22,
'ASM: OFS Cluster membership update' as e23,
'ASM PST operation' as e24,
'ASM Volume Background' as e25,
'asynch descriptor resize' as e26,
'Auto BMR completion' as e27,
'Auto BMR RPC standby catchup' as e28,
'AWR Flush' as e29,
'AWR Metric Capture' as e30,
'Backup Restore Event 19778 sleep' as e31,
'Backup Restore Switch Bitmap sleep' as e32,
'Backup Restore Throttle sleep' as e33,
'BFILE check if exists' as e34,
'BFILE check if open' as e35,
'BFILE closure' as e36,
'BFILE get length' as e37,
'BFILE get name object' as e38,
'BFILE get path object' as e39,
'BFILE internal seek' as e40,
'BFILE open' as e41,
'block change tracking buffer space' as e42,
'blocking txn id for DDL' as e43,
'broadcast mesg queue transition' as e44,
'broadcast mesg recovery queue transition' as e45,
'buffer busy' as e46,
'buffer deadlock' as e47,
'buffer dirty disabled' as e48,
'buffer exterminate' as e49,
'buffer freelistbusy' as e50,
'buffer invalidation wait' as e51,
'buffer latch' as e52,
'buffer rememberlist busy' as e53,
'buffer resize' as e54,
'buffer write wait' as e55,
'buffer writeList full' as e56,
'cell manager cancel work request' as e57,
'cell smart flash unkeep' as e58,
'cell worker online completion' as e59,
'cell worker retry ' as e60,
'CGS skgxn join retry' as e61,
'CGS wait for IPC msg' as e62,
'change tracking file parallel write' as e63,
'change tracking file synchronous read' as e64,
'change tracking file synchronous write' as e65,
'check CPU wait times' as e66,
'checkpoint advanced' as e67,
'cleanup of aborted process' as e68,
'Cluster stabilization wait' as e69,
'Cluster Suspension wait' as e70,
'Compression analysis' as e71,
'control file diagnostic dump' as e72,
'control file heartbeat' as e73,
'cr request retry' as e74,
'CRS call completion' as e75,
'CSS group membership query' as e76,
'CSS group registration' as e77,
'CSS initialization' as e78,
'CSS operation: action' as e79,
'CSS operation: data query' as e80,
'CSS operation: data update' as e81,
'CSS operation: diagnostic' as e82,
'CSS operation: query' as e83,
'CSS Xgrp shared operation' as e84,
'CTWR media recovery checkpoint request' as e85,
'Data Guard Broker Wait' as e86,
'Data Guard: process clean up' as e87,
'Data Guard: process exit' as e88,
'Data Guard: RFS disk I/O' as e89,
'Data Pump slave init' as e90,
'Data Pump slave startup' as e91,
'datafile move cleanup during resize' as e92,
'DBMS_LDAP: LDAP operation ' as e93,
'DBWR range invalidation sync' as e94,
'debugger command' as e95,
'DFS db file lock' as e96,
'DFS lock handle' as e97,
'dispatcher shutdown' as e98,
'dma prepare busy' as e99,
'DSKM to complete cell health check' as e100,
'dupl. cluster key' as e101,
'EMON slave messages' as e102,
'EMON termination' as e103,
'enq: AB - ABMR process initialized' as e104,
'enq: AB - ABMR process start/stop' as e105,
'enq: AD - allocate AU' as e106,
'enq: AD - deallocate AU' as e107,
'enq: AD - relocate AU' as e108,
'enq: AE - lock' as e109,
'enq: AF - task serialization' as e110,
'enq: AG - contention' as e111,
'enq: AM - ASM ACD Relocation' as e112,
'enq: AM - ASM Amdu Dump' as e113,
'enq: AM - ASM cache freeze' as e114,
'enq: AM - ASM disk based alloc/dealloc' as e115,
'enq: AM - ASM file descriptor' as e116,
'enq: AM - ASM File Destroy' as e117,
'enq: AM - ASM file relocation' as e118,
'enq: AM - ASM Grow ACD' as e119,
'enq: AM - ASM Password File Update' as e120,
'enq: AM - ASM reserved' as e121,
'enq: AM - ASM User' as e122,
'enq: AM - background COD reservation' as e123,
'enq: AM - block repair' as e124,
'enq: AM - client registration' as e125,
'enq: AM - disk offline' as e126,
'enq: AM - group block' as e127,
'enq: AM - group use' as e128,
'enq: AM - rollback COD reservation' as e129,
'enq: AM - shutdown' as e130,
'enq: AO - contention' as e131,
'enq: AP - contention' as e132,
'enq: AS - service activation' as e133,
'enq: AT - contention' as e134,
'enq: AV - add/enable first volume in DG' as e135,
'enq: AV - AVD client registration' as e136,
'enq: AV - persistent DG number' as e137,
'enq: AV - volume relocate' as e138,
'enq: AW - AW generation lock' as e139,
'enq: AW - AW state lock' as e140,
'enq: AW - AW$ table lock' as e141,
'enq: AW - user access for AW' as e142,
'enq: AY - contention' as e143,
'enq: BF - allocation contention' as e144,
'enq: BF - PMON Join Filter cleanup' as e145,
'enq: BM - clonedb bitmap file write' as e146,
'enq: BR - file shrink' as e147,
'enq: BR - multi-section restore header' as e148,
'enq: BR - multi-section restore section' as e149,
'enq: BR - perform autobackup' as e150,
'enq: BR - proxy-copy' as e151,
'enq: BR - request autobackup' as e152,
'enq: BR - space info datafile hdr update' as e153,
'enq: CA - contention' as e154,
'enq: CF - contention' as e155,
'enq: CI - contention' as e156,
'enq: CL - compare labels' as e157,
'enq: CL - drop label' as e158,
'enq: CM - diskgroup dismount' as e159,
'enq: CM - gate' as e160,
'enq: CM - instance' as e161,
'enq: CN - race with init' as e162,
'enq: CN - race with reg' as e163,
'enq: CN - race with txn' as e164,
'enq: CO - master slave det' as e165,
'enq: CQ - contention' as e166,
'enq: CR - block range reuse ckpt' as e167,
'enq: CT - change stream ownership' as e168,
'enq: CT - CTWR process start/stop' as e169,
'enq: CT - global space management' as e170,
'enq: CT - local space management' as e171,
'enq: CT - reading' as e172,
'enq: CT - state' as e173,
'enq: CT - state change gate 1' as e174,
'enq: CT - state change gate 2' as e175,
'enq: CU - contention' as e176,
'enq: CX - TEXT: Index Specific Lock' as e177,
'enq: DD - contention' as e178,
'enq: DF - contention' as e179,
'enq: DG - contention' as e180,
'enq: DL - contention' as e181,
'enq: DM - contention' as e182,
'enq: DN - contention' as e183,
'enq: DO - disk online' as e184,
'enq: DO - disk online operation' as e185,
'enq: DO - disk online recovery' as e186,
'enq: DO - Staleness Registry create' as e187,
'enq: DO - startup of MARK process' as e188,
'enq: DP - contention' as e189,
'enq: DR - contention' as e190,
'enq: DS - contention' as e191,
'enq: DT - contention' as e192,
'enq: DV - contention' as e193,
'enq: DW - contention' as e194,
'enq: DX - contention' as e195,
'enq: FA - access file' as e196,
'enq: FB - contention' as e197,
'enq: FC - open an ACD thread' as e198,
'enq: FC - recover an ACD thread' as e199,
'enq: FD - Flashback coordinator' as e200,
'enq: FD - Flashback logical operations' as e201,
'enq: FD - Flashback on/off' as e202,
'enq: FD - Marker generation' as e203,
'enq: FD - Restore point create/drop' as e204,
'enq: FD - Tablespace flashback on/off' as e205,
'enq: FE - contention' as e206,
'enq: FG - FG redo generation enq race' as e207,
'enq: FG - LGWR redo generation enq race' as e208,
'enq: FG - serialize ACD relocate' as e209,
'enq: FL - Flashback database log' as e210,
'enq: FL - Flashback db command' as e211,
'enq: FM - contention' as e212,
'enq: FP - global fob contention' as e213,
'enq: FR - contention' as e214,
'enq: FR - recover the thread' as e215,
'enq: FR - use the thread' as e216,
'enq: FS - contention' as e217,
'enq: FT - allow LGWR writes' as e218,
'enq: FT - disable LGWR writes' as e219,
'enq: FU - contention' as e220,
'enq: FX - issue ACD Xtnt Relocation CIC' as e221,
'enq: HD - contention' as e222,
'enq: HP - contention' as e223,
'enq: HQ - contention' as e224,
'enq: IA - contention' as e225,
'enq: ID - contention' as e226,
'enq: IL - contention' as e227,
'enq: IM - contention for blr' as e228,
'enq: IR - contention' as e229,
'enq: IR - contention2' as e230,
'enq: IS - contention' as e231,
'enq: IT - contention' as e232,
'enq: JD - contention' as e233,
'enq: JI - contention' as e234,
'enq: JQ - contention' as e235,
'enq: JS - aq sync' as e236,
'enq: JS - contention' as e237,
'enq: JS - evt notify' as e238,
'enq: JS - evtsub add' as e239,
'enq: JS - evtsub drop' as e240,
'enq: JS - job recov lock' as e241,
'enq: JS - job run lock - synchronize' as e242,
'enq: JS - q mem clnup lck' as e243,
'enq: JS - queue lock' as e244,
'enq: JS - sch locl enqs' as e245,
'enq: JS - wdw op' as e246,
'enq: KD - determine DBRM master' as e247,
'enq: KM - contention' as e248,
'enq: KP - contention' as e249,
'enq: KQ - access ASM attribute' as e250,
'enq: KT - contention' as e251,
'enq: MD - contention' as e252,
'enq: MH - contention' as e253,
'enq: MK - contention' as e254,
'enq: ML - contention' as e255,
'enq: MN - contention' as e256,
'enq: MO - contention' as e257,
'enq: MR - contention' as e258,
'enq: MR - standby role transition' as e259,
'enq: MS - contention' as e260,
'enq: MW - contention' as e261,
'enq: MX - sync storage server info' as e262,
'enq: OC - contention' as e263,
'enq: OD - Serializing DDLs' as e264,
'enq: OL - contention' as e265,
'enq: OQ - xsoqhiAlloc' as e266,
'enq: OQ - xsoqhiClose' as e267,
'enq: OQ - xsoqhiFlush' as e268,
'enq: OQ - xsoq*histrecb' as e269,
'enq: OQ - xsoqhistrecb' as e270,
'enq: OT - TEXT: Generic Lock' as e271,
'enq: OW - initialization' as e272,
'enq: OW - termination' as e273,
'enq: PD - contention' as e274,
'enq: PE - contention' as e275,
'enq: PF - contention' as e276,
'enq: PG - contention' as e277,
'enq: PH - contention' as e278,
'enq: PI - contention' as e279,
'enq: PL - contention' as e280,
'enq: PR - contention' as e281,
'enq: PS - contention' as e282,
'enq: PT - contention' as e283,
'enq: PV - syncshut' as e284,
'enq: PV - syncstart' as e285,
'enq: PW - perwarm status in dbw0' as e286,
'enq: RB - contention' as e287,
'enq: RD - RAC load' as e288,
'enq: RE - block repair contention' as e289,
'enq: RF - atomicity' as e290,
'enq: RF - DG Broker Current File ID' as e291,
'enq: RF - FSFO Observer Heartbeat' as e292,
'enq: RF - FSFO Primary Shutdown suspended' as e293,
'enq: RF - new AI' as e294,
'enq: RF - RF - Database Automatic Disable' as e295,
'enq: RF - synch: DG Broker metadata' as e296,
'enq: RF - synchronization: aifo master' as e297,
'enq: RF - synchronization: critical ai' as e298,
'enq: RK - set key' as e299,
'enq: RL - RAC wallet lock' as e300,
'enq: RN - contention' as e301,
'enq: RP - contention' as e302,
'enq: RR - contention' as e303,
'enq: RS - file delete' as e304,
'enq: RS - persist alert level' as e305,
'enq: RS - prevent aging list update' as e306,
'enq: RS - prevent file delete' as e307,
'enq: RS - read alert level' as e308,
'enq: RS - record reuse' as e309,
'enq: RS - write alert level' as e310,
'enq: RT - contention' as e311,
'enq: RT - thread internal enable/disable' as e312,
'enq: RU - contention' as e313,
'enq: RU - waiting' as e314,
'enq: RW - MV metadata contention' as e315,
'enq: RX - relocate extent' as e316,
'enq: RX - unlock extent' as e317,
'enq: SB - logical standby metadata' as e318,
'enq: SB - table instantiation' as e319,
'enq: SE - contention' as e320,
'enq: SF - contention' as e321,
'enq: SH - contention' as e322,
'enq: SI - contention' as e323,
'enq: SJ - Slave Task Cancel' as e324,
'enq: SK - contention' as e325,
'enq: SL - escalate lock' as e326,
'enq: SL - get lock' as e327,
'enq: SL - get lock for undo' as e328,
'enq: SO - contention' as e329,
'enq: SP - contention 1' as e330,
'enq: SP - contention 2' as e331,
'enq: SP - contention 3' as e332,
'enq: SP - contention 4' as e333,
'enq: SR - contention' as e334,
'enq: SU - contention' as e335,
'enq: SW - contention' as e336,
'enq: TA - contention' as e337,
'enq: TB - SQL Tuning Base Cache Load' as e338,
'enq: TB - SQL Tuning Base Cache Update' as e339,
'enq: TC - contention' as e340,
'enq: TC - contention2' as e341,
'enq: TD - KTF dump entries' as e342,
'enq: TE - KTF broadcast' as e343,
'enq: TF - contention' as e344,
'enq: TH - metric threshold evaluation' as e345,
'enq: TK - Auto Task Serialization' as e346,
'enq: TK - Auto Task Slave Lockout' as e347,
'enq: TL - contention' as e348,
'enq: TO - contention' as e349,
'enq: TP - contention' as e350,
'enq: TQ - DDL contention' as e351,
'enq: TQ - DDL-INI contention' as e352,
'enq: TQ - INI contention' as e353,
'enq: TQ - TM contention' as e354,
'enq: TS - contention' as e355,
'enq: TT - contention' as e356,
'enq: TX - contention' as e357,
'enq: US - contention' as e358,
'enq: WA - contention' as e359,
'enq: WF - contention' as e360,
'enq: WG - delete fso' as e361,
'enq: WL - contention' as e362,
'enq: WL - RAC-wide SGA contention' as e363,
'enq: WL - RFS global state contention' as e364,
'enq: WL - Test access/locking' as e365,
'enq: WM - WLM Plan activation' as e366,
'enq: WP - contention' as e367,
'enq: WR - contention' as e368,
'enq: XC - XDB Configuration' as e369,
'enq: XD - ASM disk drop/add' as e370,
'enq: XD - ASM disk OFFLINE' as e371,
'enq: XD - ASM disk ONLINE' as e372,
'enq: XH - contention' as e373,
'enq: XL - fault extent map' as e374,
'enq: XQ - purification' as e375,
'enq: XQ - recovery' as e376,
'enq: XQ - relocation' as e377,
'enq: XR - database force logging' as e378,
'enq: XR - quiesce database' as e379,
'enq: XY - contention' as e380,
'enq: ZA - add std audit table partition' as e381,
'enq: ZF - add fga audit table partition' as e382,
'enq: ZH - compression analysis' as e383,
'enq: ZZ - update hash tables' as e384,
'events in waitclass Other' as e385,
'extent map load/unlock' as e386,
'FAL archive wait 1 sec for REOPEN minimum' as e387,
'flashback free VI log' as e388,
'flashback log switch' as e389,
'free global transaction table entry' as e390,
'free process state object' as e391,
'GCR CSS join retry' as e392,
'GCR ctx lock acquisition' as e393,
'GCR lock acquisition' as e394,
'GCR member Data from CSS ' as e395,
'gcs ddet enter server mode' as e396,
'gcs domain validation' as e397,
'gcs drm freeze begin' as e398,
'gcs drm freeze in enter server mode' as e399,
'gcs enter server mode' as e400,
'gcs lmon dirtydetach step completion' as e401,
'GCS lock cancel' as e402,
'GCS lock cvt S' as e403,
'GCS lock cvt X' as e404,
'GCS lock esc' as e405,
'GCS lock esc X' as e406,
'GCS lock open' as e407,
'GCS lock open S' as e408,
'GCS lock open X' as e409,
'gcs log flush sync' as e410,
'GCS recovery lock convert' as e411,
'GCS recovery lock open' as e412,
'gcs remastering wait for read latch' as e413,
'gcs resource directory to be unfrozen' as e414,
'gcs retry nowait latch get' as e415,
'gcs to be enabled' as e416,
'ges cached resource cleanup' as e417,
'ges cancel' as e418,
'ges cgs registration' as e419,
'ges client process to exit' as e420,
'ges DFS hang analysis phase 2 acks' as e421,
'ges enter server mode' as e422,
'ges generic event' as e423,
'ges global resource directory to be frozen' as e424,
'ges inquiry response' as e425,
'ges lmd and pmon to attach' as e426,
'ges LMD suspend for testing event' as e427,
'ges lmd sync during reconfig' as e428,
'ges LMD to inherit communication channels' as e429,
'ges LMD to shutdown' as e430,
'ges lmd/lmses to freeze in rcfg' as e431,
'ges lmd/lmses to unfreeze in rcfg' as e432,
'ges LMON for send queues' as e433,
'ges LMON to get to FTDONE ' as e434,
'ges LMON to join CGS group' as e435,
'ges lms sync during dynamic remastering and reconfig' as e436,
'ges master to get established for SCN op' as e437,
'ges message buffer allocation' as e438,
'ges performance test completion' as e439,
'ges pmon to exit' as e440,
'ges process with outstanding i/o' as e441,
'ges resource cleanout during enqueue open' as e442,
'ges resource cleanout during enqueue open-cvt' as e443,
'ges resource directory to be unfrozen' as e444,
'ges retry query node' as e445,
'ges reusing os pid' as e446,
'ges RMS0 retry add redo log' as e447,
'ges user error' as e448,
'ges wait for lmon to be ready' as e449,
'ges yield cpu in reconfig' as e450,
'ges/gcs diag dump' as e451,
'ges1 LMON to wake up LMD - mrcvr' as e452,
'ges2 LMON to wake up LMD - mrcvr' as e453,
'ges2 LMON to wake up lms - mrcvr 2' as e454,
'ges2 LMON to wake up lms - mrcvr 3' as e455,
'ges2 proc latch in rm latch get 1' as e456,
'ges2 proc latch in rm latch get 2' as e457,
'GIPC operation: dump' as e458,
'global cache busy' as e459,
'global enqueue expand wait' as e460,
'global plug and play automatic resource creation' as e461,
'GPnP Get Error' as e462,
'GPnP Get Item' as e463,
'GPnP Initialization' as e464,
'GPnP Set Item' as e465,
'GPnP Termination' as e466,
'GV$: slave acquisition retry wait time' as e467,
'imm op' as e468,
'IMR CSS join retry' as e469,
'IMR disk votes' as e470,
'IMR membership resolution' as e471,
'IMR mount phase II completion' as e472,
'IMR net-check message ack' as e473,
'IMR rr lock release' as e474,
'IMR rr update' as e475,
'inactive session' as e476,
'inactive transaction branch' as e477,
'index block split' as e478,
'instance state change' as e479,
'IPC busy async request' as e480,
'IPC send completion sync' as e481,
'IPC wait for name service busy' as e482,
'IPC waiting for OSD resources' as e483,
'job scheduler coordinator slave wait' as e484,
'jobq slave shutdown wait' as e485,
'jobq slave TJ process wait' as e486,
'kcbzps' as e487,
'kdblil wait before retrying ORA-54' as e488,
'kdic_do_merge' as e489,
'kfcl: instance recovery' as e490,
'kgltwait' as e491,
'kjbdomalc allocate recovery domain - retry' as e492,
'kjbdrmcvtq lmon drm quiesce: ping completion' as e493,
'kjbopen wait for recovery domain attach' as e494,
'KJC: Wait for msg sends to complete' as e495,
'kjctcisnd: Queue/Send client message' as e496,
'kjctssqmg: quick message send wait' as e497,
'kjudomatt wait for recovery domain attach' as e498,
'kjudomdet wait for recovery domain detach' as e499,
'kjxgrtest' as e500,
'kkdlgon' as e501,
'kkdlhpon' as e502,
'kkdlsipon' as e503,
'kksfbc child completion' as e504,
'kksfbc research' as e505,
'kkshgnc reloop' as e506,
'kksscl hash split' as e507,
'knpc_acwm_AwaitChangedWaterMark' as e508,
'knpc_anq_AwaitNonemptyQueue' as e509,
'knpsmai' as e510,
'kpodplck wait before retrying ORA-54' as e511,
'ksbcic' as e512,
'ksbsrv' as e513,
'ksdxexeother' as e514,
'ksdxexeotherwait' as e515,
'ksim generic wait event' as e516,
'kslwait unit test event 1' as e517,
'kslwait unit test event 2' as e518,
'kslwait unit test event 3' as e519,
'ksv slave avail wait' as e520,
'ksxr poll remote instances' as e521,
'ksxr wait for mount shared' as e522,
'ktfbtgex' as e523,
'ktm: instance recovery' as e524,
'ktsambl' as e525,
'kttm2d' as e526,
'Kupp process shutdown' as e527,
'kupp process wait' as e528,
'kxfxse' as e529,
'kxfxsp' as e530,
'latch: active service list' as e531,
'latch activity' as e532,
'latch: cache buffer handles' as e533,
'latch: cache buffers lru chain' as e534,
'latch: call allocation' as e535,
'latch: change notification client cache latch' as e536,
'latch: Change Notification Hash table latch' as e537,
'latch: checkpoint queue latch' as e538,
'latch: enqueue hash chains' as e539,
'latch free' as e540,
'latch: gc element' as e541,
'latch: gcs resource hash' as e542,
'latch: ges resource hash list' as e543,
'latch: lob segment dispenser latch' as e544,
'latch: lob segment hash table latch' as e545,
'latch: lob segment query latch' as e546,
'latch: messages' as e547,
'latch: object queue header operation' as e548,
'latch: parallel query alloc buffer' as e549,
'latch: PX hash array latch' as e550,
'latch: redo allocation' as e551,
'latch: session allocation' as e552,
'latch: undo global data' as e553,
'latch: virtual circuit queues' as e554,
'latch: WCR: processes HT' as e555,
'latch: WCR: sync' as e556,
'LGWR ORL/NoExp FAL archival' as e557,
'LGWR simulation latency wait' as e558,
'LGWR wait for redo copy' as e559,
'LGWR-LNS wait on channel' as e560,
'library cache revalidation' as e561,
'library cache shutdown' as e562,
'listen endpoint status' as e563,
'listener registration dump' as e564,
'LMON global data update' as e565,
'lms flush message acks' as e566,
'LNS simulation latency wait' as e567,
'lock close' as e568,
'lock deadlock retry' as e569,
'lock escalate retry' as e570,
'lock release pending' as e571,
'log file switch (clearing log file)' as e572,
'log switch/archive' as e573,
'log write(even)' as e574,
'log write(odd)' as e575,
'Logical Standby Apply shutdown' as e576,
'Logical Standby Debug' as e577,
'Logical Standby dictionary build' as e578,
'Logical Standby pin transaction' as e579,
'Logical Standby Terminal Apply' as e580,
'L1 validation' as e581,
'master diskmon read' as e582,
'master diskmon startup' as e583,
'master exit' as e584,
'MMON (Lite) shutdown' as e585,
'MMON slave messages' as e586,
'MRP inactivation' as e587,
'MRP state inspection' as e588,
'MRP termination' as e589,
'MRP wait on archivelog archival' as e590,
'MRP wait on archivelog arrival' as e591,
'MRP wait on process restart' as e592,
'MRP wait on process start' as e593,
'MRP wait on startup clear' as e594,
'name-service call wait' as e595,
'NFS read delegation outstanding' as e596,
'no free buffers' as e597,
'no free locks' as e598,
'null event' as e599,
'OJVM: Generic' as e600,
'OLAP Aggregate Client Deq' as e601,
'OLAP Aggregate Client Enq' as e602,
'OLAP Aggregate Master Deq' as e603,
'OLAP Aggregate Master Enq' as e604,
'OLAP Null PQ Reason' as e605,
'OLAP Parallel Temp Grew' as e606,
'OLAP Parallel Temp Grow Request' as e607,
'OLAP Parallel Temp Grow Wait' as e608,
'OLAP Parallel Type Deq' as e609,
'opishd' as e610,
'optimizer stats update retry' as e611,
'OSD IPC library' as e612,
'parallel recovery change buffer free' as e613,
'parallel recovery coord send blocked' as e614,
'parallel recovery coord wait for reply' as e615,
'parallel recovery read buffer free' as e616,
'parallel recovery slave wait for change' as e617,
'pending global transaction(s)' as e618,
'pmon dblkr tst event' as e619,
'PMON to cleanup detached branches at shutdown' as e620,
'PMON to cleanup pseudo-branches at svc stop time' as e621,
'prewarm transfer retry' as e622,
'prior spawner clean up' as e623,
'process diagnostic dump' as e624,
'process shutdown' as e625,
'process startup' as e626,
'process terminate' as e627,
'PX create server' as e628,
'PX Deq Credit: free buffer' as e629,
'PX Deq Credit: Session Stats' as e630,
'PX Deq: OLAP Update Close' as e631,
'PX Deq: OLAP Update Execute' as e632,
'PX Deq: OLAP Update Reply' as e633,
'PX Deq: reap credit' as e634,
'PX Deq: Signal ACK EXT' as e635,
'PX Deq: Signal ACK RSG' as e636,
'PX Deq: Slave Join Frag' as e637,
'PX Deq: Slave Session Stats' as e638,
'PX Deq: Table Q Close' as e639,
'PX Deq: Table Q Get Keys' as e640,
'PX Deq: Table Q qref' as e641,
'PX Deq: Test for credit' as e642,
'PX Deq: Test for msg' as e643,
'PX hash elem being inserted' as e644,
'PX Nsq: PQ descriptor query' as e645,
'PX Nsq: PQ load info query' as e646,
'PX qref latch' as e647,
'PX Send Wait' as e648,
'PX server shutdown' as e649,
'PX signal server' as e650,
'PX slave connection' as e651,
'PX slave release' as e652,
'qerex_gdml' as e653,
'queue slave messages' as e654,
'rdbms ipc message block' as e655,
'rdbms ipc reply' as e656,
'readable standby redo apply remastering' as e657,
'recovery area: computing applied logs' as e658,
'recovery area: computing backed up files' as e659,
'recovery area: computing dropped files' as e660,
'recovery area: computing obsolete files' as e661,
'recovery buffer pinned' as e662,
'recovery instance recovery completion ' as e663,
'reliable message' as e664,
'Replication Dequeue ' as e665,
'resmgr:internal state cleanup' as e666,
'Resolution of in-doubt txns' as e667,
'RFS announce' as e668,
'RFS attach' as e669,
'RFS close' as e670,
'RFS create' as e671,
'RFS detach' as e672,
'RFS dispatch' as e673,
'RFS ping' as e674,
'RFS register' as e675,
'rollback operations active' as e676,
'rollback operations block full' as e677,
'rolling migration: cluster quiesce' as e678,
'row cache cleanup' as e679,
'row cache process' as e680,
'RSGA: RAC reconfiguration' as e681,
'RVWR wait for flashback copy' as e682,
'scginq AST call' as e683,
'secondary event' as e684,
'select wait' as e685,
'set director factor wait' as e686,
'SGA: allocation forcing component growth' as e687,
'SGA: sga_target resize' as e688,
'shutdown after switchover to standby' as e689,
'slave exit' as e690,
'Space Manager: slave messages' as e691,
'standby query scn advance' as e692,
'Streams AQ: emn coordinator waiting for slave to start' as e693,
'Streams AQ: qmn coordinator waiting for slave to start' as e694,
'Streams AQ: QueueTable kgl locks' as e695,
'Streams AQ: waiting for busy instance for instance_name' as e696,
'Streams capture: waiting for database startup' as e697,
'Streams miscellaneous event' as e698,
'Streams: RAC waiting for inter instance ack' as e699,
'SUPLOG PL wait for inflight pragma-d PL/SQL' as e700,
'Sync ASM rebalance' as e701,
'TEST: action hang' as e702,
'TEST: action sync' as e703,
'test long ops' as e704,
'timer in sksawat' as e705,
'transaction' as e706,
'TSE master key rekey' as e707,
'TSE SSO wallet reopen' as e708,
'tsm with timeout' as e709,
'txn to complete' as e710,
'unbound tx' as e711,
'undo segment recovery' as e712,
'undo_retention publish retry' as e713,
'unspecified wait event' as e714,
'wait active processes' as e715,
'wait for a paralle reco to abort' as e716,
'wait for a undo record' as e717,
'wait for another txn - rollback to savepoint' as e718,
'wait for another txn - txn abort' as e719,
'wait for another txn - undo rcv abort' as e720,
'wait for assert messages to be sent' as e721,
'wait for change' as e722,
'wait for EMON to spawn' as e723,
'wait for FMON to come up' as e724,
'wait for kkpo ref-partitioning *TEST EVENT*' as e725,
'wait for master scn' as e726,
'wait for MTTR advisory state object' as e727,
'wait for scn ack' as e728,
'Wait for shrink lock' as e729,
'Wait for shrink lock2' as e730,
'wait for stopper event to be increased' as e731,
'wait for sync ack' as e732,
'Wait for TT enqueue' as e733,
'wait for verification ack' as e734,
'wait list latch activity' as e735,
'wait list latch free' as e736,
'Wait on stby instance close' as e737,
'waiting to get CAS latch' as e738,
'waiting to get RM CAS latch' as e739,
'WCR: capture file IO write' as e740,
'WCR: RAC message context busy' as e741,
'WCR: Sync context busy' as e742,
'writes stopped by instance recovery or database suspension' as e743,
'xdb schema cache initialization' as e744,
'XDB SGA initialization' as e745
 )
  )
order by snap_id;
--------------
--Subset of Others class
select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in 
(
'ADR block file read' as ADR_block_file_read,
'OJVM: Generic' as OJVM_Generic,
'DBMS_LDAP: LDAP operation ' as DBMS_LDAP_operation,
'latch free' as latch_free,
'kksfbc child completion' as kksfbc_child_completion,
'process diagnostic dump' as process_diagnostic_dump,
'LGWR wait for redo copy' as LGWR_wait_for_redo_copy,
'latch: enqueue hash chains' as latch__enqueue_hash_chains,
'asynch descriptor resize' as asynch_descriptor_resize,
'enq: CF - contention' as enq_CF_contention
)
  )
order by snap_id;
------------------------

select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'buffer busy waits', 'cursor: mutex S', 'cursor: mutex X', 'cursor: pin S', 'cursor: pin S wait on X', 'cursor: pin X', 'db flash cache invalidate wait', 'enq: HV - contention', 'enq: TX - index contention', 'enq: WG - lock fso', 'latch: cache buffers chains', 'latch: In memory undo latch', 'latch: MQL Tracking Latch', 'latch: row cache objects', 'latch: shared pool', 'latch: Undo Hint Latch', 'libcache interrupt action by LCK', 'library cache load lock', 'library cache lock', 'library cache: mutex S', 'library cache: mutex X', 'library cache pin', 'logout restrictor', 'os thread startup', 'pipe put', 'resmgr:internal state change', 'resmgr:sessions to exit', 'row cache lock', 'row cache read', 'securefile chain update', 'SecureFile mutex', 'Shared IO Pool Memory', 'Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692  
  and SE.EVENT_NAME in ( 'buffer busy waits', 'cursor: mutex S', 'cursor: mutex X', 'cursor: pin S', 'cursor: pin S wait on X', 'cursor: pin X', 'db flash cache invalidate wait', 'enq: HV - contention', 'enq: TX - index contention', 'enq: WG - lock fso', 'latch: cache buffers chains', 'latch: In memory undo latch', 'latch: MQL Tracking Latch', 'latch: row cache objects', 'latch: shared pool', 'latch: Undo Hint Latch', 'libcache interrupt action by LCK', 'library cache load lock', 'library cache lock', 'library cache: mutex S', 'library cache: mutex X', 'library cache pin', 'logout restrictor', 'os thread startup', 'pipe put', 'resmgr:internal state change', 'resmgr:sessions to exit', 'row cache lock', 'row cache read', 'securefile chain update', 'SecureFile mutex', 'Shared IO Pool Memory', 'Streams apply: waiting for dependency' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'buffer busy waits' as buffer_busy_waits,
'cursor: mutex S' as cursor__mutex_S,
'cursor: mutex X' as cursor__mutex_X,
'cursor: pin S' as cursor__pin_S,
'cursor: pin S wait on X' as cursor__pin_S_wait_on_X,
'cursor: pin X' as cursor__pin_X,
'db flash cache invalidate wait' as db_flash_cache_invalidate_wait,
'enq: HV - contention' as eqnHV___contention,
'enq: TX - index contention' as eqnTX___index_contention,
'enq: WG - lock fso' as eqnWG___lock_fso,
'latch: cache buffers chains' as latch__cache_buffers_chains,
'latch: In memory undo latch' as latch__In_memory_undo_latch,
'latch: MQL Tracking Latch' as latch__MQL_Tracking_Latch,
'latch: row cache objects' as latch__row_cache_objects,
'latch: shared pool' as latch__shared_pool,
'latch: Undo Hint Latch' as latch__Undo_Hint_Latch,
'libcache interrupt action by LCK' as libcacheIntrrptActionByLCK,
'library cache load lock' as library_cache_load_lock,
'library cache lock' as library_cache_lock,
'library cache: mutex S' as library_cache__mutex_S,
'library cache: mutex X' as library_cache__mutex_X,
'library cache pin' as library_cache_pin,
'logout restrictor' as logout_restrictor,
'os thread startup' as os_thread_startup,
'pipe put' as pipe_put,
'resmgr:internal state change' as resmgr_internal_state_change,
'resmgr:sessions to exit' as resmgr_sessions_to_exit,
'row cache lock' as row_cache_lock,
'row cache read' as row_cache_read,
'securefile chain update' as securefile_chain_update,
'SecureFile mutex' as SecureFile_mutex,
'Shared IO Pool Memory' as Shared_IO_Pool_Memory,
'Streams apply: waiting for dependency' as StrmsApplyWaiting4dependency
)
    )
order by snap_id;

-- SystemIO
select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSTEM_EVENT se, SYS.WRH$_EVENT_NAME en
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692
  and se.event_id=EN.EVENT_ID and se.dbid=en.dbid 
  and EN.EVENT_NAME in ( 
'kst: async disk IO','ksfd: async disk IO','Log archive I/O','RMAN backup & recovery I/O','Standby redo I/O','io done','control file sequential read','control file single write','control file parallel write','recovery read','ARCH wait for pending I/Os','LNS ASYNC control file txn','LGWR sequential i/o','LGWR random i/o','RFS sequential i/o','RFS random i/o','RFS write','ARCH sequential i/o','ARCH random i/o','log file sequential read','log file single write','log file parallel write','db file parallel write','kfk: async disk IO'  
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSTEM_EVENT se, SYS.WRH$_EVENT_NAME en
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692
  and se.event_id=EN.EVENT_ID and se.dbid=en.dbid 
  and EN.EVENT_NAME in (
'kst: async disk IO','ksfd: async disk IO','Log archive I/O','RMAN backup & recovery I/O','Standby redo I/O','io done','control file sequential read','control file single write','control file parallel write','recovery read','ARCH wait for pending I/Os','LNS ASYNC control file txn','LGWR sequential i/o','LGWR random i/o','RFS sequential i/o','RFS random i/o','RFS write','ARCH sequential i/o','ARCH random i/o','log file sequential read','log file single write','log file parallel write','db file parallel write','kfk: async disk IO'   
   )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in 
(
'kst: async disk IO' as kst__async_disk_IO,
'ksfd: async disk IO' as ksfd__async_disk_IO,
'Log archive I/O' as Log_archive_I_O,
'RMAN backup & recovery I/O' as RMAN_backup___recovery_I_O,
'Standby redo I/O' as Standby_redo_I_O,
'io done' as io_done,
'control file sequential read' as control_file_sequential_read,
'control file single write' as control_file_single_write,
'control file parallel write' as control_file_parallel_write,
'recovery read' as recovery_read,
'ARCH wait for pending I/Os' as ARCH_wait_for_pending_I_Os,
'LNS ASYNC control file txn' as LNS_ASYNC_control_file_txn,
'LGWR sequential i/o' as LGWR_sequential_i_o,
'LGWR random i/o' as LGWR_random_i_o,
'RFS sequential i/o' as RFS_sequential_i_o,
'RFS random i/o' as RFS_random_i_o,
'RFS write' as RFS_write,
'ARCH sequential i/o' as ARCH_sequential_i_o,
'ARCH random i/o' as ARCH_random_i_o,
'log file sequential read' as log_file_sequential_read,
'log file single write' as log_file_single_write,
'log file parallel write' as log_file_parallel_write,
'db file parallel write' as db_file_parallel_write,
'kfk: async disk IO' as kfk__async_disk_IO
)
  )
order by snap_id;
------------------------

-- Event explanation
select * 
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 
  'pinned buffers inspected','physical writes from cache','physical writes','index fast full scans (full)','free buffer requested','free buffer inspected','user I/O wait time','physical reads','physical reads cache' 
  )
  and S.SNAP_ID between 4333 and 4692
),
b as ( 
  select * from local_data 
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'user I/O wait time' as userIOwt,
'physical reads' as ph_reads,
'physical reads cache' as ph_reads_cache,
'free buffer inspected' as free_buff_insp,
'free buffer requested' as free_buff_req,
'pinned buffers inspected' as pin_buff_insp,
'physical writes from cache' as ph_wr_from_bcache,
'physical writes' as ph_writes,
'index fast full scans (full)' as indx_ffs
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- Given Events
select *
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       EN.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSTEM_EVENT se, SYS.WRH$_EVENT_NAME en
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.SNAP_ID between 4333 and 4692
  and se.event_id=EN.EVENT_ID and se.dbid=en.dbid 
  and EN.EVENT_NAME in ( 
  'log file switch (checkpoint incomplete)','log file switch (private strand flush incomplete)','log file switch (archiving needed)','log file switch completion','log file switch (clearing log file)','enq: WL - contention' 
  )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, EN.EVENT_NAME
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in 
(
'log file switch (checkpoint incomplete)' as lfs_checkpoint_incomplete,
'log file switch (private strand flush incomplete)' as lfs_prvt_strnd_flsh_incmplt,
'log file switch (archiving needed)' as lfs_archiving_needed,
'log file switch completion' as lfs_completion,
'log file switch (clearing log file)' as lfs_clearing_log_file,
'enq: WL - contention' as enqWL_contention
)
  )
order by snap_id;
------------------------


-- Commit stats
select * 
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'commit batch performed','commit batch requested','commit batch/immediate performed','commit batch/immediate requested','commit immediate performed','commit immediate requested','commit nowait performed','commit nowait requested','commit wait performed','commit wait requested','commit wait/nowait performed','commit wait/nowait requested','user commits'  
  )
  and S.SNAP_ID between 4333 and 4692
), 
b as (
  select * from local_data
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'commit batch performed' as cbatch_performed,
'commit batch requested' as cbatch_requested,
'commit batch/immediate performed' as cbatch_immediate_performed,
'commit batch/immediate requested' as cbatch_immediate_requested,
'commit immediate performed' as cimmediate_performed,
'commit immediate requested' as cimmediate_requested,
'commit nowait performed' as cnowait_performed,
'commit nowait requested' as cnowait_requested,
'commit wait performed' as ct_wait_performed,
'commit wait requested' as cwait_requested,
'commit wait/nowait performed' as cwait_nowait_performed,
'commit wait/nowait requested' as cwait_nowait_requested,
'user commits' as user_commits
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- Physical Reads stats
select * 
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical read total IO requests','physical read total multi block requests','physical reads','physical reads cache','physical read flash cache hits','physical reads direct','physical reads direct temporary tablespace','physical reads cache prefetch','physical reads prefetch warmup','physical reads retry corrupt','physical reads direct (lob)'  
  )
  and S.SNAP_ID between 4333 and 4692
),
b as (  
  select * from local_data
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read total IO requests' as totalIO,
'physical read total multi block requests' as total_mblckIO,
'physical reads' as phr,
'physical reads cache' as phr_cache,
'physical read flash cache hits' as phr_flash_cache_hits,
'physical reads direct' as phr_direct,
'physical reads direct temporary tablespace' as phr_direct_tmp_tblspc,
'physical reads cache prefetch' as phr_cache_prefetch,
'physical reads prefetch warmup' as phr_prefetch_warmup,
'physical reads retry corrupt' as phr_retry_corrupt,
'physical reads direct (lob)' as phr_direct_lob
)
 )
order by snap_time;
--------------------------------------------------------------------------------

-- Redo stats
select * 
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'redo KB read','redo KB read (memory)','redo KB read (memory) for transport','redo KB read for transport','redo blocks checksummed by FG (exclusive)','redo blocks checksummed by LGWR','redo blocks read for recovery','redo blocks written','redo buffer allocation retries','redo entries','redo entries for lost write detection','redo k-bytes read for recovery','redo k-bytes read for terminal recovery','redo log space requests','redo log space wait time','redo ordering marks','redo size','redo size for direct writes','redo size for lost write detection','redo subscn max counts','redo synch long waits','redo synch poll writes','redo synch polls','redo synch time','redo synch time (usec)','redo synch writes','redo wastage','redo write broadcast ack count','redo write broadcast ack time','redo write broadcast lgwr post count','redo write time','redo writes'  
  )
  and S.SNAP_ID between 4333 and 4692
),
b as (  
  select * from local_data
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'redo KB read' as r_KB_read,
'redo KB read (memory)' as r_KB_read_memory,
'redo KB read (memory) for transport' as r_KB_read_mem4transport,
'redo KB read for transport' as r_KB_read4transport,
'redo blocks checksummed by FG (exclusive)' as r_blcks_chcksmmd_byFGexclusive,
'redo blocks checksummed by LGWR' as r_blocks_checksummed_by_LGWR,
'redo blocks read for recovery' as r_blocks_read4recovery,
'redo blocks written' as r_blocks_written,
'redo buffer allocation retries' as r_buffer_allocation_retries,
'redo entries' as r_entries,
'redo entries for lost write detection' as r_entries4lost_write_detection,
'redo k-bytes read for recovery' as r_kb_read4recovery,
'redo k-bytes read for terminal recovery' as r_kb_read4terminal_recovery,
'redo log space requests' as r_log_space_requests,
'redo log space wait time' as r_log_space_wait_time,
'redo ordering marks' as r_ordering_marks,
'redo size' as r_size,
'redo size for direct writes' as r_size4direct_writes,
'redo size for lost write detection' as r_size4lost_wr_detection,
'redo subscn max counts' as r_subscn_max_counts,
'redo synch long waits' as r_synch_long_waits,
'redo synch poll writes' as r_synch_poll_writes,
'redo synch polls' as r_synch_polls,
'redo synch time' as r_synch_time,
'redo synch time (usec)' as r_synch_time_usec,
'redo synch writes' as r_synch_writes,
'redo wastage' as r_wastage,
'redo write broadcast ack count' as rw_broadcast_ack_count,
'redo write broadcast ack time' as rw_broadcast_ack_time,
'redo write broadcast lgwr post count' as rw_broadcast_lgwr_post_count,
'redo write time' as rw_time,
'redo writes' as rw_s
)
 )
order by snap_time;
--------------------------------------------------------------------------------


-- Commit stats
select * 
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'commit batch performed','commit batch requested','commit batch/immediate performed','commit batch/immediate requested','commit cleanout failures: block lost','commit cleanout failures: buffer being written','commit cleanout failures: callback failure ','commit cleanout failures: cannot pin','commit cleanout failures: hot backup in progress','commit cleanout failures: write disabled','commit cleanouts','commit cleanouts successfully completed','commit immediate performed','commit immediate requested','commit nowait performed','commit nowait requested','commit txn count during cleanout','commit wait performed','commit wait requested','commit wait/nowait performed','commit wait/nowait requested','user commits'  
  )
  and S.SNAP_ID between 4333 and 4692
),
b as (  
  select * from local_data
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'commit batch performed' as c_batch_performed,
'commit batch requested' as c_batch_requested,
'commit batch/immediate performed' as c_batch_immediate_performed,
'commit batch/immediate requested' as c_batch_immediate_requested,
'commit cleanout failures: block lost' as c_cleanout_failures_block_lost,
'commit cleanout failures: buffer being written' as c_clnt_flrs_bffr_being_wrttn,
'commit cleanout failures: callback failure ' as c_clnt_flrs_cllbk_flr,
'commit cleanout failures: cannot pin' as c_cleanout_failures_cannot_pin,
'commit cleanout failures: hot backup in progress' as c_clnt_flrs_ht_bkp_in_prgrss,
'commit cleanout failures: write disabled' as c_clnt_flrs_wrt_dsbld,
'commit cleanouts' as c_cleanouts,
'commit cleanouts successfully completed' as c_clnts_sccssfll_cmpltd,
'commit immediate performed' as c_immediate_performed,
'commit immediate requested' as c_immediate_requested,
'commit nowait performed' as c_nowait_performed,
'commit nowait requested' as c_nowait_requested,
'commit txn count during cleanout' as c_txn_count_during_cleanout,
'commit wait performed' as c_wait_performed,
'commit wait requested' as c_wait_requested,
'commit wait/nowait performed' as c_wait_nowait_performed,
'commit wait/nowait requested' as c_wait_nowait_requested,
'user commits' as user_commits
)
 )
order by snap_time;
--------------------------------------------------------------------------------


-- IO by filetype: IO Req
--------------------------------------------------------------------------------
select *
from (
with 
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FILETYPE_NAME as stat_name,
        sum( nvl(IFT.SMALL_READ_REQS,0)+nvl(IFT.SMALL_WRITE_REQS,0)+nvl(IFT.LARGE_READ_REQS,0)+nvl(IFT.LARGE_WRITE_REQS,0) ) as stat_value
from SYS.WRH$_IOSTAT_FILETYPE ift, SYS.WRM$_SNAPSHOT s, SYS.WRH$_IOSTAT_FILETYPE_NAME ifn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FILETYPE_ID=IFT.FILETYPE_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FILETYPE_NAME
--order by S.SNAP_ID
 ),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
--order by e.snap_id;
 ) v
pivot (
max(value_diff)
for stat_name in (
'Other' as Other,
'Control File' as CntrlFile,
'Data File' as DataFile,
'Log File' as LogFile,
'Archive Log' as ArchLog,
'Temp File' as TempFile,
'Data File Backup' as DataFileBackup,
'Data File Incremental Backup' as DataFileIncBackup,
'Archive Log Backup' as ArchLogBackup,
'Data File Copy' as DataFileCopy,
'Flashback Log' as FlashbackLog,
'Data Pump Dump File' as DataPumpDumpFile
 )
    )
order by snap_id;
--------------------------------------------------------------------------------

-- IO by filetype: IO ServiceTime
--------------------------------------------------------------------------------
select *
from (
with 
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FILETYPE_NAME as stat_name,
        sum( nvl(IFT.SMALL_READ_SERVICETIME ,0)+nvl(IFT.SMALL_WRITE_SERVICETIME,0)+nvl(IFT.LARGE_READ_SERVICETIME,0)+nvl(IFT.LARGE_WRITE_SERVICETIME,0) ) as stat_value
from SYS.WRH$_IOSTAT_FILETYPE ift, SYS.WRM$_SNAPSHOT s, SYS.WRH$_IOSTAT_FILETYPE_NAME ifn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FILETYPE_ID=IFT.FILETYPE_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FILETYPE_NAME
--order by S.SNAP_ID
 ),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
--order by e.snap_id;
 ) v
pivot (
max(value_diff)
for stat_name in (
'Other' as Other,
'Control File' as CntrlFile,
'Data File' as DataFile,
'Log File' as LogFile,
'Archive Log' as ArchLog,
'Temp File' as TempFile,
'Data File Backup' as DataFileBackup,
'Data File Incremental Backup' as DataFileIncBackup,
'Archive Log Backup' as ArchLogBackup,
'Data File Copy' as DataFileCopy,
'Flashback Log' as FlashbackLog,
'Data Pump Dump File' as DataPumpDumpFile
 )
    )
order by snap_id;
--------------------------------------------------------------------------------

-- IOStat by iofunction, waittime
select *
from (
with 
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        IFN.FUNCTION_NAME as stat_name,
        sum( nvl(IFT.WAIT_TIME,0) ) as stat_value
from SYS.WRH$_IOSTAT_FUNCTION ift, SYS.WRM$_SNAPSHOT s, SYS.WRH$_IOSTAT_FUNCTION_NAME ifn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and IFT.DBID=S.DBID and IFT.INSTANCE_NUMBER=S.INSTANCE_NUMBER and IFT.SNAP_ID=S.SNAP_ID
  and IFN.DBID=IFT.DBID and IFN.FUNCTION_ID=IFT.FUNCTION_ID
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, IFN.FUNCTION_NAME
--order by S.SNAP_ID
 ),
b as (
  select * from local_data
),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
--order by e.snap_id;
 ) v
pivot (
max(value_diff)
for stat_name in (
'RMAN' as RMAN,
'DBWR' as DBWR,
'LGWR' as LGWR,
'ARCH' as ARCH,
'XDB' as XDB,
'Streams AQ' as StreamsAQ,
'Data Pump' as DataPump,
'Recovery' as Recovery,
'Buffer Cache Reads' as BufferCacheReads,
'Direct Reads' as DirectReads,
'Direct Writes' as DirectWrites,
'Smart Scan' as SmartScan,
'Archive Manager' as ArchManager,
'Others' as Others
 )
    )
order by snap_id;
--------------------------------------------------------------------------------

-- Given statistics
select * 
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'write clones created for recovery','prefetch clients - recycle','OTC commit optimization hits','cursor authentications','calls to kcmgas','java session heap object count','gc current block flush time','gc CPU used by this session','DDL statements parallelized','failed parse (out of shared memory) elapsed time','sequence load elapsed time','session pga memory','background elapsed time','consistent gets'
  )
  and S.SNAP_ID between 4333 and 4692
),
b as (  
  select * from local_data
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in ( 
'write clones created for recovery' as wr_clnes_crtd_4_recovery,
'prefetch clients - recycle' as prefetch_clients_recycle,
'OTC commit optimization hits' as OTC_commit_optimization_hits,
'cursor authentications' as cursor_authentications,
'calls to kcmgas' as calls_to_kcmgas,
'java session heap object count' as java_session_heap_object_count,
'gc current block flush time' as gc_current_block_flush_time,
'gc CPU used by this session' as gc_CPU_used_by_this_session,
'DDL statements parallelized' as DDL_statements_parallelized,
'failed parse (out of shared memory) elapsed time' as fp_out_of_shmem_elat,
'sequence load elapsed time' as sequence_load_elapsed_time,
'session pga memory' as session_pga_memory,
'background elapsed time' as background_elapsed_time,
'consistent gets' as consistent_gets
)
 )
order by snap_time;
--------------------------------------------------------------------------------



select SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.snap_id between 4333 and 4692
  and SE.EVENT_NAME in ( 'ack for a broadcasted res from a remote instance','ADR block file read','ADR block file write','ADR file lock','affinity expansion in replay','AQ propagation connection','AQ spill debug idle','ARCH wait for archivelog lock','ARCH wait for process death 1','ARCH wait for process start 1','ARCH wait for process start 3','ARCH wait on c/f tx acquire 1','ASM background starting','ASM cluster file access','ASM db client exists','ASM DG Unblock','ASM file metadata operation','ASM Instance startup','ASM internal hang test','ASM: MARK subscribe to msg channel','ASM metadata cache frozen','ASM network foreground exits','ASM: OFS Cluster membership update','ASM PST operation','ASM Volume Background','asynch descriptor resize','Auto BMR completion','Auto BMR RPC standby catchup','AWR Flush','AWR Metric Capture','Backup Restore Event 19778 sleep','Backup Restore Switch Bitmap sleep','Backup Restore Throttle sleep','BFILE check if exists','BFILE check if open','BFILE closure','BFILE get length','BFILE get name object','BFILE get path object','BFILE internal seek','BFILE open','block change tracking buffer space','blocking txn id for DDL','broadcast mesg queue transition','broadcast mesg recovery queue transition','buffer busy','buffer deadlock','buffer dirty disabled','buffer exterminate','buffer freelistbusy','buffer invalidation wait','buffer latch','buffer rememberlist busy','buffer resize','buffer write wait','buffer writeList full','cell manager cancel work request','cell smart flash unkeep','cell worker online completion','cell worker retry ','CGS skgxn join retry','CGS wait for IPC msg','change tracking file parallel write','change tracking file synchronous read','change tracking file synchronous write','check CPU wait times','checkpoint advanced','cleanup of aborted process','Cluster stabilization wait','Cluster Suspension wait','Compression analysis','control file diagnostic dump','control file heartbeat','cr request retry','CRS call completion','CSS group membership query','CSS group registration','CSS initialization','CSS operation: action','CSS operation: data query','CSS operation: data update','CSS operation: diagnostic','CSS operation: query','CSS Xgrp shared operation','CTWR media recovery checkpoint request','Data Guard Broker Wait','Data Guard: process clean up','Data Guard: process exit','Data Guard: RFS disk I/O','Data Pump slave init','Data Pump slave startup','datafile move cleanup during resize','DBMS_LDAP: LDAP operation ','DBWR range invalidation sync','debugger command','DFS db file lock','DFS lock handle','dispatcher shutdown','dma prepare busy','DSKM to complete cell health check','dupl. cluster key','EMON slave messages','EMON termination','enq: AB - ABMR process initialized','enq: AB - ABMR process start/stop','enq: AD - allocate AU','enq: AD - deallocate AU','enq: AD - relocate AU','enq: AE - lock','enq: AF - task serialization','enq: AG - contention','enq: AM - ASM ACD Relocation','enq: AM - ASM Amdu Dump','enq: AM - ASM cache freeze','enq: AM - ASM disk based alloc/dealloc','enq: AM - ASM file descriptor','enq: AM - ASM File Destroy','enq: AM - ASM file relocation','enq: AM - ASM Grow ACD','enq: AM - ASM Password File Update','enq: AM - ASM reserved','enq: AM - ASM User','enq: AM - background COD reservation','enq: AM - block repair','enq: AM - client registration','enq: AM - disk offline','enq: AM - group block','enq: AM - group use','enq: AM - rollback COD reservation','enq: AM - shutdown','enq: AO - contention','enq: AP - contention','enq: AS - service activation','enq: AT - contention','enq: AV - add/enable first volume in DG','enq: AV - AVD client registration','enq: AV - persistent DG number','enq: AV - volume relocate','enq: AW - AW generation lock','enq: AW - AW state lock','enq: AW - AW$ table lock','enq: AW - user access for AW','enq: AY - contention','enq: BF - allocation contention','enq: BF - PMON Join Filter cleanup','enq: BM - clonedb bitmap file write','enq: BR - file shrink','enq: BR - multi-section restore header','enq: BR - multi-section restore section','enq: BR - perform autobackup','enq: BR - proxy-copy','enq: BR - request autobackup','enq: BR - space info datafile hdr update','enq: CA - contention','enq: CF - contention','enq: CI - contention','enq: CL - compare labels','enq: CL - drop label','enq: CM - diskgroup dismount','enq: CM - gate','enq: CM - instance','enq: CN - race with init','enq: CN - race with reg','enq: CN - race with txn','enq: CO - master slave det','enq: CQ - contention','enq: CR - block range reuse ckpt','enq: CT - change stream ownership','enq: CT - CTWR process start/stop','enq: CT - global space management','enq: CT - local space management','enq: CT - reading','enq: CT - state','enq: CT - state change gate 1','enq: CT - state change gate 2','enq: CU - contention','enq: CX - TEXT: Index Specific Lock','enq: DD - contention','enq: DF - contention','enq: DG - contention','enq: DL - contention','enq: DM - contention','enq: DN - contention','enq: DO - disk online','enq: DO - disk online operation','enq: DO - disk online recovery','enq: DO - Staleness Registry create','enq: DO - startup of MARK process','enq: DP - contention','enq: DR - contention','enq: DS - contention','enq: DT - contention','enq: DV - contention','enq: DW - contention','enq: DX - contention','enq: FA - access file','enq: FB - contention','enq: FC - open an ACD thread','enq: FC - recover an ACD thread','enq: FD - Flashback coordinator','enq: FD - Flashback logical operations','enq: FD - Flashback on/off','enq: FD - Marker generation','enq: FD - Restore point create/drop','enq: FD - Tablespace flashback on/off','enq: FE - contention','enq: FG - FG redo generation enq race','enq: FG - LGWR redo generation enq race','enq: FG - serialize ACD relocate','enq: FL - Flashback database log','enq: FL - Flashback db command','enq: FM - contention','enq: FP - global fob contention','enq: FR - contention','enq: FR - recover the thread','enq: FR - use the thread','enq: FS - contention','enq: FT - allow LGWR writes','enq: FT - disable LGWR writes','enq: FU - contention','enq: FX - issue ACD Xtnt Relocation CIC','enq: HD - contention','enq: HP - contention','enq: HQ - contention','enq: IA - contention','enq: ID - contention','enq: IL - contention','enq: IM - contention for blr','enq: IR - contention','enq: IR - contention2','enq: IS - contention','enq: IT - contention','enq: JD - contention','enq: JI - contention','enq: JQ - contention','enq: JS - aq sync','enq: JS - contention','enq: JS - evt notify','enq: JS - evtsub add','enq: JS - evtsub drop','enq: JS - job recov lock','enq: JS - job run lock - synchronize','enq: JS - q mem clnup lck','enq: JS - queue lock','enq: JS - sch locl enqs','enq: JS - wdw op','enq: KD - determine DBRM master','enq: KM - contention','enq: KP - contention','enq: KQ - access ASM attribute','enq: KT - contention','enq: MD - contention','enq: MH - contention','enq: MK - contention','enq: ML - contention','enq: MN - contention','enq: MO - contention','enq: MR - contention','enq: MR - standby role transition','enq: MS - contention','enq: MW - contention','enq: MX - sync storage server info','enq: OC - contention','enq: OD - Serializing DDLs','enq: OL - contention','enq: OQ - xsoqhiAlloc','enq: OQ - xsoqhiClose','enq: OQ - xsoqhiFlush','enq: OQ - xsoq*histrecb','enq: OQ - xsoqhistrecb','enq: OT - TEXT: Generic Lock','enq: OW - initialization','enq: OW - termination','enq: PD - contention','enq: PE - contention','enq: PF - contention','enq: PG - contention','enq: PH - contention','enq: PI - contention','enq: PL - contention','enq: PR - contention','enq: PS - contention','enq: PT - contention','enq: PV - syncshut','enq: PV - syncstart','enq: PW - perwarm status in dbw0','enq: RB - contention','enq: RD - RAC load','enq: RE - block repair contention','enq: RF - atomicity','enq: RF - DG Broker Current File ID','enq: RF - FSFO Observer Heartbeat','enq: RF - FSFO Primary Shutdown suspended','enq: RF - new AI','enq: RF - RF - Database Automatic Disable','enq: RF - synch: DG Broker metadata','enq: RF - synchronization: aifo master','enq: RF - synchronization: critical ai','enq: RK - set key','enq: RL - RAC wallet lock','enq: RN - contention','enq: RP - contention','enq: RR - contention','enq: RS - file delete','enq: RS - persist alert level','enq: RS - prevent aging list update','enq: RS - prevent file delete','enq: RS - read alert level','enq: RS - record reuse','enq: RS - write alert level','enq: RT - contention','enq: RT - thread internal enable/disable','enq: RU - contention','enq: RU - waiting','enq: RW - MV metadata contention','enq: RX - relocate extent','enq: RX - unlock extent','enq: SB - logical standby metadata','enq: SB - table instantiation','enq: SE - contention','enq: SF - contention','enq: SH - contention','enq: SI - contention','enq: SJ - Slave Task Cancel','enq: SK - contention','enq: SL - escalate lock','enq: SL - get lock','enq: SL - get lock for undo','enq: SO - contention','enq: SP - contention 1','enq: SP - contention 2','enq: SP - contention 3','enq: SP - contention 4','enq: SR - contention','enq: SU - contention','enq: SW - contention','enq: TA - contention','enq: TB - SQL Tuning Base Cache Load','enq: TB - SQL Tuning Base Cache Update','enq: TC - contention','enq: TC - contention2','enq: TD - KTF dump entries','enq: TE - KTF broadcast','enq: TF - contention','enq: TH - metric threshold evaluation','enq: TK - Auto Task Serialization','enq: TK - Auto Task Slave Lockout','enq: TL - contention','enq: TO - contention','enq: TP - contention','enq: TQ - DDL contention','enq: TQ - DDL-INI contention','enq: TQ - INI contention','enq: TQ - TM contention','enq: TS - contention','enq: TT - contention','enq: TX - contention','enq: US - contention','enq: WA - contention','enq: WF - contention','enq: WG - delete fso','enq: WL - contention','enq: WL - RAC-wide SGA contention','enq: WL - RFS global state contention','enq: WL - Test access/locking','enq: WM - WLM Plan activation','enq: WP - contention','enq: WR - contention','enq: XC - XDB Configuration','enq: XD - ASM disk drop/add','enq: XD - ASM disk OFFLINE','enq: XD - ASM disk ONLINE','enq: XH - contention','enq: XL - fault extent map','enq: XQ - purification','enq: XQ - recovery','enq: XQ - relocation','enq: XR - database force logging','enq: XR - quiesce database','enq: XY - contention','enq: ZA - add std audit table partition','enq: ZF - add fga audit table partition','enq: ZH - compression analysis','enq: ZZ - update hash tables','events in waitclass Other','extent map load/unlock','FAL archive wait 1 sec for REOPEN minimum','flashback free VI log','flashback log switch','free global transaction table entry','free process state object','GCR CSS join retry','GCR ctx lock acquisition','GCR lock acquisition','GCR member Data from CSS ','gcs ddet enter server mode','gcs domain validation','gcs drm freeze begin','gcs drm freeze in enter server mode','gcs enter server mode','gcs lmon dirtydetach step completion','GCS lock cancel','GCS lock cvt S','GCS lock cvt X','GCS lock esc','GCS lock esc X','GCS lock open','GCS lock open S','GCS lock open X','gcs log flush sync','GCS recovery lock convert','GCS recovery lock open','gcs remastering wait for read latch','gcs resource directory to be unfrozen','gcs retry nowait latch get','gcs to be enabled','ges cached resource cleanup','ges cancel','ges cgs registration','ges client process to exit','ges DFS hang analysis phase 2 acks','ges enter server mode','ges generic event','ges global resource directory to be frozen','ges inquiry response','ges lmd and pmon to attach','ges LMD suspend for testing event','ges lmd sync during reconfig','ges LMD to inherit communication channels','ges LMD to shutdown','ges lmd/lmses to freeze in rcfg','ges lmd/lmses to unfreeze in rcfg','ges LMON for send queues','ges LMON to get to FTDONE ','ges LMON to join CGS group','ges lms sync during dynamic remastering and reconfig','ges master to get established for SCN op','ges message buffer allocation','ges performance test completion','ges pmon to exit','ges process with outstanding i/o','ges resource cleanout during enqueue open','ges resource cleanout during enqueue open-cvt','ges resource directory to be unfrozen','ges retry query node','ges reusing os pid','ges RMS0 retry add redo log','ges user error','ges wait for lmon to be ready','ges yield cpu in reconfig','ges/gcs diag dump','ges1 LMON to wake up LMD - mrcvr','ges2 LMON to wake up LMD - mrcvr','ges2 LMON to wake up lms - mrcvr 2','ges2 LMON to wake up lms - mrcvr 3','ges2 proc latch in rm latch get 1','ges2 proc latch in rm latch get 2','GIPC operation: dump','global cache busy','global enqueue expand wait','global plug and play automatic resource creation','GPnP Get Error','GPnP Get Item','GPnP Initialization','GPnP Set Item','GPnP Termination','GV$: slave acquisition retry wait time','imm op','IMR CSS join retry','IMR disk votes','IMR membership resolution','IMR mount phase II completion','IMR net-check message ack','IMR rr lock release','IMR rr update','inactive session','inactive transaction branch','index block split','instance state change','IPC busy async request','IPC send completion sync','IPC wait for name service busy','IPC waiting for OSD resources','job scheduler coordinator slave wait','jobq slave shutdown wait','jobq slave TJ process wait','kcbzps','kdblil wait before retrying ORA-54','kdic_do_merge','kfcl: instance recovery','kgltwait','kjbdomalc allocate recovery domain - retry','kjbdrmcvtq lmon drm quiesce: ping completion','kjbopen wait for recovery domain attach','KJC: Wait for msg sends to complete','kjctcisnd: Queue/Send client message','kjctssqmg: quick message send wait','kjudomatt wait for recovery domain attach','kjudomdet wait for recovery domain detach','kjxgrtest','kkdlgon','kkdlhpon','kkdlsipon','kksfbc child completion','kksfbc research','kkshgnc reloop','kksscl hash split','knpc_acwm_AwaitChangedWaterMark','knpc_anq_AwaitNonemptyQueue','knpsmai','kpodplck wait before retrying ORA-54','ksbcic','ksbsrv','ksdxexeother','ksdxexeotherwait','ksim generic wait event','kslwait unit test event 1','kslwait unit test event 2','kslwait unit test event 3','ksv slave avail wait','ksxr poll remote instances','ksxr wait for mount shared','ktfbtgex','ktm: instance recovery','ktsambl','kttm2d','Kupp process shutdown','kupp process wait','kxfxse','kxfxsp','latch: active service list','latch activity','latch: cache buffer handles','latch: cache buffers lru chain','latch: call allocation','latch: change notification client cache latch','latch: Change Notification Hash table latch','latch: checkpoint queue latch','latch: enqueue hash chains','latch free','latch: gc element','latch: gcs resource hash','latch: ges resource hash list','latch: lob segment dispenser latch','latch: lob segment hash table latch','latch: lob segment query latch','latch: messages','latch: object queue header operation','latch: parallel query alloc buffer','latch: PX hash array latch','latch: redo allocation','latch: session allocation','latch: undo global data','latch: virtual circuit queues','latch: WCR: processes HT','latch: WCR: sync','LGWR ORL/NoExp FAL archival','LGWR simulation latency wait','LGWR wait for redo copy','LGWR-LNS wait on channel','library cache revalidation','library cache shutdown','listen endpoint status','listener registration dump','LMON global data update','lms flush message acks','LNS simulation latency wait','lock close','lock deadlock retry','lock escalate retry','lock release pending','log file switch (clearing log file)','log switch/archive','log write(even)','log write(odd)','Logical Standby Apply shutdown','Logical Standby Debug','Logical Standby dictionary build','Logical Standby pin transaction','Logical Standby Terminal Apply','L1 validation','master diskmon read','master diskmon startup','master exit','MMON (Lite) shutdown','MMON slave messages','MRP inactivation','MRP state inspection','MRP termination','MRP wait on archivelog archival','MRP wait on archivelog arrival','MRP wait on process restart','MRP wait on process start','MRP wait on startup clear','name-service call wait','NFS read delegation outstanding','no free buffers','no free locks','null event','OJVM: Generic','OLAP Aggregate Client Deq','OLAP Aggregate Client Enq','OLAP Aggregate Master Deq','OLAP Aggregate Master Enq','OLAP Null PQ Reason','OLAP Parallel Temp Grew','OLAP Parallel Temp Grow Request','OLAP Parallel Temp Grow Wait','OLAP Parallel Type Deq','opishd','optimizer stats update retry','OSD IPC library','parallel recovery change buffer free','parallel recovery coord send blocked','parallel recovery coord wait for reply','parallel recovery read buffer free','parallel recovery slave wait for change','pending global transaction(s)','pmon dblkr tst event','PMON to cleanup detached branches at shutdown','PMON to cleanup pseudo-branches at svc stop time','prewarm transfer retry','prior spawner clean up','process diagnostic dump','process shutdown','process startup','process terminate','PX create server','PX Deq Credit: free buffer','PX Deq Credit: Session Stats','PX Deq: OLAP Update Close','PX Deq: OLAP Update Execute','PX Deq: OLAP Update Reply','PX Deq: reap credit','PX Deq: Signal ACK EXT','PX Deq: Signal ACK RSG','PX Deq: Slave Join Frag','PX Deq: Slave Session Stats','PX Deq: Table Q Close','PX Deq: Table Q Get Keys','PX Deq: Table Q qref','PX Deq: Test for credit','PX Deq: Test for msg','PX hash elem being inserted','PX Nsq: PQ descriptor query','PX Nsq: PQ load info query','PX qref latch','PX Send Wait','PX server shutdown','PX signal server','PX slave connection','PX slave release','qerex_gdml','queue slave messages','rdbms ipc message block','rdbms ipc reply','readable standby redo apply remastering','recovery area: computing applied logs','recovery area: computing backed up files','recovery area: computing dropped files','recovery area: computing obsolete files','recovery buffer pinned','recovery instance recovery completion ','reliable message','Replication Dequeue ','resmgr:internal state cleanup','Resolution of in-doubt txns','RFS announce','RFS attach','RFS close','RFS create','RFS detach','RFS dispatch','RFS ping','RFS register','rollback operations active','rollback operations block full','rolling migration: cluster quiesce','row cache cleanup','row cache process','RSGA: RAC reconfiguration','RVWR wait for flashback copy','scginq AST call','secondary event','select wait','set director factor wait','SGA: allocation forcing component growth','SGA: sga_target resize','shutdown after switchover to standby','slave exit','Space Manager: slave messages','standby query scn advance','Streams AQ: emn coordinator waiting for slave to start','Streams AQ: qmn coordinator waiting for slave to start','Streams AQ: QueueTable kgl locks','Streams AQ: waiting for busy instance for instance_name','Streams capture: waiting for database startup','Streams miscellaneous event','Streams: RAC waiting for inter instance ack','SUPLOG PL wait for inflight pragma-d PL/SQL','Sync ASM rebalance','TEST: action hang','TEST: action sync','test long ops','timer in sksawat','transaction','TSE master key rekey','TSE SSO wallet reopen','tsm with timeout','txn to complete','unbound tx','undo segment recovery','undo_retention publish retry','unspecified wait event','wait active processes','wait for a paralle reco to abort','wait for a undo record','wait for another txn - rollback to savepoint','wait for another txn - txn abort','wait for another txn - undo rcv abort','wait for assert messages to be sent','wait for change','wait for EMON to spawn','wait for FMON to come up','wait for kkpo ref-partitioning *TEST EVENT*','wait for master scn','wait for MTTR advisory state object','wait for scn ack','Wait for shrink lock','Wait for shrink lock2','wait for stopper event to be increased','wait for sync ack','Wait for TT enqueue','wait for verification ack','wait list latch activity','wait list latch free','Wait on stby instance close','waiting to get CAS latch','waiting to get RM CAS latch','WCR: capture file IO write','WCR: RAC message context busy','WCR: Sync context busy','writes stopped by instance recovery or database suspension','xdb schema cache initialization','XDB SGA initialization' )
group by SE.EVENT_NAME
order by stat_value desc;

-- Load profile
select  snap_time as snap_time,
            snap_id,
        redo_size AS redo_size,
        logical_reads AS logical_reads,
        block_changes AS block_changes,
        physical_reads AS physical_reads,
        physical_writes AS physical_writes,
        user_calls AS user_calls,
        parses AS parses,
        hard_parses AS hard_parses,
        nvl(memory_sorts,0)+nvl(disk_sorts,0) as sorts,
        logons AS logons,
        executions AS executions,
        nvl(user_commit,0)+nvl(user_rollback,0) as transactions
from (
with 
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('execute count','logons cumulative','sorts (memory)','sorts (disk)''parse count (hard)','parse count (total)','user calls','physical reads','physical writes','db block changes','session logical reads','redo size','user commits','user rollbacks')
  and S.SNAP_ID between 4333 and 4692
--  order by s.snap_id desc
),
b as (  
  select * from local_data
),
e as (
 select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in ('execute count' as executions,'logons cumulative' as logons,'sorts (memory)' as memory_sorts,'sorts (disk)' as disk_sorts,'parse count (hard)' as hard_parses,'parse count (total)' as parses,'user calls' as user_calls,'physical reads' as physical_reads,'physical writes' as physical_writes,'db block changes' as block_changes,'session logical reads' as logical_reads,'redo size' as redo_size, 'user commits' as user_commit,'user rollbacks' as user_rollback)
 )
order by snap_id;
  
select *
from (
with b as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.POOL as pool,
        ST.BYTES as bytes
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SGASTAT st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between 4333 and 4692  
),
e as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.POOL as pool,
        ST.BYTES as bytes
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SGASTAT st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between 4333 and 4692  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.pool as pool,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.pool=b.pool
 ) v
 pivot (
max(value_diff)
for pool in ( '' as other_pool, 'java pool' as java_pool, 'streams pool' as streams_pool, 'shared pool' as shared_pool, 'large pool' as large_pool )
 )
order by snap_time;
  
  
select distinct st.name 
from SYS.WRH$_SGA st
where st.dbid=3432209923 and ST.INSTANCE_NUMBER=1 and ST.SNAP_ID between 4333 and 4692;


select *
from (
with b as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as pool,
        ST.value as bytes
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SGA st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between 4333 and 4692  
),
e as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as pool,
        ST.value as bytes
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SGA st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between 4333 and 4692  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.pool as pool,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.pool=b.pool
 ) v
 pivot (
max(value_diff)
for pool in ( 'Database Buffers' as db_chache,'Redo Buffers' as redo_buffer,'Variable Size' as variable_size,'Fixed Size' as fixed_size )
 )
order by snap_time;

-- PGA Stat --------------------------------------------------------------------
select *
from (
with b as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as stat_name,
        ST.value as bytes
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_PGASTAT st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.NAME in ('extra bytes read/written','total PGA inuse','total PGA allocated','maximum PGA allocated')
),
e as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.name as stat_name,
        ST.value as bytes
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_PGASTAT st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and ST.NAME in ('extra bytes read/written','total PGA inuse','total PGA allocated','maximum PGA allocated')
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.bytes - b.bytes) < 0 then null else (e.bytes - b.bytes) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
 ) v
 pivot (
max(value_diff)
for stat_name in ( 
'extra bytes read/written' as extra_bytes,
'total PGA inuse' as pga_inuse,
'total PGA allocated' as pga_alloc,
'maximum PGA allocated' as max_pga_alloc
 )
 )
order by snap_time;
-- SQL WA Stat -----------------------------------------------------------------
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.LOW_OPTIMAL_SIZE as LOW_OPTIMAL_SIZE,
        ST.HIGH_OPTIMAL_SIZE as HIGH_OPTIMAL_SIZE,
        ST.OPTIMAL_EXECUTIONS as OPTIMAL_EXECUTIONS,
        ST.ONEPASS_EXECUTIONS as ONEPASS_EXECUTIONS,
        ST.MULTIPASSES_EXECUTIONS as MULTIPASSES_EXECUTIONS,
        ST.TOTAL_EXECUTIONS as TOTAL_EXECUTIONS
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SQL_WORKAREA_HISTOGRAM st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
order by snap_time, LOW_OPTIMAL_SIZE;

--------------------------------------------------------------------------------

-- OSstat
select
v.snap_time as snap_time,
v.snap_id as snap_id,
v.NUM_CPUS as NUM_CPUS,
v.IDLE_TIME as IDLE_TIME,
v.BUSY_TIME as BUSY_TIME,
v.USER_TIME as USER_TIME,
v.SYS_TIME as SYS_TIME,
v.IOWAIT_TIME as IOWAIT_TIME,
v.NICE_TIME as NICE_TIME,
v.RSRC_MGR_CPU_WAIT_TIME as RSRC_MGR_CPU_WAIT_TIME,
v.LOAD as LOAD,
v.NUM_CPU_SOCKETS as NUM_CPU_SOCKETS,
v.PHYSICAL_MEMORY_BYTES as PHYSICAL_MEMORY_BYTES,
v.VM_IN_BYTES as VM_IN_BYTES,
v.VM_OUT_BYTES as VM_OUT_BYTES
from (
select *
from (
with  
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_OSSTAT os, SYS.WRH$_OSSTAT_NAME osn
where   S.dbid=3432209923 
    and S.SNAP_ID between 4333 and 4692  
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
),
b as (
  select * from local_data
 ),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,'IDLE_TIME' as IDLE_TIME,'BUSY_TIME' as BUSY_TIME,'USER_TIME' as USER_TIME,'SYS_TIME' as SYS_TIME,'IOWAIT_TIME' as IOWAIT_TIME,'NICE_TIME' as NICE_TIME,'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,'LOAD' as LOAD,'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,'VM_IN_BYTES' as VM_IN_BYTES,'VM_OUT_BYTES' as VM_OUT_BYTES)
)
 ) v
order by v.snap_id;


select
v.snap_time as snap_time,
v.snap_id as snap_id,
max_cpu_time.cpu_time_available*100 as cpu_time_available_csec, 
v.NUM_CPUS as NUM_CPUS,
v.IDLE_TIME as IDLE_TIME,
v.BUSY_TIME as BUSY_TIME,
v.USER_TIME as USER_TIME,
v.SYS_TIME as SYS_TIME,
v.IOWAIT_TIME as IOWAIT_TIME,
v.NICE_TIME as NICE_TIME,
v.RSRC_MGR_CPU_WAIT_TIME as RSRC_MGR_CPU_WAIT_TIME,
v.LOAD as LOAD,
v.NUM_CPU_SOCKETS as NUM_CPU_SOCKETS,
v.PHYSICAL_MEMORY_BYTES as PHYSICAL_MEMORY_BYTES,
v.VM_IN_BYTES as VM_IN_BYTES,
v.VM_OUT_BYTES as VM_OUT_BYTES
from (
select *
from (
with  
local_data as (
select rownum, S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_OSSTAT os, SYS.WRH$_OSSTAT_NAME osn
where   S.dbid=3432209923 
    and S.SNAP_ID between 4333 and 4692  
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
),
b as (
  select * from local_data
 ),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,'IDLE_TIME' as IDLE_TIME,'BUSY_TIME' as BUSY_TIME,'USER_TIME' as USER_TIME,'SYS_TIME' as SYS_TIME,'IOWAIT_TIME' as IOWAIT_TIME,'NICE_TIME' as NICE_TIME,'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,'LOAD' as LOAD,'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,'VM_IN_BYTES' as VM_IN_BYTES,'VM_OUT_BYTES' as VM_OUT_BYTES)
)
 ) v,  
(
 select snap_id,
        --cpu_count,snap_time,prev_snap_time,
        --extract(hour from snap_time-prev_snap_time)*3600+extract(minute from snap_time-prev_snap_time)*60+extract(second from snap_time-prev_snap_time) as seconds
        cpu_count*( extract(hour from snap_time-prev_snap_time)*3600+extract(minute from snap_time-prev_snap_time)*60+extract(second from snap_time-prev_snap_time) ) as cpu_time_available
 from (
 select s.snap_id as snap_id,
        T.VALUE as cpu_count,
        S.BEGIN_INTERVAL_TIME as snap_time,
        lag(S.BEGIN_INTERVAL_TIME,1,null) over (order by s.snap_id) as prev_snap_time 
 from SYS.WRH$_PARAMETER t, SYS.WRH$_PARAMETER_NAME pn, SYS.WRM$_SNAPSHOT s
 where s.dbid=3432209923 and s.INSTANCE_NUMBER=1 and s.SNAP_ID between 4333 and 4692
   and s.DBID=T.DBID and s.INSTANCE_NUMBER=t.INSTANCE_NUMBER and s.SNAP_ID=t.SNAP_ID
   and T.PARAMETER_HASH=PN.PARAMETER_HASH and T.DBID=PN.DBID and PN.PARAMETER_NAME='cpu_count'
 order by s.snap_id
 )
 where prev_snap_time is not null
) max_cpu_time
where v.snap_id=max_cpu_time.snap_id
order by v.snap_id;

select
v.snap_id as snap_id,
v.IDLE_TIME as IDLE_TIME,
v.BUSY_TIME as BUSY_TIME
from (
select *
from (
with local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_OSSTAT os, SYS.WRH$_OSSTAT_NAME osn
where   S.dbid=3432209923 
    and S.SNAP_ID between 4333 and 4692  
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
),
b as (
  select * from local_data
 ),
e as (
  select * from local_data
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,'IDLE_TIME' as IDLE_TIME,'BUSY_TIME' as BUSY_TIME,'USER_TIME' as USER_TIME,'SYS_TIME' as SYS_TIME,'IOWAIT_TIME' as IOWAIT_TIME,'NICE_TIME' as NICE_TIME,'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,'LOAD' as LOAD,'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,'VM_IN_BYTES' as VM_IN_BYTES,'VM_OUT_BYTES' as VM_OUT_BYTES)
)
 ) v  
order by v.snap_id;
--------------------------------------------------------------------------------


select * 
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('DB CPU','DB time','CPU used by this session')
  and S.SNAP_ID between 4333 and 4692  
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('DB CPU','DB time','CPU used by this session')
  and S.SNAP_ID between 4333 and 4692  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'CPU used by this session' as cpu_usage,
'DB time' as db_time,
'DB CPU' as db_cpu
)
 )
order by snap_time;

select *
from SYS.WRH$_STAT_NAME sn
where SN.dbid=3432209923 and SN.STAT_NAME like 'DB %';

select * 
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('buffer is not pinned count', 'buffer is pinned count', 'consistent gets from cache (fastpath)', 'no work - consistent read gets', 'parse count (failures)', 'parse count (hard)', 'physical reads', 'physical reads cache', 'physical write IO requests', 'physical writes from cache', 'redo subscn max counts', 'sql area purged', 'table fetch by rowid')
  and S.snap_id between 4333 and 4692
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ('buffer is not pinned count', 'buffer is pinned count', 'consistent gets from cache (fastpath)', 'no work - consistent read gets', 'parse count (failures)', 'parse count (hard)', 'physical reads', 'physical reads cache', 'physical write IO requests', 'physical writes from cache', 'redo subscn max counts', 'sql area purged', 'table fetch by rowid')
  and S.snap_id between 4333 and 4692
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'buffer is not pinned count' as buffer_is_not_pinned_count,
'buffer is pinned count' as buffer_is_pinned_count,
'consistent gets from cache (fastpath)' as ConsGetsFromCacheFastpath,
'no work - consistent read gets' as no_work_consistent_read_gets,
'parse count (failures)' as parse_count_failures,
'parse count (hard)' as parse_count_hard,
'ph reads' as ph_reads,
'ph reads cache' as ph_reads_cache,
'ph write IO requests' as ph_write_IO_requests,
'ph writes from cache' as ph_writes_from_cache,
'redo subscn max counts' as redo_subscn_max_counts,
'sql area purged' as sql_area_purged,
'table fetch by rowid' as table_fetch_by_rowid)
 )
order by snap_time;

-- sga stat
select *          
from (
 select s.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       decode( nvl(r.pool,''),'',r.name,r.pool ) as comp_name,
       round(sum(r.BYTES)/1024/1024,2) as size_mb
from SYS.WRH$_SGASTAT r, SYS.WRM$_SNAPSHOT s
where r.SNAP_ID=S.SNAP_ID and R.DBID=S.DBID and R.INSTANCE_NUMBER=S.INSTANCE_NUMBER
  and S.dbid=3432209923
  and S.snap_id between 4333 and 4692
group by s.BEGIN_INTERVAL_TIME, s.snap_id, decode( nvl(r.pool,''),'',r.name,r.pool )
order by s.snap_id, comp_name
) v
 pivot (
max(size_mb)
for comp_name in ('buffer_cache' as buffer_cache, 'fixed_sga' as fixed_sga, 'java pool' as java_pool, 'large pool' as large_pool, 'log_buffer' as log_buffer, 'shared pool' as shared_pool, 'streams pool' as streams_pool)
 )
order by snap_time;

-----------

-- pga stat

select *
from 
(with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_PGASTAT st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between 4333 and 4692   ),
e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       St.NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_PGASTAT st
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and S.SNAP_ID between 4333 and 4692   )
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
)
pivot (
max(value_diff)
for stat_name in (
'PGA memory freed back to OS' as PGA_memory_freed_back_to_OS,
'aggregate PGA auto target' as aggregate_PGA_auto_target,
'aggregate PGA target parameter' as aggregate_PGA_target_parameter,
'bytes processed' as bytes_processed,
'cache hit percentage' as cache_hit_percentage,
'extra bytes read/written' as extra_bytes_read_written,
'global memory bound' as global_memory_bound,
'max processes count' as max_processes_count,
'maximum PGA allocated' as maximum_PGA_allocated,
'maximum PGA used for auto workareas' as maxPGA_used4auto_wa,
'maximum PGA used for manual workareas' as maxPGA_used4manual_wa,
'over allocation count' as over_allocation_count,
'process count' as process_count,
'recompute count (total)' as recompute_count__total_,
'total PGA allocated' as total_PGA_allocated,
'total PGA inuse' as total_PGA_inuse,
'total PGA used for auto workareas' as totalPGA_used4auto_wa,
'total freeable PGA memory' as total_freeable_PGA_memory
)
 )
order by snap_time;
  
select *
from (
with    b as (select rownum, S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_OSSTAT os, SYS.WRH$_OSSTAT_NAME osn
where   S.dbid=3432209923 
    and S.SNAP_ID between 4333 and 4692  
        and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
 ),
        e as (select rownum, S.BEGIN_INTERVAL_TIME as snap_time, s.snap_id as snap_id, OSN.STAT_NAME as stat_name, OS.VALUE as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_OSSTAT os, SYS.WRH$_OSSTAT_NAME osn
where   S.dbid=3432209923 
    and S.SNAP_ID between 4333 and 4692  
    and s.dbid=OS.DBID and S.INSTANCE_NUMBER=OS.INSTANCE_NUMBER and s.snap_id=os.snap_id
    and osn.dbid=s.dbid and OS.STAT_ID=OSN.STAT_ID
)
select  e.snap_time as snap_time,
        e.snap_id as snap_id, e.stat_name as stat_name,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
order by e.snap_id
 ) v
pivot (
max(value_diff)
for stat_name in ('NUM_CPUS' as NUM_CPUS,'IDLE_TIME' as IDLE_TIME,'BUSY_TIME' as BUSY_TIME,'USER_TIME' as USER_TIME,'SYS_TIME' as SYS_TIME,'IOWAIT_TIME' as IOWAIT_TIME,'NICE_TIME' as NICE_TIME,'RSRC_MGR_CPU_WAIT_TIME' as RSRC_MGR_CPU_WAIT_TIME,'LOAD' as LOAD,'NUM_CPU_SOCKETS' as NUM_CPU_SOCKETS,'PHYSICAL_MEMORY_BYTES' as PHYSICAL_MEMORY_BYTES,'VM_IN_BYTES' as VM_IN_BYTES,'VM_OUT_BYTES' as VM_OUT_BYTES)
)
order by snap_id;


select *
from SYS.WRH$_LATCH_NAME l
where l.dbid=3432209923;


select distinct sn.stat_name from SYS.WRH$_STAT_NAME sn where SN.dbid=3432209923;
select * 
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical read IO requests', 'physical read total IO requests', 'physical read total multi block requests', 'physical reads', 'physical reads cache', 'physical reads cache prefetch', 'physical reads direct', 'physical reads direct (lob)', 'physical reads direct temporary tablespace', 'physical reads for flashback new', 'physical reads prefetch warmup', 'physical reads retry corrupt' )
  and S.SNAP_ID between 4333 and 4692 
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical read IO requests', 'physical read total IO requests', 'physical read total multi block requests', 'physical reads', 'physical reads cache', 'physical reads cache prefetch', 'physical reads direct', 'physical reads direct (lob)', 'physical reads direct temporary tablespace', 'physical reads for flashback new', 'physical reads prefetch warmup', 'physical reads retry corrupt' )
  and S.SNAP_ID between 4333 and 4692 
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical read IO requests' as phr_IO_requests,
'physical read total IO requests' as phr_ttl_IO_requests,
'physical read total multi block requests' as phr_ttl_mblock_rqsts,
'physical reads' as phrs,
'physical reads cache' as phrs_cache,
'physical reads cache prefetch' as phrs_cache_prefetch,
'physical reads direct' as phrs_direct,
'physical reads direct (lob)' as phrs_direct__lob_,
'physical reads direct temporary tablespace' as phrs_direct_temp_tblspc,
'physical reads for flashback new' as phrs_for_flashback_new,
'physical reads prefetch warmup' as phrs_prefetch_warmup,
'physical reads retry corrupt' as phrs_retry_corrupt
)
 )
order by snap_time;


select * 
from (
with b as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical reads', 'physical writes' )
  and S.SNAP_ID between 4333 and 4692  
),
     e as (select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in ( 'physical reads', 'physical writes' )
  and S.SNAP_ID between 4333 and 4692  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  ) v
 pivot (
max(value_diff)
for stat_name in (
'physical reads' as phrds,
'physical writes' as phwrs
)
 )
order by snap_time;


select *
from (
with
    b as (select  snap_time, snap_id, item_name, sum(PHYRDS) as PHYRDS, sum(PHYWRTS) as PHYWRTS
        from (
        select  S.BEGIN_INTERVAL_TIME as snap_time,
                S.SNAP_ID as snap_id,
                regexp_substr(SE.FILENAME,'^\+[A-Z]{3,4}[0-9]{1}') as item_name,
                SE.PHYRDS as PHYRDS,
                SE.PHYWRTS as PHYWRTS 
        from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_FILESTATXS se
        where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
          and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id 
          and S.snap_id between 4333 and 4692
          )
        group by snap_time, snap_id, item_name
),
    e as (select  snap_time, snap_id, item_name, sum(PHYRDS) as PHYRDS, sum(PHYWRTS) as PHYWRTS
        from (
        select  S.BEGIN_INTERVAL_TIME as snap_time,
                S.SNAP_ID as snap_id,
                regexp_substr(SE.FILENAME,'^\+[A-Z]{3,4}[0-9]{1}') as item_name,
                SE.PHYRDS as PHYRDS,
                SE.PHYWRTS as PHYWRTS 
        from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_FILESTATXS se
        where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
          and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
          and S.snap_id between 4333 and 4692
           )
        group by snap_time, snap_id, item_name
        )
select  e.snap_time as snap_time, 
        e.item_name as item_name,  
        nvl(e.PHYRDS,0)-nvl(b.PHYRDS,0) as PHYRDS,
        nvl(e.PHYWRTS,0)-nvl(b.PHYWRTS,0) as PHYWRTS
from b,e
where e.snap_id=(b.snap_id + 1) and e.item_name=b.item_name
)
pivot (
max(PHYRDS) as PHYRDS, max(PHYWRTS) as PHYWRTS
for item_name in ('+SATA1' as SATA1, '+SAS1' as SAS1, '+SSD1' as SSD1) 
 )
order by snap_time;


-- Event List
select *
from (
with b as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.snap_id between 4333 and 4692
  and SE.EVENT_NAME in ( 'i/o slave wait','io done','log file parallel write','db file parallel write','log file sequential read','rdbms ipc reply','log buffer space','log file sync','SQL*Net more data to client' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
),
     e as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       S.SNAP_ID as snap_id,
       SE.EVENT_NAME as stat_name,
       sum(SE.TIME_WAITED_MICRO) as stat_value 
from SYS.WRM$_SNAPSHOT s, SYS.DBA_HIST_SYSTEM_EVENT se
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=se.dbid and S.INSTANCE_NUMBER=SE.INSTANCE_NUMBER and s.snap_id=se.snap_id
  and S.snap_id between 4333 and 4692
  and SE.EVENT_NAME in ( 'i/o slave wait','io done','log file parallel write','db file parallel write','log file sequential read','rdbms ipc reply','log buffer space','log file sync','SQL*Net more data to client' )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID, SE.EVENT_NAME
)
select e.snap_time as snap_time, e.snap_id as snap_id, e.stat_name as stat_name,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.stat_name=b.stat_name
 ) v
pivot (
max(value_diff)
for stat_name in (
'i/o slave wait' as i_o_slave_wait,
'io done' as io_done,
'log file parallel write' as log_file_parallel_write,
'db file parallel write' as db_file_parallel_write,
'log file sequential read' as log_file_sequential_read,
'rdbms ipc reply' as rdbms_ipc_reply,
'log buffer space' as log_buffer_space,
'log file sync' as log_file_sync,
'SQL*Net more data to client' as SQL_Net_more_data_to_client
)
    )
order by snap_id;

-- UNDO stat
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        round(PR.VALUE*US.ACTIVEBLKS/1024/1024/1024,2) as active_undo_Gb,
        round(PR.VALUE*US.UNEXPIREDBLKS/1024/1024/1024,2)  as unexp_undo_Gb,
        round(PR.VALUE*US.EXPIREDBLKS/1024/1024/1024,2)  as exp_undo_Gb,
        US.UNXPSTEALCNT as unexp_steals,
        US.EXPSTEALCNT as exp_steals,
        US.TUNED_UNDORETENTION as tuned_ur_sec
        --PR.VALUE as block_size
from SYS.WRH$_UNDOSTAT us, SYS.WRM$_SNAPSHOT s,
     SYS.WRH$_PARAMETER pr, SYS.WRH$_PARAMETER_NAME pn
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.snap_id between 4333 and 4692
  and US.DBID=s.dbid and US.INSTANCE_NUMBER=s.INSTANCE_NUMBER and us.snap_id=s.snap_id
  and pr.DBID=s.dbid and pr.INSTANCE_NUMBER=s.INSTANCE_NUMBER and pr.snap_id=s.snap_id
  and pr.DBID=pn.dbid and PR.PARAMETER_HASH=PN.PARAMETER_HASH and PN.PARAMETER_NAME='db_block_size'
order by s.snap_id;
--------------------------------------------------------------------------------



select T.sql_id, T.SQL_TEXT
from SYS.WRH$_SQLTEXT t
where t.dbid=3432209923 and T.SQL_ID in ('963dmyqkudx6q','0jsb9d7xjqdyc');

select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.SQL_OPCODE,
        ST.TIME_WAITED as time_waited
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.snap_id between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and ST.EVENT_ID=(select en.event_id from SYS.WRH$_EVENT_NAME en where EN.event_name='log file sync' and EN.dbid=3432209923);
  
select  distinct ST.SQL_ID
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.snap_id between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and ST.EVENT_ID=(select en.event_id from SYS.WRH$_EVENT_NAME en where EN.event_name='log file sync' and EN.dbid=3432209923)
  and ST.MODULE='perl@eqm.ekat.ertelecom.ru (TNS V1-V3)';  
  
select *
from (
select  S.SNAP_ID as snap_id,
        ST.MODULE as tag,
        sum(ST.TIME_WAITED) as time_waited
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.snap_id between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and ST.EVENT_ID=(select en.event_id from SYS.WRH$_EVENT_NAME en where EN.event_name='log file sync' and EN.dbid=3432209923)
group by S.SNAP_ID, ST.MODULE
 )
 pivot (
max(time_waited)
for tag in 
(
'reports_eqm_for_billing.pars_xml_all_data' as c1,
'' as c2,
'rman@eqmdb.ekat.ertelecom.ru (TNS V1-V3)' as c3,
'sqlplus@eqm.ekat.ertelecom.ru (TNS V1-V3)' as c4,
'ppo@eqm.ekat.ertelecom.ru (TNS V1-V3)' as c5,
'eqm_rpt.re_request' as c6,
'perl@eqm.ekat.ertelecom.ru (TNS V1-V3)' as c7,
'SQL*Plus' as c8,
'''SQL-FUNCTIONS 1.0''' as c9,
'ppo@eqmdb.ekat.ertelecom.ru (TNS V1-V3)' as c10,
'EXCEL.EXE' as c11,
'python2.7@eqm.ekat.ertelecom.ru (TNS V1-V3)' as c12,
'MMON_SLAVE' as c13,
'eqm_rpt.ktv_xml_rep' as c14,
'DBMS_SCHEDULER' as c15,
' ' as c16,
'OGG-EQMREP-OPEN_DATA_SOURCE' as c17,
'sqlplus@eqmdb.ekat.ertelecom.ru (TNS V1-V3)' as c18,
'db_creator.exe' as c19
)
 )
order by snap_id;


select  ST.SNAP_ID as snap_id,
        ST.SAMPLE_TIME as sample_time,
        ST.SESSION_ID||'.'||ST.SESSION_SERIAL# as ORA_SESSION,
        ST.XID as xid
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and ST.XID is not null
  and ST.SESSION_TYPE=1 -- Foreground
order by snap_id, ORA_SESSION;

select  --ST.SNAP_ID as snap_id,
        ST.SAMPLE_TIME as sample_time,
        ST.SESSION_ID||'.'||ST.SESSION_SERIAL# as ORA_SESSION,
        ST.XID as xid
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and st.xid is not null;
  --and ST.SESSION_ID=585 and ST.SESSION_SERIAL#=9 and st.xid is not null;

select  snap_id,
        ORA_SESSION,
        xid,
        ( max(sample_time) - min(sample_time) ) as trx_time
from (
select  ST.SNAP_ID as snap_id,
        ST.SAMPLE_TIME as sample_time,
        ST.SESSION_ID||'.'||ST.SESSION_SERIAL# as ORA_SESSION,
        ST.XID as xid
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and st.xid is not null
  )
group by snap_id, ORA_SESSION, xid
order by snap_id, ORA_SESSION, xid;

select  trunc(ST.SAMPLE_TIME,'mi') as sample_time,
        sum ( DECODE (st.session_type, 1, ST.PGA_ALLOCATED , 0) ) as FOREGROUND_PGA,
        sum ( DECODE (st.session_type, 1, 0, ST.PGA_ALLOCATED ) ) as NONFOREGROUND_PGA
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and ST.SAMPLE_TIME between to_date('29/04/2014 20:00:53','dd/mm/yyyy hh24:mi:ss') and to_date('30/04/2014 02:00:41','dd/mm/yyyy hh24:mi:ss')
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
group by trunc(ST.SAMPLE_TIME,'mi')
order by sample_time;


select  *
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and ST.SAMPLE_TIME between to_date('29/04/2014 23:10:00','dd/mm/yyyy hh24:mi:ss') and to_date('29/04/2014 23:20:00','dd/mm/yyyy hh24:mi:ss')
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and st.session_type=1
order by ST.PGA_ALLOCATED desc;


select  distinct ST.SESSION_TYPE
from SYS.WRH$_ACTIVE_SESSION_HISTORY st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and ST.SAMPLE_TIME between to_date('29/04/2014 20:00:53','dd/mm/yyyy hh24:mi:ss') and to_date('30/04/2014 02:00:41','dd/mm/yyyy hh24:mi:ss')
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID;

  
select  ST.BEGIN_TIME as date_time,
        --(ST.END_TIME-ST.BEGIN_TIME)*86400 as period_length_sec,
        ST.MAXCONCURRENCY as trx_executed,
        round( ST.TXNCOUNT/( (ST.END_TIME-ST.BEGIN_TIME)*86400 ), 2) as trx_rate_sec
from SYS.WRH$_UNDOSTAT st, SYS.WRM$_SNAPSHOT s
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
order by date_time;

select  d.snap_id as snap_id,
        S.BEGIN_INTERVAL_TIME as snap_time,
        round(d.total_active_sessions/d.total_samples,2) as avg_active_sessions
from (
select  snap_id,
        sum(session_count) as total_active_sessions,
        count(*) as total_samples
from (
select  ASH.SNAP_ID as snap_id,
        ASH.SAMPLE_TIME as sample_time,
        count(*) as session_count
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_ACTIVE_SESSION_HISTORY ash
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.snap_id between 4333 and 4692
  and S.DBID=ash.dbid and S.INSTANCE_NUMBER=ash.INSTANCE_NUMBER and s.snap_id=ash.snap_id
  and ASH.EVENT_ID in ( select EN.EVENT_ID from SYS.WRH$_EVENT_NAME en where EN.dbid=3432209923 and EN.EVENT_NAME in ('Log file init write','log file single write','log file parallel write','log file sync') )
group by ash.snap_id, ash.sample_time
 )  
group by snap_id
order by snap_id
 ) d, SYS.WRM$_SNAPSHOT s
where s.snap_id=d.snap_id and s.dbid=3432209923 and S.INSTANCE_NUMBER=1;


select  ash.*
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_ACTIVE_SESSION_HISTORY ash
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=ash.dbid and S.INSTANCE_NUMBER=ash.INSTANCE_NUMBER and s.snap_id=ash.snap_id
  and S.snap_id between 4333 and 4692
  and ASH.EVENT_ID in ( select EN.EVENT_ID from SYS.WRH$_EVENT_NAME en where EN.dbid=3432209923 and EN.EVENT_NAME in ('Log file init write','log file single write','log file parallel write','log file sync') )
;

select  count(*) as case_count,
        bucket_num
from (
select width_bucket(sql_rt_sec, 0.000353040983721778, 0.0124591386414693, 10 ) as bucket_num
       --min(sql_rt_sec), max(sql_rt_sec) 
from (
select  S.snap_id as snap_time,
        --sum(ST.EXECUTIONS_DELTA) as sql_executions,
        --sum(ST.ELAPSED_TIME_DELTA) as sql_ela_time,
        ( sum(ST.ELAPSED_TIME_DELTA)/sum(ST.EXECUTIONS_DELTA) )/1000000 as sql_rt_sec
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.snap_id between 4333 and 4692
group by S.snap_id
order by snap_time
 )
  )
group by bucket_num
order by bucket_num;
  
select  S.snap_id as snap_time,
        --sum(ST.EXECUTIONS_DELTA) as sql_executions,
        sum(ST.DISK_READS_DELTA) as sql_stat
        -- ( sum(ST.ELAPSED_TIME_DELTA)/sum(ST.EXECUTIONS_DELTA) )/1000000 as sql_rt_sec
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.snap_id between 4333 and 4692
group by S.snap_id
order by snap_time;

-- Given SQL_ID --
select *
from (
with 
local_data as (
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        ST.SQL_ID as sql_id,
        ST.EXECUTIONS_DELTA as stat_value
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SQLSTAT st
where S.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.snap_id between 4333 and 4692
  and S.DBID=ST.DBID and S.INSTANCE_NUMBER=ST.INSTANCE_NUMBER and S.SNAP_ID=ST.SNAP_ID
  and ST.SQL_ID in ( 
'68nyg57ya6q54','71s027p3sta35','04b1jzxwzrhdm','9f98vny25n0qf'  
  )
),
b as (
  select * from local_data
),
e as (
  select * from local_data
)  
select e.snap_time as snap_time, e.snap_id as snap_id, e.sql_id as sql_id,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b, e
where e.snap_id=(b.snap_id + 1) and e.sql_id=b.sql_id
) v
pivot (
max(value_diff)
for sql_id in (
'71s027p3sta35' as q71s027p3sta35,
'04b1jzxwzrhdm' as q04b1jzxwzrhdm,
'9f98vny25n0qf' as q9f98vny25n0qf
 )
)
order by snap_id;
--------------------------------------------------------------------------------
select T.ITEM_NAME
from awr_publisher.temp_explains t
where T.METRIC <= 710647.5071
order by T.METRIC;

select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.snap_id as snap_id,
        --sum(ST.EXECUTIONS_DELTA) as sql_executions
        --sum(ST.DISK_READS_DELTA) as sql_stat
        --sum(ST.DIRECT_WRITES_DELTA) as sql_stat
        --sum(ST.ELAPSED_TIME_DELTA) as ela_time,
        --sum(ST.CPU_TIME_DELTA) as cpu_time
        --sum(ST.IOWAIT_DELTA) as iowait_time
        sum(ST.PHYSICAL_READ_BYTES_DELTA) as iowait_time
        --sum(ST.CLWAIT_DELTA) as clwait_time,
        --sum(ST.APWAIT_DELTA) as apwait_time,
        --sum(ST.CCWAIT_DELTA) as ccwait_time
        -- ( sum(ST.ELAPSED_TIME_DELTA)/sum(ST.EXECUTIONS_DELTA) )/1000000 as sql_rt_sec
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.snap_id between 4333 and 4692
/*  and ST.SQL_ID in (
'085fy1xbxm6vz','0ws6373pb8rg3','30z4tq3vpvdtb','1hgbna3fjfg9a','4md3xasnf2jb5','5hny0x1nhjjcm','8qgfaun0a5265','95dpbdbxt0m7f','97hp7w2ck26nx','7rk3pcy9r2n4d','8b1kb9mx3v4zk','asurc8g6p16ns','bdx2u72fdpcja','a0jpfbh34c6gy','g3kym16x2u0u7'  
  )
  */
group by S.BEGIN_INTERVAL_TIME, S.snap_id
order by snap_time;

select  snap_time,
        max(decode(PARSING_SCHEMA_NAME,'EXCELLENT',sql_stat,null)) as EXCELLENT,
        max(decode(PARSING_SCHEMA_NAME,'EXCELLENT2',sql_stat,null)) as EXCELLENT2,
        max(decode(PARSING_SCHEMA_NAME,'EXCELLENT3',sql_stat,null)) as EXCELLENT3
from (
select  S.snap_id as snap_time,
        ST.PARSING_SCHEMA_NAME as PARSING_SCHEMA_NAME,
        sum(ST.) as sql_stat
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.snap_id between 4333 and 4692
  and ST.SQL_ID in (
'ctshk7try04xm'  
  )
group by S.snap_id, ST.PARSING_SCHEMA_NAME
order by snap_time
 )
group by snap_time
order by snap_time;


select t.sql_id, T.COMMAND_TYPE, t.sql_text
from SYS.WRH$_SQLTEXT t
where T.dbid=3432209923 --and t.snap_id between 4333 and 4692
  and T.SQL_ID in ( 
  '04b1jzxwzrhdm','0ttnwxyust0cv','4u97t5dquxqzh','71s027p3sta35','9f98vny25n0qf','f7hppc6q7a0br' 
  )
  --and upper(T.SQL_TEXT) like '%TP_MVTS_CDR%'
  ;
  
select  T.SNAP_ID as snap_id,
        sum(T.PHYSICAL_READS_DELTA) as seg_stat
from SYS.WRH$_SEG_STAT t
where T.dbid=3432209923 and T.INSTANCE_NUMBER=1 and T.SNAP_ID between 4333 and 4692
  and T.OBJ# not in ( 
  2971804,2771063,3047196,5841,385396,3055240,83619,84019,3003559 
  )
group by t.snap_id;  

-- AAS query --
select  d.snap_id as snap_id,
        S.BEGIN_INTERVAL_TIME as snap_time,
        round(d.total_active_sessions/d.total_samples,2) as avg_active_sessions
from (
select  snap_id,
        sum(session_count) as total_active_sessions,
        count(*) as total_samples
from (
select  ASH.SNAP_ID as snap_id,
        ASH.SAMPLE_TIME as sample_time,
        count(*) as session_count
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_ACTIVE_SESSION_HISTORY ash
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1
  and S.DBID=ash.dbid and S.INSTANCE_NUMBER=ash.INSTANCE_NUMBER and s.snap_id=ash.snap_id
  and S.snap_id between 4333 and 4692
  and ASH.EVENT_ID=( select EN.EVENT_ID from SYS.WRH$_EVENT_NAME en where EN.dbid=3432209923 and EN.EVENT_NAME='db file sequential read')
  and ASH.CURRENT_FILE# != 0 and ASH.CURRENT_BLOCK# != 0
group by ash.snap_id, ash.sample_time
order by ash.snap_id
 )  
group by snap_id
order by snap_id
 ) d, SYS.WRM$_SNAPSHOT s
where s.snap_id=d.snap_id and s.dbid=3432209923 and S.INSTANCE_NUMBER=1;
--------------------------------------------------------------------------------

-- SegStat
select  S.BEGIN_INTERVAL_TIME as snap_time,
        S.SNAP_ID as snap_id,
        sum(SG.PHYSICAL_WRITES_DELTA) as stat_value
from SYS.WRH$_SEG_STAT sg, SYS.WRM$_SNAPSHOT s
where s.dbid=3432209923 and S.INSTANCE_NUMBER=1 and S.SNAP_ID between 4333 and 4692
  and sg.dbid=s.dbid and SG.INSTANCE_NUMBER=S.INSTANCE_NUMBER and SG.SNAP_ID=S.SNAP_ID
  and sg.OBJ# not in ( 221668,78550,6342,3177360,1403556,515183,91647,978626,834219,94739,78532,3318245,6339,78528,1318808,91262,90877,95894,268867,78536,80822,1435369,78650,92032,90492 )
group by S.BEGIN_INTERVAL_TIME, S.SNAP_ID
order by s.snap_id;
--------------------------------------------------------------------------------

select T.ITEM_NAME
from awr_publisher.temp_explains t
where T.METRIC <= 3508165702151.7889*1.03;

select  v.ITEM_NAME,
        obj.OWNER||'.'||OBJ.OBJECT_NAME as obj_name,
        OBJ.OBJECT_TYPE
from (
select T.ITEM_NAME as ITEM_NAME
from awr_publisher.temp_explains t
--where T.METRIC <= (242711705 + 42074314754.9945)
order by T.METRIC
 ) v, dba_objects obj
where v.ITEM_NAME=OBJ.OBJECT_ID;

select  T.OWNER||'.'||T.SEGMENT_NAME as sgm_name,
        T.BLOCKS
from dba_segments t
where T.OWNER||'.'||T.SEGMENT_NAME='BITEST.D_AGREEMEN_DIMENSION_KEY_PK';
select T.PCT_FREE
from dba_tables t
where T.OWNER||'.'||T.TABLE_NAME='BITEST.D_AGREEMENTS_TAB';

select * 
from SYS.WRH$_SQL_PLAN t
where T.SQL_ID='71s027p3sta35' 
  and t.dbid=3432209923
  --and t.SNAP_ID between 4333 and 4692;