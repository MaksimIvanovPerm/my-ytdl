define v_sts_name="20180604_1_sts"
define v_task_name="saa_20180604"

exec DBMS_SQLTUNE.DROP_TUNING_TASK('&&v_task_name');

EXEC DBMS_SQLTUNE.DELETE_SQLSET(sqlset_name=>'&&v_sts_name');


select *
from SYS.DBA_SQLSET t
where T.NAME='&&v_sts_name';

select *
from SYS.DBA_SQLSET_STATEMENTS t
where T.SQLSET_NAME='myworkload';

select *
from SYS.DBA_ADVISOR_TASKS t
where t.task_name='SqlAccessAdvisorTask'
order by t.created desc;

exec DBMS_ADVISOR.DELETE_TASK('TASK_16751');

SELECT * --VALUE(P)
FROM table(DBMS_SQLTUNE.SELECT_WORKLOAD_REPOSITORY(16521,16650,
'parsing_schema_name=''BITEST'' and sql_id in (''02mru4nj8fnwa'',''0qufjxhky8x51'',''0ycchjh63r4q3'',''1jxpg2mdrwg4s'',''1rt29yf76chby'',''24nw2umc6d7ch'',''25waafqns3hz5'',''2yn9hhsvnuzd9'',''34hg07fvpxg4s'',''3zmajz37j0jf8'',''45k1uwzk3uch1'',''5uy7s1wt7awv8'',''60ft45bu3gywv'',''6vamg73kku3yd'',''77fjtp2pmpu0f'',''80gr4rhpq63nh'',''97jusnx95daus'',''a5y77zjmp9xpz'',''ahycwgbbgrvph'',''b2nawt98jtb17'',''bp0smdmkq4zht'',''bsputmscgryrs'',''d0mfhkxm8h2ch'',''fzdcdkvct5p7a'',''gnux0zb3sxduk'',''gywfdmhuzpfat'')',
NULL, NULL,NULL,NULL,1,NULL,'ALL')) P;


SELECT * --VALUE(P)
FROM table(DBMS_SQLTUNE.SELECT_WORKLOAD_REPOSITORY(begin_snap=>16521,end_snap=>16666,
basic_filter=>'parsing_schema_name=''BITEST'' and command_type!=47',
object_filter=>NULL,
ranking_measure1=>'CPU_TIME',
ranking_measure2=>NULL,
ranking_measure3=>NULL,
result_percentage=>0.5,
result_limit=>NULL,
attribute_list=>'ALL')) P;

select * from dba_tablespaces;
select 3*60||'' from dual;