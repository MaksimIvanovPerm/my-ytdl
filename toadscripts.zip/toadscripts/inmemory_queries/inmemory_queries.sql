SELECT *
FROM V$INMEMORY_AREA t;

SELECT  t.pool,
        Round(t.ALLOC_BYTES/1024/1024,2) AS ALLOC_MEM_Mb,
        Round(t.USED_BYTES/1024/1024,2) AS  USED_MEM_Mb,
        t.POPULATE_STATUS
FROM V$INMEMORY_AREA t;

SELECT s.status, s.event, p.*
FROM v$process p, v$session s
WHERE p.background=1
  AND p.addr=s.paddr
ORDER BY p.pname
;


SELECT *
FROM V$IM_SEGMENTS t
--WHERE t.OWNER='BITEST' AND t.segment_name LIKE 'D\_C%' ESCAPE '\'
ORDER BY t.owner, t.segment_name
  ;

SELECT  t.OWNER,
        t.SEGMENT_NAME,
        t.PARTITION_NAME,
        t.SEGMENT_TYPE,
        Round(t.INMEMORY_SIZE/1024/1024,2) AS INMEMORY_SIZE_MB,
        Round(t.BYTES/1024/1024,2) AS SIZE_MB,
        CASE
          WHEN t.BYTES > 0 THEN Round((t.BYTES-t.INMEMORY_SIZE)/t.BYTES,2)
        ELSE null
        END AS compress_ratio,
        Round(t.BYTES_NOT_POPULATED/1024/1024,2) AS MB_NOT_POPULATED,
        t.POPULATE_STATUS,
        t.INMEMORY_PRIORITY,
        t.INMEMORY_COMPRESSION
FROM V$IM_SEGMENTS t
ORDER BY t.OWNER, t.SEGMENT_NAME, t.PARTITION_NAME;

SELECT  t.OWNER, t.SEGMENT_NAME, t.POPULATE_STATUS,
        Round(Sum(t.INMEMORY_SIZE)/1024/1024,2) AS INMEMORY_SIZE_Mb,
        Round(Sum(t.BYTES)/1024/1024,2) AS DISK_SIZE_Mb
FROM V$IM_SEGMENTS t
GROUP BY t.OWNER, t.SEGMENT_NAME, t.POPULATE_STATUS
ORDER BY t.OWNER, t.SEGMENT_NAME, t.POPULATE_STATUS;

SELECT *
FROM V$IM_USER_SEGMENTS t;

select * 
from sys.DBA_JOINGROUPS t
;


SELECT *
FROM sys.dba_tables t
WHERE t.owner='BITEST' 
  AND t.table_name in ('D_PROBLEM_CLASSES_TAB', 'D_CITIES_TAB' )
  and t.inmemory='ENABLED'
;

ALTER TABLE "BITEST"."D_PROBLEM_CLASSES_TAB" INMEMORY NO MEMCOMPRESS;
ALTER TABLE "BITEST"."D_CITIES_TAB" INMEMORY NO MEMCOMPRESS;
exec DBMS_INMEMORY.POPULATE('BITEST', 'D_PROBLEM_CLASSES_TAB');
exec DBMS_INMEMORY.POPULATE('BITEST', 'D_CITIES_TAB');

SELECT *
FROM sys.dba_tab_partitions t
WHERE t.TABLE_OWNER='BITEST' AND t.table_name='F_SOLD_AGREEMENTS';

SELECT Round(Sum(t.BYTES)/1024/1024/1024,2) AS size_Gb
FROM sys.dba_segments t
WHERE t.OWNER='EXCELLENT' AND t.segment_name='F_SOLD_AGREEMENTS';

SELECT *
FROM sys.dba_segments t
WHERE t.OWNER='EXCELLENT' AND t.segment_name LIKE '%F\_SOLD\_AGREEMENTS%' ESCAPE '\';

---- IM Expressions
SELECT t.*
       --Count(*)
FROM sys.DBA_EXPRESSION_STATISTICS t
WHERE 1=1
  --AND t.last_modified>=(SYSDATE-1)
  AND t.SNAPSHOT='LATEST'
  AND t.owner='EXCELLENT' AND t.table_name='D_GEO_TAB'
;

SELECT tab_name, expression_text, expression_id, evaluation_count, fixed_cost,
       Sqrt(Power(evaluation_count/max_evaluation_count,2)+Power(fixed_cost/max_fixed_cost,2)) AS metric
FROM (
SELECT t.owner||'.'||t.table_name AS tab_name, t.expression_id, t.evaluation_count, fixed_cost, t.expression_text,
        Max(t.fixed_cost) OVER (ORDER BY null) AS max_fixed_cost,
        Max(t.evaluation_count) OVER (ORDER BY null) AS max_evaluation_count
FROM sys.DBA_EXPRESSION_STATISTICS t
WHERE 1=1
  AND t.last_modified>=(SYSDATE-1))
  ORDER BY metric desc
;


SELECT * FROM sys.DBA_IM_EXPRESSIONS t;

select *
from sys.DBA_INMEMORY_AIMTASKS t
;

select * 
from sys.DBA_INMEMORY_AIMTASKDETAILS t
;

---- IMA Task deals;
define v_task_name="im_advise_task"
define v_ima_owner="IMADVISOR"
set verify OFF serveroutput ON appinfo imcadvisor timing on echo off 

SELECT *
FROM &&v_ima_owner..DBA_IMA_TASK_INFORMATION t
WHERE t.task_name='&&v_task_name'
;


begin
 dbms_inmemory_advisor.drop_task(task_name=>'&&v_task_name',FORCE=>true);
exception
 when others then dbms_output.put_line('Can not drop task &&v_task_name');
end;
/

-- place service tables to imc, it much decreases time of imc-advisor work;
-- later, after imc-advisor task will be done, those tables should be get rid out from imc;
DECLARE
CURSOR c1 is
SELECT *
FROM sys.dba_segments t
WHERE t.owner='&&v_ima_owner'
  AND t.segment_type='TABLE'
  --AND t.bytes>1*1024*1024
ORDER BY t.bytes desc
;
BEGIN
 FOR i IN c1
 LOOP
  Dbms_Output.put_line('alter table '||i.owner||'.'||i.segment_name||' inmemory priority low');
  EXECUTE IMMEDIATE 'alter table '||i.owner||'.'||i.segment_name||' inmemory priority low';
 END LOOP;
END;
/

SELECT *
FROM sys.dba_tables t
WHERE t.owner='&&v_ima_owner'
  AND t.inmemory='ENABLED'
;

EXEC Dbms_Stats.gather_schema_stats(ownname=>'&&v_ima_owner',method_opt=>'for all indexed columns size auto',CASCADE=>true);
exec dbms_inmemory_advisor.create_task(task_name=>'&&v_task_name');
define ts_format="DD.MM.YYYY HH24:MI:SS.FF"
define btime="06.05.2021 05:21:00.00"
define etime="06.05.2021 23:20:00.00"
--SELECT to_timestamp('&&btime', '&&ts_format'), to_timestamp('&&etime', '&&ts_format') FROM dual;
exec dbms_inmemory_advisor.add_statistics('&&v_task_name', to_timestamp('&&btime', '&&ts_format'), to_timestamp('&&etime', '&&ts_format') );
select SYSTIMESTAMP-3600, SYSTIMESTAMP, sysdate from dual;
exec dbms_inmemory_advisor.add_statistics(task_name=>'&&v_task_name',capture_window_start=>SYSTIMESTAMP-1/24, capture_window_end=>SYSTIMESTAMP);
declare
 v_sql_coverage_pct number;
begin
 v_sql_coverage_pct := dbms_inmemory_advisor.ash_sql_coverage_pct('&&v_task_name');
 dbms_output.put_line('sql_coverage_pct='||v_sql_coverage_pct);
end;
/

exec dbms_inmemory_advisor.execute_task (task_name=>'&&v_task_name',consider_objects_like=>'CAMPAIGN.%,UNICA_USER.%,CMDM.%,PLATFORM.%,STAGE.%,EXCHANGE.%');
set pagesize 0
set linesize 128
-- select DIRECTORY_NAME||' '||DIRECTORY_PATH from dba_directories order by DIRECTORY_NAME;
-- grant read,write on directory AWR_DUMPS to &&v_ima_owner;
DECLARE
 v_rec &&v_ima_owner..DBA_IMA_TASK_INFORMATION%ROWTYPE;
BEGIN
 SELECT *
 INTO v_rec
 FROM &&v_ima_owner..DBA_IMA_TASK_INFORMATION t
 WHERE t.task_name='&&v_task_name';

 IF v_rec.state='inactive' AND v_rec.last_action='execute_task' AND v_rec.executed='Y'
 THEN
  Dbms_Output.put_line('ok, im task state is correct, try to generate report');
  dbms_inmemory_advisor.generate_recommendations (task_name=>'&&v_task_name', directory_name=>'AWR_DUMPS', inmemory_size=>32212254720, single_page_report=>TRUE);
 ELSE
  Dbms_Output.put_line('ok, im task state is not correct:'||v_rec.state||' '||v_rec.last_action||' '||v_rec.executed);
 END IF;
END;
/

SELECT t.file_name
FROM &&v_ima_owner..DBA_IMA_RECOMMENDATION_FILES t
WHERE t.task_name='&&v_task_name'
  AND Lower(t.file_name) LIKE '%.sql'
;

/*
alter table bitest.d_agreements_tab inmemory MEMCOMPRESS FOR QUERY LOW priority low;
alter table bitest.d_calendar_tab inmemory memcompress for query low priority low;
alter table bitest.d_cities_tab inmemory MEMCOMPRESS FOR QUERY LOW priority low;
alter table bitest.d_geo_tab inmemory MEMCOMPRESS FOR QUERY LOW priority low;
*/

DECLARE
 CURSOR c1 IS
 SELECT *
FROM sys.dba_tables t
WHERE 1=1
  and t.owner='&&v_ima_owner'
  AND t.inmemory='ENABLED'
  --AND t.table_name NOT IN ('D_CALENDAR_TAB','D_CITIES_TAB','D_AGREEMENTS_TAB')
;
BEGIN
 FOR i IN c1
 LOOP
  Dbms_Output.put_line('alter table '||i.owner||'.'||i.table_name||' no inmemory');
  EXECUTE IMMEDIATE 'alter table '||i.owner||'.'||i.table_name||' no inmemory';
 END LOOP;
END;
/

DECLARE
CURSOR c1 IS
SELECT t.owner, t.table_name, t.blocks, t.inmemory_priority, t.inmemory_compression
FROM sys.dba_tables t
WHERE t.inmemory='ENABLED'
--ORDER BY t.blocks desc
;
BEGIN
 FOR i IN c1
 LOOP
  Dbms_Output.put_line('alter table '||i.owner||'.'||i.table_name||' no inmemory');
  EXECUTE immediate 'alter table '||i.owner||'.'||i.table_name||' no inmemory';
 END LOOP;
END;
/

DECLARE
CURSOR c1 is
SELECT t.table_owner, t.table_name, t.partition_name, t.inmemory_priority, t.inmemory_compression
FROM sys.dba_tab_partitions t
WHERE t.inmemory='ENABLED'
;
BEGIN
 FOR i IN c1
 LOOP
  --Dbms_Output.put_line('alter table '||i.table_owner||'.'||i.table_name||' modify partition '||i.partition_name||' no inmemory');
  execute IMMEDIATE 'alter table '||i.table_owner||'.'||i.table_name||' modify partition '||i.partition_name||' no inmemory';
 END LOOP;
END;
/


SELECT *
FROM &&v_ima_owner..DBA_IMA_TASK_INFORMATION t
WHERE t.task_name='&&v_task_name'
ORDER BY t.date_created desc
;

SELECT *
FROM &&v_ima_owner.DBA_IMA_AWR_AUGMENTS t
;

SELECT *
FROM &&v_ima_owner.DBA_IMA_BENEFIT_COST t
;

SELECT *
      -- DISTINCT t.table_owner||'.'||t.table_name AS recommended_tables
FROM &&v_ima_owner..DBA_IMA_RECOMMENDATIONS t
WHERE t.task_name='&&v_task_name'
  --AND t.status='accepted'
  --AND t.table_owner||'"."'||t.table_name='CAMPAIGN"."UA_TREATMENT'
ORDER BY t.status
;

SELECT *
FROM &&v_ima_owner..DBA_IMA_RECOMMENDATION_LINES t
WHERE t.file_name='imadvisor_im_advise_task.sql'
;

SELECT *
FROM &&v_ima_owner..DBA_IMA_AWR_AUGMENTS t;

SET SERVEROUTPUT ON
DECLARE
  l_blkcnt_cmp    PLS_INTEGER;
  l_blkcnt_uncmp  PLS_INTEGER;
  l_row_cmp       PLS_INTEGER;
  l_row_uncmp     PLS_INTEGER;
  l_cmp_ratio     NUMBER;
  l_comptype_str  VARCHAR2(32767);
BEGIN
  DBMS_COMPRESSION.get_compression_ratio (
    scratchtbsname  => 'USERS',
    ownname         => 'USER1',
    objname         => 'CF1',
    subobjname      => NULL,
    comptype        => DBMS_COMPRESSION.COMP_INMEMORY_QUERY_LOW,
    blkcnt_cmp      => l_blkcnt_cmp,
    blkcnt_uncmp    => l_blkcnt_uncmp,
    row_cmp         => l_row_cmp,
    row_uncmp       => l_row_uncmp,
    cmp_ratio       => l_cmp_ratio,
    comptype_str    => l_comptype_str,
    subset_numrows  => DBMS_COMPRESSION.comp_ratio_allrows,
    objtype         => DBMS_COMPRESSION.objtype_table
  );

  DBMS_OUTPUT.put_line('Number of blocks used (compressed)       : ' ||  l_blkcnt_cmp);
  DBMS_OUTPUT.put_line('Number of blocks used (uncompressed)     : ' ||  l_blkcnt_uncmp);
  DBMS_OUTPUT.put_line('Number of rows in a block (compressed)   : ' ||  l_row_cmp);
  DBMS_OUTPUT.put_line('Number of rows in a block (uncompressed) : ' ||  l_row_uncmp);
  DBMS_OUTPUT.put_line('Compression ratio                        : ' ||  l_cmp_ratio);
  DBMS_OUTPUT.put_line('Compression type                         : ' ||  l_comptype_str);
END;
/
