select  min(statistic) as p01,
        max(statistic) as p95
from 
(
select  snap_time,
        snap_id,
        statistic,
        cume_dist() over (order by statistic) as cmdist
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=2982764204 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical reads'
  )
  and S.SNAP_ID between 17184 and 17460
),
b as (  
  select * from local_data
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as statistic 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  )
  order by snap_id
   )
where cmdist between 0.01 and 0.95;


select  snap_time,
        snap_id,
        statistic,
        wtht_outliers,
        avg(wtht_outliers) over (order by snap_id rows between 14 preceding and current row) as mvng_avg
from 
(
select  snap_time,
        snap_id,
        statistic,
        cmdist,
        case 
        when cmdist <= 0.01 then 68439
        when cmdist >= 0.95 then 3997593
        else statistic 
        end as wtht_outliers -- Replace outliers
from (
select  snap_time,
        snap_id,
        statistic,
        cume_dist() over (order by statistic) as cmdist
        --avg(statistic) over (order by null) as avg_statistic,
from (
with
local_data as (
select S.BEGIN_INTERVAL_TIME as snap_time,
       s.snap_id as snap_id,
       ST.VALUE as stat_value,
       SN.STAT_NAME as stat_name
from SYS.WRM$_SNAPSHOT s, SYS.WRH$_SYSSTAT st, SYS.WRH$_STAT_NAME sn
where s.dbid=2982764204 and S.INSTANCE_NUMBER=1
  and ST.DBID=s.dbid and ST.INSTANCE_NUMBER=S.INSTANCE_NUMBER and st.snap_id=s.snap_id
  and st.dbid=sn.dbid and ST.STAT_ID=sn.stat_id and SN.STAT_NAME in (
'physical reads'
  )
  and S.SNAP_ID between 17184 and 17460
),
b as (  
  select * from local_data
),
e as (
  select * from local_data  
)
select e.snap_time as snap_time,
       e.snap_id as snap_id,
       case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as statistic 
from b, e
where e.snap_id=(b.snap_id+1) and e.stat_name=b.stat_name
  )
  --order by snap_id
   )
   --order by snap_id
   )
    order by snap_id;
