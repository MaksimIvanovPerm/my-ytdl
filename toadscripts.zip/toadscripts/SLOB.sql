/*
export ORACLE_SID=XE
export ORACLE_HOME=/opt/oracle/product/18c/dbhomeXE
*/
create tablespace SLOB datafile '/db/u14/oradata/XE/slob_01.dbf' size 128M autoextend on next 128M maxsize unlimited;
create tablespace statspack datafile '/db/u14/oradata/XE/statspack_01.dbf' size 128M autoextend on next 128M maxsize UNLIMITED DEFAULT TABLE COMPRESS FOR oltp;
ALTER TABLEspace statspack DEFAULT INDEX COMPRESS advanced low;

SELECT *
FROM sys.dba_segments t
WHERE 1=1
  --AND t.tablespace_name='STATSPACK'
  AND t.owner='USER1'
;

SELECT Sum(t.bytes)/1024/1024 AS size_mb
FROM sys.dba_segments t
WHERE 1=1
  AND t.tablespace_name='STATSPACK'
  --AND t.owner='USER1'
;

SELECT *
FROM sys.dba_objects t
WHERE t.owner='PERFSTAT'
;

SELECT * FROM user1.cf1 t;

/*
define perfstat_password="perfstat"
define default_tablespace="STATSPACK"
define temporary_tablespace="TEMP"
@$ORACLE_HOME/rdbms/admin/spcreate.sql

export NO_OS_PERF_DATA=TRUE
./runit.sh -s 1 -t 1

define num_days=""
define begin_snap="1"
define end_snap="2"
set concat .
define report_name="/tmp/spreport_&&begin_snap._&&end_snap..txt"
@$ORACLE_HOME/rdbms/admin/spreport.sql

*/

declare
 v_max_snapid number;
 v_min_snapid number;
begin
 select Min(snap_id), Max(snap_id) INTO v_min_snapid, v_max_snapid
 from PERFSTAT.STATS$SNAPSHOT s
 WHERE s.dbid=(SELECT dbid FROM v$database);
 IF v_min_snapid IS NOT NULL AND v_max_snapid IS NOT NULL then
  perfstat.statspack.purge(i_begin_snap=>v_min_snapid, i_end_snap=>v_max_snapid, i_snap_range=>TRUE, i_extended_purge=>false);
  COMMIT;
 END IF;
EXCEPTION
 WHEN OTHERS THEN NULL;
end;
/

/*
export NO_OS_PERF_DATA=TRUE
export BASE_DIR="/home/oracle/SLOB/SLOB"
. "${BASE_DIR}/slob.conf"
. "${BASE_DIR}/misc/test_handler_lib.sh"
purge_all_snapshots
cat /dev/null > "/tmp/slob.log"
./runit.sh -s 1 -t 1 | tee -a "/tmp/slob.log"
cat /tmp/slob.log | grep "statspack snap ID"
*/

SELECT COUNT(C2) FROM user1.CF1 WHERE ( CUSTID > ( :B1 - :B2 ) ) AND (CUSTID < :B1 );

/*
vgs
lvcreate --name ora_redo --size=8G vgsys
lvs
mkfs.xfs -f -L DB_U02 /dev/mapper/vgsys-ora_redo
mkdir -p /db/u02
mount -o noatime,nodiratime,nobarrier,logbsize=256k /dev/mapper/vgsys-ora_redo /db/u02
cat /proc/mounts | grep u02
chown -R oracle:dba /db/u02
chmod -R 775 /db/u02
# as oracle
mkdir -p /db/u02/oradata/XE

ALTER DATABASE ADD LOGFILE GROUP ... SIZE ... BLOCKSIZE 4096;
- ??????????? ??? ORA-01378 ? ??? ??????????? '_disk_sector_size_override'=true
*/

execute dbms_scheduler.set_attribute('MONDAY_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('TUESDAY_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('WEDNESDAY_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('THURSDAY_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('FRIDAY_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('SATURDAY_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('SUNDAY_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('WEEKNIGHT_WINDOW','RESOURCE_PLAN','');
execute dbms_scheduler.set_attribute('WEEKEND_WINDOW','RESOURCE_PLAN','');
COMMIT;

EXEC DBMS_SCHEDULER.CLOSE_WINDOW('SYS.WEEKNIGHT_WINDOW');
EXEC DBMS_SCHEDULER.CLOSE_WINDOW('SATURDAY_WINDOW');
COMMIT;

EXEC dbms_scheduler.disable('SYS.WEEKNIGHT_WINDOW');
EXEC dbms_scheduler.disable('SYS.WEEKEND_WINDOW');
EXEC dbms_scheduler.disable('SYS.MONDAY_WINDOW');
EXEC dbms_scheduler.disable('SYS.TUESDAY_WINDOW');
EXEC dbms_scheduler.disable('SYS.WEDNESDAY_WINDOW');
EXEC dbms_scheduler.disable('SYS.THURSDAY_WINDOW');
EXEC dbms_scheduler.disable('SYS.FRIDAY_WINDOW');
EXEC dbms_scheduler.disable('SYS.SATURDAY_WINDOW');
EXEC dbms_scheduler.disable('SYS.SUNDAY_WINDOW');
COMMIT;



EXEC dbms_scheduler.disable('MAINTENANCE_WINDOW_GROUP', FORCE=>true);
EXEC dbms_scheduler.disable('ORA$AT_WGRP_OS');
EXEC dbms_scheduler.disable('ORA$AT_WGRP_SA');
EXEC dbms_scheduler.disable('ORA$AT_WGRP_SQ');
COMMIT;

SELECT *
FROM sys.dba_tables t
WHERE t.owner='USER1'
;

--cache stat
SELECT * FROM V$RESULT_CACHE_STATISTICS;

--cache data
select * FROM V$RESULT_CACHE_MEMORY t;

--cache results info: sql-querirs, status of their results in cache, lru-count and etc
select * FROM V$RESULT_CACHE_OBJECTS t;

SELECT * FROM V$RESULT_CACHE_DEPENDENCY t;

ALTER DATABASE ADD LOGFILE GROUP 4 ('/db/u02/oradata/XE/redo04_01.log') SIZE 1G;
ALTER DATABASE ADD LOGFILE GROUP 5 ('/db/u02/oradata/XE/redo05_01.log') SIZE 1G;
ALTER DATABASE ADD LOGFILE GROUP 6 ('/db/u02/oradata/XE/redo06_01.log') SIZE 1G;
ALTER DATABASE ADD LOGFILE GROUP 7 ('/db/u02/oradata/XE/redo07_01.log') SIZE 1G;