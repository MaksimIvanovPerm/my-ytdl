select *
from REDMINE.REDMINE2JIRA t;