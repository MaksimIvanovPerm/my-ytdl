select  T.*
from SYS.V_$PARAMETER t
where T.NAME like 'parallel%';

select *
from v$instance;
select 2*32*4*5 from dual;

select * from V$PX_BUFFER_ADVICE t;

select  s.sid||','||S.SERIAL# as sess_info,
        S.STATE, S.STATUS, S.EVENT, S.SQL_ID, S.SQL_HASH_VALUE,
        SN.NAME, T.VALUE
from V$PX_SESSTAT t, v$statname sn, v$session s
where T.VALUE > 0
  and T.STATISTIC#=SN.STATISTIC#
  and T.SID=s.sid and T.SERIAL#=S.SERIAL#
order by s.sid, T.VALUE desc;

select T.STATUS as status, count(*)
from V$PX_PROCESS t
group by T.STATUS
order by 2 desc;

select  t.pid, t.status,
        S.STATE, S.EVENT, S.SQL_ID, S.SQL_HASH_VALUE,
        S.BLOCKING_SESSION, S.BLOCKING_SESSION_STATUS
from V$PX_PROCESS t, v$session s
where t.sid=s.sid and t.serial#=s.serial#;

select *
from SYS.V_$SQL t
where T.SQL_ID='0rcap2a721xhk' and T.PLAN_HASH_VALUE='2384524818';

select * from V$PX_PROCESS_SYSSTAT t;

select * from V$PQ_SESSTAT;


SELECT NAME, VALUE FROM V$SYSSTAT
WHERE UPPER (NAME) LIKE '%PARALLEL OPERATIONS%'
OR UPPER (NAME) LIKE '%PARALLELIZED%' OR UPPER (NAME) LIKE '%PX%';