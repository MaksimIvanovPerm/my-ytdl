SELECT *
FROM sys.DBA_STREAMS_RULES t
--WHERE t.streams_type='CAPTURE' and t.streams_name='TPCC_CPTR'
--WHERE t.streams_type='PROPAGATION' AND t.streams_name='TPCC_PRPGTN'
WHERE t.streams_type='APPLY' AND t.streams_name='TPCC_APPL'
;

SELECT *
FROM SYS.DBA_EVALUATION_CONTEXTS t
;

SELECT *
FROM SYS.DBA_EVALUATION_CONTEXT_TABLES t
WHERE t.evaluation_context_name='STREAMS$_EVALUATION_CONTEXT'
;

SELECT *
FROM SYS.DBA_EVALUATION_CONTEXT_VARS t
WHERE t.evaluation_context_name='STREAMS$_EVALUATION_CONTEXT'
;

SELECT *
FROM SYS.DBA_RULES t
WHERE t.rule_owner='STRMADMIN'
  AND t.rule_name='ONLY_SETTED_TABLES'
;

SELECT *
FROM SYS.DBA_RULE_SETS t
WHERE t.rule_set_owner='STRMADMIN'
;

SELECT *
FROM sys.DBA_RULE_SET_RULES t
WHERE t.rule_set_name='TPCC_APPLY_PRS'
;

EXEC DBMS_RULE_ADM.CREATE_RULE_SET(rule_set_name=>'TPCC_APPLY_PRS',rule_set_comment=>'Positive set of rules for TPCC_APPLY');
EXEC DBMS_RULE_ADM.CREATE_RULE(rule_name=>'ONLY_SETTED_TABLES', condition=>':dml.get_object_owner() = ''TPCC'' and (:dml.get_object_name()=''CUSTOMER'' or :dml.get_object_name()=''DISTRICT'' or :dml.get_object_name()=''HISTORY'' or :dml.get_object_name()=''ITEM'' or :dml.get_object_name()=''ORDERS'' or :dml.get_object_name()=''STOCK'' or :dml.get_object_name()=''TEST_TABLE'' or :dml.get_object_name()=''WAREHOUSE'')', rule_comment=>'Only setted list of tables');
EXEC DBMS_RULE_ADM.ALTER_RULE(rule_name=>'ONLY_SETTED_TABLES', condition=>':dml.get_object_owner() = ''TPCC'' and (:dml.get_object_name()=''CUSTOMER'' or :dml.get_object_name()=''DISTRICT'' or :dml.get_object_name()=''HISTORY'' or :dml.get_object_name()=''ITEM'' or :dml.get_object_name()=''ORDERS'' or :dml.get_object_name()=''STOCK'' or :dml.get_object_name()=''WAREHOUSE'')');

EXEC DBMS_RULE_ADM.ADD_RULE(rule_name=>'ONLY_SETTED_TABLES',rule_set_name=>'TPCC_APPLY_PRS',evaluation_context=>'SYS.STREAMS$_EVALUATION_CONTEXT');

EXEC DBMS_RULE_ADM.DROP_RULE_SET(rule_set_name=>'TPCC_APPLY_PRS',delete_rules=>TRUE);

((((:dml.get_object_owner() = 'TPCC') and :dml.get_source_database_name() = 'BUILD_HQ.TESTING.ERTELECOM.RU' )) and (:dml.get_compatible() <= dbms_streams.compatible_11_2))