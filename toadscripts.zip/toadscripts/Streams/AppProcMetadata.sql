SELECT *
FROM sys.dba_apply t
WHERE t.apply_name='TPCC_APPL'
;

SELECT *
FROM sys.DBA_APPLY_PARAMETERS t
WHERE t.apply_name='TPCC_APPL'
ORDER BY t.parameter
;

SELECT current_scn FROM v$database;

SELECT *
FROM sys.DBA_APPLY_SPILL_TXN t
WHERE t.apply_name='TPCC_APPL'
;

SELECT /*+PARAM('_module_action_old_length',0)*/ ACTION,
       SID,
       SERIAL#,
       PROCESS,
       SUBSTR(PROGRAM,INSTR(PROGRAM,'(')+1,4) PROCESS_NAME,
       status,
       event,
       sql_id
  FROM V$SESSION
  WHERE MODULE ='Streams' AND
        ACTION LIKE '%Apply%'
;

SELECT *
FROM v$sql t
WHERE t.sql_id='fvgd59hm5p45n'
;

SELECT r.APPLY_NAME,
       ap.APPLY_CAPTURED,
       SUBSTR(s.PROGRAM,INSTR(s.PROGRAM,'(')+1,4) PROCESS_NAME,
       r.STATE,
       r.TOTAL_MESSAGES_DEQUEUED,
       r.sga_allocated,
       s.sid,s.serial#,s.event,s.action,
       r.proxy_sid,
       r.proxy_serial,
       r.proxy_spid
       FROM SYS.V_$STREAMS_APPLY_READER r, V$SESSION s, DBA_APPLY ap
       WHERE r.SID = s.SID AND
             r.SERIAL# = s.SERIAL# AND
             r.APPLY_NAME = ap.APPLY_NAME
;

SELECT c.APPLY_NAME,
       SUBSTR(s.PROGRAM,INSTR(s.PROGRAM,'(')+1,4) PROCESS_NAME,
       c.SID,
       c.SERIAL#,
       c.STATE,
       c.total_errors,
       c.lwm_position, c.hwm_position,
       s.event
       FROM SYS.V_$STREAMS_APPLY_COORDINATOR c, V$SESSION s
       WHERE c.SID = s.SID AND
             c.SERIAL# = s.SERIAL#
;

SELECT c.APPLY_NAME,
       c.TOTAL_RECEIVED,
       c.TOTAL_APPLIED,
       c.TOTAL_ERRORS,
       (c.TOTAL_ASSIGNED - (c.TOTAL_ROLLBACKS + c.TOTAL_APPLIED)) BEING_APPLIED,
       c.UNASSIGNED_COMPLETE_TXNS,
       c.TOTAL_IGNORED,
       s.event, s.state
       FROM SYS.V_$STREAMS_APPLY_COORDINATOR c, v$session s
WHERE c.sid=s.sid AND c.serial#=s.serial#
;

SELECT APPLY_NAME,
       SOURCE_DATABASE,
       LOCAL_TRANSACTION_ID,
       ERROR_NUMBER,
       ERROR_MESSAGE,
       MESSAGE_COUNT
  FROM DBA_APPLY_ERROR t
;

SELECT *
FROM sys.DBA_APPLY_ERROR_MESSAGES t
;

EXEC DBMS_APPLY_ADM.EXECUTE_ALL_ERRORS('TPCC_APPL');
EXEC DBMS_APPLY_ADM.START_APPLY('TPCC_APPL');
EXEC DBMS_APPLY_ADM.STOP_APPLY('TPCC_APPL');

EXEC DBMS_APPLY_ADM.ALTER_APPLY(apply_name=>'TPCC_APPL',rule_set_name=>'TPCC_APPLY_PRS');