CREATE PROFILE unlim_profile limit COMPOSITE_LIMIT unlimited  PASSWORD_GRACE_TIME unlimited  CPU_PER_SESSION unlimited  CPU_PER_CALL unlimited  LOGICAL_READS_PER_SESSION unlimited  LOGICAL_READS_PER_CALL unlimited  IDLE_TIME unlimited  CONNECT_TIME unlimited  PRIVATE_SGA unlimited  FAILED_LOGIN_ATTEMPTS unlimited  PASSWORD_LIFE_TIME unlimited  PASSWORD_REUSE_TIME unlimited  PASSWORD_REUSE_MAX unlimited  PASSWORD_LOCK_TIME unlimited  SESSIONS_PER_USER unlimited;
CREATE USER strmadmin IDENTIFIED BY YtrbqGfhjkm DEFAULT TABLESPACE excellent TEMPORARY TABLESPACE temp;
GRANT DBA TO strmadmin;
ALTER USER strmadmin PROFILE unlim_profile;

exec DBMS_STREAMS_AUTH.GRANT_ADMIN_PRIVILEGE(grantee=>'strmadmin',grant_privileges => TRUE);

select *
FROM DBA_STREAMS_ADMINISTRATOR t
;

SELECT * FROM GLOBAL_NAME;
-- At hq_dev:
CREATE DATABASE LINK BUILD.TESTING.ERTELECOM.RU CONNECT TO strmadmin IDENTIFIED BY YtrbqGfhjkm USING 'designdb';
-- At perm_dev:
CREATE DATABASE LINK BUILD_HQ.TESTING.ERTELECOM.RU CONNECT TO strmadmin IDENTIFIED BY YtrbqGfhjkm USING 'dev_hq';

SELECT *
FROM sys.dba_directories t
ORDER BY t.directory_name
;

SELECT *
FROM sys.DBA_STREAMS_UNSUPPORTED t
WHERE t.owner='EXCELLENT'
;

conn strmadmin
begin
DBMS_STREAMS_ADM.MAINTAIN_SCHEMAS(schema_names=>'TPCC',
   source_directory_object=>'AWR_DUMP_DIR',
   destination_directory_object=>'AWR_DUMP_DIR',
   source_database=>'BUILD_HQ.TESTING.ERTELECOM.RU',
   destination_database=>'BUILD.TESTING.ERTELECOM.RU',
   perform_actions=>FALSE,
   script_name=>'init_rep.sql',
   script_directory_object=>'PLSHPROF_DIR',
   --dump_file_name               IN VARCHAR2  DEFAULT NULL,
   capture_name=>'TPCC_CPTR',
   capture_queue_table=>'TPCC_CPTR_QT',
   capture_queue_name=>'TPCC_CPTR_Q',
   --capture_queue_user           IN VARCHAR2  DEFAULT NULL,
   propagation_name=>'TPCC_PRPGTN',
   apply_name=>'TPCC_APPL',
   apply_queue_table=>'TPCC_APPL_QT',
   apply_queue_name=>'TPCC_APPL_Q',
   --apply_queue_user             IN VARCHAR2  DEFAULT NULL,
   --log_file                     IN VARCHAR2  DEFAULT NULL,*/
   bi_directional=>FALSE,
   include_ddl=>FALSE
   --instantiation=>DBMS_STREAMS_ADM.INSTANTIATION_SCHEMA_NETWORK
   );
END;
/

SELECT *
FROM sys.DBA_APPLY_INSTANTIATED_SCHEMAS t
;
