SELECT SUPPLEMENTAL_LOG_DATA_MIN log_min,
       SUPPLEMENTAL_LOG_DATA_PK log_pk,
       SUPPLEMENTAL_LOG_DATA_FK log_fk,
       SUPPLEMENTAL_LOG_DATA_UI log_ui,
       SUPPLEMENTAL_LOG_DATA_ALL log_all
FROM V$DATABASE
;

SELECT *
FROM sys.DBA_CAPTURE_PREPARED_SCHEMAS t
;

SELECT *
FROM sys.DBA_CAPTURE_PREPARED_TABLES t
WHERE t.table_owner='TPCC'
;

SELECT *
FROM sys.DBA_CAPTURE t
WHERE t.capture_name='TPCC_CPTR'
;

SELECT status,
       last_enqueued_scn-curr_scn AS how_old_last_enqurd_lcd,
       captured_scn-curr_scn AS how_old_are_captured_changes,
       applied_scn-curr_scn AS how_old_are_applied_changes,
       required_checkpoint_scn-curr_scn AS how_long_ago_redo_is_neede
FROM (
SELECT t.status, t.captured_scn, t.applied_scn, t.required_checkpoint_scn, t.last_enqueued_scn,
(SELECT current_scn FROM v$database) AS curr_scn
FROM sys.DBA_CAPTURE t
WHERE t.capture_name='TPCC_CPTR'
 )
;


SELECT *
FROM V$SESSION
  WHERE MODULE ='Streams' AND
        ACTION LIKE '%Capture%';

-- Different States of Capture & Apply Process (Doc ID 471713.1)
-- Streams Combined Capture and Apply in 11g (Doc ID 463820.1) sys.V_$STREAMS_CAPTURE.OPTIMIZATION > 0
SELECT *
FROM  sys.V_$STREAMS_CAPTURE sc
;

SELECT CAPTURE_NAME, STATE FROM V$STREAMS_CAPTURE;

SELECT *
FROM v$archived_log t
WHERE t.first_change#>=14290263995986
ORDER BY t.SEQUENCE#
;


SELECT r.CONSUMER_NAME,
       r.SOURCE_DATABASE,
       r.SEQUENCE#,
       r.NAME
  FROM DBA_REGISTERED_ARCHIVED_LOG r, DBA_CAPTURE c
  WHERE r.CONSUMER_NAME =  c.CAPTURE_NAME AND r.NEXT_SCN >= c.REQUIRED_CHECKPOINT_SCN
    AND c.capture_name='TPCC_CPTR'
UNION all
SELECT NULL, NULL, l.sequence#, l.status||' redo-log' AS name
FROM sys.v_$log l
WHERE l.next_change#>=(SELECT c.REQUIRED_CHECKPOINT_SCN FROM sys.dba_capture c WHERE c.capture_name='TPCC_CPTR')
ORDER BY 3 desc
;

SELECT *
FROM sys.DBA_LOGMNR_SESSION t
;

SELECT *
FROM SYS.V_$LOGMNR_SESSION t
WHERE t.session_id=2
;

EXEC  dbms_capture_adm.stop_capture('TPCC_CPTR');
BEGIN
 DBMS_CAPTURE_ADM.ALTER_CAPTURE(capture_name=>'TPCC_CPTR', first_scn=>14291487655664);
END;
/

exec dbms_capture_adm.start_capture('TPCC_CPTR');
exec dbms_capture_adm.stop_capture('TPCC_CPTR');