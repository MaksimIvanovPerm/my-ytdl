set serveroutput on;

declare
 task_name   varchar2(100) := 'ANALYZE_TABLE';
begin
 DBMS_ADVISOR.DELETE_TASK(task_name);
exception when others then null;
end;
/



declare
task_name   varchar2(100) := 'ANALYZE_TABLE';
descr       varchar2(500) := 'Analyze TABLE-segments for their fragmentation percentage';
task_id     number;
v_x         number;
begin
    dbms_output.put_line('Create task '||task_name);
    dbms_advisor.create_task('Segment Advisor',task_id, task_name, descr, NULL);
    dbms_output.put_line('Task ID = ' || task_id || ' Name = ' || task_name) ;
end;
/

select * 
from SYS.DBA_ADVISOR_TASKS t
where T.TASK_NAME='ANALYZE_TABLE';

declare
 task_name      varchar2(100) := 'ANALYZE_TABLE';
 v_owner        varchar2(30) := upper('EXCELLENT');
 v_object_id    number;
 cursor c1(p_owner in varchar2) is
select  T.OWNER as tab_owner,
        T.SEGMENT_NAME as tab_name,
        round(T.BYTES/1024/1024,2) as size_Mb,
        LB.TABLE_NAME
from SYS.DBA_SEGMENTS t, sys.DBA_TABLES lb
where T.SEGMENT_NAME=LB.TABLE_NAME
  and LB.OWNER=p_owner
  and round(T.BYTES/1024/1024,2) > 2;
begin
 for i in c1(v_owner)
 loop
  dbms_advisor.create_object(task_name, 'TABLE', i.tab_owner, i.tab_name, NULL, NULL, NULL, v_object_id);
 end loop;
 --dbms_output.put_line('Object id: '||v_object_id);
end;
/

select *
from SYS.DBA_ADVISOR_OBJECTS t
where T.TASK_NAME='ANALYZE_TABLE';


declare
 task_name      varchar2(100) := 'ANALYZE_TABLE';
 v_time_limit   number := 3600; -- Amount of time for advisor task working, in seconds
begin
dbms_advisor.set_task_parameter(task_name, 'RECOMMEND_ALL', 'FALSE') ;
dbms_advisor.set_task_parameter(task_name, 'TIME_LIMIT', v_time_limit ) ;
dbms_advisor.set_task_parameter(task_name, 'MODE', 'COMPREHENSIVE') ;
dbms_advisor.set_task_parameter(task_name, 'DAYS_TO_EXPIRE', '2') ;
dbms_advisor.set_task_parameter(task_name, 'HISTORY_LEVEL', 'NONE') ;
end;
/

select T.PARAMETER_NAME, T.PARAMETER_VALUE
from sys.DBA_ADVISOR_PARAMETERS t
where T.TASK_NAME='ANALYZE_TABLE'
order by T.PARAMETER_NAME;


declare
 task_name   varchar2(100) := 'ANALYZE_TABLE';
begin
 dbms_application_info.set_action('running: '||task_name);
 dbms_advisor.execute_task(task_name);
end;
/

select *
from DBA_ADVISOR_FINDINGS t 
where T.TASK_NAME='ANALYZE_TABLE';

select  TOBJ.TASK_NAME,
        TOBJ.ATTR1,
        TOBJ.ATTR2,
        T.MORE_INFO,
        T.MESSAGE
from SYS.DBA_ADVISOR_FINDINGS t,sys.DBA_ADVISOR_OBJECTS tobj
where T.TASK_NAME='ANALYZE_TABLE'
  and T.TASK_NAME=tobj.TASK_NAME
  and T.OBJECT_ID=tobj.OBJECT_ID;

select *
from sys.DBA_ADVISOR_OBJECTS t
where T.TASK_NAME='ANALYZE_TABLE';

select *
from SYS.DBA_ADVISOR_ACTIONS t
where T.TASK_NAME='ANALYZE_TABLE';

select *
from sys.DBA_ADVISOR_COMMANDS t;


/*
select t.*
from table(dbms_space.asa_recommendations('FALSE', 'FALSE', 'FALSE')) t
order by t.task_id desc;
*/

select  segment_name as seg_name,
        round(allocated_space/1024/1024,1) alloc_mb,
        round(used_space/1024/1024,1) used_mb,
        round(reclaimable_space/1024/1024,1) reclaim_mb,
        round(reclaimable_space/allocated_space*100,1) pct_save,
        recommendations,
        c1 code1,
        c2 code2,
        c3 code3
from table(dbms_space.asa_recommendations()) where task_id = (select t.task_id from SYS.DBA_ADVISOR_TASKS t where T.TASK_NAME='ANALYZE_TABLE');



declare
 task_name   varchar2(100) := 'ANALYZE_TABLE';
begin
 DBMS_ADVISOR.DELETE_TASK(task_name);
 null;
exception when others then null;
end;
/
