set serveroutput on;
set feedback off
set pagesize 0
set timing on
set serveroutput on
set verify off
set linesize 128

define tname="ANALYZE_LOBS"
-- Amount of time, in seconds, as limit for adviser task working;
define tlimit="3600" 

spool /tmp/spad_table.log replace

select distinct sid working_sess_sid from v$mystat;

declare
 task_name   varchar2(100) := '&&tname';
begin
 DBMS_ADVISOR.DELETE_TASK(task_name);
exception when others then null;
end;
/



declare
task_name   varchar2(100) := '&&tname';
descr       varchar2(500) := 'Analyze LOB-segments for their fragmentation percentage';
task_id     number;
v_x         number;
begin
    dbms_output.put_line('Create task '||task_name);
    dbms_advisor.create_task('Segment Advisor',task_id, task_name, descr, NULL);
    dbms_output.put_line('Task ID = ' || task_id || ' Name = ' || task_name) ;
end;
/

--select * from SYS.DBA_ADVISOR_TASKS t where T.TASK_NAME='&&tname';
select OWNER||' '||TASK_NAME||' '||CREATED||' '||STATUS||' '||ERROR_MESSAGE from SYS.DBA_ADVISOR_TASKS t where T.TASK_NAME='&&tname';

declare
 task_name      varchar2(100) := '&&tname';
 v_owner        varchar2(30) := upper('EXCELLENT');
 v_object_id    number;
 cursor c1(p_owner in varchar2) is
select  T.OWNER as lob_segment_owner,
        T.SEGMENT_NAME as lob_segment_name,
        round(T.BYTES/1024/1024,2) as size_Mb,
        LB.TABLE_NAME as tab_name,
        LB.COLUMN_NAME as col_name
from SYS.DBA_SEGMENTS t, sys.DBA_LOBS lb
where T.SEGMENT_NAME=LB.SEGMENT_NAME
  --and LB.OWNER=p_owner
  and round(T.BYTES/1024/1024,2) > 2
order by 3 desc;
begin
 for i in c1(v_owner)
 loop
  dbms_advisor.create_object(task_name, 'LOB', i.lob_segment_owner, i.lob_segment_name, NULL, NULL, NULL, v_object_id);
 end loop;
 dbms_output.put_line('Object id: '||v_object_id);
end;
/

--select * from SYS.DBA_ADVISOR_OBJECTS t where T.TASK_NAME='&&tname';
select attr1||'.'||attr2 as lobs4processing  from SYS.DBA_ADVISOR_OBJECTS t where T.TASK_NAME='&&tname';


declare
 task_name      varchar2(100) := '&&tname';
 v_time_limit   number := &&tlimit; -- Amount of time for advisor task working, in seconds
begin
dbms_advisor.set_task_parameter(task_name, 'RECOMMEND_ALL', 'FALSE') ;
dbms_advisor.set_task_parameter(task_name, 'TIME_LIMIT', v_time_limit ) ;
dbms_advisor.set_task_parameter(task_name, 'MODE', 'COMPREHENSIVE') ;
dbms_advisor.set_task_parameter(task_name, 'DAYS_TO_EXPIRE', '2') ;
dbms_advisor.set_task_parameter(task_name, 'HISTORY_LEVEL', 'NONE') ;
end;
/

select T.PARAMETER_NAME||' '||T.PARAMETER_VALUE
from sys.DBA_ADVISOR_PARAMETERS t
where T.TASK_NAME='&&tname'
order by T.PARAMETER_NAME;


declare
 task_name   varchar2(100) := '&&tname';
begin
 dbms_application_info.set_action('running: '||task_name);
 dbms_advisor.execute_task(task_name);
end;
/


select 'seg_name                    alloc_Mb    used_Mb reclaim_Mb  pct_save' from dual
union all 
select  segment_name||'     '||round(allocated_space/1024/1024,1)||'    '||round(used_space/1024/1024,1)||' '||round(reclaimable_space/1024/1024,1)||'  '||round(reclaimable_space/allocated_space*100,1)
from table(dbms_space.asa_recommendations()) where task_id = (select t.task_id from SYS.DBA_ADVISOR_TASKS t where T.TASK_NAME='&&tname');

select  c2||';'||chr(10)||c1||';' as cmd from table(dbms_space.asa_recommendations()) where task_id = (select t.task_id from SYS.DBA_ADVISOR_TASKS t where T.TASK_NAME='&&tname');




/*
select *
from sys.DBA_ADVISOR_OBJECTS t
where T.TASK_NAME='&&tname';

select *
from SYS.DBA_ADVISOR_ACTIONS t
where T.TASK_NAME='&&tname';

select *
from sys.DBA_ADVISOR_COMMANDS t;
*/

/*
select t.*
from table(dbms_space.asa_recommendations('FALSE', 'FALSE', 'FALSE')) t
order by t.task_id desc;
*/
/*
select  segment_name as seg_name,
        round(allocated_space/1024/1024,1) alloc_mb,
        round(used_space/1024/1024,1) used_mb,
        round(reclaimable_space/1024/1024,1) reclaim_mb,
        round(reclaimable_space/allocated_space*100,1) pct_save,
        recommendations,
        c1 code1,
        c2 code2,
        c3 code3
from table(dbms_space.asa_recommendations()) where task_id = 95108;
*/


declare
 task_name   varchar2(100) := '&&tname';
begin
 DBMS_ADVISOR.DELETE_TASK(task_name);
 null;
exception when others then null;
end;
/

spool off;

undefine tname
undefine
