select * from dba_data_files where tablespace_name='EXCELLENT' order by file_id;
select * from dba_data_files where tablespace_name='YOLA_SCHEMAS' order by file_id;
select * from dba_data_files where tablespace_name='SUPPORT_EXCL' order by file_name;
select * from dba_data_files where tablespace_name='INDEX_ALL' order by file_name;
select * from dba_data_files where tablespace_name='WEB' order by file_name;
select * from dba_data_files where tablespace_name='MONITOR' order by file_name;
select * from dba_data_files where tablespace_name='ALIEN_USERS' order by file_name;
select * from dba_data_files where tablespace_name='EXCL_ADDITION' order by file_name;
select * from dba_data_files where tablespace_name='TPCCTAB' order by file_name;
select * from dba_data_files where tablespace_name='SYSTEM' order by file_name;
select * from dba_data_files where tablespace_name='SYSAUX' order by file_name;
select * from dba_data_files where tablespace_name='EXCELLENT_BIG';
select * from dba_data_files where tablespace_name='';
select * from dba_data_files where tablespace_name='';
select * from dba_data_files where tablespace_name='';
select * from dba_data_files where tablespace_name='';
select * from dba_data_files where tablespace_name='';
select * from dba_data_files where tablespace_name='';


select *
from (
select T.SEGMENT_NAME||' '||T.SEGMENT_TYPE||' '||t.bytes/1024/1024 as segment_size_mb
from dba_segments t
where T.TABLESPACE_NAME='SYSAUX'
order by bytes desc
) v
where rownum <= 10;


select * from dba_data_files t
where   t.autoextensible='YES'
        and T.FILE_NAME like '/db/u12/%'
        and t.bytes < T.MAXBYTES
order by file_name;

select T.TABLESPACE_NAME as TABLESPACE_NAME,
       trunc(sum(T.MAXBYTES-T.USER_BYTES)/1024/1024,2) as req4growing_mb
from dba_data_files t
where   t.autoextensible='YES'
        and T.FILE_NAME like '/db/u11/%'
        and t.bytes < T.MAXBYTES
group by T.TABLESPACE_NAME
order by req4growing_mb desc;

select '|_.TABLESPACE
NAME|_.REQ4GROWING_MB|' as col from dual
union all
select  '|=.'||v.TABLESPACE_NAME||'|>.'||v.req4growing_mb||'|'
from (
select T.TABLESPACE_NAME as TABLESPACE_NAME,
       trunc(sum(T.MAXBYTES-T.USER_BYTES)/1024/1024,2) as req4growing_mb
from dba_data_files t
where   t.autoextensible='YES'
        and T.FILE_NAME like '/db/u12/%'
        and t.bytes < T.MAXBYTES
group by T.TABLESPACE_NAME
order by req4growing_mb desc ) v;


select distinct T.TABLESPACE_NAME from dba_data_files t where T.FILE_NAME like '/db/u12/%';
select 1073676288/1024/1024/1024 from dual;


select max( replace(substr(T.FILE_NAME,instr(T.FILE_NAME,'_',-1)+1),'.dbf')*1 ) as num_sign
from dba_data_files t
where T.TABLESPACE_NAME='INDEX_ALL'
order by num_sign desc;


select max( replace(substr(T.FILE_NAME,instr(T.FILE_NAME,'_',-1)+1),'.dbf')*1 ) as num_sign
from dba_data_files t
where T.TABLESPACE_NAME='SUPPORT_EXCL'
order by num_sign desc;


--alter tablespace EXCELLENT add datafile '/db/u21/oradata/parser1/excellent_10.dbf' size 128 M autoextend on next 128 M maxsize 10240 M;
--alter database datafile 86, 87, 88 autoextend on next 128 M maxsize 20480 M;
--alter database datafile 15 autoextend on next 128 M maxsize 15360 M;
--alter tablespace SUPPORT_EXCL add datafile '/db/u01/oradata/parser1/support_excl_06.dbf' size 128 M autoextend on next 128 M maxsize 10240 M;
--alter tablespace INDEX_ALL add datafile '/db/u21/oradata/parser1/indexall_15.dbf' size 128 M autoextend on next 128 M maxsize 10240 M;
select * from dba_segments where tablespace_name='MONITOR' order by bytes desc;
select * from dba_temp_files;
select * from dba_data_files;
select 34359721984/1024/1024/1024 from dual;
--alter tablespace SYSTEM add datafile '/db/u11/oradata/builddev/system_02.dbf' size 64 M autoextend on next 64 M maxsize 4096 M;


/*
ALTER TABLESPACE * ADD DATAFILE '/db/u14/oradata/billing/*_*.dbf' SIZE 128M AUTOEXTEND ON  NEXT 128M MAXSIZE 5120M;
*/

select file_id from dba_data_files t
where T.TABLESPACE_NAME='INDEX_ALL'
  and file_name in (select v.name as file_name
                    from (
                     select t.file#, t.name, to_number( replace(substr(T.NAME,instr(T.NAME,'_',-1)+1),'.dbf') ) as file_name_num
                     from v$datafile t
                     where T.TS# = ( select ts# from v$tablespace where name='INDEX_ALL' ) and rownum >= 1
                    ) v where v.file_name_num > 20)
order by file_id desc;



alter system archive log current;
alter database create physical standby controlfile  as '/home/oracle/ctrl_.bin';
!mv /home/oracle/ctrl_.bin /home/oracle/ctrl.bin

crosscheck copy of controlfile;
delete noprompt expired copy of controlfile;

run
{
allocate channel nfs device type disk format '/db/backup/billing/rman_nfs/full_%T.%d.%s.%p.%c' maxpiecesize=10G rate=30720K;
backup channel 'nfs' (datafile 77, 78);
}
exit;

/*
#rsync -v ctrl.bin db2.`hostname -f | awk -F "." '{print $2}'`.ertelecom.ru::tnsadmin
rsync -v /home/oracle/ctrl.bin `hostname | tr -s '12' '21'`.`hostname -f | awk -F "." '{print $2}'`.ertelecom.ru::tnsadmin
rm -f /home/oracle/ctrl.bin
*/
--- standby side:
select database_role from v$database;
/*
shutdown immediate;
startup nomount;
exit;
*/

restore controlfile from '/etc/oracle/ctrl.bin';
exit
--rm -f /etc/oracle/ctrl.bin

rmanshellc
sql "alter database mount standby database";
restore datafile 77, 78;
exit;



--primary side:
archive log list;
alter system archive log current;
exit;

tail -f -n 25 /var/log/rias/dba/rman.log
