select  st.value as stat,
        s.sid||','||s.serial# as sess_id,
        p.spid,
        s.action,
        s.module,
        S.PROGRAM,
        S.USERNAME,
        S.OSUSER,
        S.MACHINE,
        s.sql_id,
        S.PREV_SQL_ID,
        s.event,
        s.server,
        S.BLOCKING_SESSION,
        s.LAST_CALL_ET,
        s.LOGON_TIME,
        s.status
from v$sesstat st, v$statname nm, v$session s, v$process p
where st.sid in ( select sid from v$session where server<>'DEDICATED' )
  and nm.statistic# = st.statistic#
  and nm.name ='session uga memory'
  and S.SID=st.sid and s.paddr=p.addr
order by stat desc;

SELECT *
FROM V$SGA_RESIZE_OPS t
ORDER BY t.START_TIME desc;

SELECT *
FROM v$sga_dynamic_components t;

SELECT *
FROM v$active_session_history t
WHERE t.sql_id='d7kmvk2k0j3k9';

SELECT *
FROM sys.dba_procedures t
WHERE t.OBJECT_ID=63273 AND t.SUBPROGRAM_ID=1;

--ALTER SYSTEM FLUSH shared_pool;