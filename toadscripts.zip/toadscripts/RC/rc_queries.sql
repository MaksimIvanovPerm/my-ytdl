SELECT *
FROM V$RESULT_CACHE_STATISTICS t
;

SELECT *
FROM V$RESULT_CACHE_MEMORY t
;

SELECT Round( (Count(*)*1024)/1024/1024 , 2) AS SizeMb, t.free
FROM V$RESULT_CACHE_MEMORY t
GROUP BY t.free
ORDER BY 1 desc
;

select * from v$sgastat where pool='shared pool' and name like 'Result%';

SELECT Count(*), t.object_id
FROM V$RESULT_CACHE_MEMORY t
GROUP BY t.object_id
ORDER BY 1 desc
;

SELECT *
FROM V$RESULT_CACHE_OBJECTS t
;

SELECT *
FROM V$RESULT_CACHE_DEPENDENCY t
;

EXECUTE DBMS_RESULT_CACHE.MEMORY_REPORT;

