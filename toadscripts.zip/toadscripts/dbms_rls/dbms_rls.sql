CREATE TABLE excellent.test_2019 TABLESPACE excellent AS SELECT * FROM dba_objects WHERE ROWNUM <= 100;

BEGIN
WHILE
END;
/

