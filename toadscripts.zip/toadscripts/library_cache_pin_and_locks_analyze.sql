-- https://orainternals.wordpress.com/2009/06/02/library-cache-lock-and-library-cache-pin-waits/

select to_char(t.SESSION_ID,'999') sid,
s.event, s.state, s.osuser, s.blocking_session, s.final_blocking_session,
t.LOCK_TYPE Type,
substr(t.lock_id1,1,23) Object_Name,
substr(t.mode_held,1,4) HELD, substr(mode_requested,1,4) REQ,
t.lock_id2 Lock_addr
from dba_lock_internal t, v$session s
where
mode_requested<>'None'
and mode_requested<>mode_held
and session_id in ( select sid from v$session_wait where wait_time=0 and event='library cache lock')
and s.sid=t.session_id
;

select
 distinct
   p.spid, s.PROCESS, ses.ksusenum||','||ses.ksuseser sid_serial#,
   s.osuser, s.username, s.action AS action, s.MODULE AS MODULE,
   s.blocking_session, s.final_blocking_session, --s.sql_id, s.plsql_entry_object_id, s.plsql_object_id,
   ob.kglnaown obj_owner, ob.kglnaobj obj_name
   ,lk.kgllkcnt lck_cnt, lk.kgllkmod lock_mode, lk.kgllkreq lock_req
   , w.state, w.event, w.wait_Time, w.seconds_in_Wait
 from
  x$kgllk lk,  x$kglob ob,x$ksuse ses, v$session_wait w, v$session s, v$process p
where lk.kgllkhdl in
(select kgllkhdl from x$kgllk where kgllkreq >0 )
and ob.kglhdadr = lk.kgllkhdl
and lk.kgllkuse = ses.addr
and w.sid = ses.indx
AND ses.ksusenum=s.sid AND ses.ksuseser=s.serial#
AND s.paddr=p.addr
order by seconds_in_wait DESC
;


--- Find current sql for given session sid;
select p.spid, s.*
from v$session s, v$process p
where s.paddr=p.addr and s.machine='MOKRUSHIN-DV';


select s.sid, s.machine, s.program, s.status, s.server, s.action, SQL.SQL_TEXT
from v$session s, v$sql sql
where S.SQL_ADDRESS=SQL.ADDRESS and S.SQL_HASH_VALUE=SQL.HASH_VALUE
and s.sid in (449);

select s.sid, s.serial#, s.server, s.machine, s.program, s.status, s.module, s.action,
       sw.event, sw.p1, sw.p1text, sw.p2, sw.p2text, sw.p3, sw.p3text, SW.SECONDS_IN_WAIT
from v$session s, v$session_wait sw
where s.type='USER' and s.sid=sw.sid and sw.event not like 'SQL*Net%'
order by SW.SECONDS_IN_WAIT desc;

--alter system kill session '449, 24' immediate;
---

select * from v$session_wait where event not like 'SQL*Net%' order by seconds_in_wait desc;

-- library cache pin analyze --

select * from V$SESSION_WAIT where event like '%cache pin%';
select distinct p1raw from V$SESSION_WAIT where event like '%cache pin%';

SELECT kglnaown "Owner", kglnaobj "Object"
    FROM x$kglob
   WHERE kglhdadr='00000000B8EF37A8';

SELECT pr.spid, s.sid, s.username, s.status, s.server, s.program, s.machine, s.module, kglpnmod "Mode", kglpnreq "Req", s.module, s.action, S.LAST_CALL_ET, SW.EVENT, SW.SECONDS_IN_WAIT
    FROM x$kglpn p, v$session s, v$session_wait sw, v$process pr
   WHERE p.kglpnuse=s.saddr and s.sid=sw.sid and s.paddr=pr.addr
     AND p.kglpnhdl='0000000960A58758'
     order by SW.SECONDS_IN_WAIT;


SELECT   'alter system kill session '''||s.sid||', '||s.serial#||''' immediate;'
    FROM x$kglpn p, v$session s, v$session_wait sw, v$process pr
   WHERE p.kglpnuse=s.saddr and s.sid=sw.sid and s.paddr=pr.addr
     AND p.kglpnhdl='0000000958C20248'
     and s.machine != 'PERM\UK-KRUPIN';

--------------------------------
-- library cache lock analyze --

select s.sid, s.osuser, s.username, S.MACHINE, S.PROGRAM, S.STATUS, S.ACTION, S.SERVER, sw.event, sw.p1, sw.p1text, sw.p2, sw.p2text, sw.p3, sw.p3text, SW.SECONDS_IN_WAIT
from V$SESSION_WAIT sw, v$session s
where sw.event like '%cache lock%'
      and s.sid=sw.sid;

select * from V$SESSION_WAIT where event like '%cache lock%';

select
 distinct
   --'alter system kill session '''||ses.ksusenum||', '||ses.ksuseser||''' immediate;', ssn.machine, ssn.program, ssn.module, ses.ksuseser serial#, ses.ksuudlna username,KSUSEMNM module,
   ses.ksusenum as sid, ses.ksuseser as "serial#", ssn.machine, ssn.program, ssn.module, ses.ksuudlna username,KSUSEMNM module,
   ob.kglnaown obj_owner, ob.kglnaobj obj_name
   ,lk.kgllkcnt lck_cnt, lk.kgllkmod lock_mode, lk.kgllkreq lock_req
   , w.state, w.event, w.wait_Time, w.seconds_in_Wait
 from
  x$kgllk lk,  x$kglob ob, x$ksuse ses, v$session_wait w, v$session ssn
where lk.kgllkhdl in (select kgllkhdl from x$kgllk where kgllkreq >0 )
  and ob.kglhdadr = lk.kgllkhdl
  and lk.kgllkuse = ses.addr
  and w.sid = ses.indx and ssn.sid=w.sid
order by seconds_in_wait desc;

--------------------------------
SELECT   'alter system kill session '''||s.sid||', '||s.serial#||''' immediate;' as cmd,
         pr.spid, s.sid, s.serial#, s.username, s.status, s.server, s.program, s.machine, kglpnmod "Mode", kglpnreq "Req"
    FROM x$kglpn p, v$session s, v$process pr
   WHERE p.kglpnuse=s.saddr
     AND kglpnhdl='00000000CA2AC130'
         and s.paddr=pr.addr;

---------------------------------
select * from dba_objects where object_name='CC_FUNCS';

/*
 x$kgllk, x$kglpn and x$kglob

Library cache locks and pins are externalized in three x$ tables.
x$kgllk is externalizing all locking structures on an object. Entries in x$kglob acts as a resource structure.
x$kglpn is externalizing all library cache pins.

x$kglob.kglhdadr acts as a pointer to the resource structure.
Presumably, kglhdadr stands KGL handle address. x$kgllk acts as a lock structure and x$kgllk.kgllkhdl points to x$kglob.kglhdadr.
Also, x$kglpn acts as a pin stucture and x$kglpn.kglpnhdl points to x$kglob.kglhdadr to pin a resource.
To give an analogy between object locking scenarios, x$kglob acts as resource structure and x$kgllk acts as lock structures for library cache locks.
For library cache pins, x$kglpn acts as pin structure. x$kglpn also pins that resource using kglpnhdl.
This might be clear after reviewing the example below.
*/

select
 distinct
   'alter system kill session '''||ses.ksusenum||', '||ses.ksuseser||''' immediate;'
 from
  x$kgllk lk,  x$kglob ob, x$ksuse ses, v$session_wait w, v$session ssn
where lk.kgllkhdl in (select kgllkhdl from x$kgllk where kgllkreq >0 )
  and ob.kglhdadr = lk.kgllkhdl
  and lk.kgllkuse = ses.addr
  and w.sid = ses.indx and ssn.sid=w.sid
  and ssn.sid != 1392;


select * from v$session where sid='13';

alter system kill session '611, 17874' immediate;

select * from dba_tablespaces order by tablespace_name;
select * from x$kgllk lk where lk.kgllkreq > 0;

select * from x$ksuse where ksusenum=260;
select * from v$session where sid=260;

SELECT *
FROM sys.dba_db_links t
--WHERE Upper(t.db_link) LIKE '%MVTS%'
ORDER BY t.db_link
;

select
 distinct
   p.spid, s.PROCESS, ses.ksusenum||','||ses.ksuseser sid_serial#,
   s.osuser, s.username, s.action AS action, s.MODULE AS MODULE,
   s.blocking_session, s.final_blocking_session, --s.sql_id, s.plsql_entry_object_id, s.plsql_object_id,
   ob.kglnaown obj_owner, ob.kglnaobj obj_name
   ,lk.kgllkcnt lck_cnt, lk.kgllkmod lock_mode, lk.kgllkreq lock_req
   , w.state, w.event, w.wait_Time, w.seconds_in_Wait
 from
  x$kgllk lk,  x$kglob ob,x$ksuse ses, v$session_wait w, v$session s, v$process p
where lk.kgllkhdl in
(select kgllkhdl from x$kgllk where kgllkreq >0 )
and ob.kglhdadr = lk.kgllkhdl
and lk.kgllkuse = ses.addr
and w.sid = ses.indx
AND ses.ksusenum=s.sid AND ses.ksuseser=s.serial#
AND s.paddr=p.addr
order by seconds_in_wait DESC;