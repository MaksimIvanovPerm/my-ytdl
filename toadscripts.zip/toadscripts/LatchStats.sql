SELECT *
FROM v$latch t
ORDER BY t.wait_time desc
--ORDER BY t.immediate_gets desc
;

SELECT *
FROM V$LATCH_CHILDREN lc
WHERE lc.latch#=307
ORDER BY lc.wait_time desc
;

SELECT *
FROM V$LATCH_MISSES t
WHERE t.parent_name='shared pool'
ORDER BY t.sleep_count desc
;

SELECT *
FROM V$LATCHHOLDER t
;

SELECT *
FROM x$ksuprlat t
;

SELECT t.current_size
FROM v$sga_dynamic_components t
WHERE t.component='shared pool'
;

select ksmdsidx, count(*) , Round(sum(ksmsslen)/1024/1024,2) AS SubHeap_size_MB
from x$ksmss
where ksmdsidx>0
group by ksmdsidx
order by 1
;

SELECT t.*
FROM v$sga_dynamic_components t
--WHERE t.component='shared pool'
;

-- Note 1643312.1
SELECT
   subpool
 , name
 --, SUM(bytes)
 , ROUND(SUM(bytes)/1048576,2) MB
FROM (
   SELECT
       'shared pool ('||DECODE(TO_CHAR(ksmdsidx),'0','0 - Unused',ksmdsidx)||'):' subpool
     , ksmssnam      name
     , ksmsslen      bytes
   FROM x$ksmss
   WHERE ksmsslen > 0
)
GROUP BY subpool, name
HAVING ROUND(SUM(bytes)/1048576,2) > 0
ORDER BY subpool ASC, SUM(bytes) DESC
;

select ksmdsidx, sum(ksmsslen) from x$ksmss group by ksmdsidx;
select ksmssnam, sum(ksmsslen) from x$ksmss  where ksmdsidx=1 group by ksmssnam order by 2 DESC;

SELECT n.ksppinm name, v.KSPPSTVL value
FROM x$ksppi n, x$ksppsv v
WHERE n.indx = v.indx
AND (n.ksppinm LIKE '%shared_pool%' OR n.ksppinm IN ('_kghdsidx_count', '_ksmg_granule_size', '_memory_imm_mode_without_autosga'))
ORDER BY 1;

select *
    from x$kghlu
    where kghlushrpool = 1;


SELECT t.*
from sys.v_$sql t
ORDER BY t.typecheck_mem desc
;

SELECT *
FROM v$sql_workarea t
WHERE t.sql_id='7nv1kfms0xybp'
;

SELECT *
FROM v$sql_plan t
WHERE t.hash_value=4027513205
;


select t.sql_id, Sum(chunk_size) AS shared_mem_bytes
FROM  sys.v_$sql_shared_memory t
GROUP BY t.sql_id
ORDER BY 2 DESC
;

select t.chunk_com, Sum(chunk_size) AS shared_mem_bytes
FROM  sys.v_$sql_shared_memory t
WHERE t.sql_id='7nv1kfms0xybp'
GROUP BY t.chunk_com
ORDER BY 2 DESC;

SELECT *
FROM sys.V_$SQL_SHARED_CURSOR t
where t.sql_id='1vrw3naztt0qm'
;

SELECT
sum( decode(unbound_cursor,'Y',1,0) ) as unbound_cursor,
sum( decode(sql_type_mismatch,'Y',1,0) ) as sql_type_mismatch,
sum( decode(optimizer_mismatch,'Y',1,0) ) as optimizer_mismatch,
sum( decode(outline_mismatch,'Y',1,0) ) as outline_mismatch,
sum( decode(stats_row_mismatch,'Y',1,0) ) as stats_row_mismatch,
sum( decode(literal_mismatch,'Y',1,0) ) as literal_mismatch,
sum( decode(force_hard_parse,'Y',1,0) ) as force_hard_parse,
sum( decode(explain_plan_cursor,'Y',1,0) ) as explain_plan_cursor,
sum( decode(buffered_dml_mismatch,'Y',1,0) ) as buffered_dml_mismatch,
sum( decode(pdml_env_mismatch,'Y',1,0) ) as pdml_env_mismatch,
sum( decode(inst_drtld_mismatch,'Y',1,0) ) as inst_drtld_mismatch,
sum( decode(slave_qc_mismatch,'Y',1,0) ) as slave_qc_mismatch,
sum( decode(typecheck_mismatch,'Y',1,0) ) as typecheck_mismatch,
sum( decode(auth_check_mismatch,'Y',1,0) ) as auth_check_mismatch,
sum( decode(bind_mismatch,'Y',1,0) ) as bind_mismatch,
sum( decode(describe_mismatch,'Y',1,0) ) as describe_mismatch,
sum( decode(language_mismatch,'Y',1,0) ) as language_mismatch,
sum( decode(translation_mismatch,'Y',1,0) ) as translation_mismatch,
sum( decode(bind_equiv_failure,'Y',1,0) ) as bind_equiv_failure,
sum( decode(insuff_privs,'Y',1,0) ) as insuff_privs,
sum( decode(insuff_privs_rem,'Y',1,0) ) as insuff_privs_rem,
sum( decode(remote_trans_mismatch,'Y',1,0) ) as remote_trans_mismatch,
sum( decode(logminer_session_mismatch,'Y',1,0) ) as logminer_session_mismatch,
sum( decode(incomp_ltrl_mismatch,'Y',1,0) ) as incomp_ltrl_mismatch,
sum( decode(overlap_time_mismatch,'Y',1,0) ) as overlap_time_mismatch,
sum( decode(edition_mismatch,'Y',1,0) ) as edition_mismatch,
sum( decode(mv_query_gen_mismatch,'Y',1,0) ) as mv_query_gen_mismatch,
sum( decode(user_bind_peek_mismatch,'Y',1,0) ) as user_bind_peek_mismatch,
sum( decode(typchk_dep_mismatch,'Y',1,0) ) as typchk_dep_mismatch,
sum( decode(no_trigger_mismatch,'Y',1,0) ) as no_trigger_mismatch,
sum( decode(flashback_cursor,'Y',1,0) ) as flashback_cursor,
sum( decode(anydata_transformation,'Y',1,0) ) as anydata_transformation,
sum( decode(pddl_env_mismatch,'Y',1,0) ) as pddl_env_mismatch,
sum( decode(top_level_rpi_cursor,'Y',1,0) ) as top_level_rpi_cursor,
sum( decode(different_long_length,'Y',1,0) ) as different_long_length,
sum( decode(logical_standby_apply,'Y',1,0) ) as logical_standby_apply,
sum( decode(diff_call_durn,'Y',1,0) ) as diff_call_durn,
sum( decode(bind_uacs_diff,'Y',1,0) ) as bind_uacs_diff,
sum( decode(plsql_cmp_switchs_diff,'Y',1,0) ) as plsql_cmp_switchs_diff,
sum( decode(cursor_parts_mismatch,'Y',1,0) ) as cursor_parts_mismatch,
sum( decode(stb_object_mismatch,'Y',1,0) ) as stb_object_mismatch,
sum( decode(crossedition_trigger_mismatch,'Y',1,0) ) as crossedition_trigger_mismatch,
sum( decode(pq_slave_mismatch,'Y',1,0) ) as pq_slave_mismatch,
sum( decode(top_level_ddl_mismatch,'Y',1,0) ) as top_level_ddl_mismatch,
sum( decode(multi_px_mismatch,'Y',1,0) ) as multi_px_mismatch,
sum( decode(bind_peeked_pq_mismatch,'Y',1,0) ) as bind_peeked_pq_mismatch,
sum( decode(mv_rewrite_mismatch,'Y',1,0) ) as mv_rewrite_mismatch,
sum( decode(roll_invalid_mismatch,'Y',1,0) ) as roll_invalid_mismatch,
sum( decode(optimizer_mode_mismatch,'Y',1,0) ) as optimizer_mode_mismatch,
sum( decode(px_mismatch,'Y',1,0) ) as px_mismatch,
sum( decode(mv_staleobj_mismatch,'Y',1,0) ) as mv_staleobj_mismatch,
sum( decode(flashback_table_mismatch,'Y',1,0) ) as flashback_table_mismatch,
sum( decode(litrep_comp_mismatch,'Y',1,0) ) as litrep_comp_mismatch,
sum( decode(plsql_debug,'Y',1,0) ) as plsql_debug,
sum( decode(load_optimizer_stats,'Y',1,0) ) as load_optimizer_stats,
sum( decode(acl_mismatch,'Y',1,0) ) as acl_mismatch,
sum( decode(flashback_archive_mismatch,'Y',1,0) ) as flashback_archive_mismatch,
sum( decode(lock_user_schema_failed,'Y',1,0) ) as lock_user_schema_failed,
sum( decode(remote_mapping_mismatch,'Y',1,0) ) as remote_mapping_mismatch,
sum( decode(load_runtime_heap_failed,'Y',1,0) ) as load_runtime_heap_failed,
sum( decode(hash_match_failed,'Y',1,0) ) as hash_match_failed,
sum( decode(purged_cursor,'Y',1,0) ) as purged_cursor,
sum( decode(bind_length_upgradeable,'Y',1,0) ) as bind_length_upgradeable
FROM sys.V_$SQL_SHARED_CURSOR t
where t.sql_id='c5h8bcpw9g9qz'
;










