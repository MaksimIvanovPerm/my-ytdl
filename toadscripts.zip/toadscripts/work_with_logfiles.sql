SELECT *
FROM sys.v$log t;

SELECT * FROM sys.v$logfile t;

SELECT l.group#, l.sequence#, l.status, Round(l.bytes/1024/1024,2) , l.members, t.member
FROM sys.v$logfile t, v$log l
WHERE l.group#=t.group#
ORDER BY t.group#;

ALTER SYSTEM ARCHIVE Log CURRENT;
ALTER SYSTEM CHECKPOINT;

ALTER SYSTEM SWITCH LOGFILE;

ALTER DATABASE ADD LOGFILE GROUP 6 ('/db/u00/oradata/dwh/redo06_01.dbf','/db/u00/oradata/dwh/redo06_02.dbf') SIZE 2G;
ALTER DATABASE ADD LOGFILE GROUP 7 ('/db/u00/oradata/dwh/redo07_01.dbf','/db/u00/oradata/dwh/redo07_02.dbf') SIZE 2G;
ALTER DATABASE ADD LOGFILE GROUP 8 ('/db/u00/oradata/dwh/redo08_01.dbf','/db/u00/oradata/dwh/redo08_02.dbf') SIZE 2G;
ALTER DATABASE ADD LOGFILE GROUP 9 ('/db/u00/oradata/dwh/redo09_01.dbf','/db/u00/oradata/dwh/redo09_02.dbf') SIZE 2G;

ALTER DATABASE DROP LOGFILE GROUP 5;
