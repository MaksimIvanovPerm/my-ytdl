SELECT Count(*), p.p_type
FROM tpch.SUPPLIER s,  tpch.PARTSUPP ps, tpch.PART p
WHERE s.s_nationkey=5
  AND ps.ps_suppkey=s.s_suppkey
  AND ps.ps_partkey=p.p_partkey
GROUP BY p.p_type
ORDER BY 1 desc
;

DROP USER tpch CASCADE;
EXEC Dbms_Stats.GATHER_SCHEMA_STATS('tpch',estimate_percent=>'95',method_opt=>'for all indexed columns size auto',CASCADE=>TRUE,FORCE=>true);

grant select on tpch.CUSTOMER to cacheuser;
grant select on tpch.LINEITEM to cacheuser;
grant select on tpch.NATION to cacheuser;
grant select on tpch.ORDERS to cacheuser;
grant select on tpch.PART to cacheuser;
grant select on tpch.PARTSUPP to cacheuser;
grant select on tpch.REGION to cacheuser;
grant select on tpch.SUPPLIER to cacheuser;

define test_id="5"

SELECT To_Date(to_char(to_date('1970-01-01','YYYY-MM-DD') + numtodsinterval(v1.dt,'SECOND'),'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') AS datetime, v.DELTA AS DELTA
FROM (
SELECT t.stat_value-(Lag(t.stat_value,1,NULL) OVER (ORDER BY t.datetime asc)) AS DELTA, t.datetime AS dt
FROM excellent.tt_stat t
WHERE t.id=&&test_id
  AND t.stat_name='cs.server.executes.creates'
ORDER BY t.datetime asc) v,
(SELECT DISTINCT a1.datetime dt FROM excellent.tt_stat a1 WHERE a1.id=&&test_id) v1
 WHERE 1=1 --v.DELTA IS NOT NULL
   AND v.dt(+)=v1.dt
ORDER BY v1.dt asc
;

SELECT *
FROM (
SELECT t.datetime,
       t.stat_name,
       Round(t.stat_value/1024,2) AS stat_value
FROM excellent.tt_stat t
WHERE t.id=5
  AND t.stat_name IN ('TEMP_IN_USE_SIZE','TEMP_IN_USE_HIGH_WATER','TEMP_ALLOCATED_SIZE','PERM_IN_USE_SIZE','PERM_IN_USE_HIGH_WATER','PERM_ALLOCATED_SIZE')
  --AND t.datetime IN (1524220964,1524221024)
)
pivot (
 Max(stat_value)
 FOR (stat_name) IN (
'TEMP_IN_USE_SIZE' as TEMP_IN_USE_SIZE,
'TEMP_IN_USE_HIGH_WATER' as TEMP_IN_USE_HIGH_WATER,
'TEMP_ALLOCATED_SIZE' as TEMP_ALLOCATED_SIZE,
'PERM_IN_USE_SIZE' as PERM_IN_USE_SIZE,
'PERM_IN_USE_HIGH_WATER' as PERM_IN_USE_HIGH_WATER,
'PERM_ALLOCATED_SIZE' as PERM_ALLOCATED_SIZE
 )
)
ORDER BY datetime
;


SELECT DISTINCT t.stat_name
FROM excellent.tt_stat t
WHERE t.id=5
--ORDER BY 1
;

SELECT t.datetime,
       Row_Number() OVER (ORDER BY t.datetime) AS rid,
       t.stat_name,
       t.stat_value
FROM excellent.tt_stat t
WHERE t.id=5
  AND t.stat_name IN ('TEMP_IN_USE_SIZE','TEMP_IN_USE_HIGH_WATER','TEMP_ALLOCATED_SIZE','PERM_IN_USE_SIZE','PERM_IN_USE_HIGH_WATER','PERM_ALLOCATED_SIZE')
ORDER BY t.datetime;

select cast(sum(l_extendedprice) as NUMBER) / 7.0 as avg_yearly
from tpch.lineitem, tpch.part
where p_partkey = l_partkey and p_brand = 'Brand#32' and p_container = 'WRAP DRUM'
  and l_quantity < ( select 0.2 * avg(l_quantity) from tpch.lineitem where l_partkey = p_partkey)
;

select s_name, count(*) as numwait
from supplier, lineitem l1, orders, nation
where s_suppkey = l1.l_suppkey
 and o_orderkey = l1.l_orderkey
 and o_orderstatus = 'F' and l1.l_receiptdate > l1.l_commitdate and exists ( select * from lineitem l2 where l2.l_orderkey = l1.l_orderkey and l2.l_suppkey <> l1.l_suppkey) and not exists ( select * from lineitem l3 where l3.l_orderkey = l1.l_orderkey and l3.l_suppkey <> l1.l_suppkey and l3.l_receiptdate > l3.l_commitdate) and s_nationkey = n_nationkey and n_name = 'JORDAN' group by s_name order by numwait desc, s_name

