-- Cleanup old model with same name (if any)
BEGIN
  DBMS_DATA_MINING.DROP_MODEL('GLMR_SH_Regr_sample');
EXCEPTION WHEN OTHERS THEN NULL; END;
/

-------------------
-- SPECIFY SETTINGS
--
-- Cleanup old settings table for repeat runs
BEGIN EXECUTE IMMEDIATE 'DROP TABLE glmr_sh_sample_settings';
EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- Cleanup diagnostic table
BEGIN EXECUTE IMMEDIATE 'DROP TABLE glmr_sh_sample_diag';
EXCEPTION WHEN OTHERS THEN NULL; END;
/


begin
  execute immediate 'drop table glmr_sh_sample_settings';
EXCEPTION WHEN OTHERS THEN NULL; END;
/


CREATE TABLE glmr_sh_sample_settings (
  setting_name  VARCHAR2(30),
  setting_value VARCHAR2(30));

BEGIN
-- Populate settings table
  INSERT INTO glmr_sh_sample_settings (setting_name, setting_value) VALUES
  (dbms_data_mining.algo_name, dbms_data_mining.algo_generalized_linear_model);
  INSERT INTO  glmr_sh_sample_settings (setting_name, setting_value) VALUES
    (dbms_data_mining.glms_diagnostics_table_name, 'GLMR_SH_SAMPLE_DIAG');
  INSERT INTO  glmr_sh_sample_settings (setting_name, setting_value) VALUES
    (dbms_data_mining.prep_auto, dbms_data_mining.prep_auto_on);
  -- Examples of other possible overrides are:
  --(dbms_data_mining.glms_ridge_regression,
  -- dbms_data_mining.glms_ridge_reg_enable);
  commit;
END;
/

SELECT * FROM glmr_sh_sample_settings;

---------------------
-- CREATE A NEW MODEL
--
BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'GLMR_SH_Regr_sample',
    mining_function     => dbms_data_mining.regression,
    data_table_name     => 'mining_data_build_v',
    case_id_column_name => 'SNAP_ID',
    target_column_name  => 'ELAPSED_TIME_DELTA',
    settings_table_name => 'glmr_sh_sample_settings');
END;
/

SELECT setting_name, setting_value
  FROM user_mining_model_settings
 WHERE model_name = 'GLMR_SH_REGR_SAMPLE'
ORDER BY setting_name;

SELECT attribute_name, attribute_type
  FROM user_mining_model_attributes
 WHERE model_name = 'GLMR_SH_REGR_SAMPLE'
ORDER BY attribute_name;


SELECT *
  FROM TABLE(dbms_data_mining.get_model_details_global('GLMR_SH_Regr_sample'))
ORDER BY global_detail_name;

-- Attribute coefficients
SELECT *
FROM TABLE(dbms_data_mining.get_model_details_glm('GLMR_SH_Regr_sample'))
ORDER BY class, attribute_name, attribute_value;

SELECT  t.case_id,
        trunc(t.target_value) as target_value,
        trunc(t.predicted_value) as predicted_value,
        round(t.residual,2) as residual
          FROM glmr_sh_sample_diag t
        ORDER BY case_id;

SELECT round(SQRT(AVG((A.pred - B.ELAPSED_TIME_DELTA) * (A.pred - B.ELAPSED_TIME_DELTA))),2) rmse,
       round(AVG(ABS(a.pred - B.ELAPSED_TIME_DELTA)),2) mae
  FROM (SELECT snap_id, prediction(GLMR_SH_Regr_sample using *) pred
          FROM mining_data_build_v) A,
       mining_data_build_v B
 WHERE A.snap_id = B.snap_id;

-- Variant with sys_load
create or replace view mining_data_build_v
as
select  S.SNAP_ID,
        --ST.PLAN_HASH_VALUE,
        ST.ELAPSED_TIME_DELTA/ST.EXECUTIONS_DELTA as ELAPSED_TIME_DELTA,
        --ST.EXECUTIONS_DELTA,
        OST.VALUE as sys_load,
        /*ST.BUFFER_GETS_DELTA/ST.EXECUTIONS_DELTA as BUFFER_GETS_DELTA,
        ST.CPU_TIME_DELTA/ST.EXECUTIONS_DELTA as CPU_TIME_DELTA,
        ST.PHYSICAL_READ_BYTES_DELTA/ST.EXECUTIONS_DELTA as PHYSICAL_READ_BYTES_DELTA,
        ST.PHYSICAL_WRITE_BYTES_DELTA/ST.EXECUTIONS_DELTA as PHYSICAL_WRITE_BYTES_DELTA,
        ST.FETCHES_DELTA/ST.EXECUTIONS_DELTA as FETCHES_DELTA,
        ST.SORTS_DELTA/ST.EXECUTIONS_DELTA as SORTS_DELTA,
        */
        ST.ROWS_PROCESSED_DELTA/ST.EXECUTIONS_DELTA as ROWS_PROCESSED_DELTA
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s, SYS.WRH$_OSSTAT ost, SYS.WRH$_OSSTAT_NAME osn
where s.dbid=3158406466 and S.INSTANCE_NUMBER=1 and S.snap_id between 32579 and 33204 --33336
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.DBID=ost.dbid and S.INSTANCE_NUMBER=ost.INSTANCE_NUMBER and s.snap_id=ost.snap_id
  and OST.STAT_ID=OSN.STAT_ID and OST.DBID=OSN.DBID
  and ST.sql_id='ddqu5vmxdsyxn'
  and ST.EXECUTIONS_DELTA > 0
  and OSN.STAT_NAME='LOAD'
order by ST.SNAP_ID;

drop view mining_data_build_v;

select * from mining_data_build_v;


select  snap_id,
        ELAPSED_TIME_DELTA,
        ( ROWS_PROCESSED_DELTA*3235999.89916375 + SYS_LOAD*147362.896701599 + 68300148.7409645 ) as pred_value
from (
select  S.SNAP_ID as snap_id,
        --ST.PLAN_HASH_VALUE,
        ST.ELAPSED_TIME_DELTA/ST.EXECUTIONS_DELTA as ELAPSED_TIME_DELTA,
        --ST.EXECUTIONS_DELTA,
        OST.VALUE as sys_load,
        ST.BUFFER_GETS_DELTA/ST.EXECUTIONS_DELTA as BUFFER_GETS_DELTA,
        ST.CPU_TIME_DELTA/ST.EXECUTIONS_DELTA as CPU_TIME_DELTA,
        ST.PHYSICAL_READ_BYTES_DELTA/ST.EXECUTIONS_DELTA as PHYSICAL_READ_BYTES_DELTA,
        ST.PHYSICAL_WRITE_BYTES_DELTA/ST.EXECUTIONS_DELTA as PHYSICAL_WRITE_BYTES_DELTA,
        ST.FETCHES_DELTA/ST.EXECUTIONS_DELTA as FETCHES_DELTA,
        ST.SORTS_DELTA/ST.EXECUTIONS_DELTA as SORTS_DELTA,
        ST.ROWS_PROCESSED_DELTA/ST.EXECUTIONS_DELTA as ROWS_PROCESSED_DELTA
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s, SYS.WRH$_OSSTAT ost, SYS.WRH$_OSSTAT_NAME osn
where s.dbid=3158406466 and S.INSTANCE_NUMBER=1 and S.snap_id between 33204 and 33336
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and S.DBID=ost.dbid and S.INSTANCE_NUMBER=ost.INSTANCE_NUMBER and s.snap_id=ost.snap_id
  and OST.STAT_ID=OSN.STAT_ID and OST.DBID=OSN.DBID
  and ST.sql_id='ddqu5vmxdsyxn'
  and ST.EXECUTIONS_DELTA > 0
  and OSN.STAT_NAME='LOAD'
  )
order by SNAP_ID;


-- Variant with sys_load
create or replace view mining_data_build_v
as
SELECT  sqlstat.snap_id AS snap_id,
        --systat.snap_time AS snap_time,
        Round(sqlstat.ELAPSED_TIME_DELTA,2) AS ELAPSED_TIME_DELTA,
        sqlstat.ROWS_PROCESSED_DELTA AS ROWS_PROCESSED,
        Nvl(Round(systat.value_diff/(3600*Power(10,6)),2),5) AS AAS
FROM
(
select  S.SNAP_ID,
        ST.ELAPSED_TIME_DELTA/ST.EXECUTIONS_DELTA as ELAPSED_TIME_DELTA,
        ST.ROWS_PROCESSED_DELTA/ST.EXECUTIONS_DELTA as ROWS_PROCESSED_DELTA
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s
where s.dbid=3158406466 and S.INSTANCE_NUMBER=1 and S.snap_id between 32579 and 33204 --33336
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and ST.sql_id='ddqu5vmxdsyxn'
  and ST.EXECUTIONS_DELTA > 0
) sqlstat,
(
WITH local_data AS (
SELECT  s.snap_id,
        s.begin_interval_time AS snap_time,
        ST.VALUE as stat_value
FROM SYS.wrm$_snapshot s, SYS.WRH$_SYS_TIME_MODEL st, SYS.WRH$_STAT_NAME tmn
where s.dbid=3158406466 and S.INSTANCE_NUMBER=1 and S.snap_id between 32579 and 33204 --33336
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  AND tmn.dbid=s.dbid
  AND ST.STAT_ID=TMN.STAT_ID AND tmn.stat_name='DB time'
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1)
) systat
WHERE sqlstat.snap_id=systat.snap_id;



drop view mining_data_build_v;

select * from mining_data_build_v;


select  snap_id,
        ELAPSED_TIME_DELTA,
        ( aas*645405.022700686 + ROWS_PROCESSED*3249655.11559709 + 62279070.2001926 ) as pred_value
from (

SELECT  sqlstat.snap_id AS snap_id,
        --systat.snap_time AS snap_time,
        Round(sqlstat.ELAPSED_TIME_DELTA,2) AS ELAPSED_TIME_DELTA,
        sqlstat.ROWS_PROCESSED_DELTA AS ROWS_PROCESSED,
        Nvl(Round(systat.value_diff/(3600*Power(10,6)),2),5) AS AAS
FROM
(
select  S.SNAP_ID,
        ST.ELAPSED_TIME_DELTA/ST.EXECUTIONS_DELTA as ELAPSED_TIME_DELTA,
        ST.ROWS_PROCESSED_DELTA/ST.EXECUTIONS_DELTA as ROWS_PROCESSED_DELTA
from SYS.WRH$_SQLSTAT st, SYS.WRM$_SNAPSHOT s
where s.dbid=3158406466 and S.INSTANCE_NUMBER=1 and S.snap_id between 32579 and 33204 --33336
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  and ST.sql_id='ddqu5vmxdsyxn'
  and ST.EXECUTIONS_DELTA > 0
) sqlstat,
(
WITH local_data AS (
SELECT  s.snap_id,
        s.begin_interval_time AS snap_time,
        ST.VALUE as stat_value
FROM SYS.wrm$_snapshot s, SYS.WRH$_SYS_TIME_MODEL st, SYS.WRH$_STAT_NAME tmn
where s.dbid=3158406466 and S.INSTANCE_NUMBER=1 and S.snap_id between 32579 and 33204 --33336
  and S.DBID=st.dbid and S.INSTANCE_NUMBER=st.INSTANCE_NUMBER and s.snap_id=st.snap_id
  AND tmn.dbid=s.dbid
  AND ST.STAT_ID=TMN.STAT_ID AND tmn.stat_name='DB time'
  ),
b as ( select * from local_data ),
e as ( select * from local_data )
select  e.snap_time as snap_time,
        e.snap_id as snap_id,
        case when (e.stat_value - b.stat_value) < 0 then null else (e.stat_value - b.stat_value) end as value_diff
from b,e
where e.snap_id=(b.snap_id + 1)
) systat
WHERE sqlstat.snap_id=systat.snap_id

  )
order by SNAP_ID;
