select * from dba_temp_files;
select * from dba_data_files t;
select * from v$datafile;
select * from v$tempfile where ts# = (select ts# from v$tablespace where name='RAM_TEMP');
select round(sum(bytes)/1024/1024/1024,2) as temp_size_Gb from v$tempfile where ts# = (select ts# from v$tablespace where name='RAM_TEMP');
select * from v$tempseg_usage t where T.TABLESPACE='RAM_TEMP' order by T.BLOCKS desc;
select * from v$tempseg_usage t where T.SESSION_ADDR='00000008F0FBFCC0' order by T.BLOCKS desc;
select  round(sum(T.BLOCKS)*32768/1024/1024,2) as size_Mb,
        T.SESSION_ADDR
from    v$tempseg_usage t
group by rollup(T.SESSION_ADDR)
order by 1 desc;


select * from v$tempseg_usage t where T.TABLESPACE='RAM_TEMP' order by T.segfile#;
select * from v$tempseg_usage t order by T.TABLESPACE;
select * from v$tempseg_usage t order by T.BLOCKS desc;
select * from v$sort_segment;

select T.SEGTYPE, sum(T.BLOCKS) as data_size
from v$tempseg_usage t
where T.TABLESPACE='RAM_TEMP'
group by T.SEGTYPE
order by 2 desc;

select * from V$TEMPORARY_LOBS;
select t.sql_fulltext from v$sql t where t.sql_id='dctu64hw17wqu';
select (111616*32768)/1024/1024 from dual;
select 6149/60 from dual;
select * from dba_extents t where T.TABLESPACE_NAME='RAM_TEMP';
select * from dba_segments t where T.TABLESPACE_NAME='RAM_TEMP';

