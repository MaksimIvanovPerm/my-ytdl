select 'alter index '||T.OWNER||'.'||T.INDEX_NAME||' rebuild compress online;' 
from dba_indexes t
where T.OWNER not in ('RIAS','DBSNMP','OUTLN','SYS','SYSTEM')
  and T.COMPRESSION!='ENABLED';
  
  
select  round(sum(bytes)/1024/1024/1024,2) as size_gb,
        T.SEGMENT_TYPE
from dba_segments t
where T.OWNER not in ('RIAS','DBSNMP','OUTLN','SYS','SYSTEM')
  and T.SEGMENT_TYPE in ('TABLE','INDEX')
group by T.SEGMENT_TYPE
order by 1 desc;

select * from v$database;

select  T.OWNER||'.'||T.SEGMENT_NAME as object_name,
        round(T.BYTES/1024/1024,2) as size_mb
from dba_segments t
where regexp_like(T.OWNER,'DATA_[A-Z]+')
  and T.SEGMENT_TYPE='TABLE'
order by T.BYTES desc;

select 'alter table '||T.OWNER||'.'||T.TABLE_NAME||' compress for oltp;' as cmd
from dba_tables t
where regexp_like(T.OWNER,'DATA_[A-Z]+')
  and regexp_like(T.TABLE_NAME,'NAT_TRANSLATIONS_M[0-9]?');


