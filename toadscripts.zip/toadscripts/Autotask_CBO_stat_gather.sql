select t.*
from DBA_TAB_STATISTICS t
where T.STATTYPE_LOCKED is not null
  and T.OWNER='EXCELLENT' --T.OWNER not in ('SYS','SYSTEM','SYSMAN','SQLTXPLAIN');

exec DBMS_STATS.UNLOCK_SCHEMA_STATS(ownname=>'EXCELLENT');
select t.owner, count(*)
from DBA_TAB_STATISTICS t
where T.STATTYPE_LOCKED is not null
group by T.OWNER
order by 2 desc;

select *
from dba_jobs t;

select * from DBA_AUTOTASK_CLIENT t;

select * from DBA_AUTOTASK_CLIENT_HISTORY t
where T.CLIENT_NAME='auto optimizer stats collection'
ORDER BY t.window_end_time desc
;

select * from DBA_AUTOTASK_CLIENT_JOB t;
select * from DBA_AUTOTASK_JOB_HISTORY t
where T.CLIENT_NAME='auto optimizer stats collection'
ORDER BY t.job_start_time desc
;

select * from DBA_AUTOTASK_OPERATION t;
select * from DBA_AUTOTASK_SCHEDULE t;

DBA_SCHEDULER_JOB_LOG
DBA_SCHEDULER_JOB_ROLES
DBA_SCHEDULER_JOB_RUN_DETAILS
select * from DBA_SCHEDULER_JOBS t where T.JOB_NAME='ORA$AT_OS_OPT_SY_2482';
select * from SYS.DBA_SCHEDULER_WINDOW_GROUPS t where T.WINDOW_GROUP_NAME='ORA$AT_WGRP_OS';
select * from sys.DBA_SCHEDULER_WINGROUP_MEMBERS t where T.WINDOW_GROUP_NAME='ORA$AT_WGRP_OS';
select *
from sys.dba_SCHEDULER_WINDOWS t
where T.WINDOW_NAME in ( select SWM.WINDOW_NAME from sys.DBA_SCHEDULER_WINGROUP_MEMBERS swm where swm.WINDOW_GROUP_NAME='ORA$AT_WGRP_OS' )
order by T.WINDOW_NAME;

update RIAS.MONITORING_CONFIG t
set t.str='0'
where t.ns='cbo_stat' and t.name='control';
select *
from RIAS.MONITORING_CONFIG t
where t.ns='cbo_stat' and t.name='control';
commit;
-- control    cbo_stat    ������(0)/����������(1) �� ������ �������� ������� ����������    2        0

-- Global Prefs.
SELECT 'DEGREE: '||DBMS_STATS.GET_PREFS('DEGREE') FROM dual
union all
SELECT 'ESTIMATE_PERCENT: '||DBMS_STATS.GET_PREFS('ESTIMATE_PERCENT') FROM dual
union all
SELECT 'METHOD_OPT: '||DBMS_STATS.GET_PREFS('METHOD_OPT') FROM dual
union all
SELECT 'NO_INVALIDATE: '||DBMS_STATS.GET_PREFS('NO_INVALIDATE') FROM dual
union all
SELECT 'GRANULARITY: '||DBMS_STATS.GET_PREFS('GRANULARITY') FROM dual
union all
SELECT 'PUBLISH: '||DBMS_STATS.GET_PREFS('PUBLISH') FROM dual
union all
SELECT 'INCREMENTAL: '||DBMS_STATS.GET_PREFS('INCREMENTAL') FROM dual
union all
SELECT 'STALE_PERCENT: '||DBMS_STATS.GET_PREFS('STALE_PERCENT') FROM dual;

BEGIN
  --dbms_auto_task_admin.disable(client_name => 'auto space advisor',operation   => NULL, window_name => NULL);
  --dbms_auto_task_admin.disable(client_name => 'sql tuning advisor',operation   => NULL, window_name => NULL);
  dbms_auto_task_admin.disable(client_name => 'auto optimizer stats collection',operation   => NULL, window_name => NULL);
END;
/


BEGIN
  dbms_auto_task_admin.disable(client_name => 'auto space advisor',operation   => NULL, window_name => NULL);
  dbms_auto_task_admin.disable(client_name => 'sql tuning advisor',operation   => NULL, window_name => NULL);
  dbms_auto_task_admin.enable(client_name => 'auto optimizer stats collection',operation   => NULL, window_name => NULL);
END;
/

select client_name,status from Dba_Autotask_Client;

alter system set resource_manager_plan='FORCE:' scope=both;

COMMIT;

exec DBMS_STATS.CREATE_STAT_TABLE('SYSTEM','STATTB_20190611','SYSAUX');
exec DBMS_STATS.EXPORT_TABLE_STATS('ESPP','T_BUSINESS_OPERATION',stattab=>'STATTB_20190611',statid=>'qqq',cascade=>TRUE,statown=>'SYSTEM',stat_category=>'OBJECT_STATS');
exec DBMS_STATS.DELETE_TABLE_STATS('ESPP','T_BUSINESS_OPERATION',cascade_parts=>TRUE,cascade_columns=>TRUE,cascade_indexes=>TRUE);
exec DBMS_STATS.IMPORT_TABLE_STATS(ownname=>'ESPP',tabname=>'T_BUSINESS_OPERATION',stattab=>'STATTB_20190611',statid=>'QQQ',cascade=>TRUE,statown=>'SYSTEM');

SELECT *
FROM sys.dba_tab_statistics t
WHERE t.owner='ESPP'
  AND t.table_name='T_BUSINESS_OPERATION'
;

SELECT *
FROM sys.DBA_TAB_STAT_PREFS t
WHERE t.owner='ESPP'
  AND t.table_name='T_BUSINESS_OPERATION'
;

SELECT *
FROM sys.DBA_TAB_STATS_HISTORY t
WHERE t.owner='ESPP'
  AND t.table_name='T_BUSINESS_OPERATION'
;
