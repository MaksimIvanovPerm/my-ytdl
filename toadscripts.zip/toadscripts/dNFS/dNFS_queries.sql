SELECT * FROM V$DNFS_CHANNELS t
;

SELECT * FROM V$DNFS_FILES t
;

SELECT * FROM V$DNFS_SERVERS t
;

SELECT p.spid, p.pname, t.*
FROM V$DNFS_STATS t, sys.v_$process p
WHERE t.pnum=p.pid
;

SELECT * FROM sys.v_$process p
;

SELECT * FROM V$NFS_CLIENTS t
;

SELECT * FROM V$NFS_LOCKS t
;

SELECT * FROM V$NFS_OPEN_FILES t
;

