begin
 EXECUTE IMMEDIATE 'drop table t1 purge';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

begin
 EXECUTE IMMEDIATE 'drop table t2 purge';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

begin
 EXECUTE IMMEDIATE 'drop table t3 purge';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

define rows_count="10000"
CREATE TABLE t1 (id NUMBER primary key, attr1 NUMBER);
DECLARE
 v_count NUMBER := &&rows_count;
BEGIN
 FOR i IN 1..v_count
 LOOP
  INSERT INTO t1 VALUES(i,Abs(Dbms_Random.random));
 END LOOP;
 COMMIT;
END;
/


CREATE TABLE t2 (id NUMBER, attr1 NUMBER, attr2 DATE, p_id NUMBER);
select p.spid, s.sid||','||s.serial#||' '||s.username||' '||s.program||' '||s.machine||' '||s.action
from v$session s, v$process p
where s.status='ACTIVE' and s.type='USER'
  and s.paddr=p.addr;

DECLARE
 v_count NUMBER := &&rows_count;
 v_up_lim NUMBER := 2000000;
 v_id    NUMBER := 1;
 j       NUMBER;
 k       NUMBER;
 k_max   NUMBER;
BEGIN
 SELECT Max(id)+1
 INTO k_max
 FROM t1;

 FOR i IN (SELECT id FROM t1 ORDER BY id)
 LOOP
  --k := Mod(Abs(Dbms_Random.random),i.id)+1;
  k:=Trunc( v_up_lim/Power((k_max-i.id),2) );
  IF k<1
  THEN
   k:=1;
  END if;
  Dbms_Application_Info.set_action('i: '||i.id||'; k: '||k);
  FOR j IN 1..k
  loop
   INSERT INTO t2 VALUES(v_id, Abs(Dbms_Random.random), SYSDATE, i.id);
   v_id := v_id+1;
  END LOOP;
 END LOOP;
 COMMIT;
END;
/

ALTER TABLE t2 ADD CONSTRAINT t2_pk_id primary KEY (id);
ALTER TABLE t2 ADD CONSTRAINT t2_fk_to_t1_id FOREIGN KEY (p_id) REFERENCES t1(id);
CREATE INDEX t2_idx_fk ON t2(p_id);


CREATE TABLE t3 (id NUMBER, attr1 NUMBER, attr2 DATE, p_id NUMBER);
DECLARE
 v_count NUMBER := &&rows_count;
 v_up_lim NUMBER := 2000000;
 v_id    NUMBER := 1;
 j       NUMBER;
 k       NUMBER;
 k_max   NUMBER;
BEGIN
 SELECT Max(id)+1
 INTO k_max
 FROM t1;

 FOR i IN (SELECT id FROM t1 ORDER BY id)
 LOOP
  --k := Mod(Abs(Dbms_Random.random),i.id)+1;
  k:=Trunc( v_up_lim/Power((k_max-i.id),2) );
  IF k<1
  THEN
   k:=1;
  END if;
  Dbms_Application_Info.set_action('i: '||i.id||'; k: '||k);
  FOR j IN 1..k
  loop
   INSERT INTO t3 VALUES(v_id, Abs(Dbms_Random.random), SYSDATE, i.id);
   v_id := v_id+1;
  END LOOP;
 END LOOP;
 COMMIT;
END;
/

/*UPDATE t2 SET p_id=&&rows_count WHERE p_id=(&&rows_count-1);
COMMIT;
UPDATE t2 SET p_id=&&rows_count WHERE p_id=(&&rows_count-1);
COMMIT;*/

ALTER TABLE t3 ADD CONSTRAINT t3_pk_id primary KEY (id);
ALTER TABLE t3 ADD CONSTRAINT t3_fk_to_t1_id FOREIGN KEY (p_id) REFERENCES t1(id);
CREATE INDEX t3_idx_fk ON t3(p_id);



SELECT Count(id) FROM t2 t;
SELECT Count(id), Count(DISTINCT p_id) FROM t3 t;
SELECT Count(*), t.p_id
FROM SYSTEM.t2 t
GROUP BY t.p_id
ORDER BY 1 desc;

SELECT Count(*)
FROM (
SELECT *
FROM (SELECT p_id, Avg(attr1) avg_value, min(attr2) AS min_time, max(attr2) AS max_time
FROM t2
WHERE p_id BETWEEN 9000 AND 10000 AND ROWNUM=rownum
GROUP BY p_id) v1,
(SELECT p_id, Avg(attr1) avg_value, min(attr2) AS min_time, max(attr2) AS max_time
FROM t3
WHERE p_id BETWEEN 9000 AND 10000 AND ROWNUM=rownum
GROUP BY p_id) v2,
t1 t
WHERE t.id=v1.p_id AND t.id=v2.p_id
  AND t.id BETWEEN 9000 AND 10000 )
;
SELECT * FROM TABLE(DBMS_XPLAN.display_cursor(FORMAT => 'ALLSTATS LAST'));

set pagesize 0
set newp none
set feedback off
set long 1000000
set longchunksize 1000000
set linesize 1000

var x NUMBER;
var y NUMBER;
alter session set STATISTICS_LEVEL=all;
exec :x :=  9000;
exec :y := 10000;
SELECT Count(*)
FROM (
SELECT /*+ NO_ADAPTIVE_PLAN */ --Round(Avg(t2.attr1),2) avg_value, Round(StdDev(t2.attr1),2) AS std_dev, Min(t2.attr2) begin_time, Max(t2.attr2) end_time,
       t2.attr1, t2.attr2,
       t1.attr1 AS p_attr, rownum
FROM t1, t2
WHERE t1.id=t2.p_id
  AND t1.id between :x AND :y
--GROUP BY t1.attr1
ORDER BY t1.id );
SELECT * FROM TABLE(DBMS_XPLAN.display_cursor(FORMAT => 'ALLSTATS LAST'));



DECLARE
v_x NUMBER;
v_low  NUMBER;
v_high NUMBER;
BEGIN
FOR i IN 1..1000
loop
v_low:=1;
v_high:=1;
loop
v_low := Mod(Abs(Dbms_Random.random),&&rows_count);
v_high := Mod(Abs(Dbms_Random.random),&&rows_count);
EXIT WHEN v_low < v_high;
END LOOP;

SELECT Count(*)
INTO v_x
FROM (
SELECT /*+ NO_ADAPTIVE_PLAN label1 */ t2.attr1, t2.attr2, t1.attr1 AS p_attr, rownum
FROM t1, t2
WHERE t1.id=t2.p_id
  AND t1.id between v_low AND v_high
ORDER BY t1.id );
END LOOP;
END;
/

SELECT /*+ opt_param('optimizer_features_enable','12.1.0')
opt_param('_optimizer_use_feedback','true'),
opt_param('_optimizer_gather_feedback','true')
opt_param('optimizer_mode','all_rows') */
SELECT * FROM TABLE(DBMS_XPLAN.display_cursor(FORMAT => 'advanced ALLSTATS LAST'));

exec :x :=  9997;
exec :y := 10000;
SELECT
t.p_id, Avg(t.attr1) AS stat_val
FROM SYSTEM.t2 t
WHERE t.p_id BETWEEN :x AND :y
GROUP BY t.p_id
ORDER BY t.p_id
;
SELECT * FROM TABLE(DBMS_XPLAN.display_cursor(FORMAT => 'advanced ALLSTATS LAST'));

define v_sql_id="fz9b7yyb9bmd3"
SELECT --t.*
       t.child_number, t.plan_hash_value,
       t.exact_matching_signature, t.force_matching_signature,
       t.is_bind_sensitive, t.is_bind_aware, t.is_shareable,
       t.sql_plan_baseline
FROM sys.v_$sql t
WHERE t.sql_id='&&v_sql_id'
;

SELECT *
FROM sys.v_$sql_shared_cursor t
WHERE t.sql_id='&&v_sql_id'
;


SELECT *
FROM sys.v_$sql_plan t
WHERE t.sql_id='&&v_sql_id'
ORDER BY t.child_number asc
;

SELECT * FROM sys.V_$SQL_CS_STATISTICS t;
SELECT * FROM sys.V_$SQL_CS_SELECTIVITY t WHERE t.sql_id='&&v_sql_id';
SELECT * FROM sys.V_$SQL_CS_HISTOGRAM t WHERE t.sql_id='&&v_sql_id';

DECLARE
 n BINARY_INTEGER;
begin
n:=DBMS_SPM.LOAD_PLANS_FROM_CURSOR_CACHE(sql_id=>'&&v_sql_id', plan_hash_value=>3983573630, enabled => 'no');
Dbms_Output.put_line('sql baseline(s) created: '||n);
END;
/

DECLARE
 n BINARY_INTEGER;
begin
n:=dbms_spm.load_plans_from_cursor_cache(sql_id=>'d1qst8bc01amx', plan_hash_value=>879973834, sql_handle=>'SQL_58da98bf4ada5245');
Dbms_Output.put_line('sql baseline(s) created: '||n);
END;
/


SELECT t.*
FROM sys.DBA_SQL_PLAN_BASELINES t, v$sql s
WHERE s.exact_matching_signature=t.signature
  AND s.sql_id='&&v_sql_id'
;

SELECT *
FROM sys.v_$sql_plan t
;

SELECT *
FROM sys.v_$sql t
WHERE 1=1
  --AND t.sql_plan_baseline='SQL_PLAN_5jqnsrx5dnnk5fb145f58'
  AND t.sql_id='&&v_sql_id'
;

SELECT * FROM TABLE (DBMS_XPLAN.display_sql_plan_baseline (plan_name => 'SQL_PLAN_5jqnsrx5dnnk59b5c9609'));
alter session set OPTIMIZER_USE_SQL_PLAN_BASELINES=true;

alter session set max_dump_file_size = unlimited;
alter session set tracefile_identifier=QQQ;
ALTER SESSION SET EVENTS '10053 trace name context forever, level 1';
alter session set events '10053 trace name context off';
DECLARE
 n BINARY_INTEGER;
begin
n:=DBMS_SPM.DROP_SQL_PLAN_BASELINE(sql_handle=>'SQL_58da98bf4ada5245'); --,plan_name=>'SQL_PLAN_5jqnsrx5dnnk59b5c9609'
Dbms_Output.put_line('sql baseline(s) dropped: '||n);
END;
/


EXEC DBMS_STATS.GATHER_TABLE_STATS(ownname=>'SYSTEM', tabname=>'T1', method_opt=>'for all indexed columns size 256', CASCADE=>true);
EXEC DBMS_STATS.GATHER_TABLE_STATS(ownname=>'SYSTEM', tabname=>'T2', method_opt=>'for all indexed columns size 256', CASCADE=>true);
EXEC DBMS_STATS.GATHER_TABLE_STATS(ownname=>'SYSTEM', tabname=>'T3', method_opt=>'for all indexed columns size 256', CASCADE=>true);
SELECT *
FROM sys.dba_tab_col_statistics t
WHERE t.owner='SYSTEM'
  AND t.table_name='T2'
  AND t.column_name='P_ID'
;

SELECT *
FROM sys.dba_tab_histograms t
WHERE t.owner='SYSTEM'
  AND t.table_name='T2'
  AND t.column_name='P_ID'
;

EXEC DBMS_STATS.DELETE_TABLE_STATS(ownname=>'SYSTEM', tabname=>'T1');
EXEC DBMS_STATS.DELETE_TABLE_STATS(ownname=>'SYSTEM', tabname=>'T2');
