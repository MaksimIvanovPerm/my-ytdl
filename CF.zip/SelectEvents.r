library(RODBC)
db <- odbcConnect("dwh","system","YU8T2XsUeeE80")

v_dbid=2041257920
v_b_snap_id=19751
v_e_snap_id=20098

v_str=paste('SELECT DISTINCT en.event_id 
FROM sys.WRH$_EVENT_NAME en 
WHERE en.wait_class=\'Other\' AND en.dbid=',v_dbid,sep="")
items=sqlQuery(db,v_str,errors=TRUE,believeNRows=FALSE)
head(items)

v_str=paste('SELECT s.snap_id AS snaps FROM SYS.WRM$_SNAPSHOT s WHERE s.dbid=',v_dbid,'
and s.snap_id between ',v_b_snap_id,' and ',v_e_snap_id,' order by s.snap_id',sep="")
snaps=sqlQuery(db,v_str,errors=TRUE,believeNRows=FALSE)

x=NULL
v_count=1
for(i in items$EVENT_ID )
{
print(i)
# i=3940042335
v_str=paste('SELECT se.snap_id as snap_id,  sum(se.time_waited_micro) AS stat_value
FROM sys.WRH$_SYSTEM_EVENT se
WHERE se.event_id=',i,'
and se.dbid=',v_dbid,'
and se.snap_id between ',v_b_snap_id,'
and ',v_e_snap_id,' group by se.snap_id',sep="")
y=sqlQuery(db,v_str,errors=TRUE,believeNRows=FALSE)
z=NULL
z=merge(x=snaps,y=y,by.x="SNAPS",by.y="SNAP_ID",all.x=T)
z$STAT_VALUE[is.na(z$STAT_VALUE)]=0
z=z[order(z$SNAPS, decreasing=F),]
if ( v_count == 1 ) {
 x=data.frame(col1=z$STAT_VALUE)
 colnames(x)[1]=paste(i,sep="")
 }
else {
 x=cbind(x,z$STAT_VALUE)
 colnames(x)[length(colnames(x))]=paste(i,sep="")
}
 v_count=v_count+1
}

x=x[which(apply(x, 2, sd)>0)]
y=x[1,]
y[1,]=0
colnames(y)=colnames(x)
for(i in 2:nrow(x)) {
#i=2
y[i,]=x[i,]-x[i-1,]
 y[i,which(y[i,]<0)]=0
}

v_data_file=paste('/tmp/joined_data2.dat',sep="")
write.table(y,file=v_data_file,quote=T,sep="\t",dec=",",col.names=T, row.names=F)


