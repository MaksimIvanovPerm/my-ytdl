#library(stringr)
#library(RODBC)
library(ROracle)
drv=dbDriver("Oracle")

#db <- odbcConnect("eqmmon","awr_publisher","Dtynbkznjh1_")
#db <- odbcConnect("billing_perm","system","ptvkz4ybrf0")
#db <- odbcConnect("billing_spb","system","Gtnh1Gthdsq0")
#db <- odbcConnect("billing_nsk","system","ptvkz4ybrf_")
#db <- odbcConnect("billing_nn","system","ptvkz4ybrf_")
#db <- odbcConnect("billing_hq","system","XthnNtXnjNfrjt_")
#db <- odbcConnect("billing_chel","system","rbhbk2vbajlbq_")
#db <- odbcConnect("billing_kzn","system","ctvbyfh7_")
#db <- odbcConnect("billing_ryazan","system","gh0bpdtltybtHW5F0")
#db <- odbcConnect("billing_oren","system","rbhbk2vbajlbq0")
#db <- odbcConnect("billing_samara","system","ptvkz4ybrf_")
#db <- odbcConnect("billing_volgograd","system","jhdfnbz40")
#db <- odbcConnect("billing_chelny","system","rbhbk2vbajlbq0")
#db <- odbcConnect("billing_izhevsk","system","rbhbk2vbajlbq_")
#db <- odbcConnect("billing_kirov","system","gh0dblty1t0")
#db <- odbcConnect("espp","system","njEj3tj34pPzsne_")
#db <- odbcConnect("db1_enforta","system","CtrhtnysqCbc!")
#db <- odbcConnect("natstat","system","YjdstUhfgkb1_")
#db <- odbcConnect("genesys","system","VtufGhjtrn1")

#db <- odbcConnect("raddb_penza","system","gh013dtltybt_")
#db <- odbcConnect("raddb_nn","system","YRWTqbf9qXs7Uc0")
#db <- odbcConnect("raddb_spb","system","ghjbpdtltybtvHK4p0")
#db <- odbcConnect("raddb_spb","system","ghjbpdtltybtvHK4p0")
#db <- odbcConnect("raddb_kursk","system","CxqjouLD6K8W0")
#db <- odbcConnect("raddb_saratov","system","YY6aaCqHgfjnxGDdjV_")

#db <- odbcConnect("bi_sa","system","CBXaUapYh7Yg")
#db <- odbcConnect("dwh","system","YU8T2XsUeeE80")
#db <- odbcConnect("interact","system","lehfwrbqghjtrn_")
#db <- odbcConnect("eskk","system","eeFSaTY0o8xVM")

#db <- odbcConnect("preproduction","system","DjnNfrGfhjkm_")
#db <- odbcConnect("hq_dev","system","Fdtycbc2_")
#db <- odbcConnect("perm_dev","system","Fdtycbc1_")


euclid_dist=function(p1,p2,normalize=0,normalizeto=1){
  if (normalize>0)
  {
    p1=normalizeto*(p1/sqrt(sum(p1^2)) )
    p2=normalizeto*(p2/sqrt(sum(p2^2)))
  }
  sqrt(sum((p1 - p2) ^ 2))  
}

v_out_file=paste('/tmp/joined_data2.dat',sep="")
v_dbid=3453375711
v_b_snap_id=27953
v_e_snap_id=27987
v_stat_name="DB_BLOCK_CHANGES_DELTA"

db_user="system"
db_user_pwd="eeFSaTY0o8xVM"
db_tns="eskk"
conn=dbConnect(drv, username = db_user, password = db_user_pwd, dbname = db_tns, stmt_cache=0L)

v_str=paste('alter session set cursor_sharing=force',sep="")
res=dbSendQuery(conn, statement=v_str)


v_str=paste('select  T.SNAP_ID as snap_id, sum(',v_stat_name,') as stat_value
from SYS.WRH$_SEG_STAT t
where T.dbid=',v_dbid,' and T.INSTANCE_NUMBER=1 and T.SNAP_ID between ',v_b_snap_id,' and ',v_e_snap_id,'
group by t.snap_id
order by t.snap_id',sep="")
res=dbSendQuery(conn, statement=v_str, bulk_read=5000L)
y=fetch(res, n = -1)
dbClearResult(res)
y$STAT_VALUE[is.na(y$STAT_VALUE)]=0
head(y)

v_str=paste('SELECT DISTINCT s.obj# obj_id 
from SYS.WRH$_SEG_STAT s
where s.dbid=',v_dbid,' and S.INSTANCE_NUMBER=1 AND S.snap_id between ',v_b_snap_id,' and ',v_e_snap_id, sep="")

v_str=paste('SELECT DISTINCT s.obj# obj_id from SYS.WRH$_SEG_STAT s where s.dbid=',v_dbid, sep="")
res=dbSendQuery(conn, statement=v_str, bulk_read=5000L)
v_obj_id=fetch(res, n = -1)
dbClearResult(res)
head(v_obj_id)

objects=data.frame(obj_id=as.numeric(),metric=as.numeric())
v_count=1
for(i in v_obj_id$OBJ_ID )
{
  print(i, quote=F)
  #i=48819
  v_str=paste('select  T.SNAP_ID as snap_id, T.',v_stat_name,' as OBJ_STAT
from SYS.WRH$_SEG_STAT t
where T.dbid=',v_dbid,'
      and T.INSTANCE_NUMBER=1
      and T.SNAP_ID between ',v_b_snap_id,' and ',v_e_snap_id,'
      and t.obj#=',i,sep="")
res=dbSendQuery(conn, statement=v_str, bulk_read=5000L)
x=fetch(res, n = -1)
dbClearResult(res)
z=NULL
z=merge(x=x,y=y,by.x="SNAP_ID",by.y="SNAP_ID",all.y=TRUE)
z$OBJ_STAT[is.na(z$OBJ_STAT)]=0
objects[v_count,1]=i
objects[v_count,2]=euclid_dist(z$OBJ_STAT, z$STAT_VALUE, normalize=0)
v_count=v_count+1
}
head(objects)
dbDisconnect(conn)

summary(objects$metric)
quantile(objects$metric,0.15,na.rm=T)
z=subset(objects,objects$metric<=quantile(objects$metric,0.05,na.rm=T))
head(z[order(z$metric,na.last = TRUE, decreasing = FALSE),], 20)

options(scipen=10)
write.table(objects,file=v_out_file,quote=T,sep="\t",dec=",",col.names=TRUE, row.names=F, na="")
options(scipen=0)  # restore the default


