library(ROracle)
drv=dbDriver("Oracle")

euclid_dist=function(p1,p2,normalize=0,normalizeto=1){
  if (normalize>0)
  {
    p1=normalizeto*(p1/sqrt(sum(p1^2)) )
    p2=normalizeto*(p2/sqrt(sum(p2^2)))
  }
  sqrt(sum((p1 - p2) ^ 2))
}

v_out_file=paste('/tmp/joined_data2.dat',sep="")

db_user="system"
db_user_pwd="njEj3tj34pPzsne_"
db_tns="espp"
conn=dbConnect(drv, username = db_user, password = db_user_pwd, dbname = db_tns, stmt_cache=0L)

v_str=paste('alter session set cursor_sharing=force',sep="")
res=dbSendQuery(conn, statement=v_str)

v_str=sprintf("SELECT t.datetime AS dt, Sum(t.bytes) AS STAT_VALUE
FROM SYSTEM.segments_size t
GROUP BY t.datetime
ORDER BY t.datetime asc")
res=dbSendQuery(conn, statement=v_str, bulk_read=5000L)
y=fetch(res, n = -1)
dbClearResult(res)
y$STAT_VALUE[is.na(y$STAT_VALUE)]=0
head(y)

v_str=sprintf("SELECT DISTINCT t.owner, t.segment_name 
FROM SYSTEM.segments_size t
WHERE 1=1
  AND NOT regexp_like(t.segment_name,'^BIN\\$.*')
  AND NOT regexp_like(t.segment_name,'^_SYSSMU[0-9]+_[0-9]+\\$*')")
res=dbSendQuery(conn, statement=v_str, bulk_read=5000L)
v_obj_id=fetch(res, n = -1)
dbClearResult(res)
head(v_obj_id)

objects=data.frame(obj_id=as.character(),metric=as.numeric())
v_count=1
for(i in 1:nrow(v_obj_id))
{
  #print( sprintf( "%d %s.%s", i, v_obj_id$OWNER[i], v_obj_id$SEGMENT_NAME[i] ) , quote=F)
  print(i, quote=F)
  #i=48819
  v_str=sprintf("SELECT t.datetime AS dt,
       Sum(t.bytes) AS segstat_value
FROM SYSTEM.segments_size t
WHERE 1=1 
  AND t.owner='%s' AND t.segment_name='%s'
GROUP BY t.datetime
ORDER BY t.datetime asc", v_obj_id$OWNER[i], v_obj_id$SEGMENT_NAME[i])
res=dbSendQuery(conn, statement=v_str, bulk_read=5000L)
x=fetch(res, n = -1)
dbClearResult(res)
z=NULL
z=merge(x=x,y=y,by.x="DT",by.y="DT",all.y=TRUE)
z$SEGSTAT_VALUE[is.na(z$SEGSTAT_VALUE)]=0
objects[v_count,1]=sprintf("%s.%s",v_obj_id$OWNER[i], v_obj_id$SEGMENT_NAME[i])
objects[v_count,2]=euclid_dist(z$STAT_VALUE, z$SEGSTAT_VALUE, normalize=0)
v_count=v_count+1
}
head(objects)
dbDisconnect(conn)

options(scipen=10)
write.table(objects,file=v_out_file,quote=T,sep="\t",dec=",",col.names=TRUE, row.names=F, na="")
options(scipen=0)  # restore the default



